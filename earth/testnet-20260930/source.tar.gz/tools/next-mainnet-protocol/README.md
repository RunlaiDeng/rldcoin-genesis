# Next-mainnet regional protocol candidate

This is an isolated consensus fork, with its own implementation source identity.
It implements actual regional source/destination block validation, signed profile
binding, canonical coupled timing, exact capped fresh issuance, channel protection,
finality, import/fee maturity and native replay. An omitted regional field retains
the existing encoding and timing; an explicit profile changes network identity.
The archived storage candidate and its evidence remain a separate release.

The native tests exercise 10-second reward maturity over 6,000 subsequent blocks,
3,600-second source retargeting and channel dispute/finalization, and independent
600/3,600-second destination import and return policies. Disposable two-node HTTP
tests verify signed regional PoW adoption, mined-block sync and native restart.
An additional adopted-mode fixture signs source finality, imports to a distinct
regional destination, validates return receipts and recovers the native store.
These use private disposable directories and known test genesis validators. They
do not attest independence, physical delay, production capacity or safe mining.

The fresh-genesis profile only accepts zero predecessor issuance height. A separate
native migration capability authenticates original signed genesis/adoptions, both
complete replayed ledgers, selected/unselected histories, installed finality and
four canonical signer-lock records. All original validators re-sign exact regional
rules, implementation, cut and mapped assets. It preserves native owners/amounts,
remaining maturity, cumulative work, permanent export retirement, unique imports
and the partial-era remaining reward budget. Pending old exports require frozen
selected proofs and new finality with the remaining old wait. Active old channels
must settle first. Fresh constructors cannot activate inherited assets. This first
600-second migration refuses missing archives for other export destinations.

Ten native migration tests cover asset conservation, forged fully signed cuts,
missing retained forks, duplicate imports, orphan proofs, old-network signatures,
new-network spending, old pending protections, post-migration regular exports,
complete private archive replay and durable source/destination recovery. Recovery
refuses changed inventories, missing canonical signer locks and deleted or foreign
migration authorization. The archive writer never overwrites an existing directory;
its reader checks the accepted migration ID and replays all native retained blocks.

Two migrated-process tests launch actual source/destination nodes, synchronize mined
branches and finality, import a pending old export, verify a new return receipt,
check spendable balances and restart both ledgers. They also refuse wrong acceptance,
missing locks and non-loopback listeners before creating ledger directories. All
fixture assets and validator secrets are disposable. The prior 16 runtime tests
continue to cover regional fresh genesis and storage compatibility.

Filesystem signing/retirement ceremony, inherited old receipt and client/wallet
continuity, new resource capacity and independent production qualification remain
release requirements.
Arithmetic remaining issuance alone cannot authorize migration. No service switch is performed;
no test genesis, balances, low difficulty or fixture signatures authorize mainnet.

## Exact source verification

The manifest commits the complete named Rust implementation, lockfile and protocol
specification. The deterministic archive contains those inputs and the independent
verifier. Extract into an empty directory, then run:

```
python3 tools/implementation-source/verify.py --root . \
  --manifest /absolute/source-manifest.json --expected-commitment EXACT_MANIFEST_COMMITMENT
cargo test --release --locked -p rld-pow -p rld-value-successor --lib --test runtime --test migrated_runtime -- --test-threads=2
cargo clippy --release --locked --workspace --all-targets -- -D warnings
cargo build --release --locked -p rld-cli --bin rld-genesis
./target/release/rld-genesis implementation-source > embedded-source.json
```

Compare the complete embedded manifest with source-manifest.json. Source identity
is not a binary attestation, independent audit or an adoption signature. All
successful platform runs must name the exact archived source and tested commit.

## Private migrated process startup

After independently preparing and accepting the complete signed migration archive,
use private local paths and distinct source mirror directories:

```
rld-earth-node run-migrated --migration-archive /private/full-archive \
  --accept-migration EXACT_MIGRATION_ID --data-dir /private/new-source \
  --listen 127.0.0.1:48300
rld-earth-destination-node run-migrated --migration-archive /private/full-archive \
  --accept-migration EXACT_MIGRATION_ID --source-data-dir /private/destination-source \
  --source-node http://127.0.0.1:48300 --data-dir /private/new-destination \
  --listen 127.0.0.1:48310
```

Status includes the explicit `migration_id` and signed `regional_timing`. Existing
adopted-mode HTTP routes are retained for transport compatibility; their presence
alone is not an independently accepted migration or wallet continuity evidence.
Archive creation currently requires the native verified capability API; a durable
irreversible operator signing/retirement workflow is not yet supplied. Do not copy
these disposable fixture commands into a production service configuration.
