#!/usr/bin/env python3
"""Freeze the isolated next-mainnet implementation without overwriting a release."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--base', required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location('implementation', root/'tools/implementation-source/verify.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
inventory = module.capture(root)
(out/'source-manifest.json').write_text(json.dumps(inventory, indent=2)+'\n')
extras = ['tools/implementation-source/verify.py', 'tools/next-mainnet-protocol/README.md', 'tools/next-mainnet-protocol/package.py', 'AGENTS.md', 'LICENSE']
with (out/'source.tar.gz').open('wb') as file, gzip.GzipFile(fileobj=file, mode='wb', mtime=0, filename='') as compressed, tarfile.open(fileobj=compressed, mode='w|') as archive:
    for name in sorted({entry['path'] for entry in inventory['files']} | set(extras)):
        path = root/name
        assert path.is_file() and not path.is_symlink(), name
        data = path.read_bytes()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
        archive.addfile(entry, io.BytesIO(data))
(out/'README.md').write_bytes((root/'tools/next-mainnet-protocol/README.md').read_bytes())
# New implementation inputs must be staged; the explicit baseline survives commits.
patch = subprocess.run(['git', 'diff', args.base, '--', *module.ROOTS], cwd=root, capture_output=True, check=True).stdout
(out/'implementation.patch').write_bytes(patch)
files = ['source.tar.gz', 'source-manifest.json', 'README.md', 'implementation.patch']
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256((out/name).read_bytes()).hexdigest()}  {name}\n' for name in files))
print(json.dumps(dict(implementation_source=inventory['commitment'], files=files, production_authorized=False)))
