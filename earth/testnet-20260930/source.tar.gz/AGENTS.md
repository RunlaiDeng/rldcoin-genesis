# Next-mainnet protocol research

This checkout is the isolated protocol fork for NEXT-MAINNET. Its changes require a new source identity; never claim the frozen 9acf9472 candidate authorizes them. Keep the old candidate and its archives reproducible in the other checkout.

The user asked to focus on NEXT-MAINNET and stop inspecting current production. Use disposable signed test genesis and private fixture data for development. Do not switch live services or manufacture production authorization from public test keys.

Bind regional parameters to immutable signed contexts and validate coupled windows and exact capped emission. Node execution and native replay must enforce the parameters. Keep current-era remaining issuance and already emitted value; destination has no native issuance. Test-parameter arithmetic is not full capacity or PoW security qualification.

Asset migration must preserve both native histories, roots, finality and signer locks, existing maturity/protection, source export retirement and destination unique imports. Do not infer an asset import authorization from a snapshot or a mathematical schedule. Record incomplete node, migration, resource and external gates accurately.
