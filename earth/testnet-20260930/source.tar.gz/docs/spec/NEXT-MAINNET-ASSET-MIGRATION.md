# First native dual-ledger regional asset migration

Migration requires original authenticated genesis, PoW/value adoption, destination
authorization, complete replayed retained source and destination histories (including
unselected forks), selected roots/work/heads, installed source finality and its four
canonical signer-lock records. All original validators must sign a new, separately
accepted statement binding those inputs, exact new implementation/specification,
regional timing, asset maps and remaining issuance. Claiming a snapshot or source
hash cannot construct a verified migration. This is a first migration from the
original 600-second Earth rules. Every old export route requires its destination
archive; the current first-route implementation refuses missing destination archives.

Old channels must finish their original contest and settlement; active escrows and
challenge reservations prevent activation. All old native assets and records remain
in the frozen legacy replay. Liquid UTXOs keep owner and amount, with namespaced
outpoints. Unexpired maturity converts the remaining old block duration to a ceiling
number of new regional blocks. Source emission starts at the old exact total and
current-era position; only the remaining current-era budget and subsequent capped
eras are mined. Source permanent export retirement remains separate from destination
imported coins and is never refunded. Destination has zero native issuance.

The new source chain, genesis and destination context/genesis separately bind the
signed migration and mapped assets. Fresh-genesis constructors cannot activate a
migrated ledger. Legacy imports retain unique (old source, export) keys. Previously
imported records cannot create another coin. Unimported old exports use membership
in a selected frozen legacy checkpoint, the permanently retired export record and
new source finality. Any remaining old 12-inclusion confirmation wait is converted
without shortening its nominal duration; the new finality depth also applies. Old
unselected checkpoints confer no bridge authority. No receipt or elapsed timeout
creates an export refund.

The native state constructors and block execution implement these rules. A private
complete handoff includes original authorization inputs, every retained block,
selected heads, old finality and four canonical signer locks. An independently
accepted migration ID and the exact current implementation are mandatory. Recovery
replays both native histories in bounded disk-backed temporary workspaces, verifies
all signed roots and histories and reconstructs the capability. Neither an unsigned
inventory count nor a cached state authorizes assets. Partial, extra, noncanonical,
linked or missing records are refused. A shared archive lease remains held while
source and destination processes operate; archive publication is immutable and never
overwrites an existing directory.

Migrated source and destination stores durably bind the canonical authorization
before creating their anchors. Existing migrated stores require the same explicit
capability; missing authorization is refused rather than regenerated. Native block,
submitted-command, checkpoint and finality recovery remain enforced. Both loopback
nodes expose `run-migrated` with the complete private archive and explicit migration
ID. They use the signed new regional timing and native ledger, retain the archive
lease, synchronize mined branches and source finality, and recover after restart.
The destination uses a separate locally replayed source store and verifies the
remote exact migration identity. No process loads a ledger snapshot as authority.
The inherited old canonical lock records remain frozen historical inputs; this does
not implement an irreversible operational retirement/signing ceremony.

This specification does not certify custody, physical propagation, operator
independence, resource capacity or production timing. Filesystem retirement/signing
ceremony, client/wallet pending state continuity, inherited old receipt verification
and final coordinated service replacement require separate evidence.
Production adoption excludes test genesis, public fixture secrets and low-difficulty
fixtures. An isolated signed fixture is not a production migration.
