# Regional timing protocol candidate

This source fork changes consensus identity and is not authorized by the frozen
storage candidate. The signed source adoption and hashed source context include
the complete canonical regional timing parameters. Destination context and its
genesis independently commit the destination parameters. An omitted field keeps
the legacy 600-second encoding/rules; an explicit profile has a separate identity.

Each whole-second interval in 1–3600 derives the coinbase/fee maturity, channel
contest, issuance era, source finality, destination import maturity, return
confirmation policy, retarget count/span and timestamp median window. These
parameters are indivisible. Source and destination header validation uses its
own committed target interval, retarget ancestry and median history.

Fresh regional test genesis starts with zero assets and no previous issuance
height. Rewards allocate one half of the remaining capped supply per derived
era using exact quotient/remainder arithmetic. Source blocks and replay enforce
the same distribution. Destination has no native reward. Migration of existing
assets and partial-era issuance is a distinct activation path; setting a new
genesis profile cannot import an old balance or reset old issuance.

New source channel contest deadlines, miner fee maturity and native checkpoints
use the source profile. Party payouts remain spendable at the settlement block. Source-enforced finality uses its derived inclusion depth.
Destination imports use destination maturity; adoption-bound imports must satisfy
the source's finality depth even when regional intervals differ. Restoring an
auxiliary checkpoint obtains rules from the locally replayed context, not file
claims. All asset records remain subject to native validation and conservation.

The nominal durations describe target expectations; PoW variance, actual work,
fork rate and propagation safety still require qualification. A profile selects
neither safe production seconds nor production adoption. Test genesis, public
fixture keys and balances are excluded from production. Existing assets, old
contest protection, complete dual-chain histories, permanent export locks,
unique imports, finality and signer locks require the complete migration protocol.
