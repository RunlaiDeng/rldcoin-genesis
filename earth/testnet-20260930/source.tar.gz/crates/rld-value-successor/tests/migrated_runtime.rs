//! Disposable, signed native asset migration through real source/destination
//! processes. Public fixture validators never authorize production assets.
use ed25519_dalek::SigningKey;
use rld_core::{generate_identity, sign_bytes, AdmissionHash32 as Hash, Amount};
use rld_cross_region::{
    value::{ExportCommand, ExportIntent},
    ProofBundle,
};
use rld_pow::{
    target_limit,
    transition::{self, Adoption, Approval},
    Chain, OutPoint,
};
use rld_value_successor::{
    adoption::{EarthSuccessorAdoption, EarthSuccessorAdoptionStatement},
    chain::{
        self,
        finality::{FinalityCertificate, FinalityStatement},
        CandidateChain, ObservationPolicy,
    },
    destination::pow::{
        self,
        authorization::{
            DestinationGenesisAuthorization, DestinationGenesisAuthorizationStatement,
        },
    },
    migration::{
        self, archive::VerifiedArchive, Authorization, LegacyInputs, LegacyPins, LegacyReplay,
        Options, SignerLock, Statement, VerifiedSignerLocks,
    },
    transition::TransitionPreview,
};
use sha2::{Digest, Sha256};
use std::{
    path::PathBuf,
    process::{Child, Command, Stdio},
    time::{Duration, SystemTime, UNIX_EPOCH},
};
fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs()
}
fn approvals(bytes: &[u8]) -> Vec<Approval> {
    let mut values = (2..=5)
        .map(|seed| {
            let key = SigningKey::from_bytes(&[seed; 32]);
            Approval {
                public_key: hex::encode(key.verifying_key().to_bytes()),
                signature: sign_bytes(&hex::encode([seed; 32]), bytes).unwrap(),
            }
        })
        .collect::<Vec<_>>();
    values.sort_by(|a, b| a.public_key.cmp(&b.public_key));
    values
}
fn certificate(source: &CandidateChain, adoption: Hash, block: Hash) -> FinalityCertificate {
    let statement = FinalityStatement::from_chain(source, adoption, block, None).unwrap();
    FinalityCertificate {
        approvals: approvals(&statement.signing_bytes().unwrap()),
        statement,
    }
}
fn source_block(
    source: &mut CandidateChain,
    miner: &str,
    commands: Vec<chain::Command>,
    start: u64,
) -> chain::Block {
    let timestamp = start + (source.height() as u64 + 1) * source.timing().seconds;
    let mut block = source.template(miner.into(), timestamp, commands).unwrap();
    while !chain::mine_batch(&mut block, 10000).unwrap() {}
    source.accept(block.clone(), now()).unwrap();
    block
}
struct Fixture {
    root: PathBuf,
    migration: migration::VerifiedMigration,
    pending: ProofBundle,
    recipient: String,
    miner: String,
    children: Vec<Child>,
}
impl Drop for Fixture {
    fn drop(&mut self) {
        for p in &mut self.children {
            let _ = p.kill();
            let _ = p.wait();
        }
        if !std::thread::panicking() {
            let _ = std::fs::remove_dir_all(&self.root);
        } else {
            eprintln!("migrated process fixture retained: {}", self.root.display());
        }
    }
}
impl Fixture {
    fn new() -> Self {
        let root = std::env::temp_dir().join(format!(
            "rld-migrated-runtime-{}",
            generate_identity().public_key
        ));
        std::fs::create_dir(&root).unwrap();
        let genesis = include_bytes!("../../../vectors/m0-genesis-v3/manifest.json");
        let history = b"[]";
        let manifest = rld_core::M0GenesisManifestFile::decode_json(genesis).unwrap();
        let pin = Hash::from_hex(manifest.manifest_sha256()).unwrap();
        let start = now() - 100000;
        let statement = transition::draft(genesis, history, pin, target_limit(), start).unwrap();
        let pow = Adoption {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        let v1 = Chain::new(
            pow.verify(genesis, history, pin, pow.statement.id().unwrap())
                .unwrap(),
        )
        .unwrap();
        let origin = pow.statement.implementation_source_sha256;
        let preview = TransitionPreview::from_replayed_v1(&v1, origin).unwrap();
        let statement =
            EarthSuccessorAdoptionStatement::from_replayed_fresh_chain(&v1, &preview).unwrap();
        let earth = EarthSuccessorAdoption {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        let owner = generate_identity();
        let recipient = generate_identity();
        let mut source = CandidateChain::from_replayed_pow_chain(&v1).unwrap();
        let context = pow::Context {
            chain_id: Hash([91; 32]),
            source_policy: ObservationPolicy {
                source_chain_id: source.chain_id(),
                accepted_v1_tip: v1.tip(),
                minimum_confirmations: 12,
                minimum_cumulative_work: rld_core::header_work(target_limit()),
            },
            started_at: start,
            initial_target: target_limit(),
            regional: None,
            migration: None,
            source_finality: Some(pow::SourceFinalityTrust {
                earth_adoption_id: earth.statement.id().unwrap(),
                validator_keys: pow.approvals.iter().map(|a| a.public_key.clone()).collect(),
            }),
        };
        let signer = generate_identity();
        let statement =
            DestinationGenesisAuthorizationStatement::from_context(&context, &preview).unwrap();
        let authorization = DestinationGenesisAuthorization {
            signature: sign_bytes(&signer.secret_key, &statement.signing_bytes().unwrap()).unwrap(),
            signer_public_key: signer.public_key.clone(),
            statement,
        };
        let mut destination = pow::DestinationPowChain::new(context.clone()).unwrap();
        let mut coins = Vec::new();
        while source.height() < 101 {
            let b = source_block(&mut source, &owner.public_key, vec![], start);
            if coins.len() < 2 {
                let mut bytes = b"RLD-EARTH-UNIFIED-SUCCESSOR-COINBASE\0".to_vec();
                bytes.extend(b.header.chain_id.0);
                bytes.extend(b.header.parent.0);
                bytes.extend(b.header.height.to_be_bytes());
                bytes.extend(hex::decode(&b.header.miner).unwrap());
                bytes.extend(b.header.commands_root.0);
                coins.push(OutPoint {
                    transaction: Hash(Sha256::digest(bytes).into()),
                    index: 0,
                });
            }
        }
        let mut exports = Vec::new();
        for point in coins {
            let coin = source.state().coin(&point).unwrap();
            let intent = ExportIntent {
                source_chain_id: source.chain_id(),
                destination_chain_id: context.chain_id,
                input: point,
                owner: owner.public_key.clone(),
                recipient: recipient.public_key.clone(),
                amount: Amount(1000),
                source_fee: Amount(1),
                destination_fee: Amount(10),
                change: Amount(coin.output.amount.0 - 1001),
                valid_through_height: 130,
            };
            let id = intent.id().unwrap();
            let command = ExportCommand {
                owner_signature: sign_bytes(&owner.secret_key, &intent.signing_bytes().unwrap())
                    .unwrap(),
                intent,
            };
            let block = source_block(
                &mut source,
                &owner.public_key,
                vec![chain::Command::Export(command)],
                start,
            );
            exports.push((id, block.header.id().unwrap()));
        }
        while source.height() < 113 {
            source_block(&mut source, &owner.public_key, vec![], start);
        }
        let finality = certificate(&source, earth.statement.id().unwrap(), exports[0].1);
        source.install_finality(exports[0].1).unwrap();
        let imported = source.export_bundle(exports[0].0, exports[0].1).unwrap();
        let pending = source.export_bundle(exports[1].0, exports[1].1).unwrap();
        let mut block = destination
            .template(
                &source,
                owner.public_key.clone(),
                start + 600,
                vec![pow::Command::FinalizedImport {
                    bundle: imported,
                    certificate: finality.clone(),
                }],
            )
            .unwrap();
        while !pow::mine_batch(&mut block, 10000).unwrap() {}
        destination.accept(&source, block, now()).unwrap();
        let pins = LegacyPins {
            manifest: pin,
            pow_adoption: pow.statement.id().unwrap(),
            earth_adoption: earth.statement.id().unwrap(),
            preview: preview.id().unwrap(),
            origin_implementation: origin,
            destination_authorization: authorization.statement.id().unwrap(),
            destination_signer: signer.public_key,
        };
        let legacy = LegacyReplay::verify(LegacyInputs {
            genesis,
            history,
            pow_adoption: &pow,
            earth_adoption: &earth,
            preview: &preview,
            destination_authorization: &authorization,
            v1: &v1,
            source: &source,
            destination: &destination,
            finality: &finality,
            pins: pins.clone(),
        })
        .unwrap();
        let lock = SignerLock {
            source_chain_id: source.chain_id(),
            earth_adoption_id: pins.earth_adoption,
            certificate_id: finality.statement.id().unwrap(),
            height: finality.statement.height,
            block: finality.statement.block,
        };
        let records = pow
            .approvals
            .iter()
            .map(|a| (a.public_key.clone(), serde_json::to_vec(&lock).unwrap()))
            .collect::<Vec<_>>();
        let locks = VerifiedSignerLocks::from_canonical_records(&legacy, &records).unwrap();
        let activation = now() - 12000;
        let statement = Statement::draft(
            &legacy,
            &locks,
            Options {
                timing: rld_regional_rules::TimingRules::new(3600, 600).unwrap(),
                source_started_at: activation,
                destination_started_at: activation,
            },
        )
        .unwrap();
        let signed = Authorization {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        let migration = signed
            .verify(&legacy, &locks, signed.statement.id().unwrap())
            .unwrap();
        migration
            .write_archive(&root.join("archive"), &records)
            .unwrap();
        Self {
            root,
            migration,
            pending,
            recipient: recipient.public_key,
            miner: owner.public_key,
            children: Vec::new(),
        }
    }
    fn launch(
        &mut self,
        name: &str,
        destination: bool,
        source: Option<&str>,
        peer: Option<&str>,
    ) -> String {
        let socket = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let address = socket.local_addr().unwrap();
        drop(socket);
        let binary = if destination {
            env!("CARGO_BIN_EXE_rld-earth-destination-node")
        } else {
            env!("CARGO_BIN_EXE_rld-earth-node")
        };
        let mut command = Command::new(binary);
        command
            .arg("run-migrated")
            .arg("--migration-archive")
            .arg(self.root.join("archive"))
            .args(["--accept-migration", &self.migration.id().unwrap().to_hex()])
            .arg("--data-dir")
            .arg(self.root.join(name))
            .args(["--listen", &address.to_string()]);
        if destination {
            command
                .arg("--source-data-dir")
                .arg(self.root.join(format!("{name}-source")))
                .args(["--source-node", source.unwrap()]);
        }
        if let Some(peer) = peer {
            command.args(["--peer", peer]);
        }
        let log = std::fs::File::create(self.root.join(format!("{name}.log"))).unwrap();
        self.children.push(
            command
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(log)
                .spawn()
                .unwrap(),
        );
        format!("http://{address}")
    }
    fn stop(&mut self, index: usize) {
        let id = self.children[index].id();
        assert!(Command::new("kill")
            .args(["-TERM", &id.to_string()])
            .status()
            .unwrap()
            .success());
        assert!(self.children[index].wait().unwrap().success());
    }
}
async fn state(client: &reqwest::Client, url: &str, height: u128) -> serde_json::Value {
    for _ in 0..200 {
        if let Ok(response) = client.get(url).send().await {
            if response.status().is_success() {
                let value = response.json::<serde_json::Value>().await.unwrap();
                if value["height"]
                    .as_str()
                    .and_then(|v| v.parse::<u128>().ok())
                    .is_some_and(|v| v >= height)
                {
                    return value;
                }
            }
        }
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
    panic!("migrated process did not reach height {height}: {url}")
}
async fn post<T: serde::Serialize>(client: &reqwest::Client, url: &str, body: &T) {
    let response = client.post(url).json(body).send().await.unwrap();
    let status = response.status();
    let text = response.text().await.unwrap();
    assert!(status.is_success(), "{url}: {status} {text}");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn signed_migrated_processes_sync_legacy_import_finality_receipt_and_native_restart() {
    let mut f = Fixture::new();
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(3))
        .no_proxy()
        .build()
        .unwrap();
    let id = f.migration.id().unwrap();
    let a = f.launch("source-a", false, None, None);
    let b = f.launch("source-b", false, None, Some(&a));
    let initial = state(&client, &format!("{a}/v1/earth/status"), 0).await;
    assert_eq!(initial["migration_id"], id.to_hex());
    assert_eq!(
        initial["chain_id"],
        f.migration.source_chain_id().unwrap().to_hex()
    );
    assert_eq!(initial["regional_timing"]["seconds"], 3600);
    state(&client, &format!("{b}/v1/earth/status"), 0).await;
    let dst = f.launch("destination-a", true, Some(&a), None);
    let initial_dest = state(&client, &format!("{dst}/v1/earth-destination/status"), 0).await;
    assert_eq!(initial_dest["migration_id"], id.to_hex());
    assert_eq!(initial_dest["imported_total"], "1000");
    assert_eq!(initial_dest["regional_timing"]["seconds"], 600);
    let mut source = CandidateChain::from_verified_migration(&f.migration).unwrap();
    let mut first = Hash::ZERO;
    for n in 1..=3 {
        let block = source_block(
            &mut source,
            &f.miner,
            vec![],
            f.migration.statement().source_started_at,
        );
        if n == 1 {
            first = block.header.id().unwrap();
        }
        post(&client, &format!("{a}/v1/earth/blocks"), &block).await;
    }
    let cert = certificate(&source, id, first);
    source.install_finality(first).unwrap();
    post(&client, &format!("{a}/v1/earth/finality"), &cert).await;
    let mirrored = state(&client, &format!("{b}/v1/earth/status"), 3).await;
    assert_eq!(mirrored["tip"], source.tip().to_hex());
    let destination_b = f.launch("destination-b", true, Some(&a), Some(&dst));
    state(
        &client,
        &format!("{destination_b}/v1/earth-destination/status"),
        0,
    )
    .await;
    let mut destination = pow::DestinationPowChain::from_verified_migration(&f.migration).unwrap();
    // Wait for the destination's locally replayed source to install the exact finality.
    let mut installed = false;
    for _ in 0..100 {
        let v = state(&client, &format!("{dst}/v1/earth-destination/status"), 0).await;
        if v["source_finality_block"] == first.to_hex() {
            installed = true;
            break;
        }
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
    assert!(
        installed,
        "destination did not install migrated source finality"
    );
    let command = pow::Command::LegacyImport {
        bundle: f.pending.clone(),
        certificate: cert.clone(),
    };
    for n in 1..=12 {
        let commands = if n == 1 {
            vec![command.clone()]
        } else {
            vec![]
        };
        let time = f.migration.statement().options.destination_started_at + n * 600;
        let mut block = destination
            .template(&source, f.miner.clone(), time, commands)
            .unwrap();
        while !pow::mine_batch(&mut block, 10000).unwrap() {}
        destination.accept(&source, block.clone(), now()).unwrap();
        post(
            &client,
            &format!("{dst}/v1/earth-destination/blocks"),
            &block,
        )
        .await;
    }
    let remote = state(
        &client,
        &format!("{destination_b}/v1/earth-destination/status"),
        12,
    )
    .await;
    assert_eq!(remote["tip"], destination.tip().to_hex());
    assert_eq!(remote["imported_total"], "2000");
    let policy = pow::receipt::InclusionPolicy {
        destination_chain_id: destination.chain_id(),
        accepted_genesis: destination.genesis(),
        minimum_confirmations: 12,
        minimum_inclusion_work: rld_core::header_work(
            f.migration.statement().destination_initial_target,
        ),
    };
    let receipt = destination
        .observe_import(&source, &f.pending, &policy)
        .unwrap();
    let mut live_receipt = receipt.clone();
    live_receipt.live_rld = true;
    post(
        &client,
        &format!("{dst}/v1/earth-destination/verify-receipt"),
        &serde_json::json!({"bundle":f.pending,"policy":policy,"receipt":live_receipt}),
    )
    .await;
    let balance: serde_json::Value = client
        .get(format!(
            "{dst}/v1/earth-destination/balance/{}",
            f.recipient
        ))
        .send()
        .await
        .unwrap()
        .error_for_status()
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(balance["spendable_runlai"], "1980");
    f.stop(3);
    f.stop(2);
    f.stop(1);
    f.stop(0);
    let restored = VerifiedArchive::open(&f.root.join("archive"), id, now()).unwrap();
    assert_eq!(
        restored.migration().statement().source_retired,
        Amount(2000)
    );
    drop(restored);
    let a = f.launch("source-a", false, None, None);
    let source_after = state(&client, &format!("{a}/v1/earth/status"), 3).await;
    assert_eq!(source_after["tip"], source.tip().to_hex());
    assert_eq!(
        source_after["state_root"],
        source.state().root().unwrap().to_hex()
    );
    let dst = f.launch("destination-a", true, Some(&a), None);
    let after = state(&client, &format!("{dst}/v1/earth-destination/status"), 12).await;
    assert_eq!(after["tip"], destination.tip().to_hex());
    assert_eq!(
        after["state_root"],
        destination.state().root().unwrap().to_hex()
    );
    assert_eq!(after["imported_total"], "2000");
    let response = client
        .post(format!("{dst}/v1/earth-destination/template"))
        .json(&serde_json::json!({"miner":f.miner,"timestamp":now(),"commands":[command]}))
        .send()
        .await
        .unwrap();
    assert!(!response.status().is_success());
}

#[test]
fn migrated_processes_reject_wrong_acceptance_missing_locks_and_public_listeners() {
    let f = Fixture::new();
    let locks = f.root.join("archive/signer-locks");
    let record = std::fs::read_dir(&locks)
        .unwrap()
        .next()
        .unwrap()
        .unwrap()
        .path();
    let bytes = std::fs::read(&record).unwrap();
    for destination in [false, true] {
        for case in ["wrong-acceptance", "missing-lock", "public-listener"] {
            if case == "missing-lock" {
                std::fs::remove_file(&record).unwrap();
            }
            let data = f.root.join(format!("rejected-{destination}-{case}"));
            let source_data = f.root.join(format!("rejected-source-{case}"));
            let accepted = if case == "wrong-acceptance" {
                Hash([99; 32])
            } else {
                f.migration.id().unwrap()
            };
            let binary = if destination {
                env!("CARGO_BIN_EXE_rld-earth-destination-node")
            } else {
                env!("CARGO_BIN_EXE_rld-earth-node")
            };
            let mut command = Command::new(binary);
            command
                .arg("run-migrated")
                .arg("--migration-archive")
                .arg(f.root.join("archive"))
                .args(["--accept-migration", &accepted.to_hex()])
                .arg("--data-dir")
                .arg(&data)
                .args([
                    "--listen",
                    if case == "public-listener" {
                        "0.0.0.0:0"
                    } else {
                        "127.0.0.1:0"
                    },
                ]);
            if destination {
                command
                    .arg("--source-data-dir")
                    .arg(&source_data)
                    .args(["--source-node", "http://127.0.0.1:9"]);
            }
            let mut child = command
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::piped())
                .spawn()
                .unwrap();
            let deadline = std::time::Instant::now() + Duration::from_secs(10);
            while child.try_wait().unwrap().is_none() {
                if std::time::Instant::now() >= deadline {
                    let _ = child.kill();
                    let _ = child.wait();
                    panic!("invalid migrated startup did not terminate: {destination} {case}");
                }
                std::thread::sleep(Duration::from_millis(10));
            }
            let output = child.wait_with_output().unwrap();
            assert!(!output.status.success());
            let message = String::from_utf8(output.stderr).unwrap();
            let expected = match case {
                "wrong-acceptance" => "acceptance",
                "missing-lock" => "signer-lock archive inventory",
                _ => "listener",
            };
            assert!(
                message.contains(expected),
                "{destination} {case}: {message}"
            );
            assert!(
                !data.exists() && !source_data.exists(),
                "rejected startup created a ledger"
            );
            if case == "missing-lock" {
                std::fs::write(&record, &bytes).unwrap();
            }
        }
    }
}
