//! Explicit, retained, low-difficulty qualification workload. Never mainnet.
use crate::{
    chain::{self, storage::CandidateStore, CandidateChain, ObservationPolicy},
    destination::pow::{self, storage::DestinationPowStore},
    *,
};
use rld_core::{generate_identity, sign_bytes, Identity};
use rld_pow::{target_limit, Output, Transfer, BLOCK_SECONDS};
use std::{fs, path::PathBuf, time::Instant};

const START: u64 = 1_000_000;
fn stamp(height: u128) -> u64 {
    START + u64::try_from(height).unwrap() * BLOCK_SECONDS
}
fn source_block(
    store: &mut CandidateStore,
    miner: &Identity,
    commands: Vec<chain::Command>,
) -> chain::Block {
    let height = store.chain().height() + 1;
    let mut block = store
        .chain()
        .template(miner.public_key.clone(), stamp(height), commands)
        .unwrap();
    while !chain::mine_batch(&mut block, 1000).unwrap() {}
    assert!(store.accept(block.clone(), stamp(height)).unwrap());
    block
}
fn consolidation(chain: &CandidateChain, owner: &Identity) -> Vec<chain::Command> {
    let height = chain.height() + 1;
    if !height.is_multiple_of(25) {
        return vec![];
    }
    let inputs: Vec<_> = chain
        .state()
        .coins
        .iter()
        .filter(|(_, c)| c.output.owner == owner.public_key && c.spendable_height <= height)
        .take(32)
        .collect();
    if inputs.len() < 2 {
        return vec![];
    }
    let amount = inputs.iter().map(|(_, c)| c.output.amount.0).sum::<u128>();
    let mut tx = Transfer {
        chain_id: chain.chain_id(),
        owner: owner.public_key.clone(),
        inputs: inputs.iter().map(|(p, _)| (*p).clone()).collect(),
        outputs: vec![Output {
            owner: owner.public_key.clone(),
            amount: Amount(amount - 1),
        }],
        fee: Amount(1),
        valid_through_height: height + 12,
        signature: String::new(),
    };
    tx.signature = sign_bytes(&owner.secret_key, &tx.signing_bytes().unwrap()).unwrap();
    vec![chain::Command::Transfer(tx)]
}

#[test]
#[ignore = "explicit retained active-history stress; needs a new RLD_CAPACITY_OUTPUT directory"]
fn active_history_crosses_halving_reorganizes_and_replays() {
    let count: u128 = std::env::var("RLD_CAPACITY_BLOCKS")
        .unwrap_or_else(|_| "210100".into())
        .parse()
        .unwrap();
    assert!((1000..=250000).contains(&count));
    let root = PathBuf::from(
        std::env::var_os("RLD_CAPACITY_OUTPUT").expect("set a new evidence output path"),
    );
    assert!(root.is_absolute() && !root.exists());
    fs::create_dir_all(root.parent().unwrap()).unwrap();
    fs::create_dir(&root).unwrap();
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&root, fs::Permissions::from_mode(0o700)).unwrap();
    }
    let start = Instant::now();
    let miner = generate_identity();
    let recipient = generate_identity();
    let context = rld_pow::Context {
        network_domain: format!("fixture:storage-qualification:{}", miner.public_key),
        zone_id: "fixture-storage".into(),
        currency_genesis: Hash([1; 32]),
        manifest_pin: Hash([2; 32]),
        transition_id: Hash([3; 32]),
        legacy_height: 0,
        legacy_state_root: Hash([4; 32]),
        started_at: START,
        initial_target: target_limit(),
        regional: None,
    };
    let v1 = rld_pow::Chain::new(context.clone()).unwrap();
    fs::write(
        root.join("context.json"),
        serde_json::to_vec_pretty(&context).unwrap(),
    )
    .unwrap();
    let mut signers: Vec<_> = (0..4).map(|_| generate_identity()).collect();
    signers.sort_by(|a, b| a.public_key.cmp(&b.public_key));
    let keys: Vec<_> = signers.iter().map(|k| k.public_key.clone()).collect();
    let adoption = Hash([44; 32]);
    let mut store = CandidateStore::open_finalized(
        &root.join("source"),
        &v1,
        stamp(count + 1000),
        adoption,
        keys.clone(),
    )
    .unwrap();
    let mut reference = CandidateChain::from_replayed_pow_chain(&v1).unwrap();
    let mut deep_fork = None;
    let mut fork_count = 0u128;
    let mut reference_blocks = 0u128;
    for height in 1..=count {
        if height == count - 11 {
            deep_fork = Some(store.chain().clone());
        }
        let mut sibling = height.is_multiple_of(100).then(|| store.chain().clone());
        let commands = consolidation(store.chain(), &miner);
        let block = source_block(&mut store, &miner, commands);
        if height <= 10_000 {
            reference.accept(block.clone(), stamp(height)).unwrap();
            assert_eq!(reference.tip(), store.chain().tip());
            assert_eq!(
                reference.state().root().unwrap(),
                store.chain().state().root().unwrap()
            );
            reference_blocks += 1;
        }
        if let Some(fork) = sibling.as_mut() {
            let mut block = fork
                .template(miner.public_key.clone(), stamp(height) + 1, vec![])
                .unwrap();
            while !chain::mine_batch(&mut block, 1000).unwrap() {}
            assert!(!store.accept(block.clone(), stamp(height) + 1).unwrap());
            if height <= 10_000 {
                assert!(!reference.accept(block, stamp(height) + 1).unwrap());
            }
            fork_count += 1;
        }
        if height.is_multiple_of(10_000) {
            let (entries, cached, bytes) = store.chain().history_stats();
            assert!(cached <= 256 && bytes <= 4 * 1024 * 1024);
            assert_eq!(
                store.chain().state().totals().unwrap().0 .0,
                rld_pow::cumulative_emission(height)
            );
            let (common, page) = store.chain().sync_page(&[v1.tip()], 8).unwrap();
            assert_eq!(common, v1.tip());
            assert_eq!(page.len(), 8);
            assert_eq!(page[0].header.height, 1);
            let prior = store.chain().selected_block_id(height - 8).unwrap();
            let (common, page) = store.chain().sync_page(&[prior], 8).unwrap();
            assert_eq!(common, prior);
            assert_eq!(page[0].header.parent, prior);
            assert_eq!(
                page.last().unwrap().header.id().unwrap(),
                store.chain().tip()
            );
            eprintln!("source height={height} retained={entries} cached={cached} cache_bytes={bytes} elapsed_s={:.3}", start.elapsed().as_secs_f64());
        }
    }
    drop(reference);
    let cold_start = Instant::now();
    let mut fork = deep_fork.take().unwrap();
    while fork.height() <= count {
        let height = fork.height() + 1;
        let mut block = fork
            .template(miner.public_key.clone(), stamp(height) + 2, vec![])
            .unwrap();
        while !chain::mine_batch(&mut block, 1000).unwrap() {}
        fork.accept(block.clone(), stamp(height) + 2).unwrap();
        store.accept(block, stamp(height) + 2).unwrap();
        fork_count += 1;
    }
    assert_eq!(store.chain().tip(), fork.tip());
    assert_eq!(
        store.chain().state().root().unwrap(),
        fork.state().root().unwrap()
    );
    drop(fork);
    let cold_reorg_seconds = cold_start.elapsed().as_secs_f64();
    let destination_id = Hash([91; 32]);
    let height = store.chain().height() + 1;
    let (input, coin) = store
        .chain()
        .state()
        .coins
        .iter()
        .filter(|(_, c)| c.spendable_height <= height)
        .max_by_key(|(_, c)| c.output.amount.0)
        .unwrap();
    let amount = Amount::from_rld_whole(1).unwrap();
    let intent = rld_cross_region::value::ExportIntent {
        source_chain_id: store.chain().chain_id(),
        destination_chain_id: destination_id,
        input: input.clone(),
        owner: miner.public_key.clone(),
        recipient: recipient.public_key.clone(),
        amount,
        source_fee: Amount(1),
        destination_fee: Amount(10),
        change: Amount(coin.output.amount.0 - amount.0 - 1),
        valid_through_height: height + 12,
    };
    let export_id = intent.id().unwrap();
    let command = rld_cross_region::value::ExportCommand {
        owner_signature: sign_bytes(&miner.secret_key, &intent.signing_bytes().unwrap()).unwrap(),
        intent,
    };
    let export = source_block(&mut store, &miner, vec![chain::Command::Export(command)]);
    let checkpoint = export.header.id().unwrap();
    for _ in 0..11 {
        source_block(&mut store, &miner, vec![]);
    }
    let statement =
        chain::finality::FinalityStatement::from_chain(store.chain(), adoption, checkpoint, None)
            .unwrap();
    let certificate = chain::finality::FinalityCertificate {
        approvals: signers
            .iter()
            .map(|key| rld_pow::transition::Approval {
                public_key: key.public_key.clone(),
                signature: sign_bytes(&key.secret_key, &statement.signing_bytes().unwrap())
                    .unwrap(),
            })
            .collect(),
        statement,
    };
    store.install_finality(certificate.clone()).unwrap();
    let bundle = store.chain().export_bundle(export_id, checkpoint).unwrap();
    let source_policy = ObservationPolicy {
        source_chain_id: store.chain().chain_id(),
        accepted_v1_tip: v1.tip(),
        minimum_confirmations: 12,
        minimum_cumulative_work: certificate.statement.cumulative_work,
    };
    let dest_context = pow::Context {
        chain_id: destination_id,
        source_policy,
        started_at: START,
        initial_target: target_limit(),
        regional: None,
        migration: None,
        source_finality: Some(pow::SourceFinalityTrust {
            earth_adoption_id: adoption,
            validator_keys: keys.clone(),
        }),
    };
    fs::write(
        root.join("destination-context.json"),
        serde_json::to_vec_pretty(&dest_context).unwrap(),
    )
    .unwrap();
    let before_source = serde_json::json!({"tip":store.chain().tip(),"height":store.chain().height().to_string(),"root":store.chain().state().root().unwrap(),"work":store.chain().chainwork(),"totals":store.chain().state().totals().unwrap(),"finalized":store.chain().finalized(),"history":store.chain().history_stats()});
    let source_build_seconds = start.elapsed().as_secs_f64();
    let mut destination = DestinationPowStore::open(
        &root.join("destination"),
        dest_context.clone(),
        store.chain(),
        stamp(count + 1000),
    )
    .unwrap();
    let dest_start = Instant::now();
    let mut dest_fork = None;
    let mut destination_payment = None;
    let mut import_id_bytes = b"RLD-EARTH-DESTINATION-POW-IMPORT-OUTPUT\0".to_vec();
    import_id_bytes.extend(destination_id.0);
    import_id_bytes.extend(bundle.source_chain_id.0);
    import_id_bytes.extend(bundle.export_id.0);
    let import_input = rld_pow::OutPoint {
        transaction: hash(&import_id_bytes),
        index: 0,
    };
    for height in 1..=count {
        // Exercise a real signed import at the end, so the workload covers
        // long empty history plus value, without claiming heavy payment load.
        if height == count - 4 {
            dest_fork = Some(destination.chain().clone());
        }
        let commands = if height == count - 10 {
            vec![pow::Command::FinalizedImport {
                bundle: bundle.clone(),
                certificate: certificate.clone(),
            }]
        } else if height == count - 3 {
            let coin = destination.chain().state().coin(&import_input).unwrap();
            let mut tx = Transfer {
                chain_id: destination_id,
                owner: recipient.public_key.clone(),
                inputs: vec![import_input.clone()],
                outputs: vec![Output {
                    owner: miner.public_key.clone(),
                    amount: Amount(coin.output.amount.0 - 1),
                }],
                fee: Amount(1),
                valid_through_height: height + 12,
                signature: String::new(),
            };
            tx.signature = sign_bytes(&recipient.secret_key, &tx.signing_bytes().unwrap()).unwrap();
            destination_payment = Some(tx.id().unwrap());
            vec![pow::Command::Transfer(tx)]
        } else {
            vec![]
        };
        let mut block = destination
            .template(
                store.chain(),
                miner.public_key.clone(),
                stamp(height),
                commands,
            )
            .unwrap();
        while !pow::mine_batch(&mut block, 1000).unwrap() {}
        assert!(destination
            .accept(store.chain(), block, stamp(height))
            .unwrap());
        if height.is_multiple_of(10_000) {
            let (entries, cached, bytes) = destination.chain().history_stats();
            assert!(cached <= 256 && bytes <= 4 * 1024 * 1024);
            eprintln!("destination height={height} retained={entries} cached={cached} cache_bytes={bytes} elapsed_s={:.3}",dest_start.elapsed().as_secs_f64());
        }
    }
    assert!(destination.chain().state().coin(&import_input).is_none());
    assert!(destination
        .chain()
        .state()
        .coin(&rld_pow::OutPoint {
            transaction: destination_payment.unwrap(),
            index: 0
        })
        .is_some());
    let mut dest_fork = dest_fork.take().unwrap();
    let destination_cold_start = Instant::now();
    while dest_fork.height() <= count {
        let height = dest_fork.height() + 1;
        let mut block = dest_fork
            .template(
                store.chain(),
                miner.public_key.clone(),
                stamp(height) + 2,
                vec![],
            )
            .unwrap();
        while !pow::mine_batch(&mut block, 1000).unwrap() {}
        dest_fork
            .accept(store.chain(), block.clone(), stamp(height) + 2)
            .unwrap();
        destination
            .accept(store.chain(), block, stamp(height) + 2)
            .unwrap();
    }
    assert_eq!(destination.chain().tip(), dest_fork.tip());
    assert_eq!(
        destination.chain().state().root().unwrap(),
        dest_fork.state().root().unwrap()
    );
    assert!(destination.chain().state().coin(&import_input).is_some());
    assert!(destination
        .chain()
        .state()
        .coin(&rld_pow::OutPoint {
            transaction: destination_payment.unwrap(),
            index: 0
        })
        .is_none());
    let destination_cold_reorg_seconds = destination_cold_start.elapsed().as_secs_f64();
    drop(dest_fork);
    assert_eq!(destination.chain().state().imported_total(), amount);
    let before_destination = serde_json::json!({"tip":destination.chain().tip(),"height":destination.chain().height().to_string(),"root":destination.chain().state().root().unwrap(),"work":destination.chain().chainwork(),"imported_total":destination.chain().state().imported_total(),"genesis":destination.chain().genesis(),"history":destination.chain().history_stats()});
    let destination_build_seconds = dest_start.elapsed().as_secs_f64();
    drop(destination);
    drop(store);
    let replay_start = Instant::now();
    let source = CandidateStore::open_finalized(
        &root.join("source"),
        &v1,
        stamp(count + 1000),
        adoption,
        keys,
    )
    .unwrap();
    assert_eq!(
        serde_json::to_value(source.chain().tip()).unwrap(),
        before_source["tip"]
    );
    assert_eq!(
        serde_json::to_value(source.chain().state().root().unwrap()).unwrap(),
        before_source["root"]
    );
    assert_eq!(
        serde_json::to_value(source.chain().chainwork()).unwrap(),
        before_source["work"]
    );
    assert_eq!(source.chain().finalized().unwrap().0, checkpoint);
    let source_replay_seconds = replay_start.elapsed().as_secs_f64();
    let replay_start = Instant::now();
    let destination = DestinationPowStore::open(
        &root.join("destination"),
        dest_context,
        source.chain(),
        stamp(count + 1000),
    )
    .unwrap();
    assert_eq!(
        serde_json::to_value(destination.chain().tip()).unwrap(),
        before_destination["tip"]
    );
    assert_eq!(
        serde_json::to_value(destination.chain().state().root().unwrap()).unwrap(),
        before_destination["root"]
    );
    assert_eq!(
        serde_json::to_value(destination.chain().chainwork()).unwrap(),
        before_destination["work"]
    );
    assert_eq!(destination.chain().state().imported_total(), amount);
    let policy = pow::receipt::InclusionPolicy {
        destination_chain_id: destination_id,
        accepted_genesis: destination.chain().genesis(),
        minimum_confirmations: 2,
        minimum_inclusion_work: rld_core::header_work(target_limit()),
    };
    let receipt = destination
        .chain()
        .observe_import(source.chain(), &bundle, &policy)
        .unwrap();
    let observed = destination
        .chain()
        .verify_import_receipt(source.chain(), &bundle, &policy, &receipt)
        .unwrap();
    assert!(observed.confirmations >= 7);
    let report = serde_json::json!({"result":"PASS","scope":"isolated low-difficulty valid PoW with bounded UTXO consolidation; not production or heavy payment workload","implementation_source":rld_core::implementation_source::IMPLEMENTATION_SOURCE_COMMITMENT,"crossed_200000_selected":count>200000,"requested_blocks_each":count.to_string(),"source":before_source,"destination":before_destination,"source_side_branch_blocks":fork_count.to_string(),"memory_backend_comparison_selected_blocks":reference_blocks.to_string(),"cold_13_block_reorganization_seconds":cold_reorg_seconds,"destination_cold_6_block_reorganization_seconds":destination_cold_reorg_seconds,"mature_destination_payment_then_reorg_verified":true,"source_build_seconds":source_build_seconds,"destination_build_seconds":destination_build_seconds,"source_replay_seconds":source_replay_seconds,"destination_replay_seconds":replay_start.elapsed().as_secs_f64(),"full_native_history_retained":true,"source_finality_replayed":true,"import_receipt":receipt,"confirmed_import":observed.confirmations.to_string(),"production_changed":false,"independently_reviewed":false});
    drop(destination);
    drop(source);
    fs::write(
        root.join("report.json"),
        serde_json::to_vec_pretty(&report).unwrap(),
    )
    .unwrap();
    eprintln!("{}", serde_json::to_string(&report).unwrap());
}
