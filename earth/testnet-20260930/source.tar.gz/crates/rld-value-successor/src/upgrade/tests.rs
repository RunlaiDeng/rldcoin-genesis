use super::*;
use crate::{
    adoption::EarthSuccessorAdoptionStatement,
    chain::{storage::CandidateStore, ObservationPolicy},
    destination::pow::{
        self, authorization::DestinationGenesisAuthorizationStatement, storage::DestinationPowStore,
    },
};
use ed25519_dalek::SigningKey;
use rld_core::{generate_identity, sign_bytes};
use rld_pow::{target_limit, transition};
use std::fs;

fn approvals(bytes: &[u8]) -> Vec<Approval> {
    let mut values: Vec<_> = (2..=5)
        .map(|seed| {
            let key = SigningKey::from_bytes(&[seed; 32]);
            Approval {
                public_key: hex::encode(key.verifying_key().to_bytes()),
                signature: sign_bytes(&hex::encode([seed; 32]), bytes).unwrap(),
            }
        })
        .collect();
    values.sort_by(|a, b| a.public_key.cmp(&b.public_key));
    values
}
struct Fixture {
    genesis: Vec<u8>,
    pow: Adoption,
    earth: EarthSuccessorAdoption,
    v1: Chain,
    preview: TransitionPreview,
    authorization: UpgradeAuthorization,
}
impl Fixture {
    fn new() -> Self {
        Self::with_origin(Hash([29; 32]))
    }
    fn with_origin(origin: Hash) -> Self {
        let genesis = include_bytes!("../../../../vectors/m0-genesis-v3/manifest.json").to_vec();
        let manifest = rld_core::M0GenesisManifestFile::decode_json(&genesis).unwrap();
        let pin = Hash::from_hex(manifest.manifest_sha256()).unwrap();
        let mut statement =
            transition::draft(&genesis, b"[]", pin, target_limit(), 1_000_000).unwrap();
        statement.implementation_source_sha256 = origin;
        let pow = Adoption {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        let v1 = Chain::new(
            pow.verify_with_pinned_release_source(
                &genesis,
                b"[]",
                pin,
                pow.statement.id().unwrap(),
                origin,
            )
            .unwrap(),
        )
        .unwrap();
        let preview = TransitionPreview::from_replayed_v1_with_source(&v1, origin, origin).unwrap();
        let statement =
            EarthSuccessorAdoptionStatement::from_replayed_fresh_chain(&v1, &preview).unwrap();
        let earth = EarthSuccessorAdoption {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        let destination = Context {
            chain_id: Hash([91; 32]),
            source_policy: ObservationPolicy {
                source_chain_id: v1.context.chain_id().unwrap(),
                accepted_v1_tip: v1.tip(),
                minimum_confirmations: 12,
                minimum_cumulative_work: rld_core::header_work(target_limit()),
            },
            started_at: 1_000_000,
            initial_target: target_limit(),
            regional: None,
            migration: None,
            source_finality: Some(pow::SourceFinalityTrust {
                earth_adoption_id: earth.statement.id().unwrap(),
                validator_keys: pow.approvals.iter().map(|a| a.public_key.clone()).collect(),
            }),
        };
        let statement = UpgradeStatement {
            format: FORMAT.into(),
            origin_source_sha256: origin,
            implementation_source_sha256: implementation_source().unwrap(),
            earth_adoption_id: earth.statement.id().unwrap(),
            transition_preview_id: preview.id().unwrap(),
            source_chain_id: v1.context.chain_id().unwrap(),
            v1_tip: v1.tip(),
            storage: STORAGE.into(),
            qualification_evidence_sha256: Hash([77; 32]),
            destinations: vec![destination],
        };
        let authorization = UpgradeAuthorization {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        Self {
            genesis,
            pow,
            earth,
            v1,
            preview,
            authorization,
        }
    }
    fn verify(&self, a: &UpgradeAuthorization) -> Result<VerifiedUpgrade> {
        a.verify(
            &self.genesis,
            b"[]",
            &self.pow,
            &self.earth,
            &self.v1,
            &self.preview,
            self.preview.id()?,
            self.earth.statement.id()?,
            a.statement.id()?,
        )
    }
}
#[test]
fn upgrade_requires_original_trust_exact_source_identity_and_all_signatures() {
    let f = Fixture::new();
    let a = &f.authorization;
    let valid = f.verify(a).unwrap();
    assert_eq!(valid.origin_source(), Hash([29; 32]));
    assert!(f
        .preview
        .verify_for_candidate(&f.v1, Hash([29; 32]), f.preview.id().unwrap())
        .is_err());
    assert!(f
        .earth
        .verify(
            &f.genesis,
            b"[]",
            &f.pow,
            &f.v1,
            &f.preview,
            f.earth.statement.id().unwrap()
        )
        .is_err());
    let mut changed = a.clone();
    changed.approvals.pop();
    assert!(f.verify(&changed).is_err());
    let mut changed = a.clone();
    changed.approvals[0] = changed.approvals[1].clone();
    assert!(f.verify(&changed).is_err());
    let mut changed = a.clone();
    changed.approvals.swap(0, 1);
    assert!(f.verify(&changed).is_err());
    let mut changed = a.clone();
    changed.statement.qualification_evidence_sha256 = Hash([78; 32]);
    assert!(f.verify(&changed).is_err());
    for mutation in 0..6 {
        let mut changed = a.clone();
        match mutation {
            0 => changed.statement.implementation_source_sha256 = Hash([88; 32]),
            1 => changed.statement.origin_source_sha256 = Hash([28; 32]),
            2 => changed.statement.source_chain_id = Hash([88; 32]),
            3 => changed.statement.transition_preview_id = Hash([88; 32]),
            4 => changed.statement.qualification_evidence_sha256 = Hash::ZERO,
            _ => {
                changed.statement.destinations[0]
                    .source_policy
                    .accepted_v1_tip = Hash([88; 32])
            }
        }
        changed.approvals = approvals(&changed.statement.signing_bytes().unwrap());
        assert!(f.verify(&changed).is_err());
    }
    assert!(a
        .verify(
            &f.genesis,
            b"[]",
            &f.pow,
            &f.earth,
            &f.v1,
            &f.preview,
            f.preview.id().unwrap(),
            f.earth.statement.id().unwrap(),
            Hash([88; 32])
        )
        .is_err());
    let mut different = f.preview.clone();
    different.successor_spec_sha256 = Hash([99; 32]);
    assert!(a
        .verify(
            &f.genesis,
            b"[]",
            &f.pow,
            &f.earth,
            &f.v1,
            &different,
            f.preview.id().unwrap(),
            f.earth.statement.id().unwrap(),
            a.statement.id().unwrap()
        )
        .is_err());
}
#[test]
fn compatible_stores_preserve_original_genesis_history_and_require_authorization_on_reopen() {
    let f = Fixture::new();
    let upgrade = f.verify(&f.authorization).unwrap();
    let root = std::env::temp_dir().join(format!(
        "rld-compatible-store-{}",
        generate_identity().public_key
    ));
    let src = root.join("source");
    let dst = root.join("destination");
    let mut source = CandidateStore::open_compatible(&src, &f.v1, 1_100_000, &upgrade).unwrap();
    let miner = generate_identity();
    let mut block = source
        .chain()
        .template(miner.public_key.clone(), 1_000_600, vec![])
        .unwrap();
    while !crate::chain::mine_batch(&mut block, 1000).unwrap() {}
    source.accept(block, 1_100_000).unwrap();
    let source_tip = source.chain().tip();
    let source_root = source.chain().state().root().unwrap();
    let context = f.authorization.statement.destinations[0].clone();
    let original_genesis = context
        .genesis_with_source(upgrade.origin_source())
        .unwrap();
    assert_ne!(original_genesis, context.genesis().unwrap());
    let mut destination = DestinationPowStore::open_compatible(
        &dst,
        context.clone(),
        source.chain(),
        1_100_000,
        &upgrade,
    )
    .unwrap();
    let mut block = destination
        .template(source.chain(), miner.public_key, 1_000_600, vec![])
        .unwrap();
    assert_eq!(block.header.parent, original_genesis);
    while !pow::mine_batch(&mut block, 1000).unwrap() {}
    destination
        .accept(source.chain(), block, 1_100_000)
        .unwrap();
    let destination_tip = destination.chain().tip();
    let anchor = fs::read(src.join("anchor.json")).unwrap();
    let identity = fs::read(dst.join("identity.json")).unwrap();
    drop(destination);
    drop(source);
    assert!(CandidateStore::open_finalized(
        &src,
        &f.v1,
        1_100_000,
        upgrade.earth_adoption_id(),
        upgrade.validator_keys().to_vec()
    )
    .is_err());
    let source = CandidateStore::open_compatible(&src, &f.v1, 1_100_000, &upgrade).unwrap();
    assert_eq!(source.chain().tip(), source_tip);
    assert_eq!(source.chain().state().root().unwrap(), source_root);
    assert!(DestinationPowStore::open(&dst, context.clone(), source.chain(), 1_100_000).is_err());
    let destination = DestinationPowStore::open_compatible(
        &dst,
        context.clone(),
        source.chain(),
        1_100_000,
        &upgrade,
    )
    .unwrap();
    assert_eq!(destination.chain().tip(), destination_tip);
    assert_eq!(destination.chain().genesis(), original_genesis);
    assert_eq!(fs::read(src.join("anchor.json")).unwrap(), anchor);
    assert_eq!(fs::read(dst.join("identity.json")).unwrap(), identity);
    let signer = generate_identity();
    let statement = DestinationGenesisAuthorizationStatement::from_context_with_source(
        &context,
        &f.preview,
        upgrade.origin_source(),
    )
    .unwrap();
    let signed = DestinationGenesisAuthorization {
        signature: sign_bytes(&signer.secret_key, &statement.signing_bytes().unwrap()).unwrap(),
        statement,
        signer_public_key: signer.public_key.clone(),
    };
    upgrade
        .verify_destination_authorization(
            &signed,
            &context,
            &f.preview,
            signed.statement.id().unwrap(),
            &signer.public_key,
        )
        .unwrap();
    let mut wrong_context = context;
    wrong_context.started_at += 1;
    assert!(upgrade.verify_destination(&wrong_context).is_err());
    drop(destination);
    drop(source);
    fs::write(src.join("UPGRADE-AUTHORIZATION.json"), b"{}").unwrap();
    assert!(CandidateStore::open_compatible(&src, &f.v1, 1_100_000, &upgrade).is_err());
    fs::remove_dir_all(root).unwrap();
}

#[test]
#[ignore = "writes public-only inputs for the separate node process qualification"]
fn write_compatible_process_fixture() {
    let root = std::path::PathBuf::from(
        std::env::var_os("RLD_COMPAT_FIXTURE_DIR").expect("set a new fixture directory"),
    );
    assert!(root.is_absolute() && !root.exists());
    fs::create_dir_all(&root).unwrap();
    let origin = std::env::var("RLD_COMPAT_ORIGIN_SOURCE")
        .map(|v| Hash::from_hex(&v).unwrap())
        .unwrap_or(Hash([29; 32]));
    let f = Fixture::with_origin(origin);
    let upgrade = f.verify(&f.authorization).unwrap();
    let context = &f.authorization.statement.destinations[0];
    let signer = generate_identity();
    let statement = DestinationGenesisAuthorizationStatement::from_context_with_source(
        context,
        &f.preview,
        upgrade.origin_source(),
    )
    .unwrap();
    let destination_authorization = DestinationGenesisAuthorization {
        signature: sign_bytes(&signer.secret_key, &statement.signing_bytes().unwrap()).unwrap(),
        statement,
        signer_public_key: signer.public_key.clone(),
    };
    for (name,bytes) in [
        ("genesis.json",f.genesis.clone()),("history.json",b"[]".to_vec()),
        ("pow-adoption.json",serde_json::to_vec(&f.pow).unwrap()),
        ("earth-adoption.json",serde_json::to_vec(&f.earth).unwrap()),
        ("preview.json",f.preview.canonical_bytes().unwrap()),
        ("upgrade.json",f.authorization.canonical_bytes().unwrap()),
        ("destination-context.json",serde_json::to_vec(context).unwrap()),
        ("destination-authorization.json",destination_authorization.canonical_bytes().unwrap()),
        ("pins.json",serde_json::to_vec(&serde_json::json!({"manifest":f.v1.context.manifest_pin,"pow_adoption":f.pow.statement.id().unwrap(),"pow_source":f.pow.statement.implementation_source_sha256,"preview":f.preview.id().unwrap(),"earth_adoption":f.earth.statement.id().unwrap(),"upgrade":upgrade.id(),"origin_source":upgrade.origin_source(),"implementation_source":implementation_source().unwrap(),"destination_authorization":destination_authorization.statement.id().unwrap(),"destination_signer":signer.public_key,"destination_genesis":context.genesis_with_source(upgrade.origin_source()).unwrap(),"miner":generate_identity().public_key})).unwrap()),
    ] {fs::write(root.join(name),bytes).unwrap();}
}
