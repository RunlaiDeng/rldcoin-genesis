use super::*;
use crate::{
    adoption::EarthSuccessorAdoptionStatement,
    chain::{self, finality::FinalityStatement, Command, ObservationPolicy},
    destination::pow::authorization::DestinationGenesisAuthorizationStatement,
};
use ed25519_dalek::SigningKey;
use rld_core::{generate_identity, sign_bytes, Identity};
use rld_cross_region::{
    value::{ExportCommand, ExportIntent},
    ProofBundle,
};
use rld_pow::{target_limit, transition, Output, Transfer};

const START: u64 = 1_000_000;
fn private_fixture_root() -> std::path::PathBuf {
    let root = std::env::temp_dir().join(format!(
        "rld-migration-storage-{}",
        generate_identity().public_key
    ));
    std::fs::create_dir(&root).unwrap();
    root
}
fn approvals(bytes: &[u8]) -> Vec<Approval> {
    let mut values: Vec<_> = (2..=5)
        .map(|seed| {
            let key = SigningKey::from_bytes(&[seed; 32]);
            Approval {
                public_key: hex::encode(key.verifying_key().to_bytes()),
                signature: sign_bytes(&hex::encode([seed; 32]), bytes).unwrap(),
            }
        })
        .collect();
    values.sort_by(|a, b| a.public_key.cmp(&b.public_key));
    values
}
fn mine_source(c: &mut CandidateChain, miner: &str, commands: Vec<Command>, start: u64) -> Hash {
    let time = start + (c.height() as u64 + 1) * c.timing().seconds;
    let mut block = c.template(miner.to_owned(), time, commands).unwrap();
    while !chain::mine_batch(&mut block, 10000).unwrap() {}
    let id = block.header.id().unwrap();
    c.accept(block, time).unwrap();
    id
}
fn mine_dest(
    c: &mut DestinationPowChain,
    source: &CandidateChain,
    miner: &str,
    commands: Vec<pow::Command>,
    start: u64,
) -> Hash {
    let time = start + (c.height() as u64 + 1) * c.migration_context().timing().seconds;
    let mut block = c
        .template(source, miner.to_owned(), time, commands)
        .unwrap();
    while !pow::mine_batch(&mut block, 10000).unwrap() {}
    let id = block.header.id().unwrap();
    c.accept(source, block, time).unwrap();
    id
}
fn export(
    c: &CandidateChain,
    owner: &Identity,
    recipient: &str,
    dst: Hash,
    amount: u128,
) -> ExportCommand {
    let (point, coin) = c
        .state()
        .coins
        .iter()
        .find(|(_, coin)| {
            coin.output.owner == owner.public_key && coin.spendable_height <= c.height() + 1
        })
        .unwrap();
    let intent = ExportIntent {
        source_chain_id: c.chain_id(),
        destination_chain_id: dst,
        input: point.clone(),
        owner: owner.public_key.clone(),
        recipient: recipient.to_owned(),
        amount: Amount(amount),
        source_fee: Amount(1),
        destination_fee: Amount(1),
        change: Amount(coin.output.amount.0 - amount - 1),
        valid_through_height: c.height() + 12,
    };
    ExportCommand {
        owner_signature: sign_bytes(&owner.secret_key, &intent.signing_bytes().unwrap()).unwrap(),
        intent,
    }
}
fn certificate(c: &CandidateChain, id: Hash, block: Hash) -> FinalityCertificate {
    let statement = FinalityStatement::from_chain(c, id, block, None).unwrap();
    FinalityCertificate {
        approvals: approvals(&statement.signing_bytes().unwrap()),
        statement,
    }
}
fn transfer(
    chain_id: Hash,
    owner: &Identity,
    point: OutPoint,
    amount: Amount,
    to: &str,
) -> Transfer {
    let mut tx = Transfer {
        chain_id,
        owner: owner.public_key.clone(),
        inputs: vec![point],
        outputs: vec![Output {
            owner: to.to_owned(),
            amount: Amount(amount.0 - 1),
        }],
        fee: Amount(1),
        valid_through_height: 10000,
        signature: String::new(),
    };
    tx.signature = sign_bytes(&owner.secret_key, &tx.signing_bytes().unwrap()).unwrap();
    tx
}
struct Fixture {
    genesis: Vec<u8>,
    pow: Adoption,
    earth: EarthSuccessorAdoption,
    preview: TransitionPreview,
    v1: Chain,
    source: CandidateChain,
    no_fork: CandidateChain,
    destination: DestinationPowChain,
    authorization: DestinationGenesisAuthorization,
    finality: FinalityCertificate,
    pins: LegacyPins,
    owner: Identity,
    recipient: Identity,
    imported: ProofBundle,
    pending: ProofBundle,
    orphan: ProofBundle,
}
impl Fixture {
    fn new() -> Self {
        let genesis = include_bytes!("../../../../vectors/m0-genesis-v3/manifest.json").to_vec();
        let manifest = rld_core::M0GenesisManifestFile::decode_json(&genesis).unwrap();
        let pin = Hash::from_hex(manifest.manifest_sha256()).unwrap();
        let origin = Hash([29; 32]);
        let mut statement = transition::draft(&genesis, b"[]", pin, target_limit(), START).unwrap();
        statement.implementation_source_sha256 = origin;
        let pow = Adoption {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        let v1 = Chain::new(
            pow.verify_with_pinned_release_source(
                &genesis,
                b"[]",
                pin,
                pow.statement.id().unwrap(),
                origin,
            )
            .unwrap(),
        )
        .unwrap();
        let preview = TransitionPreview::from_replayed_v1_with_source(&v1, origin, origin).unwrap();
        let statement =
            EarthSuccessorAdoptionStatement::from_replayed_fresh_chain(&v1, &preview).unwrap();
        let earth = EarthSuccessorAdoption {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        let owner = generate_identity();
        let recipient = generate_identity();
        let mut source = CandidateChain::from_replayed_pow_chain(&v1).unwrap();
        let context = pow::Context {
            chain_id: Hash([91; 32]),
            source_policy: ObservationPolicy {
                source_chain_id: source.chain_id(),
                accepted_v1_tip: v1.tip(),
                minimum_confirmations: 12,
                minimum_cumulative_work: rld_core::header_work(target_limit()),
            },
            started_at: START,
            initial_target: target_limit(),
            regional: None,
            migration: None,
            source_finality: Some(pow::SourceFinalityTrust {
                earth_adoption_id: earth.statement.id().unwrap(),
                validator_keys: pow.approvals.iter().map(|a| a.public_key.clone()).collect(),
            }),
        };
        let mut destination =
            DestinationPowChain::new_with_source(context.clone(), origin).unwrap();
        let signer = generate_identity();
        let statement = DestinationGenesisAuthorizationStatement::from_context_with_source(
            &context, &preview, origin,
        )
        .unwrap();
        let authorization = DestinationGenesisAuthorization {
            signature: sign_bytes(&signer.secret_key, &statement.signing_bytes().unwrap()).unwrap(),
            statement,
            signer_public_key: signer.public_key.clone(),
        };
        while source.height() < 101 {
            mine_source(&mut source, &owner.public_key, vec![], START);
        }
        let mut fork = source.clone();
        let command = export(
            &source,
            &owner,
            &recipient.public_key,
            context.chain_id,
            10000,
        );
        let export_id = command.intent.id().unwrap();
        let first = mine_source(
            &mut source,
            &owner.public_key,
            vec![Command::Export(command)],
            START,
        );
        let command = export(
            &source,
            &owner,
            &recipient.public_key,
            context.chain_id,
            5000,
        );
        let pending_id = command.intent.id().unwrap();
        let second = mine_source(
            &mut source,
            &owner.public_key,
            vec![Command::Export(command)],
            START,
        );
        while source.height() < 113 {
            mine_source(&mut source, &owner.public_key, vec![], START);
        }
        let no_fork = source.clone();
        let command = export(&fork, &owner, &recipient.public_key, context.chain_id, 7000);
        let orphan_id = command.intent.id().unwrap();
        let orphan_checkpoint = mine_source(
            &mut fork,
            &owner.public_key,
            vec![Command::Export(command)],
            START,
        );
        let orphan = fork.export_bundle(orphan_id, orphan_checkpoint).unwrap();
        source
            .accept(fork.block(orphan_checkpoint).unwrap(), START + 113 * 600)
            .unwrap();
        assert_eq!(source.tip(), no_fork.tip());
        let finality = certificate(&source, earth.statement.id().unwrap(), first);
        finality
            .verify(
                &source,
                earth.statement.id().unwrap(),
                &context.source_finality.as_ref().unwrap().validator_keys,
            )
            .unwrap();
        source.install_finality(first).unwrap();
        let imported = source.export_bundle(export_id, first).unwrap();
        let pending = source.export_bundle(pending_id, second).unwrap();
        mine_dest(
            &mut destination,
            &source,
            &owner.public_key,
            vec![pow::Command::FinalizedImport {
                bundle: imported.clone(),
                certificate: finality.clone(),
            }],
            START,
        );
        let pins = LegacyPins {
            manifest: pin,
            pow_adoption: pow.statement.id().unwrap(),
            earth_adoption: earth.statement.id().unwrap(),
            preview: preview.id().unwrap(),
            origin_implementation: origin,
            destination_authorization: authorization.statement.id().unwrap(),
            destination_signer: signer.public_key,
        };
        Self {
            genesis,
            pow,
            earth,
            preview,
            v1,
            source,
            no_fork,
            destination,
            authorization,
            finality,
            pins,
            owner,
            recipient,
            imported,
            pending,
            orphan,
        }
    }
    fn legacy(&self) -> LegacyReplay {
        self.legacy_with(&self.source, &self.destination).unwrap()
    }
    fn legacy_with(
        &self,
        source: &CandidateChain,
        destination: &DestinationPowChain,
    ) -> Result<LegacyReplay> {
        LegacyReplay::verify(LegacyInputs {
            genesis: &self.genesis,
            history: b"[]",
            pow_adoption: &self.pow,
            earth_adoption: &self.earth,
            preview: &self.preview,
            destination_authorization: &self.authorization,
            v1: &self.v1,
            source,
            destination,
            finality: &self.finality,
            pins: self.pins.clone(),
        })
    }
    fn locks(&self, legacy: &LegacyReplay) -> (VerifiedSignerLocks, Vec<(String, Vec<u8>)>) {
        let record = SignerLock {
            source_chain_id: legacy.source.chain_id(),
            earth_adoption_id: self.pins.earth_adoption,
            certificate_id: self.finality.statement.id().unwrap(),
            height: self.finality.statement.height,
            block: self.finality.statement.block,
        };
        let records = legacy
            .validators
            .iter()
            .map(|key| (key.clone(), serde_json::to_vec(&record).unwrap()))
            .collect::<Vec<_>>();
        (
            VerifiedSignerLocks::from_canonical_records(legacy, &records).unwrap(),
            records,
        )
    }
    fn authorization(
        &self,
        source_seconds: u64,
        dest_seconds: u64,
    ) -> (LegacyReplay, VerifiedSignerLocks, Authorization) {
        let legacy = self.legacy();
        let (locks, _) = self.locks(&legacy);
        let statement = Statement::draft(
            &legacy,
            &locks,
            Options {
                timing: TimingRules::new(source_seconds, dest_seconds).unwrap(),
                source_started_at: START + 113 * 600,
                destination_started_at: START + 600,
            },
        )
        .unwrap();
        let signed = Authorization {
            approvals: approvals(&statement.signing_bytes().unwrap()),
            statement,
        };
        (legacy, locks, signed)
    }
    fn migration(&self, source_seconds: u64, dest_seconds: u64) -> VerifiedMigration {
        let (legacy, locks, signed) = self.authorization(source_seconds, dest_seconds);
        signed
            .verify(&legacy, &locks, signed.statement.id().unwrap())
            .unwrap()
    }
}

#[test]
fn native_migration_preserves_both_ledgers_retirement_maturity_and_partial_issuance() {
    let f = Fixture::new();
    let m = f.migration(3600, 600);
    let mut source = CandidateChain::from_verified_migration(&m).unwrap();
    let destination = DestinationPowChain::from_verified_migration(&m).unwrap();
    assert_ne!(source.chain_id(), f.source.chain_id());
    assert_ne!(destination.chain_id(), f.destination.chain_id());
    assert!(DestinationPowChain::new(m.destination_context().unwrap()).is_err());
    let old = f.source.state().commitment().unwrap();
    let new = source.state().commitment().unwrap();
    assert_eq!(old.emitted, new.emitted);
    assert_eq!(old.retired, new.retired);
    assert_eq!(old.liquid, new.liquid);
    assert_eq!(new.retired, Amount(15000));
    assert_eq!(destination.state().imported_total(), Amount(10000));
    assert_eq!(source.chainwork(), f.source.chainwork());
    assert_eq!(destination.chainwork(), f.destination.chainwork());
    for (point, coin) in &f.source.state().coins {
        let mapped = source
            .state()
            .coin(&remapped_point(f.source.chain_id(), point).unwrap())
            .unwrap();
        assert_eq!(mapped.output, coin.output);
        assert_eq!(
            mapped.spendable_height,
            (coin.spendable_height.saturating_sub(113) * 600).div_ceil(3600)
        );
    }
    let (oldcoins, _) = f.destination.state().migration_assets();
    for (point, coin) in &oldcoins {
        let mapped = destination
            .state()
            .coin(&remapped_point(f.destination.chain_id(), point).unwrap())
            .unwrap();
        assert_eq!(mapped.output, coin.output);
        assert_eq!(
            mapped.spendable_height,
            coin.spendable_height.saturating_sub(1)
        );
    }
    assert_eq!(
        destination
            .state()
            .balance(&f.recipient.public_key, 0)
            .unwrap(),
        (Amount(0), Amount(9999))
    );
    assert_eq!(
        destination
            .state()
            .balance(&f.recipient.public_key, 6)
            .unwrap(),
        (Amount(9999), Amount(0))
    );
    mine_source(
        &mut source,
        &f.owner.public_key,
        vec![],
        m.statement().source_started_at,
    );
    assert_eq!(
        source.state().commitment().unwrap().emitted,
        m.issuance().unwrap().cumulative(1).unwrap()
    );
    assert_ne!(
        m.issuance().unwrap().cumulative(1).unwrap(),
        m.source_context().cumulative_emission(1).unwrap()
    );
    let checkpoint = source.replayed_checkpoint().unwrap();
    source.verify_replayed_checkpoint(&checkpoint).unwrap();
    let mut altered = serde_json::to_value(&checkpoint).unwrap();
    altered["state"]["migration_retirement"]["retired"] = serde_json::to_value(Amount(0)).unwrap();
    assert!(source
        .verify_replayed_checkpoint(&serde_json::from_value(altered).unwrap())
        .is_err());
}

#[test]
fn pending_old_export_uses_new_finality_and_cannot_remint_imported_assets() {
    let f = Fixture::new();
    let m = f.migration(3600, 3600);
    let mut source = CandidateChain::from_verified_migration(&m).unwrap();
    let mut dst = DestinationPowChain::from_verified_migration(&m).unwrap();
    let start = m.statement().source_started_at;
    let first = mine_source(&mut source, &f.owner.public_key, vec![], start);
    assert!(FinalityStatement::from_chain(&source, m.id().unwrap(), first, None).is_err());
    for _ in 0..2 {
        mine_source(&mut source, &f.owner.public_key, vec![], start);
    }
    let cert = certificate(&source, m.id().unwrap(), first);
    let command = pow::Command::LegacyImport {
        bundle: f.pending.clone(),
        certificate: cert.clone(),
    };
    assert!(dst
        .template(
            &source,
            f.owner.public_key.clone(),
            START + 600 + 3600,
            vec![command.clone()]
        )
        .is_err());
    source.install_finality(first).unwrap();
    let ts = START + 600 + 3600;
    assert!(dst
        .template(
            &source,
            f.owner.public_key.clone(),
            ts,
            vec![pow::Command::LegacyImport {
                bundle: f.imported.clone(),
                certificate: cert.clone()
            }]
        )
        .is_err());
    assert!(dst
        .template(
            &source,
            f.owner.public_key.clone(),
            ts,
            vec![pow::Command::LegacyImport {
                bundle: f.orphan.clone(),
                certificate: cert.clone()
            }]
        )
        .is_err());
    let import = mine_dest(
        &mut dst,
        &source,
        &f.owner.public_key,
        vec![command.clone()],
        START + 600,
    );
    assert_eq!(dst.state().imported_total(), Amount(15000));
    assert!(dst
        .template(
            &source,
            f.owner.public_key.clone(),
            ts + 3600,
            vec![command]
        )
        .is_err());
    let mut audit = dst.state().clone();
    audit.audit_source(&source).unwrap();
    assert_eq!(
        dst.state().balance(&f.recipient.public_key, 1).unwrap(),
        (Amount(9999), Amount(4999))
    );
    assert_eq!(
        dst.state().balance(&f.recipient.public_key, 2).unwrap(),
        (Amount(14998), Amount(0))
    );
    for _ in 0..2 {
        mine_dest(&mut dst, &source, &f.owner.public_key, vec![], START + 600);
    }
    let policy = crate::destination::pow::receipt::InclusionPolicy {
        destination_chain_id: dst.chain_id(),
        accepted_genesis: dst.genesis(),
        minimum_confirmations: 3,
        minimum_inclusion_work: rld_core::header_work(m.statement().destination_initial_target),
    };
    let receipt = dst.observe_import(&source, &f.pending, &policy).unwrap();
    assert_eq!(receipt.block, import);
    dst.verify_import_receipt(&source, &f.pending, &policy, &receipt)
        .unwrap();
    assert_eq!(dst.state().imported_total(), Amount(15000));
    let new_export = export(
        &source,
        &f.owner,
        &f.recipient.public_key,
        dst.chain_id(),
        1000,
    );
    let new_id = new_export.intent.id().unwrap();
    let checkpoint = mine_source(
        &mut source,
        &f.owner.public_key,
        vec![Command::Export(new_export)],
        start,
    );
    for _ in 0..2 {
        mine_source(&mut source, &f.owner.public_key, vec![], start);
    }
    let statement = FinalityStatement::from_chain(
        &source,
        m.id().unwrap(),
        checkpoint,
        Some(cert.statement.id().unwrap()),
    )
    .unwrap();
    let new_cert = FinalityCertificate {
        approvals: approvals(&statement.signing_bytes().unwrap()),
        statement,
    };
    source.install_finality(checkpoint).unwrap();
    let new_bundle = source.export_bundle(new_id, checkpoint).unwrap();
    mine_dest(
        &mut dst,
        &source,
        &f.owner.public_key,
        vec![pow::Command::FinalizedImport {
            bundle: new_bundle,
            certificate: new_cert,
        }],
        START + 600,
    );
    assert_eq!(source.state().commitment().unwrap().retired, Amount(16000));
    assert_eq!(dst.state().imported_total(), Amount(16000));
    let mut audit = dst.state().clone();
    audit.audit_source(&source).unwrap();
}

#[test]
fn faster_finality_cannot_skip_the_remaining_legacy_export_wait() {
    let f = Fixture::new();
    let m = f.migration(30, 600);
    let mut source = CandidateChain::from_verified_migration(&m).unwrap();
    let mut dst = DestinationPowChain::from_verified_migration(&m).unwrap();
    let start = m.statement().source_started_at;
    let mut block20 = Hash::ZERO;
    let first = mine_source(&mut source, &f.owner.public_key, vec![], start);
    while source.height() < 221 {
        let id = mine_source(&mut source, &f.owner.public_key, vec![], start);
        if source.height() == 20 {
            block20 = id;
        }
    }
    let early = certificate(&source, m.id().unwrap(), first);
    source.install_finality(first).unwrap();
    let early_command = pow::Command::LegacyImport {
        bundle: f.pending.clone(),
        certificate: early.clone(),
    };
    let error = dst
        .template(
            &source,
            f.owner.public_key.clone(),
            START + 1200,
            vec![early_command],
        )
        .unwrap_err();
    assert!(error.contains("remaining old finality wait"), "{error}");
    while source.height() < 240 {
        mine_source(&mut source, &f.owner.public_key, vec![], start);
    }
    let statement = FinalityStatement::from_chain(
        &source,
        m.id().unwrap(),
        block20,
        Some(early.statement.id().unwrap()),
    )
    .unwrap();
    let cert = FinalityCertificate {
        approvals: approvals(&statement.signing_bytes().unwrap()),
        statement,
    };
    source.install_finality(block20).unwrap();
    mine_dest(
        &mut dst,
        &source,
        &f.owner.public_key,
        vec![pow::Command::LegacyImport {
            bundle: f.pending.clone(),
            certificate: cert,
        }],
        START + 600,
    );
    assert_eq!(dst.state().imported_total(), Amount(15000));
    assert_eq!(
        source.state().commitment().unwrap().emitted,
        m.issuance().unwrap().cumulative(240).unwrap()
    );
}

#[test]
fn faster_source_preserves_remaining_old_maturity_and_rejects_old_signed_commands() {
    let f = Fixture::new();
    let m = f.migration(10, 600);
    let mut source = CandidateChain::from_verified_migration(&m).unwrap();
    let (point, coin) = f
        .source
        .state()
        .coins
        .iter()
        .find(|(_, c)| c.spendable_height == 114)
        .unwrap();
    let mapped = remapped_point(f.source.chain_id(), point).unwrap();
    assert_eq!(source.state().coin(&mapped).unwrap().spendable_height, 60);
    let tx = transfer(
        source.chain_id(),
        &f.owner,
        mapped,
        coin.output.amount,
        &f.recipient.public_key,
    );
    let old = transfer(
        f.source.chain_id(),
        &f.owner,
        point.clone(),
        coin.output.amount,
        &f.recipient.public_key,
    );
    let start = m.statement().source_started_at;
    assert!(source
        .template(
            f.owner.public_key.clone(),
            start + 10,
            vec![Command::Transfer(old)]
        )
        .is_err());
    while source.height() < 58 {
        mine_source(&mut source, &f.owner.public_key, vec![], start);
    }
    assert!(source
        .template(
            f.owner.public_key.clone(),
            start + 590,
            vec![Command::Transfer(tx.clone())]
        )
        .is_err());
    mine_source(&mut source, &f.owner.public_key, vec![], start);
    mine_source(
        &mut source,
        &f.owner.public_key,
        vec![Command::Transfer(tx)],
        start,
    );
    assert_eq!(source.height(), 60);
    assert_eq!(
        source.state().commitment().unwrap().emitted,
        m.issuance().unwrap().cumulative(60).unwrap()
    );
    assert_eq!(source.state().commitment().unwrap().retired, Amount(15000));
}

#[test]
fn inherited_destination_coin_requires_remaining_maturity_and_new_network_signature() {
    let f = Fixture::new();
    let m = f.migration(3600, 600);
    let source = CandidateChain::from_verified_migration(&m).unwrap();
    let mut dst = DestinationPowChain::from_verified_migration(&m).unwrap();
    let (coins, _) = f.destination.state().migration_assets();
    let (point, coin) = coins
        .iter()
        .find(|(_, c)| c.output.owner == f.recipient.public_key)
        .unwrap();
    let newpoint = remapped_point(f.destination.chain_id(), point).unwrap();
    let to = generate_identity();
    let tx = transfer(
        dst.chain_id(),
        &f.recipient,
        newpoint,
        coin.output.amount,
        &to.public_key,
    );
    let old = transfer(
        f.destination.chain_id(),
        &f.recipient,
        point.clone(),
        coin.output.amount,
        &to.public_key,
    );
    assert!(dst
        .template(
            &source,
            f.owner.public_key.clone(),
            START + 1200,
            vec![pow::Command::Transfer(old)]
        )
        .is_err());
    for _ in 0..4 {
        mine_dest(&mut dst, &source, &f.owner.public_key, vec![], START + 600);
    }
    assert!(dst
        .template(
            &source,
            f.owner.public_key.clone(),
            START + 3600,
            vec![pow::Command::Transfer(tx.clone())]
        )
        .is_err());
    mine_dest(&mut dst, &source, &f.owner.public_key, vec![], START + 600);
    mine_dest(
        &mut dst,
        &source,
        &f.owner.public_key,
        vec![pow::Command::Transfer(tx)],
        START + 600,
    );
    assert_eq!(dst.state().imported_total(), Amount(10000));
    assert_eq!(
        dst.state().balance(&to.public_key, 7).unwrap(),
        (Amount(9998), Amount(0))
    );
}

#[test]
fn signatures_cannot_authorize_forged_native_assets_rules_or_missing_retained_forks() {
    let f = Fixture::new();
    let (legacy, locks, signed) = f.authorization(3600, 600);
    assert!(signed.verify(&legacy, &locks, Hash::ZERO).is_err());
    let mut no_fork = f.no_fork.clone();
    no_fork
        .install_finality(f.finality.statement.block)
        .unwrap();
    let truncated = f.legacy_with(&no_fork, &f.destination).unwrap();
    assert_eq!(legacy.source.tip(), truncated.source.tip());
    assert_eq!(
        legacy.source.state().root().unwrap(),
        truncated.source.state().root().unwrap()
    );
    assert!(signed
        .verify(&truncated, &locks, signed.statement.id().unwrap())
        .is_err());
    for change in 0..7 {
        let mut forged = signed.clone();
        match change {
            0 => forged.statement.source_emitted = Amount(forged.statement.source_emitted.0 + 1),
            1 => forged.statement.source_retired = Amount(0),
            2 => forged.statement.destination_imported = Amount(0),
            3 => forged.statement.destination_asset_map_root = Hash([8; 32]),
            4 => forged.statement.implementation_source = Hash([9; 32]),
            5 => forged.statement.signer_locks_sha256 = Hash([10; 32]),
            _ => forged.statement.retire_old_network = false,
        }
        forged.approvals = approvals(&forged.statement.signing_bytes().unwrap());
        assert!(forged
            .verify(&legacy, &locks, forged.statement.id().unwrap())
            .is_err());
    }
    let mut forged = signed.clone();
    forged.approvals.pop();
    assert!(forged
        .verify(&legacy, &locks, signed.statement.id().unwrap())
        .is_err());
    let mut forged = signed.clone();
    forged.approvals.swap(0, 1);
    assert!(forged
        .verify(&legacy, &locks, signed.statement.id().unwrap())
        .is_err());
    let (_, mut records) = f.locks(&legacy);
    records[0].1.push(b' ');
    assert!(VerifiedSignerLocks::from_canonical_records(&legacy, &records).is_err());
    let (_, mut records) = f.locks(&legacy);
    records[1] = records[0].clone();
    assert!(VerifiedSignerLocks::from_canonical_records(&legacy, &records).is_err());
}

#[test]
fn old_active_channel_blocks_migration_without_shortening_its_original_contest() {
    use rld_fast_payments::{
        successor::{OpenChannel, OpenIntent},
        ChannelState, SignedState,
    };
    let f = Fixture::new();
    let mut source = f.source.clone();
    let (point, coin) = source
        .state()
        .coins
        .iter()
        .find(|(_, c)| c.spendable_height <= source.height())
        .unwrap();
    let intent = OpenIntent {
        chain_id: source.chain_id(),
        input: point.clone(),
        party_a: f.owner.public_key.clone(),
        party_b: f.recipient.public_key.clone(),
        capacity: Amount(10000),
        close_fee: Amount(1),
        opening_fee: Amount(1),
        change: Amount(coin.output.amount.0 - 10001),
        valid_through_height: source.height() + 12,
    };
    let funding = intent.funding().unwrap();
    let state = ChannelState::initial(&funding).unwrap();
    let bytes = state.signing_bytes(&funding).unwrap();
    let initial = SignedState {
        state,
        signature_a: sign_bytes(&f.owner.secret_key, &bytes).unwrap(),
        signature_b: sign_bytes(&f.recipient.secret_key, &bytes).unwrap(),
    };
    let command = OpenChannel {
        signature_a: sign_bytes(&f.owner.secret_key, &intent.signing_bytes().unwrap()).unwrap(),
        intent,
        initial,
    };
    mine_source(
        &mut source,
        &f.owner.public_key,
        vec![Command::Open(command)],
        START,
    );
    let error = match f.legacy_with(&source, &f.destination) {
        Ok(_) => panic!("active old channel migrated"),
        Err(e) => e,
    };
    assert!(error.contains("old channels must exit"), "{error}");
    assert_eq!(source.timing().contest_blocks, 2016);
}

#[test]
fn complete_archive_replays_retained_forks_and_durable_migrated_assets_finality_and_receipts() {
    use crate::{chain::storage::CandidateStore, destination::pow::storage::DestinationPowStore};
    let f = Fixture::new();
    let migration = f.migration(3600, 3600);
    let (_, records) = f.locks(&migration.legacy);
    let root = private_fixture_root();
    let archive_path = root.join("archive");
    migration.write_archive(&archive_path, &records).unwrap();
    assert!(migration.write_archive(&archive_path, &records).is_err());
    let archive =
        archive::VerifiedArchive::open(&archive_path, migration.id().unwrap(), START + 200000)
            .unwrap();
    let m = archive.migration();
    assert_eq!(
        m.legacy_source().migration_history().unwrap(),
        f.source.migration_history().unwrap()
    );
    assert_eq!(
        m.legacy_source().history_stats().0,
        f.source.history_stats().0
    );
    assert!(m
        .legacy_source()
        .block(f.orphan.source_checkpoint)
        .is_some());
    let mut source =
        CandidateStore::open_migrated(&root.join("source"), START + 200000, m).unwrap();
    let mut first = Hash::ZERO;
    for n in 1..=3 {
        let timestamp = m.statement().source_started_at + n * 3600;
        let mut block = source
            .chain()
            .template(f.owner.public_key.clone(), timestamp, vec![])
            .unwrap();
        while !chain::mine_batch(&mut block, 10000).unwrap() {}
        if n == 1 {
            first = block.header.id().unwrap();
        }
        source.accept(block, timestamp).unwrap();
    }
    let cert = certificate(source.chain(), m.id().unwrap(), first);
    source.install_finality(cert.clone()).unwrap();
    source.write_replayed_checkpoint().unwrap();
    assert!(CandidateStore::open_migrated(&root.join("source"), START + 200000, m).is_err());
    let command = pow::Command::LegacyImport {
        bundle: f.pending.clone(),
        certificate: cert.clone(),
    };
    let mut destination = DestinationPowStore::open_migrated(
        &root.join("destination"),
        source.chain(),
        START + 200000,
        m,
    )
    .unwrap();
    let timestamp = m.statement().options.destination_started_at + 3600;
    destination
        .submit_command(
            source.chain(),
            command.clone(),
            &f.owner.public_key,
            timestamp,
        )
        .unwrap();
    drop(destination);
    let mut destination = DestinationPowStore::open_migrated(
        &root.join("destination"),
        source.chain(),
        START + 200000,
        m,
    )
    .unwrap();
    assert_eq!(destination.submitted_count(), 1);
    for n in 1..=3 {
        let timestamp = m.statement().options.destination_started_at + n * 3600;
        let commands = if n == 1 {
            vec![command.clone()]
        } else {
            vec![]
        };
        let mut block = destination
            .chain()
            .clone()
            .template(
                source.chain(),
                f.owner.public_key.clone(),
                timestamp,
                commands,
            )
            .unwrap();
        while !pow::mine_batch(&mut block, 10000).unwrap() {}
        destination
            .accept(source.chain(), block, timestamp)
            .unwrap();
    }
    let policy = crate::destination::pow::receipt::InclusionPolicy {
        destination_chain_id: destination.chain().chain_id(),
        accepted_genesis: destination.chain().genesis(),
        minimum_confirmations: 3,
        minimum_inclusion_work: rld_core::header_work(m.statement().destination_initial_target),
    };
    let receipt = destination
        .chain()
        .observe_import(source.chain(), &f.pending, &policy)
        .unwrap();
    let source_tip = source.chain().tip();
    let source_root = source.chain().state().root().unwrap();
    let dest_tip = destination.chain().tip();
    let dest_root = destination.chain().state().root().unwrap();
    let migration_bytes = m.canonical_bytes().to_vec();
    drop(destination);
    drop(source);
    drop(archive);
    let archive =
        archive::VerifiedArchive::open(&archive_path, migration.id().unwrap(), START + 200000)
            .unwrap();
    let m = archive.migration();
    let source = CandidateStore::open_migrated(&root.join("source"), START + 200000, m).unwrap();
    let destination = DestinationPowStore::open_migrated(
        &root.join("destination"),
        source.chain(),
        START + 200000,
        m,
    )
    .unwrap();
    assert_eq!(source.chain().tip(), source_tip);
    assert_eq!(source.chain().state().root().unwrap(), source_root);
    assert_eq!(source.finality(), Some(&cert));
    assert_eq!(destination.chain().tip(), dest_tip);
    assert_eq!(destination.chain().state().root().unwrap(), dest_root);
    assert_eq!(
        source.chain().state().commitment().unwrap().retired,
        Amount(15000)
    );
    assert_eq!(destination.chain().state().imported_total(), Amount(15000));
    destination
        .chain()
        .verify_import_receipt(source.chain(), &f.pending, &policy, &receipt)
        .unwrap();
    assert!(destination
        .chain()
        .clone()
        .template(
            source.chain(),
            f.owner.public_key.clone(),
            m.statement().options.destination_started_at + 4 * 3600,
            vec![command]
        )
        .is_err());
    assert_eq!(
        std::fs::read(root.join("source/MIGRATION-AUTHORIZATION.json")).unwrap(),
        migration_bytes
    );
    assert_eq!(
        std::fs::read(root.join("destination/MIGRATION-AUTHORIZATION.json")).unwrap(),
        migration_bytes
    );
    drop(destination);
    drop(source);
    drop(archive);
    std::fs::remove_dir_all(root).unwrap();
}

#[test]
fn migrated_stores_refuse_deleted_changed_or_cross_network_acceptance() {
    use crate::{chain::storage::CandidateStore, destination::pow::storage::DestinationPowStore};
    let f = Fixture::new();
    let m = f.migration(3600, 600);
    let other = f.migration(600, 600);
    let root = private_fixture_root();
    let src = root.join("source");
    let dst = root.join("destination");
    let source = CandidateStore::open_migrated(&src, START + 200000, &m).unwrap();
    let destination =
        DestinationPowStore::open_migrated(&dst, source.chain(), START + 200000, &m).unwrap();
    drop(destination);
    drop(source);
    assert!(CandidateStore::open(&src, &f.v1, START + 200000).is_err());
    assert!(CandidateStore::open_migrated(&src, START + 200000, &other).is_err());
    std::fs::remove_file(src.join("MIGRATION-AUTHORIZATION.json")).unwrap();
    assert!(CandidateStore::open_migrated(&src, START + 200000, &m).is_err());
    std::fs::write(
        src.join("MIGRATION-AUTHORIZATION.json"),
        m.canonical_bytes(),
    )
    .unwrap();
    let source = CandidateStore::open_migrated(&src, START + 200000, &m).unwrap();
    std::fs::write(dst.join("MIGRATION-AUTHORIZATION.json"), b"{}").unwrap();
    assert!(DestinationPowStore::open_migrated(&dst, source.chain(), START + 200000, &m).is_err());
    std::fs::remove_file(dst.join("MIGRATION-AUTHORIZATION.json")).unwrap();
    assert!(DestinationPowStore::open_migrated(&dst, source.chain(), START + 200000, &m).is_err());
    assert!(DestinationPowStore::open_migrated(
        &root.join("wrong-source"),
        &f.source,
        START + 200000,
        &m
    )
    .is_err());
    assert!(!root.join("wrong-source").exists());
    drop(source);
    std::fs::remove_dir_all(root).unwrap();
}

#[test]
fn migration_archive_rejects_missing_extra_changed_and_noncanonical_evidence() {
    let f = Fixture::new();
    let m = f.migration(3600, 600);
    let (_, records) = f.locks(&m.legacy);
    let root = private_fixture_root();
    let path = root.join("archive");
    m.write_archive(&path, &records).unwrap();
    assert!(archive::VerifiedArchive::open(&path, Hash([9; 32]), START + 200000).is_err());
    std::fs::write(path.join("foreign-snapshot.json"), b"{}").unwrap();
    assert!(archive::VerifiedArchive::open(&path, m.id().unwrap(), START + 200000).is_err());
    std::fs::remove_file(path.join("foreign-snapshot.json")).unwrap();
    let filename = path
        .join("source-blocks")
        .join(format!("{}.json", f.orphan.source_checkpoint.to_hex()));
    let bytes = std::fs::read(&filename).unwrap();
    std::fs::remove_file(&filename).unwrap();
    assert!(archive::VerifiedArchive::open(&path, m.id().unwrap(), START + 200000).is_err());
    let manifest_path = path.join("archive.json");
    let original_manifest = std::fs::read_to_string(&manifest_path).unwrap();
    let count = m.legacy_source().history_stats().0;
    let rewritten = original_manifest.replace(
        &format!("\"source_blocks\":{count}"),
        &format!("\"source_blocks\":{}", count - 1),
    );
    assert_ne!(rewritten, original_manifest);
    std::fs::write(&manifest_path, rewritten).unwrap();
    let error = match archive::VerifiedArchive::open(&path, m.id().unwrap(), START + 200000) {
        Ok(_) => panic!("unsigned inventory erased retained branch"),
        Err(e) => e,
    };
    assert!(error.contains("differ from native replay"), "{error}");
    std::fs::write(manifest_path, original_manifest).unwrap();
    std::fs::write(&filename, &bytes).unwrap();
    let mut malformed = bytes.clone();
    malformed.push(b' ');
    std::fs::write(&filename, malformed).unwrap();
    assert!(archive::VerifiedArchive::open(&path, m.id().unwrap(), START + 200000).is_err());
    std::fs::write(&filename, &bytes).unwrap();
    let lock = path
        .join("signer-locks")
        .join(format!("{}.json", records[0].0));
    let old = std::fs::read(&lock).unwrap();
    std::fs::write(&lock, b"{}").unwrap();
    assert!(archive::VerifiedArchive::open(&path, m.id().unwrap(), START + 200000).is_err());
    std::fs::write(&lock, old).unwrap();
    assert!(archive::VerifiedArchive::open(&path, m.id().unwrap(), START + 200000).is_ok());
    std::fs::remove_dir_all(root).unwrap();
}
