//! Private, complete migration handoff. No ledger snapshot is recovery authority.
use super::*;
use crate::chain;
use serde::de::DeserializeOwned;
use std::{
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
    sync::Arc,
};

const ARCHIVE_FORMAT: &str = "RLD-NEXT-MAINNET-NATIVE-MIGRATION-ARCHIVE-V1";
const MAX_BLOCKS: usize = 1_000_000;
const MAX_BYTES: u64 = 128 * 1024 * 1024 * 1024;
const INPUT_BYTES: usize = 4 * 1024 * 1024;
const TOP: [&str; 12] = [
    "archive.json",
    "archive.lock",
    "migration.json",
    "genesis.json",
    "history.json",
    "pow-adoption.json",
    "earth-adoption.json",
    "preview.json",
    "destination-authorization.json",
    "destination-context.json",
    "old-finality.json",
    "signer-locks",
];

fn io<T>(value: std::io::Result<T>) -> Result<T> {
    value.map_err(|e| e.to_string())
}
fn directory(path: &Path) -> Result<()> {
    let m = io(fs::symlink_metadata(path))?;
    require(
        m.is_dir() && !m.file_type().is_symlink(),
        "unsafe migration archive directory",
    )
}
fn private_dir(path: &Path) -> Result<()> {
    let mut builder = fs::DirBuilder::new();
    #[cfg(unix)]
    {
        use std::os::unix::fs::DirBuilderExt;
        builder.mode(0o700);
    }
    io(builder.create(path))
}
fn read(path: &Path, limit: usize) -> Result<Vec<u8>> {
    let m = io(fs::symlink_metadata(path))?;
    require(
        m.is_file() && !m.file_type().is_symlink() && m.len() <= limit as u64,
        "unsafe or oversized migration archive file",
    )?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        require(m.nlink() == 1, "linked migration archive file")?;
    }
    let mut bytes = Vec::new();
    io(io(File::open(path))?
        .take(limit as u64 + 1)
        .read_to_end(&mut bytes))?;
    require(
        bytes.len() <= limit,
        "migration archive file grew beyond bound",
    )?;
    Ok(bytes)
}
fn decode<T: Serialize + DeserializeOwned>(path: &Path, limit: usize) -> Result<T> {
    let b = read(path, limit)?;
    let value: T = serde_json::from_slice(&b).map_err(|e| e.to_string())?;
    require(
        serde_json::to_vec(&value).map_err(|e| e.to_string())? == b,
        "noncanonical migration archive JSON",
    )?;
    Ok(value)
}
fn write(path: &Path, bytes: &[u8]) -> Result<()> {
    let mut options = OpenOptions::new();
    options.create_new(true).write(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    let mut file = io(options.open(path))?;
    io(file.write_all(bytes))?;
    io(file.sync_all())
}
fn json(path: &Path, value: &impl Serialize) -> Result<()> {
    write(path, &serde_json::to_vec(value).map_err(|e| e.to_string())?)
}
fn sync(path: &Path) -> Result<()> {
    io(io(File::open(path))?.sync_all())
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Manifest {
    format: String,
    migration_id: Hash,
    source_blocks: usize,
    destination_blocks: usize,
}

pub(super) struct ReplayWorkspace(PathBuf);
impl ReplayWorkspace {
    fn new() -> Result<Arc<Self>> {
        let root = std::env::temp_dir().join(format!(
            "rld-native-migration-replay-{}",
            rld_core::generate_identity().public_key
        ));
        private_dir(&root)?;
        private_dir(&root.join("source"))?;
        private_dir(&root.join("destination"))?;
        Ok(Arc::new(Self(root)))
    }
}
impl Drop for ReplayWorkspace {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

/// The read lease protects against cooperative writes. Native replay and the
/// signed full history commitments protect against altered or partial copies.
pub struct VerifiedArchive {
    migration: VerifiedMigration,
    _lease: File,
}
impl VerifiedArchive {
    pub fn migration(&self) -> &VerifiedMigration {
        &self.migration
    }
    pub fn open(root: &Path, accepted: Hash, now: u64) -> Result<Self> {
        require(
            !accepted.is_zero(),
            "missing independently accepted migration ID",
        )?;
        directory(root)?;
        // Exact inventory rejects foreign files, caches and unpublished fragments.
        let mut found = std::collections::BTreeSet::new();
        for entry in io(fs::read_dir(root))? {
            let entry = io(entry)?;
            let name = entry
                .file_name()
                .into_string()
                .map_err(|_| "non-UTF8 archive name")?;
            require(
                TOP.contains(&name.as_str())
                    || name == "source-blocks"
                    || name == "destination-blocks",
                "unexpected migration archive entry",
            )?;
            found.insert(name);
        }
        require(
            found.len() == TOP.len() + 2,
            "incomplete migration archive inventory",
        )?;
        require(
            read(&root.join("archive.lock"), 0)?.is_empty(),
            "invalid archive lease file",
        )?;
        let lease = io(File::open(root.join("archive.lock")))?;
        lease
            .try_lock_shared()
            .map_err(|e| format!("migration archive is busy: {e}"))?;
        let manifest: Manifest = decode(&root.join("archive.json"), 4096)?;
        require(
            manifest.format == ARCHIVE_FORMAT
                && manifest.migration_id == accepted
                && manifest.source_blocks <= MAX_BLOCKS
                && manifest.destination_blocks <= MAX_BLOCKS,
            "migration archive format, acceptance or count bound differs",
        )?;
        let authorization: Authorization = decode(&root.join("migration.json"), 65536)?;
        require(
            authorization.statement.id()? == accepted
                && authorization.statement.implementation_source == implementation()?
                && authorization.statement.rules_sha256 == rules_hash(),
            "archive migration acceptance, implementation or rules differ",
        )?;
        let pins = &authorization.statement.legacy_pins;
        let genesis = read(&root.join("genesis.json"), INPUT_BYTES)?;
        let history = read(&root.join("history.json"), INPUT_BYTES)?;
        let pow: Adoption = decode(&root.join("pow-adoption.json"), 65536)?;
        let earth: EarthSuccessorAdoption = decode(&root.join("earth-adoption.json"), 65536)?;
        let preview: TransitionPreview = decode(&root.join("preview.json"), 65536)?;
        let dst_authorization: DestinationGenesisAuthorization =
            decode(&root.join("destination-authorization.json"), 65536)?;
        let dst_context: pow::Context = decode(&root.join("destination-context.json"), 65536)?;
        let finality: FinalityCertificate = decode(&root.join("old-finality.json"), 8192)?;
        let context = pow.verify_with_pinned_release_source(
            &genesis,
            &history,
            pins.manifest,
            pins.pow_adoption,
            preview.v1_source_sha256,
        )?;
        let v1 = Chain::new(context)?;
        earth.verify_with_source(
            &genesis,
            &history,
            &pow,
            &v1,
            &preview,
            pins.earth_adoption,
            pins.origin_implementation,
        )?;
        dst_authorization.verify_with_source(
            &dst_context,
            &preview,
            pins.destination_authorization,
            &pins.destination_signer,
            pins.origin_implementation,
        )?;
        // Reject bad migration signatures before replaying potentially large histories.
        require(
            pow.approvals.len() == 4 && authorization.approvals.len() == 4,
            "archive requires four original migration signers",
        )?;
        let bytes = authorization.statement.signing_bytes()?;
        for (approval, key) in authorization.approvals.iter().zip(&pow.approvals) {
            require(
                approval.public_key == key.public_key,
                "archive migration signer differs",
            )?;
            verify_bytes(&key.public_key, &bytes, &approval.signature)?;
        }
        let workspace = ReplayWorkspace::new()?;
        let mut source = CandidateChain::from_replayed_pow_chain(&v1)?;
        source.migration_replay_index(&workspace.0.join("source"))?;
        let mut total = 0u64;
        let entries = block_index::<chain::Block>(
            &root.join("source-blocks"),
            rld_pow::MAX_BLOCK_BYTES,
            manifest.source_blocks,
            &mut total,
            |b| (b.header.height, b.header.id()),
        )?;
        for (height, id, path) in entries {
            let b: chain::Block = decode(&path, rld_pow::MAX_BLOCK_BYTES)?;
            require(
                b.header.height == height && b.header.id()? == id,
                "source archive changed during replay",
            )?;
            source.accept(b, now)?;
        }
        source.restore_migration_head(authorization.statement.source_tip)?;
        let validators: Vec<_> = pow.approvals.iter().map(|a| a.public_key.clone()).collect();
        finality.verify(&source, pins.earth_adoption, &validators)?;
        source.install_finality(finality.statement.block)?;
        let mut destination =
            DestinationPowChain::new_with_source(dst_context, pins.origin_implementation)?;
        destination.migration_replay_index(&workspace.0.join("destination"))?;
        let entries = block_index::<pow::Block>(
            &root.join("destination-blocks"),
            pow::MAX_DESTINATION_BLOCK_BYTES,
            manifest.destination_blocks,
            &mut total,
            |b| (b.header.height, b.header.id()),
        )?;
        for (height, id, path) in entries {
            let b: pow::Block = decode(&path, pow::MAX_DESTINATION_BLOCK_BYTES)?;
            require(
                b.header.height == height && b.header.id()? == id,
                "destination archive changed during replay",
            )?;
            destination.accept(&source, b, now)?;
        }
        destination.restore_migration_head(authorization.statement.destination_tip, &source)?;
        let legacy = LegacyReplay::verify(LegacyInputs {
            genesis: &genesis,
            history: &history,
            pow_adoption: &pow,
            earth_adoption: &earth,
            preview: &preview,
            destination_authorization: &dst_authorization,
            v1: &v1,
            source: &source,
            destination: &destination,
            finality: &finality,
            pins: pins.clone(),
        })?;
        let records = lock_records(&root.join("signer-locks"), &validators)?;
        let locks = VerifiedSignerLocks::from_canonical_records(&legacy, &records)?;
        let mut migration = authorization.verify(&legacy, &locks, accepted)?;
        migration.replay_guard = Some(workspace);
        Ok(Self {
            migration,
            _lease: lease,
        })
    }
}

type BlockIndex = Vec<(u128, Hash, PathBuf)>;
fn block_index<T: Serialize + DeserializeOwned>(
    root: &Path,
    limit: usize,
    count: usize,
    total: &mut u64,
    identify: impl Fn(&T) -> (u128, Result<Hash>),
) -> Result<BlockIndex> {
    directory(root)?;
    let mut entries = Vec::new();
    for entry in io(fs::read_dir(root))? {
        require(
            entries.len() < count && entries.len() < MAX_BLOCKS,
            "extra or excessive retained archive blocks",
        )?;
        let entry = io(entry)?;
        let name = entry
            .file_name()
            .into_string()
            .map_err(|_| "non-UTF8 archive block name")?;
        require(
            name.len() == 69 && name.ends_with(".json"),
            "unexpected archive block file",
        )?;
        let bytes = read(&entry.path(), limit)?;
        *total = total
            .checked_add(bytes.len() as u64)
            .ok_or("archive byte count overflow")?;
        require(
            *total <= MAX_BYTES,
            "migration archive total byte capacity exceeded",
        )?;
        let b: T = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
        require(
            serde_json::to_vec(&b).map_err(|e| e.to_string())? == bytes,
            "noncanonical archived block",
        )?;
        let (height, id) = identify(&b);
        let id = id?;
        require(
            name == format!("{}.json", id.to_hex()),
            "archived block filename/hash differs",
        )?;
        entries.push((height, id, entry.path()));
    }
    require(entries.len() == count, "missing retained archive block")?;
    entries.sort_unstable_by_key(|(height, id, _)| (*height, *id));
    Ok(entries)
}
fn lock_records(root: &Path, validators: &[String]) -> Result<Vec<(String, Vec<u8>)>> {
    directory(root)?;
    let mut names = Vec::with_capacity(4);
    for entry in io(fs::read_dir(root))? {
        require(names.len() < 4, "excessive signer-lock archive inventory")?;
        names.push(io(entry)?);
    }
    require(
        names.len() == 4
            && names.iter().all(|entry| {
                validators
                    .iter()
                    .any(|key| entry.file_name() == format!("{key}.json").as_str())
            }),
        "signer-lock archive inventory differs",
    )?;
    validators
        .iter()
        .map(|key| Ok((key.clone(), read(&root.join(format!("{key}.json")), 4096)?)))
        .collect()
}

impl VerifiedMigration {
    /// New private directory, immutable handoff; never writes an existing node.
    pub fn write_archive(&self, root: &Path, records: &[(String, Vec<u8>)]) -> Result<()> {
        let locks = VerifiedSignerLocks::from_canonical_records(&self.legacy, records)?;
        self.authorization
            .verify(&self.legacy, &locks, self.id()?)?;
        let source_count = self.legacy.source.history_stats().0;
        let destination_count = self.legacy.destination.history_stats().0;
        require(
            source_count <= MAX_BLOCKS && destination_count <= MAX_BLOCKS,
            "archive retained block count capacity exceeded",
        )?;
        require(
            self.legacy.inputs.genesis.len() <= INPUT_BYTES
                && self.legacy.inputs.history.len() <= INPUT_BYTES,
            "original migration input exceeds archive bound",
        )?;
        private_dir(root)?;
        write(&root.join("archive.lock"), b"")?;
        let inputs = &self.legacy.inputs;
        write(&root.join("migration.json"), self.canonical_bytes())?;
        write(&root.join("genesis.json"), &inputs.genesis)?;
        write(&root.join("history.json"), &inputs.history)?;
        json(&root.join("pow-adoption.json"), &inputs.pow)?;
        json(&root.join("earth-adoption.json"), &inputs.earth)?;
        json(&root.join("preview.json"), &inputs.preview)?;
        json(
            &root.join("destination-authorization.json"),
            &inputs.destination_authorization,
        )?;
        json(
            &root.join("destination-context.json"),
            &self.legacy.destination.migration_context(),
        )?;
        json(&root.join("old-finality.json"), &self.legacy.finality)?;
        private_dir(&root.join("signer-locks"))?;
        for (key, bytes) in records {
            write(
                &root.join("signer-locks").join(format!("{key}.json")),
                bytes,
            )?;
        }
        sync(&root.join("signer-locks"))?;
        private_dir(&root.join("source-blocks"))?;
        private_dir(&root.join("destination-blocks"))?;
        let mut total = 0u64;
        self.legacy.source.visit_migration_blocks(|block| {
            let bytes = serde_json::to_vec(&block).map_err(|e| e.to_string())?;
            total = total
                .checked_add(bytes.len() as u64)
                .ok_or("archive byte count overflow")?;
            require(total <= MAX_BYTES, "archive byte capacity exceeded")?;
            write(
                &root
                    .join("source-blocks")
                    .join(format!("{}.json", block.header.id()?.to_hex())),
                &bytes,
            )
        })?;
        self.legacy.destination.visit_migration_blocks(|block| {
            let bytes = serde_json::to_vec(&block).map_err(|e| e.to_string())?;
            total = total
                .checked_add(bytes.len() as u64)
                .ok_or("archive byte count overflow")?;
            require(total <= MAX_BYTES, "archive byte capacity exceeded")?;
            write(
                &root
                    .join("destination-blocks")
                    .join(format!("{}.json", block.header.id()?.to_hex())),
                &bytes,
            )
        })?;
        sync(&root.join("source-blocks"))?;
        sync(&root.join("destination-blocks"))?;
        // Last publication proves the writer completed; signatures and native
        // histories still determine acceptance when this directory is restored.
        json(
            &root.join("archive.json"),
            &Manifest {
                format: ARCHIVE_FORMAT.into(),
                migration_id: self.id()?,
                source_blocks: source_count,
                destination_blocks: destination_count,
            },
        )?;
        sync(root)?;
        if let Some(parent) = root.parent() {
            sync(parent)?;
        }
        Ok(())
    }
}
