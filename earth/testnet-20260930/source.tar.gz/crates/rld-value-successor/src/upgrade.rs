//! Explicit unanimous consent to a compatible implementation replacement.
//! Original consensus identity is retained only after the original adoption
//! and every new signature have been verified. This does not certify review,
//! independence, capacity, or payment safety; evidence hashes are commitments.
use crate::{
    adoption::EarthSuccessorAdoption,
    destination::pow::{authorization::DestinationGenesisAuthorization, Context},
    hash, require,
    transition::TransitionPreview,
    Result,
};
use rld_core::{verify_bytes, AdmissionHash32 as Hash};
use rld_pow::{
    transition::{Adoption, Approval},
    Chain,
};
use serde::{Deserialize, Serialize};

pub const FORMAT: &str = "RLD-EARTH-COMPATIBLE-IMPLEMENTATION-V1";
pub const STORAGE: &str = "CANONICAL-BLOCKS-FULL-REPLAY-DISPOSABLE-INDEX-V1";

pub fn implementation_source() -> Result<Hash> {
    Hash::from_hex(rld_core::implementation_source::IMPLEMENTATION_SOURCE_COMMITMENT)
        .map_err(|e| e.to_string())
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct UpgradeStatement {
    pub format: String,
    pub origin_source_sha256: Hash,
    pub implementation_source_sha256: Hash,
    pub earth_adoption_id: Hash,
    pub transition_preview_id: Hash,
    pub source_chain_id: Hash,
    pub v1_tip: Hash,
    pub storage: String,
    pub qualification_evidence_sha256: Hash,
    /// Exact existing destinations accepted by these same validators.
    /// At most 16; ordered by chain ID, never duplicate or zero.
    pub destinations: Vec<Context>,
}
impl UpgradeStatement {
    pub fn signing_bytes(&self) -> Result<Vec<u8>> {
        let mut bytes = b"RLD-EARTH-COMPATIBLE-IMPLEMENTATION-V1\0".to_vec();
        bytes.extend(serde_json::to_vec(self).map_err(|e| e.to_string())?);
        Ok(bytes)
    }
    pub fn id(&self) -> Result<Hash> {
        Ok(hash(&self.signing_bytes()?))
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct UpgradeAuthorization {
    pub statement: UpgradeStatement,
    pub approvals: Vec<Approval>,
}

/// Cannot be constructed by a caller-supplied source hash or validator list.
#[derive(Clone, Debug)]
pub struct VerifiedUpgrade {
    authorization: UpgradeAuthorization,
    canonical: Vec<u8>,
    validator_keys: Vec<String>,
}
impl UpgradeAuthorization {
    pub fn canonical_bytes(&self) -> Result<Vec<u8>> {
        serde_json::to_vec(self).map_err(|e| e.to_string())
    }
    #[allow(clippy::too_many_arguments)]
    pub fn verify(
        &self,
        genesis: &[u8],
        history: &[u8],
        original_pow: &Adoption,
        original_earth: &EarthSuccessorAdoption,
        v1: &Chain,
        preview: &TransitionPreview,
        accepted_preview: Hash,
        accepted_earth: Hash,
        accepted_upgrade: Hash,
    ) -> Result<VerifiedUpgrade> {
        let s = &self.statement;
        require(
            s.format == FORMAT
                && s.storage == STORAGE
                && !s.origin_source_sha256.is_zero()
                && s.implementation_source_sha256 == implementation_source()?
                && s.origin_source_sha256 != s.implementation_source_sha256
                && !s.qualification_evidence_sha256.is_zero(),
            "unsupported implementation upgrade or missing evidence commitment",
        )?;
        require(
            !accepted_upgrade.is_zero()
                && s.id()? == accepted_upgrade
                && !accepted_preview.is_zero()
                && preview.id()? == accepted_preview
                && s.transition_preview_id == accepted_preview
                && !accepted_earth.is_zero()
                && s.earth_adoption_id == accepted_earth
                && s.source_chain_id == v1.context.chain_id()?
                && s.v1_tip == v1.tip(),
            "upgrade identity or explicit acceptance pin differs",
        )?;
        original_earth.verify_with_source(
            genesis,
            history,
            original_pow,
            v1,
            preview,
            accepted_earth,
            s.origin_source_sha256,
        )?;
        let keys: Vec<_> = original_pow
            .approvals
            .iter()
            .map(|a| a.public_key.clone())
            .collect();
        require(
            keys.len() == 4 && self.approvals.len() == 4 && keys.windows(2).all(|p| p[0] < p[1]),
            "upgrade requires the four original sorted validators",
        )?;
        let bytes = s.signing_bytes()?;
        for (approval, key) in self.approvals.iter().zip(&keys) {
            require(
                &approval.public_key == key,
                "upgrade validator differs from original adoption",
            )?;
            verify_bytes(key, &bytes, &approval.signature)?;
        }
        require(
            s.destinations.len() <= 16
                && s.destinations
                    .windows(2)
                    .all(|p| p[0].chain_id < p[1].chain_id),
            "upgrade destination list bound or order",
        )?;
        for destination in &s.destinations {
            destination.validate()?;
            require(
                destination.source_policy.source_chain_id == s.source_chain_id
                    && destination.source_policy.accepted_v1_tip == s.v1_tip
                    && destination.source_finality.as_ref().is_some_and(|t| {
                        t.earth_adoption_id == accepted_earth && t.validator_keys == keys
                    }),
                "upgrade destination source trust differs",
            )?;
        }
        Ok(VerifiedUpgrade {
            authorization: self.clone(),
            canonical: self.canonical_bytes()?,
            validator_keys: keys,
        })
    }
}
impl VerifiedUpgrade {
    pub fn id(&self) -> Hash {
        self.authorization
            .statement
            .id()
            .expect("verified serializable statement")
    }
    pub fn origin_source(&self) -> Hash {
        self.authorization.statement.origin_source_sha256
    }
    pub fn canonical_bytes(&self) -> &[u8] {
        &self.canonical
    }
    pub fn earth_adoption_id(&self) -> Hash {
        self.authorization.statement.earth_adoption_id
    }
    pub fn validator_keys(&self) -> &[String] {
        &self.validator_keys
    }
    pub fn verify_source(&self, v1: &Chain) -> Result<()> {
        require(
            v1.context.chain_id()? == self.authorization.statement.source_chain_id
                && v1.tip() == self.authorization.statement.v1_tip,
            "upgrade source chain differs",
        )
    }
    pub fn verify_destination(&self, context: &Context) -> Result<()> {
        require(
            self.authorization.statement.destinations.contains(context),
            "destination absent from compatible upgrade authorization",
        )
    }
    pub fn verify_destination_authorization(
        &self,
        authorization: &DestinationGenesisAuthorization,
        context: &Context,
        preview: &TransitionPreview,
        accepted: Hash,
        signer: &str,
    ) -> Result<()> {
        self.verify_destination(context)?;
        require(
            preview.id()? == self.authorization.statement.transition_preview_id,
            "upgrade preview differs",
        )?;
        authorization.verify_with_source(context, preview, accepted, signer, self.origin_source())
    }
}

#[cfg(test)]
mod tests;
