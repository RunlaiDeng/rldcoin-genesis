//! First regional asset migration. Only authenticated native replay and exact
//! unanimous new signatures can construct the activation capability. Snapshots
//! and callers' claimed balances are never constructors of migrated ledgers.
use crate::{
    adoption::EarthSuccessorAdoption,
    chain::{finality::FinalityCertificate, CandidateChain},
    destination::pow::{self, authorization::DestinationGenesisAuthorization, DestinationPowChain},
    hash, require,
    transition::TransitionPreview,
    Ledger, Result,
};
use rld_core::{verify_bytes, AdmissionHash32 as Hash, AdmissionWork as Work, Amount};
use rld_fast_payments::Phase;
use rld_pow::{
    transition::{Adoption, Approval},
    Chain, Coin, OutPoint,
};
use rld_regional_rules::{SourceIssuance, TimingRules};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

pub const FORMAT: &str = "RLD-NEXT-MAINNET-ASSET-MIGRATION-V1";
pub mod archive;
fn commitment<T: Serialize + ?Sized>(domain: &[u8], value: &T) -> Result<Hash> {
    let mut b = domain.to_vec();
    b.extend(serde_json::to_vec(value).map_err(|e| e.to_string())?);
    Ok(hash(&b))
}
pub fn rules_hash() -> Hash {
    hash(include_bytes!(
        "../../../docs/spec/NEXT-MAINNET-ASSET-MIGRATION.md"
    ))
}
fn implementation() -> Result<Hash> {
    crate::upgrade::implementation_source()
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct LegacyPins {
    pub manifest: Hash,
    pub pow_adoption: Hash,
    pub earth_adoption: Hash,
    pub preview: Hash,
    pub origin_implementation: Hash,
    pub destination_authorization: Hash,
    pub destination_signer: String,
}
pub struct LegacyInputs<'a> {
    pub genesis: &'a [u8],
    pub history: &'a [u8],
    pub pow_adoption: &'a Adoption,
    pub earth_adoption: &'a EarthSuccessorAdoption,
    pub preview: &'a TransitionPreview,
    pub destination_authorization: &'a DestinationGenesisAuthorization,
    pub v1: &'a Chain,
    pub source: &'a CandidateChain,
    pub destination: &'a DestinationPowChain,
    pub finality: &'a FinalityCertificate,
    pub pins: LegacyPins,
}
#[derive(Clone)]
pub struct LegacyReplay {
    source: CandidateChain,
    destination: DestinationPowChain,
    context: rld_pow::Context,
    pins: LegacyPins,
    validators: Vec<String>,
    finality: FinalityCertificate,
    inputs: OriginalInputs,
}
#[derive(Clone)]
struct OriginalInputs {
    genesis: Vec<u8>,
    history: Vec<u8>,
    pow: Adoption,
    earth: EarthSuccessorAdoption,
    preview: TransitionPreview,
    destination_authorization: DestinationGenesisAuthorization,
}
impl LegacyReplay {
    pub fn verify(input: LegacyInputs<'_>) -> Result<Self> {
        let p = &input.pins;
        require(
            !p.origin_implementation.is_zero(),
            "missing pinned old implementation",
        )?;
        let context = input.pow_adoption.verify_with_pinned_release_source(
            input.genesis,
            input.history,
            p.manifest,
            p.pow_adoption,
            input.preview.v1_source_sha256,
        )?;
        require(
            input.v1.context == context && context.regional.is_none() && context.legacy_height == 0,
            "first migration requires the authenticated original 600-second genesis",
        )?;
        require(
            input.preview.id()? == p.preview,
            "old preview acceptance differs",
        )?;
        input.earth_adoption.verify_with_source(
            input.genesis,
            input.history,
            input.pow_adoption,
            input.v1,
            input.preview,
            p.earth_adoption,
            p.origin_implementation,
        )?;
        let validators: Vec<_> = input
            .pow_adoption
            .approvals
            .iter()
            .map(|a| a.public_key.clone())
            .collect();
        require(
            input.source.migration().is_none()
                && input.source.timing().seconds == 600
                && input.source.chain_id() == context.chain_id()?
                && input.source.v1_tip() == input.v1.tip()
                && input.source.anchor_commitment()?
                    == Ledger::from_replayed_pow_chain(input.v1)?.commitment()?
                && input.source.history_healthy()
                && input.destination.history_healthy()
                && !input.destination.halted(),
            "old native histories or replay anchor differ",
        )?;
        let dest_context = input.destination.migration_context();
        require(
            dest_context.regional.is_none()
                && dest_context.migration.is_none()
                && dest_context.source_policy.source_chain_id == input.source.chain_id()
                && dest_context.source_policy.accepted_v1_tip == input.v1.tip()
                && dest_context.source_policy.minimum_confirmations >= 12
                && dest_context.source_finality.as_ref().is_some_and(|t| {
                    t.earth_adoption_id == p.earth_adoption && t.validator_keys == validators
                }),
            "old destination does not preserve adopted source finality",
        )?;
        input.destination_authorization.verify_with_source(
            &dest_context,
            input.preview,
            p.destination_authorization,
            &p.destination_signer,
            p.origin_implementation,
        )?;
        require(
            input.destination.genesis()
                == dest_context.genesis_with_source(p.origin_implementation)?,
            "old destination genesis differs from signed authorization",
        )?;
        input
            .finality
            .verify(input.source, p.earth_adoption, &validators)?;
        require(
            input.source.finalized()
                == Some((
                    input.finality.statement.block,
                    input.finality.statement.height,
                )),
            "installed old source finality differs from retained certificate",
        )?;
        let mut audit = input.destination.state().clone();
        audit.audit_source(input.source)?;
        input.source.state().root()?;
        input.destination.state().root()?;
        require(
            input
                .source
                .state()
                .escrows
                .values()
                .all(|e| e.phase == Phase::Settled)
                && input.source.state().reserved_fees.is_empty(),
            "old channels must exit under their original protection before migration",
        )?;
        require(
            input
                .source
                .state()
                .exports
                .values()
                .all(|r| r.command.intent.destination_chain_id == input.destination.chain_id()),
            "a destination archive is required for every existing export route",
        )?;
        SourceIssuance::from_emission(
            input.source.height(),
            input.source.state().commitment()?.emitted,
            rld_regional_rules::RegionTiming::new(600).map_err(|e| e.to_string())?,
        )
        .map_err(|e| e.to_string())?;
        Ok(Self {
            source: input.source.clone(),
            destination: input.destination.clone(),
            context,
            pins: input.pins,
            validators,
            finality: input.finality.clone(),
            inputs: OriginalInputs {
                genesis: input.genesis.to_vec(),
                history: input.history.to_vec(),
                pow: input.pow_adoption.clone(),
                earth: input.earth_adoption.clone(),
                preview: input.preview.clone(),
                destination_authorization: input.destination_authorization.clone(),
            },
        })
    }
}

/// Canonical persisted signer-lock record used by the existing signing tool.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct SignerLock {
    pub source_chain_id: Hash,
    pub earth_adoption_id: Hash,
    pub certificate_id: Hash,
    #[serde(with = "rld_pow::decimal")]
    pub height: u128,
    pub block: Hash,
}
#[derive(Clone, Debug)]
pub struct VerifiedSignerLocks {
    digest: Hash,
    source: Hash,
    certificate: Hash,
}
impl VerifiedSignerLocks {
    /// The ceremony caller reads its four actual, privately locked files.
    /// This checks exact content and binding, not custody or independence.
    pub fn from_canonical_records(
        legacy: &LegacyReplay,
        records: &[(String, Vec<u8>)],
    ) -> Result<Self> {
        require(records.len() == 4, "four retained signer locks required")?;
        let expected = SignerLock {
            source_chain_id: legacy.source.chain_id(),
            earth_adoption_id: legacy.pins.earth_adoption,
            certificate_id: legacy.finality.statement.id()?,
            height: legacy.finality.statement.height,
            block: legacy.finality.statement.block,
        };
        for ((key, bytes), expected_key) in records.iter().zip(&legacy.validators) {
            require(
                key == expected_key && bytes.len() <= 4096,
                "signer lock key or resource bound differs",
            )?;
            let lock: SignerLock = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
            require(
                serde_json::to_vec(&lock).map_err(|e| e.to_string())? == *bytes && lock == expected,
                "signer lock differs from installed old finality",
            )?;
        }
        Ok(Self {
            digest: commitment(b"RLD-NEXT-MIGRATION-SIGNER-LOCKS\0", records)?,
            source: legacy.source.chain_id(),
            certificate: legacy.finality.statement.id()?,
        })
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Retirement {
    pub old_source_chain_id: Hash,
    pub old_state_root: Hash,
    pub old_export_root: Hash,
    pub old_export_count: u32,
    pub retired: Amount,
}
impl Retirement {
    pub(crate) fn validate(&self) -> Result<()> {
        require(
            !self.old_source_chain_id.is_zero()
                && !self.old_state_root.is_zero()
                && !self.old_export_root.is_zero()
                && self.retired.0 <= rld_core::TOTAL_SUPPLY_RUNLAI
                && self.old_export_count as usize <= crate::MAX_EXPORTS,
            "invalid migrated export retirement",
        )
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct DestinationIdentity {
    pub migration_id: Hash,
    pub asset_map_root: Hash,
    pub legacy_genesis: Hash,
    pub legacy_state_root: Hash,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct DestinationInheritance {
    pub identity: DestinationIdentity,
    pub legacy_source: Hash,
    pub legacy_destination: Hash,
    pub imported_total: Amount,
    pub imported_keys: Vec<(Hash, Hash)>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Options {
    pub timing: TimingRules,
    pub source_started_at: u64,
    pub destination_started_at: u64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Statement {
    pub format: String,
    pub rules_sha256: Hash,
    pub implementation_source: Hash,
    pub legacy_pins: LegacyPins,
    pub options: Options,
    pub source_tip: Hash,
    #[serde(with = "rld_pow::decimal")]
    pub source_height: u128,
    pub source_work: Work,
    pub source_state_root: Hash,
    pub source_history_root: Hash,
    pub source_finality_id: Hash,
    pub signer_locks_sha256: Hash,
    pub destination_tip: Hash,
    #[serde(with = "rld_pow::decimal")]
    pub destination_height: u128,
    pub destination_work: Work,
    pub destination_genesis: Hash,
    pub destination_state_root: Hash,
    pub destination_history_root: Hash,
    pub source_asset_map_root: Hash,
    pub destination_asset_map_root: Hash,
    pub destination_imported_keys_root: Hash,
    pub source_emitted: Amount,
    pub source_retired: Amount,
    pub destination_imported: Amount,
    pub source_initial_target: Work,
    pub destination_initial_target: Work,
    pub source_started_at: u64,
    pub retire_old_network: bool,
}
impl Statement {
    pub fn draft(
        legacy: &LegacyReplay,
        locks: &VerifiedSignerLocks,
        options: Options,
    ) -> Result<Self> {
        options.timing.validate().map_err(|e| e.to_string())?;
        require(
            locks.source == legacy.source.chain_id()
                && locks.certificate == legacy.finality.statement.id()?,
            "signer locks belong to another legacy replay",
        )?;
        let last_source = legacy
            .source
            .block(legacy.source.tip())
            .ok_or("migration needs a selected source block")?;
        let last_destination = legacy.destination.block(legacy.destination.tip());
        require(
            options.source_started_at >= last_source.header.timestamp
                && options.destination_started_at
                    >= last_destination
                        .as_ref()
                        .map_or(legacy.destination.migration_context().started_at, |b| {
                            b.header.timestamp
                        }),
            "activation clock precedes native cut",
        )?;
        let source_coins = remap_coins(
            legacy.source.chain_id(),
            &legacy.source.state().coins,
            legacy.source.height(),
            options.timing.source.seconds,
        )?;
        let (old_dest_coins, old_keys) = legacy.destination.state().migration_assets();
        let dest_coins = remap_coins(
            legacy.destination.chain_id(),
            &old_dest_coins,
            legacy.destination.height(),
            options.timing.destination.seconds,
        )?;
        let c = legacy.source.state().commitment()?;
        require(
            legacy.destination.state().imported_total().0 <= c.retired.0,
            "destination issuance is not backed by permanent source retirement",
        )?;
        let source_initial_target = crate::chain::scale_target(
            last_source.header.target,
            options.timing.source.seconds,
            600,
        )?;
        let destination_initial_target = crate::chain::scale_target(
            last_destination
                .as_ref()
                .map_or(legacy.destination.migration_context().initial_target, |b| {
                    b.header.target
                }),
            options.timing.destination.seconds,
            600,
        )?;
        Ok(Self {
            format: FORMAT.into(),
            rules_sha256: rules_hash(),
            implementation_source: implementation()?,
            legacy_pins: legacy.pins.clone(),
            source_tip: legacy.source.tip(),
            source_height: legacy.source.height(),
            source_work: legacy.source.chainwork(),
            source_state_root: c.root()?,
            source_history_root: legacy.source.migration_history()?,
            source_finality_id: legacy.finality.statement.id()?,
            signer_locks_sha256: locks.digest,
            destination_tip: legacy.destination.tip(),
            destination_height: legacy.destination.height(),
            destination_work: legacy.destination.chainwork(),
            destination_genesis: legacy.destination.genesis(),
            destination_state_root: legacy.destination.state().root()?,
            destination_history_root: legacy.destination.migration_history()?,
            source_asset_map_root: coins_root(&source_coins)?,
            destination_asset_map_root: coins_root(&dest_coins)?,
            destination_imported_keys_root: commitment(
                b"RLD-NEXT-MIGRATION-IMPORT-KEYS\0",
                &old_keys,
            )?,
            source_emitted: c.emitted,
            source_retired: c.retired,
            destination_imported: legacy.destination.state().imported_total(),
            source_initial_target,
            destination_initial_target,
            source_started_at: options.source_started_at,
            options,
            retire_old_network: true,
        })
    }
    pub fn signing_bytes(&self) -> Result<Vec<u8>> {
        let mut b = b"RLD-NEXT-MAINNET-ASSET-MIGRATION-V1\0".to_vec();
        b.extend(serde_json::to_vec(self).map_err(|e| e.to_string())?);
        Ok(b)
    }
    pub fn id(&self) -> Result<Hash> {
        Ok(hash(&self.signing_bytes()?))
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Authorization {
    pub statement: Statement,
    pub approvals: Vec<Approval>,
}
#[derive(Clone)]
pub struct VerifiedMigration {
    authorization: Authorization,
    legacy: LegacyReplay,
    canonical: Vec<u8>,
    replay_guard: Option<std::sync::Arc<archive::ReplayWorkspace>>,
}
impl std::fmt::Debug for VerifiedMigration {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("VerifiedMigration")
            .field("id", &self.id())
            .finish()
    }
}
impl Authorization {
    pub fn verify(
        &self,
        legacy: &LegacyReplay,
        locks: &VerifiedSignerLocks,
        accepted: Hash,
    ) -> Result<VerifiedMigration> {
        let expected = Statement::draft(legacy, locks, self.statement.options.clone())?;
        require(
            self.statement == expected && !accepted.is_zero() && self.statement.id()? == accepted,
            "migration assets, rules, source, cut or acceptance differ from native replay",
        )?;
        require(
            self.approvals.len() == 4,
            "every original validator must adopt the migration",
        )?;
        let b = self.statement.signing_bytes()?;
        for (approval, key) in self.approvals.iter().zip(&legacy.validators) {
            require(
                &approval.public_key == key,
                "migration validators differ from original adoption",
            )?;
            verify_bytes(key, &b, &approval.signature)?;
        }
        Ok(VerifiedMigration {
            authorization: self.clone(),
            legacy: legacy.clone(),
            canonical: serde_json::to_vec(self).map_err(|e| e.to_string())?,
            replay_guard: None,
        })
    }
}

pub fn remapped_point(old_chain: Hash, point: &OutPoint) -> Result<OutPoint> {
    Ok(OutPoint {
        transaction: commitment(b"RLD-NEXT-MIGRATED-OUTPOINT\0", &(old_chain, point))?,
        index: 0,
    })
}
fn remaining_maturity(old_height: u128, spendable: u128, seconds: u64) -> Result<u128> {
    let remaining = spendable.saturating_sub(old_height);
    let duration = remaining
        .checked_mul(600)
        .ok_or("old maturity time overflow")?;
    Ok(duration.div_ceil(seconds as u128))
}
fn remap_coins(
    old_chain: Hash,
    coins: &BTreeMap<OutPoint, Coin>,
    height: u128,
    seconds: u64,
) -> Result<BTreeMap<OutPoint, Coin>> {
    coins
        .iter()
        .map(|(point, coin)| {
            Ok((
                remapped_point(old_chain, point)?,
                Coin {
                    output: coin.output.clone(),
                    spendable_height: remaining_maturity(height, coin.spendable_height, seconds)?,
                },
            ))
        })
        .collect()
}
fn coins_root(coins: &BTreeMap<OutPoint, Coin>) -> Result<Hash> {
    commitment(
        b"RLD-NEXT-MIGRATION-ASSET-MAP\0",
        &coins.iter().collect::<Vec<_>>(),
    )
}
impl VerifiedMigration {
    pub fn id(&self) -> Result<Hash> {
        self.authorization.statement.id()
    }
    pub fn statement(&self) -> &Statement {
        &self.authorization.statement
    }
    pub fn canonical_bytes(&self) -> &[u8] {
        &self.canonical
    }
    pub fn validator_keys(&self) -> &[String] {
        &self.legacy.validators
    }
    pub fn legacy_source(&self) -> &CandidateChain {
        &self.legacy.source
    }
    pub fn legacy_destination(&self) -> &DestinationPowChain {
        &self.legacy.destination
    }
    pub(crate) fn manifest_pin(&self) -> Hash {
        self.legacy.pins.manifest
    }
    pub fn source_chain_id(&self) -> Result<Hash> {
        commitment(b"RLD-NEXT-MIGRATED-SOURCE-IDENTITY\0", &self.id()?)
    }
    pub fn source_genesis(&self) -> Result<Hash> {
        commitment(
            b"RLD-NEXT-MIGRATED-SOURCE-GENESIS\0",
            &(
                self.id()?,
                self.source_chain_id()?,
                self.statement().source_asset_map_root,
            ),
        )
    }
    pub fn issuance(&self) -> Result<SourceIssuance> {
        SourceIssuance::from_emission(
            self.statement().source_height,
            self.statement().source_emitted,
            self.statement().options.timing.source.clone(),
        )
        .map_err(|e| e.to_string())
    }
    pub(crate) fn source_context(&self) -> rld_pow::Context {
        let mut c = self.legacy.context.clone();
        c.regional = Some(self.statement().options.timing.source.clone());
        c.started_at = self.statement().options.source_started_at;
        c.initial_target = self.statement().source_initial_target;
        c
    }
    pub(crate) fn source_ledger(&self) -> Result<Ledger> {
        let old = self.legacy.source.state();
        let c = old.commitment()?;
        let ledger = Ledger {
            timing: self.statement().options.timing.source.clone(),
            chain_id: self.source_chain_id()?,
            v1_tip: self.source_genesis()?,
            v1_root: c.root()?,
            anchor_height: 0,
            emitted: c.emitted,
            coins: remap_coins(
                old.chain_id,
                &old.coins,
                self.statement().source_height,
                self.statement().options.timing.source.seconds,
            )?,
            escrows: BTreeMap::new(),
            reserved_fees: BTreeMap::new(),
            exports: BTreeMap::new(),
            migration_retirement: Some(Retirement {
                old_source_chain_id: old.chain_id,
                old_state_root: c.root()?,
                old_export_root: c.export_root,
                old_export_count: c.export_count,
                retired: c.retired,
            }),
        };
        require(
            coins_root(&ledger.coins)? == self.statement().source_asset_map_root,
            "source migration asset map differs",
        )?;
        ledger.root()?;
        Ok(ledger)
    }
    pub fn destination_context(&self) -> Result<pow::Context> {
        let identity = DestinationIdentity {
            migration_id: self.id()?,
            asset_map_root: self.statement().destination_asset_map_root,
            legacy_genesis: self.statement().destination_genesis,
            legacy_state_root: self.statement().destination_state_root,
        };
        let mut context = pow::Context {
            chain_id: Hash::ZERO,
            source_policy: crate::chain::ObservationPolicy {
                source_chain_id: self.source_chain_id()?,
                accepted_v1_tip: self.source_genesis()?,
                minimum_confirmations: self
                    .statement()
                    .options
                    .timing
                    .source
                    .finality_confirmations as u128,
                minimum_cumulative_work: self
                    .statement()
                    .source_work
                    .checked_add(rld_core::header_work(
                        self.statement().source_initial_target,
                    ))
                    .ok_or("migration source work overflow")?,
            },
            started_at: self.statement().options.destination_started_at,
            initial_target: self.statement().destination_initial_target,
            regional: Some(self.statement().options.timing.destination.clone()),
            migration: Some(identity),
            source_finality: Some(pow::SourceFinalityTrust {
                earth_adoption_id: self.id()?,
                validator_keys: self.legacy.validators.clone(),
            }),
        };
        context.chain_id = context.regional_chain_id(implementation()?)?;
        context.validate()?;
        Ok(context)
    }
    pub(crate) fn destination_state(&self) -> Result<crate::destination::DestinationSimulation> {
        self.legacy.destination.state().migrate(self)
    }
    pub(crate) fn mapped_destination_coins(&self) -> Result<BTreeMap<OutPoint, Coin>> {
        let (coins, _) = self.legacy.destination.state().migration_assets();
        let mapped = remap_coins(
            self.legacy.destination.chain_id(),
            &coins,
            self.statement().destination_height,
            self.statement().options.timing.destination.seconds,
        )?;
        require(
            coins_root(&mapped)? == self.statement().destination_asset_map_root,
            "destination asset mapping differs",
        )?;
        Ok(mapped)
    }
    pub(crate) fn legacy_record(
        &self,
        source: &CandidateChain,
        bundle: &rld_cross_region::ProofBundle,
        certificate: &FinalityCertificate,
    ) -> Result<rld_cross_region::value::ExportRecord> {
        require(
            source
                .migration()
                .is_some_and(|m| m.id().ok() == self.id().ok())
                && source.chain_id() == self.source_chain_id()?,
            "legacy bridge migration differs",
        )?;
        let old = &self.legacy.source;
        require(
            old.is_selected_ancestor(bundle.source_checkpoint)?
                && bundle.source_chain_id == old.chain_id()
                && bundle.destination_chain_id == self.legacy.destination.chain_id(),
            "legacy export route or frozen branch differs",
        )?;
        let record = old.replay_known_export_bundle(bundle)?;
        require(
            old.state().export_record(bundle.export_id) == Some(&record),
            "legacy export is absent from the frozen source assets",
        )?;
        let depth = old
            .height()
            .checked_sub(bundle.source_height)
            .and_then(|n| n.checked_add(1))
            .ok_or("legacy checkpoint height differs")?;
        let remaining = remaining_maturity(
            0,
            12u128.saturating_sub(depth),
            self.statement().options.timing.source.seconds,
        )?;
        certificate.verify(source, self.id()?, &self.legacy.validators)?;
        require(
            certificate.statement.height >= remaining
                && source.finalized().is_some_and(|(block, _)| {
                    source
                        .is_ancestor_of(certificate.statement.block, block)
                        .unwrap_or(false)
                }),
            "legacy checkpoint has not preserved its remaining old finality wait",
        )?;
        Ok(record)
    }
}

#[cfg(test)]
mod tests;
