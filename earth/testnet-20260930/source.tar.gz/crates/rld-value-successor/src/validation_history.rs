//! Disposable disk index of entries produced by full consensus replay.
//!
//! The canonical block files remain authoritative. This index is rebuilt on
//! every open, never accepted as a checkpoint. A process-only MAC key detects
//! changed cached bytes. Clones are stable prefix views with bounded private
//! overlays, so preparing a block cannot publish it to another reader.
use crate::{require, Result};
use hmac::{Hmac, Mac};
use rand::{rngs::OsRng, RngCore};
use rld_core::AdmissionHash32 as Hash;
use rusqlite::{params, Connection, OptionalExtension};
use serde::{de::DeserializeOwned, Serialize};
use sha2::Sha256;
use std::{
    collections::{BTreeMap, VecDeque},
    fmt,
    fs::{self, OpenOptions},
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
};

const CACHE_ENTRIES: usize = 256;
const CACHE_BYTES: usize = 4 * 1024 * 1024;
const ENTRY_BYTES: usize = 4 * 1024 * 1024;
const OVERLAY_ENTRIES: usize = 256;

pub(crate) struct Disk<E> {
    db: Connection,
    path: PathBuf,
    key: [u8; 32],
    count: u64,
    cache: BTreeMap<Hash, (u64, Arc<E>, usize)>,
    order: VecDeque<Hash>,
    cache_bytes: usize,
    error: Option<String>,
}
impl<E> Drop for Disk<E> {
    fn drop(&mut self) {
        // The directory lock prevents another writer from reopening this store.
        // A killed process can leave only a disposable index, never a new chain.
        let _ = fs::remove_file(&self.path);
    }
}

pub(crate) enum History<E> {
    Memory(BTreeMap<Hash, Arc<E>>),
    Disk {
        inner: Arc<Mutex<Disk<E>>>,
        visible: u64,
        writer: bool,
        overlay: BTreeMap<Hash, Arc<E>>,
    },
}
impl<E> fmt::Debug for History<E> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Memory(entries) => f
                .debug_struct("MemoryHistory")
                .field("entries", &entries.len())
                .finish(),
            Self::Disk {
                visible,
                writer,
                overlay,
                ..
            } => f
                .debug_struct("DiskHistory")
                .field("visible", visible)
                .field("writer", writer)
                .field("overlay", &overlay.len())
                .finish(),
        }
    }
}
impl<E> Default for History<E> {
    fn default() -> Self {
        Self::Memory(BTreeMap::new())
    }
}
impl<E> Clone for History<E> {
    fn clone(&self) -> Self {
        match self {
            Self::Memory(entries) => Self::Memory(entries.clone()),
            Self::Disk {
                inner,
                visible,
                overlay,
                ..
            } => Self::Disk {
                inner: inner.clone(),
                visible: *visible,
                writer: false,
                overlay: overlay.clone(),
            },
        }
    }
}

fn io<T>(r: std::io::Result<T>) -> Result<T> {
    r.map_err(|e| e.to_string())
}
fn sql<T>(r: rusqlite::Result<T>) -> Result<T> {
    r.map_err(|e| format!("validation index: {e}"))
}

impl<E: Serialize + DeserializeOwned> Disk<E> {
    fn mac(&self, id: Hash, sequence: u64, bytes: &[u8]) -> Result<Hmac<Sha256>> {
        let mut mac = Hmac::<Sha256>::new_from_slice(&self.key).map_err(|e| e.to_string())?;
        mac.update(b"RLD-REPLAY-CACHE-V1\0");
        mac.update(&id.0);
        mac.update(&sequence.to_be_bytes());
        mac.update(&(bytes.len() as u64).to_be_bytes());
        mac.update(bytes);
        Ok(mac)
    }
    fn ensure_healthy(&self) -> Result<()> {
        match &self.error {
            Some(e) => Err(format!("validation index stopped: {e}")),
            None => Ok(()),
        }
    }
    fn remember(&mut self, id: Hash, sequence: u64, entry: Arc<E>, size: usize) {
        if size > CACHE_BYTES || self.cache.contains_key(&id) {
            return;
        }
        while self.cache.len() >= CACHE_ENTRIES || self.cache_bytes + size > CACHE_BYTES {
            let Some(old) = self.order.pop_front() else {
                break;
            };
            if let Some((_, _, n)) = self.cache.remove(&old) {
                self.cache_bytes -= n;
            }
        }
        self.cache_bytes += size;
        self.order.push_back(id);
        self.cache.insert(id, (sequence, entry, size));
    }
    fn get_inner(&mut self, id: Hash, visible: u64) -> Result<Option<Arc<E>>> {
        self.ensure_healthy()?;
        if let Some((sequence, entry, _)) = self.cache.get(&id) {
            return Ok((*sequence <= visible).then(|| entry.clone()));
        }
        let row: Option<(i64, Vec<u8>, Vec<u8>)> = sql(self.db.prepare_cached(
            "SELECT seq, body, mac FROM entries WHERE id=?1 AND seq<=?2 AND length(body)<=?3",
        ))?
        .query_row(
            params![id.0.as_slice(), visible as i64, ENTRY_BYTES as i64],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)),
        )
        .optional()
        .map_err(|e| e.to_string())?;
        let Some((sequence, bytes, tag)) = row else {
            return Ok(None);
        };
        let sequence = u64::try_from(sequence).map_err(|_| "negative validation index sequence")?;
        self.mac(id, sequence, &bytes)?
            .verify_slice(&tag)
            .map_err(|_| "validation index authentication failed")?;
        let entry: E = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
        require(
            serde_json::to_vec(&entry).map_err(|e| e.to_string())? == bytes,
            "noncanonical validation index entry",
        )?;
        let entry = Arc::new(entry);
        self.remember(id, sequence, entry.clone(), bytes.len());
        Ok(Some(entry))
    }
    fn append_inner(&mut self, id: Hash, entry: Arc<E>, expected_count: u64) -> Result<u64> {
        self.ensure_healthy()?;
        require(
            self.count == expected_count,
            "stale validation index writer",
        )?;
        let bytes = serde_json::to_vec(entry.as_ref()).map_err(|e| e.to_string())?;
        require(
            bytes.len() <= ENTRY_BYTES,
            "validation index entry byte bound",
        )?;
        let sequence = self
            .count
            .checked_add(1)
            .filter(|n| *n <= i64::MAX as u64)
            .ok_or("validation index sequence exhausted")?;
        let tag = self.mac(id, sequence, &bytes)?.finalize().into_bytes();
        sql(self
            .db
            .prepare_cached("INSERT INTO entries(seq,id,body,mac) VALUES(?1,?2,?3,?4)"))?
        .execute(params![
            sequence as i64,
            id.0.as_slice(),
            bytes,
            tag.as_slice()
        ])
        .map_err(|e| e.to_string())?;
        self.count = sequence;
        self.remember(id, sequence, entry, bytes.len());
        Ok(sequence)
    }
}

impl<E: Serialize + DeserializeOwned> History<E> {
    /// Caller holds the canonical store's exclusive process lock.
    pub(crate) fn disk(root: &Path) -> Result<Self> {
        let dir = root.join("validation-cache");
        if dir.exists() {
            let meta = io(fs::symlink_metadata(&dir))?;
            require(
                meta.is_dir() && !meta.file_type().is_symlink(),
                "unsafe validation cache directory",
            )?;
        } else {
            io(fs::create_dir(&dir))?;
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            io(fs::set_permissions(&dir, fs::Permissions::from_mode(0o700)))?;
        }
        for item in io(fs::read_dir(&dir))? {
            let item = io(item)?;
            let name = item.file_name();
            let name = name.to_str().ok_or("unsafe cache name")?;
            let valid = name.len() == 39
                && name.ends_with(".sqlite")
                && name[..32].bytes().all(|b| b.is_ascii_hexdigit());
            let meta = io(fs::symlink_metadata(item.path()))?;
            require(
                valid && meta.is_file() && !meta.file_type().is_symlink(),
                "unexpected disposable cache entry",
            )?;
            #[cfg(unix)]
            {
                use std::os::unix::fs::MetadataExt;
                require(meta.nlink() == 1, "linked validation cache")?;
            }
            io(fs::remove_file(item.path()))?;
        }
        let mut key = [0; 32];
        OsRng.fill_bytes(&mut key);
        let mut nonce = [0; 16];
        OsRng.fill_bytes(&mut nonce);
        let path = dir.join(format!("{}.sqlite", hex::encode(nonce)));
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        let file = io(options.open(&path))?;
        drop(file);
        let db = sql(Connection::open(&path))?;
        // This is a replay cache, never recovery authority. Canonical files use
        // fsync before acknowledgement. Rebuilding removes all cache contents.
        sql(db.execute_batch("PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA mmap_size=0; PRAGMA cache_size=-4096; PRAGMA temp_store=FILE; CREATE TABLE entries(seq INTEGER PRIMARY KEY, id BLOB NOT NULL UNIQUE CHECK(length(id)=32), body BLOB NOT NULL, mac BLOB NOT NULL CHECK(length(mac)=32));"))?;
        Ok(Self::Disk {
            inner: Arc::new(Mutex::new(Disk {
                db,
                path,
                key,
                count: 0,
                cache: BTreeMap::new(),
                order: VecDeque::new(),
                cache_bytes: 0,
                error: None,
            })),
            visible: 0,
            writer: true,
            overlay: BTreeMap::new(),
        })
    }
    pub(crate) fn get(&self, id: &Hash) -> Result<Option<Arc<E>>> {
        match self {
            Self::Memory(entries) => Ok(entries.get(id).cloned()),
            Self::Disk {
                inner,
                visible,
                overlay,
                ..
            } => {
                let mut disk = inner.lock().map_err(|_| "validation index lock poisoned")?;
                disk.ensure_healthy()?;
                if let Some(entry) = overlay.get(id) {
                    return Ok(Some(entry.clone()));
                }
                let result = disk.get_inner(*id, *visible);
                if let Err(e) = &result {
                    disk.error = Some(e.clone());
                }
                result
            }
        }
    }
    #[cfg(test)]
    pub(crate) fn get_mut(&mut self, id: &Hash) -> Option<&mut E>
    where
        E: Clone,
    {
        match self {
            Self::Memory(entries) => entries.get_mut(id).map(Arc::make_mut),
            Self::Disk { .. } => None,
        }
    }
    pub(crate) fn contains_key(&self, id: &Hash) -> Result<bool> {
        Ok(self.get(id)?.is_some())
    }
    pub(crate) fn insert(&mut self, id: Hash, entry: E) -> Result<()> {
        require(!self.contains_key(&id)?, "duplicate validation entry")?;
        let entry = Arc::new(entry);
        match self {
            Self::Memory(entries) => {
                entries.insert(id, entry);
                Ok(())
            }
            Self::Disk {
                inner,
                visible,
                writer,
                overlay,
            } => {
                if !*writer {
                    require(
                        overlay.len() < OVERLAY_ENTRIES,
                        "speculative history overlay bound",
                    )?;
                    overlay.insert(id, entry);
                    return Ok(());
                }
                let mut disk = inner.lock().map_err(|_| "validation index lock poisoned")?;
                let result = disk.append_inner(id, entry, *visible);
                match result {
                    Ok(sequence) => {
                        *visible = sequence;
                        Ok(())
                    }
                    Err(e) => {
                        disk.error = Some(e.clone());
                        Err(e)
                    }
                }
            }
        }
    }
    /// Promote a validated private overlay only after canonical persistence.
    /// Failure poisons the shared index and requires full native-history replay.
    pub(crate) fn promote(&mut self) -> Result<()> {
        if let Self::Disk {
            inner,
            visible,
            writer,
            overlay,
        } = self
        {
            let mut disk = inner.lock().map_err(|_| "validation index lock poisoned")?;
            disk.ensure_healthy()?;
            require(
                disk.count == *visible,
                "cannot publish stale history snapshot",
            )?;
            for (id, entry) in overlay.iter() {
                match disk.append_inner(*id, entry.clone(), *visible) {
                    Ok(sequence) => *visible = sequence,
                    Err(e) => {
                        disk.error = Some(e.clone());
                        return Err(e);
                    }
                }
            }
            overlay.clear();
            *writer = true;
        }
        Ok(())
    }
    /// Enumerate the authenticated retained prefix, including unselected forks.
    /// Used for migration commitments; each resulting body is still checked by get().
    pub(crate) fn ids(&self) -> Result<Vec<Hash>> {
        let ids = match self {
            Self::Memory(entries) => entries.keys().copied().collect::<Vec<_>>(),
            Self::Disk {
                inner,
                visible,
                overlay,
                ..
            } => {
                let disk = inner.lock().map_err(|_| "validation index lock poisoned")?;
                disk.ensure_healthy()?;
                let mut query = sql(disk
                    .db
                    .prepare("SELECT id FROM entries WHERE seq <= ?1 ORDER BY id"))?;
                let rows = sql(query.query_map([*visible as i64], |row| row.get::<_, Vec<u8>>(0)))?;
                let mut ids = Vec::new();
                for row in rows {
                    require(
                        ids.len() < *visible as usize,
                        "retained history exceeds authenticated prefix",
                    )?;
                    let raw = sql(row)?;
                    ids.push(Hash(
                        raw.try_into().map_err(|_| "invalid retained entry ID")?,
                    ));
                }
                ids.extend(overlay.keys().copied());
                ids.sort_unstable();
                ids
            }
        };
        require(
            ids.len() == self.len() && ids.windows(2).all(|p| p[0] < p[1]),
            "retained history identity count or order differs",
        )?;
        Ok(ids)
    }
    pub(crate) fn len(&self) -> usize {
        match self {
            Self::Memory(entries) => entries.len(),
            Self::Disk {
                visible, overlay, ..
            } => *visible as usize + overlay.len(),
        }
    }
    pub(crate) fn is_disk(&self) -> bool {
        matches!(self, Self::Disk { .. })
    }
    pub(crate) fn healthy(&self) -> bool {
        match self {
            Self::Memory(_) => true,
            Self::Disk { inner, .. } => inner.lock().is_ok_and(|d| d.error.is_none()),
        }
    }
    pub(crate) fn stats(&self) -> (usize, usize, usize) {
        match self {
            Self::Memory(entries) => (entries.len(), entries.len(), 0),
            Self::Disk { inner, .. } => inner
                .lock()
                .map(|d| (self.len(), d.cache.len(), d.cache_bytes))
                .unwrap_or((self.len(), 0, 0)),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde::{Deserialize, Serialize};
    #[derive(Debug, Serialize, Deserialize, PartialEq)]
    struct Item {
        number: u64,
        body: String,
    }
    fn id(n: u64) -> Hash {
        let mut b = [0; 32];
        b[24..].copy_from_slice(&n.to_be_bytes());
        Hash(b)
    }
    fn root() -> PathBuf {
        let mut nonce = [0; 16];
        OsRng.fill_bytes(&mut nonce);
        let p = std::env::temp_dir().join(format!("rld-validation-index-{}", hex::encode(nonce)));
        fs::create_dir(&p).unwrap();
        p
    }
    fn item(n: u64) -> Item {
        Item {
            number: n,
            body: "test".into(),
        }
    }
    #[test]
    fn snapshot_and_prepared_overlay_are_isolated_until_promoted() {
        let root = root();
        let mut history = History::disk(&root).unwrap();
        history.insert(id(1), item(1)).unwrap();
        let old = history.clone();
        let mut prepared = history.clone();
        prepared.insert(id(2), item(2)).unwrap();
        assert_eq!(old.ids().unwrap(), vec![id(1)]);
        assert_eq!(prepared.ids().unwrap(), vec![id(1), id(2)]);
        assert!(history.get(&id(2)).unwrap().is_none());
        prepared.promote().unwrap();
        history = prepared;
        assert_eq!(history.get(&id(2)).unwrap().unwrap().number, 2);
        assert_eq!(old.ids().unwrap(), vec![id(1)]);
        assert_eq!(history.ids().unwrap(), vec![id(1), id(2)]);
        assert!(old.get(&id(2)).unwrap().is_none());
        let mut stale = old.clone();
        stale.insert(id(3), item(3)).unwrap();
        assert!(stale.promote().is_err());
        assert!(history.healthy());
        drop(stale);
        drop(old);
        drop(history);
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn disk_cache_is_bounded_and_corruption_stops_all_views() {
        let root = root();
        let mut history = History::disk(&root).unwrap();
        for n in 1..600 {
            history
                .insert(
                    id(n),
                    Item {
                        number: n,
                        body: "x".repeat(20_000),
                    },
                )
                .unwrap();
        }
        let stats = history.stats();
        assert_eq!(stats.0, 599);
        assert!(stats.1 <= CACHE_ENTRIES && stats.2 <= CACHE_BYTES);
        let clone = history.clone();
        if let History::Disk { inner, .. } = &history {
            let d = inner.lock().unwrap();
            d.db.execute(
                "UPDATE entries SET body=?1 WHERE id=?2",
                params![serde_json::to_vec(&item(999)).unwrap(), id(1).0.as_slice()],
            )
            .unwrap();
        }
        assert!(history.get(&id(1)).unwrap_err().contains("authentication"));
        assert!(!history.healthy());
        assert!(!clone.healthy());
        assert!(clone.get(&id(599)).is_err());
        assert!(history.insert(id(600), item(600)).is_err());
        drop(clone);
        drop(history);
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn actual_sqlite_full_stops_writes_without_acknowledging_entry() {
        let root = root();
        let mut history = History::disk(&root).unwrap();
        if let History::Disk { inner, .. } = &history {
            let d = inner.lock().unwrap();
            let pages: i64 =
                d.db.query_row("PRAGMA page_count", [], |r| r.get(0))
                    .unwrap();
            d.db.execute_batch(&format!("PRAGMA max_page_count={pages}"))
                .unwrap();
        }
        assert!(history
            .insert(
                id(1),
                Item {
                    number: 1,
                    body: "x".repeat(32768)
                }
            )
            .is_err());
        assert!(!history.healthy());
        assert_eq!(history.len(), 0);
        drop(history);
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn index_is_rebuilt_and_cache_links_are_rejected() {
        let root = root();
        fs::write(root.join("canonical-evidence"), b"retained").unwrap();
        let mut h = History::disk(&root).unwrap();
        h.insert(id(1), item(1)).unwrap();
        drop(h);
        let cache = root.join("validation-cache");
        fs::write(
            cache.join("11111111111111111111111111111111.sqlite"),
            b"broken cache after power loss",
        )
        .unwrap();
        let h = History::<Item>::disk(&root).unwrap();
        assert_eq!(h.len(), 0);
        drop(h);
        assert_eq!(
            fs::read(root.join("canonical-evidence")).unwrap(),
            b"retained"
        );
        #[cfg(unix)]
        {
            std::os::unix::fs::symlink(
                root.join("canonical-evidence"),
                cache.join("11111111111111111111111111111111.sqlite"),
            )
            .unwrap();
            assert!(History::<Item>::disk(&root).is_err());
            assert_eq!(
                fs::read(root.join("canonical-evidence")).unwrap(),
                b"retained"
            );
        }
        fs::remove_dir_all(root).unwrap();
    }
}
