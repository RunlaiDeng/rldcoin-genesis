use super::*;
use crate::chain::{CandidateChain, Command};
use rld_core::{generate_identity, sign_bytes, Identity};
use rld_regional_rules::RegionTiming;

fn original(owner: &str, seconds: u64, blocks: u64) -> Chain {
    let mut c = Chain::new(rld_pow::Context {
        network_domain: "next-mainnet-isolated".into(),
        zone_id: "source-test".into(),
        currency_genesis: Hash([1; 32]),
        manifest_pin: Hash([2; 32]),
        transition_id: Hash([3; 32]),
        legacy_height: 0,
        legacy_state_root: Hash([4; 32]),
        started_at: 1_000_000,
        initial_target: rld_pow::target_limit(),
        regional: Some(RegionTiming::new(seconds).unwrap()),
    })
    .unwrap();
    for n in 1..=blocks {
        let time = 1_000_000 + n * seconds;
        let mut b = c.template(owner.to_owned(), time, vec![]).unwrap();
        while !rld_pow::mine_batch(&mut b, 10000).unwrap() {}
        c.accept(b, time).unwrap();
    }
    c
}
fn mine(c: &mut CandidateChain, owner: &str, commands: Vec<Command>) -> Hash {
    let time = 1_000_000 + (c.height() as u64 + 1) * c.timing().seconds;
    let mut b = c.template(owner.to_owned(), time, commands).unwrap();
    while !chain::mine_batch(&mut b, 10000).unwrap() {}
    let id = b.header.id().unwrap();
    c.accept(b, time).unwrap();
    id
}
fn fee(
    c: &CandidateChain,
    owner: &Identity,
    channel: Hash,
    state: &SignedState,
    action: DisputeAction,
) -> ActionFee {
    let (input, coin) = if action == DisputeAction::Challenge {
        let (input, reserve) = c
            .state()
            .reserved_fees
            .iter()
            .find(|(_, r)| r.channel == channel && r.coin.output.owner == owner.public_key)
            .unwrap();
        (input, &reserve.coin)
    } else {
        c.state()
            .coins
            .iter()
            .find(|(_, coin)| {
                coin.output.owner == owner.public_key && coin.spendable_height <= c.height()
            })
            .unwrap()
    };
    let intent = ActionFeeIntent {
        chain_id: c.chain_id(),
        action,
        channel,
        signed_state: signed_state_hash(state).unwrap(),
        input: input.clone(),
        owner: owner.public_key.clone(),
        fee: Amount(1),
        change: Amount(coin.output.amount.0 - 1),
        valid_through_height: c.height() + 12,
    };
    ActionFee {
        owner_signature: sign_bytes(&owner.secret_key, &intent.signing_bytes().unwrap()).unwrap(),
        intent,
    }
}
#[test]
fn regional_source_executes_reward_maturity_retarget_and_checkpoint_rules() {
    let owner = generate_identity();
    let v1 = original(&owner.public_key, 3600, 20);
    assert_eq!(
        v1.state().emitted,
        v1.context.cumulative_emission(20).unwrap()
    );
    assert_ne!(v1.state().emitted, Amount(rld_pow::cumulative_emission(20)));
    assert!(v1
        .state()
        .coins
        .values()
        .any(|coin| coin.spendable_height == 18));
    let mut c = CandidateChain::from_replayed_pow_chain(&v1).unwrap();
    for _ in 20..24 {
        mine(&mut c, &owner.public_key, vec![]);
    }
    let time = 1_000_000 + 25 * 3600 - 1000;
    let mut b = c.template(owner.public_key.clone(), time, vec![]).unwrap();
    let target = b.header.target;
    while !chain::mine_batch(&mut b, 10000).unwrap() {}
    c.accept(b, time).unwrap();
    let b = c
        .template(owner.public_key.clone(), 1_000_000 + 26 * 3600, vec![])
        .unwrap();
    assert!(
        b.header.target < target,
        "retarget uses the committed 25-block window"
    );
    mine(&mut c, &owner.public_key, vec![]);
    assert_eq!(
        c.state().commitment().unwrap().emitted,
        v1.context.cumulative_emission(26).unwrap()
    );
    let checkpoint = c.replayed_checkpoint().unwrap();
    c.verify_replayed_checkpoint(&checkpoint).unwrap();
    let mut forged = serde_json::to_value(&checkpoint).unwrap();
    forged["state"]["coins"][0][1]["spendable_height"] = serde_json::json!("100");
    let forged = serde_json::from_value(forged).unwrap();
    assert!(c.verify_replayed_checkpoint(&forged).is_err());
    let mut other = v1.context.clone();
    other.regional = Some(RegionTiming::new(600).unwrap());
    assert_ne!(other.chain_id().unwrap(), v1.context.chain_id().unwrap());
    let mut invalid = v1.context.clone();
    invalid.regional.as_mut().unwrap().contest_blocks = 2016;
    assert!(invalid.validate().is_err());
}
#[test]
fn regional_channel_contest_finality_and_settlement_use_actual_node_execution() {
    use rld_fast_payments::successor::{OpenChannel, OpenIntent};
    let a = generate_identity();
    let b = generate_identity();
    let v1 = original(&a.public_key, 3600, 20);
    let mut c = CandidateChain::from_replayed_pow_chain(&v1).unwrap();
    let (point, coin) = c
        .state()
        .coins
        .iter()
        .find(|(_, coin)| coin.spendable_height <= 20)
        .unwrap();
    let intent = OpenIntent {
        chain_id: c.chain_id(),
        input: point.clone(),
        party_a: a.public_key.clone(),
        party_b: b.public_key.clone(),
        capacity: Amount(10000),
        close_fee: Amount(1),
        opening_fee: Amount(1),
        change: Amount(coin.output.amount.0 - 10001),
        valid_through_height: 32,
    };
    let funding = intent.funding().unwrap();
    let channel = funding.id().unwrap();
    let signed = |state: rld_fast_payments::ChannelState| {
        let bytes = state.signing_bytes(&funding).unwrap();
        SignedState {
            state,
            signature_a: sign_bytes(&a.secret_key, &bytes).unwrap(),
            signature_b: sign_bytes(&b.secret_key, &bytes).unwrap(),
        }
    };
    let initial = signed(rld_fast_payments::ChannelState::initial(&funding).unwrap());
    let open = OpenChannel {
        signature_a: sign_bytes(&a.secret_key, &intent.signing_bytes().unwrap()).unwrap(),
        intent,
        initial: initial.clone(),
    };
    let first = mine(&mut c, &a.public_key, vec![Command::Open(open)]);
    assert!(
        chain::finality::FinalityStatement::from_chain(&c, Hash([7; 32]), first, None).is_err()
    );
    let closefee = fee(&c, &a, channel, &initial, DisputeAction::Close);
    let reserved_input = c
        .state()
        .coins
        .iter()
        .find(|(p, coin)| **p != closefee.intent.input && coin.spendable_height <= c.height())
        .unwrap()
        .0
        .clone();
    let reserve_intent = ChallengeFeeReserveIntent {
        chain_id: c.chain_id(),
        channel,
        input: reserved_input,
        owner: a.public_key.clone(),
    };
    let reserve = ChallengeFeeReserve {
        owner_signature: sign_bytes(&a.secret_key, &reserve_intent.signing_bytes().unwrap())
            .unwrap(),
        intent: reserve_intent,
    };
    mine(
        &mut c,
        &a.public_key,
        vec![
            Command::ReserveChallengeFee(reserve),
            Command::Close {
                channel,
                state: initial.clone(),
                fee: closefee,
            },
        ],
    );
    assert!(
        chain::finality::FinalityStatement::from_chain(&c, Hash([7; 32]), first, None).is_err()
    );
    let latest = signed(
        initial
            .state
            .propose_payment(&funding, &a.public_key, Amount(1), Hash([8; 32]))
            .unwrap(),
    );
    let challengefee = fee(&c, &a, channel, &latest, DisputeAction::Challenge);
    mine(
        &mut c,
        &a.public_key,
        vec![Command::Challenge {
            channel,
            state: latest,
            fee: challengefee,
        }],
    );
    chain::finality::FinalityStatement::from_chain(&c, Hash([7; 32]), first, None).unwrap();
    let deadline = match c.state().escrow(channel).unwrap().phase {
        Phase::Closing {
            deadline_height, ..
        } => deadline_height,
        _ => panic!(),
    };
    assert_eq!(deadline, 22 + 336);
    while c.height() < deadline - 1 {
        mine(&mut c, &a.public_key, vec![]);
    }
    assert!(c
        .template(
            a.public_key.clone(),
            1_000_000 + (deadline as u64) * 3600,
            vec![Command::Finalize { channel }]
        )
        .is_err());
    mine(&mut c, &a.public_key, vec![]);
    mine(&mut c, &a.public_key, vec![Command::Finalize { channel }]);
    assert_eq!(c.state().escrow(channel).unwrap().phase, Phase::Settled);
    assert!(c
        .state()
        .coins
        .values()
        .any(|coin| coin.output.owner == b.public_key
            && coin.output.amount == Amount(1)
            && coin.spendable_height == deadline + 1));
    assert!(c
        .state()
        .coins
        .values()
        .any(|coin| coin.output.owner == a.public_key
            && coin.output.amount == Amount(1)
            && coin.spendable_height == deadline + 1 + 17));
    c.verify_replayed_checkpoint(&c.replayed_checkpoint().unwrap())
        .unwrap();
}
#[test]
fn regional_fast_source_requires_six_thousand_blocks_before_reward_spending() {
    let a = generate_identity();
    let b = generate_identity();
    let v1 = original(&a.public_key, 10, 1);
    let (point, coin) = v1.state().coins.iter().next().unwrap();
    assert_eq!(coin.spendable_height, 6001);
    let mut c = CandidateChain::from_replayed_pow_chain(&v1).unwrap();
    while c.height() < 5999 {
        mine(&mut c, &a.public_key, vec![]);
    }
    let mut tx = Transfer {
        chain_id: c.chain_id(),
        owner: a.public_key.clone(),
        inputs: vec![point.clone()],
        outputs: vec![
            Output {
                owner: b.public_key.clone(),
                amount: Amount(1),
            },
            Output {
                owner: a.public_key.clone(),
                amount: Amount(coin.output.amount.0 - 2),
            },
        ],
        fee: Amount(1),
        valid_through_height: 6100,
        signature: String::new(),
    };
    tx.signature = sign_bytes(&a.secret_key, &tx.signing_bytes().unwrap()).unwrap();
    assert!(c
        .template(
            a.public_key.clone(),
            1_000_000 + 6000 * 10,
            vec![Command::Transfer(tx.clone())]
        )
        .is_err());
    mine(&mut c, &a.public_key, vec![]);
    mine(&mut c, &a.public_key, vec![Command::Transfer(tx)]);
    assert!(c.state().coin(point).is_none());
    assert!(c
        .state()
        .coins
        .values()
        .any(|coin| coin.output.owner == b.public_key
            && coin.output.amount == Amount(1)
            && coin.spendable_height == 6001));
    assert_eq!(
        c.state().commitment().unwrap().emitted,
        v1.context.cumulative_emission(6001).unwrap()
    );
}
#[test]
fn regional_destination_import_maturity_and_zero_issuance_execute_in_native_chain() {
    regional_destination_case(3600);
    regional_destination_case(600);
}
fn regional_destination_case(destination_seconds: u64) {
    use crate::destination::pow;
    let a = generate_identity();
    let b = generate_identity();
    let v1 = original(&a.public_key, 3600, 20);
    let mut source = CandidateChain::from_replayed_pow_chain(&v1).unwrap();
    let policy = chain::ObservationPolicy {
        source_chain_id: source.chain_id(),
        accepted_v1_tip: source.v1_tip(),
        minimum_confirmations: 2,
        minimum_cumulative_work: v1
            .chainwork()
            .checked_add(rld_core::header_work(v1.context.initial_target))
            .unwrap(),
    };
    let mut context = pow::Context {
        chain_id: Hash::ZERO,
        source_policy: policy,
        started_at: 2_000_000,
        initial_target: rld_pow::target_limit(),
        regional: Some(RegionTiming::new(destination_seconds).unwrap()),
        migration: None,
        source_finality: None,
    };
    let origin =
        Hash::from_hex(rld_core::implementation_source::IMPLEMENTATION_SOURCE_COMMITMENT).unwrap();
    context.chain_id = context.regional_chain_id(origin).unwrap();
    let dst = context.chain_id;
    let timing = context.timing();
    let mut reused = context.clone();
    reused.regional = Some(
        RegionTiming::new(if destination_seconds == 600 {
            3600
        } else {
            600
        })
        .unwrap(),
    );
    assert!(reused.validate().is_err());
    assert_ne!(
        context.regional_chain_id(origin).unwrap(),
        reused.regional_chain_id(origin).unwrap()
    );

    let (point, coin) = source
        .state()
        .coins
        .iter()
        .find(|(_, coin)| coin.spendable_height <= 20)
        .unwrap();
    let intent = rld_cross_region::value::ExportIntent {
        source_chain_id: source.chain_id(),
        destination_chain_id: dst,
        input: point.clone(),
        owner: a.public_key.clone(),
        recipient: b.public_key.clone(),
        amount: Amount(10000),
        source_fee: Amount(1),
        destination_fee: Amount(1),
        change: Amount(coin.output.amount.0 - 10001),
        valid_through_height: 32,
    };
    let id = intent.id().unwrap();
    let command = rld_cross_region::value::ExportCommand {
        owner_signature: sign_bytes(&a.secret_key, &intent.signing_bytes().unwrap()).unwrap(),
        intent,
    };
    mine(&mut source, &a.public_key, vec![Command::Export(command)]);
    let checkpoint = mine(&mut source, &a.public_key, vec![]);
    mine(&mut source, &a.public_key, vec![]);
    let bundle = source.export_bundle(id, checkpoint).unwrap();
    let mut destination = pow::DestinationPowChain::new(context).unwrap();
    let mut block = destination
        .template(
            &source,
            a.public_key.clone(),
            2_000_000 + destination_seconds,
            vec![pow::Command::Import(bundle.clone())],
        )
        .unwrap();
    while !pow::mine_batch(&mut block, 10000).unwrap() {}
    destination
        .accept(&source, block, 2_000_000 + destination_seconds)
        .unwrap();
    assert_eq!(destination.state().imported_total(), Amount(10000));
    assert_eq!(
        destination.state().balance(&b.public_key, 1).unwrap(),
        (Amount(0), Amount(9999))
    );
    assert_eq!(
        destination
            .state()
            .balance(&b.public_key, 1 + timing.import_maturity as u128)
            .unwrap(),
        (Amount(9999), Amount(0))
    );
    assert_eq!(
        destination.state().balance(&a.public_key, 2).unwrap(),
        (Amount(0), Amount(1))
    );
    assert_eq!(
        destination
            .state()
            .balance(&a.public_key, 1 + timing.coinbase_maturity as u128)
            .unwrap(),
        (Amount(1), Amount(0))
    );
    assert!(destination
        .template(
            &source,
            a.public_key.clone(),
            2_000_000 + 2 * destination_seconds,
            vec![pow::Command::Import(bundle)]
        )
        .is_err());
    assert_eq!(destination.state().imported_total(), Amount(10000));
    let mut policy = pow::receipt::InclusionPolicy {
        destination_chain_id: dst,
        accepted_genesis: destination.genesis(),
        minimum_confirmations: timing.return_confirmations as u128,
        minimum_inclusion_work: destination.chainwork(),
    };
    let bundle = source.export_bundle(id, checkpoint).unwrap();
    // A sufficient declared policy cannot replace actual selected depth.
    assert!(destination
        .observe_import(&source, &bundle, &policy)
        .is_err());
    for n in 2..=timing.return_confirmations {
        let time = 2_000_000 + n * destination_seconds;
        let mut block = destination
            .template(&source, a.public_key.clone(), time, vec![])
            .unwrap();
        while !pow::mine_batch(&mut block, 10000).unwrap() {}
        destination.accept(&source, block, time).unwrap();
    }
    let receipt = destination
        .observe_import(&source, &bundle, &policy)
        .unwrap();
    assert_eq!(
        receipt.recipient_spendable_height,
        1 + timing.import_maturity as u128
    );
    destination
        .verify_import_receipt(&source, &bundle, &policy, &receipt)
        .unwrap();
    policy.minimum_confirmations -= 1;
    assert!(destination
        .observe_import(&source, &bundle, &policy)
        .is_err());
}
