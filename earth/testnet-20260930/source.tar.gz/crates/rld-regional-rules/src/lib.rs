//! New regional timing and capped issuance rules. Signed contexts bind these
//! parameters; constructing an arithmetic schedule does not authorize assets.
use anyhow::{ensure, Result};
use rld_core::{AdmissionHash32 as Hash, Amount, TOTAL_SUPPLY_RUNLAI};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

const BASE_SECONDS: u64 = 600;
const ERA_SECONDS: u64 = 200_000 * BASE_SECONDS;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct RegionTiming {
    pub seconds: u64,
    pub coinbase_maturity: u64,
    pub contest_blocks: u64,
    pub era_blocks: u64,
    pub finality_confirmations: u64,
    pub import_maturity: u64,
    pub return_confirmations: u64,
    pub retarget_blocks: u64,
    pub median_blocks: u64,
}
impl RegionTiming {
    pub fn new(seconds: u64) -> Result<Self> {
        ensure!(
            (1..=3600).contains(&seconds),
            "interval must be an integer in 1..=3600 seconds"
        );
        Ok(Self {
            seconds,
            coinbase_maturity: (100 * BASE_SECONDS).div_ceil(seconds),
            contest_blocks: (2016 * BASE_SECONDS).div_ceil(seconds),
            era_blocks: ERA_SECONDS.div_ceil(seconds),
            finality_confirmations: (11 * BASE_SECONDS).div_ceil(seconds) + 1,
            import_maturity: (6 * BASE_SECONDS).div_ceil(seconds),
            return_confirmations: (11 * BASE_SECONDS).div_ceil(seconds) + 1,
            retarget_blocks: (144 * BASE_SECONDS)
                .div_ceil(seconds)
                .max((143 * BASE_SECONDS).div_ceil(seconds) + 1),
            median_blocks: (10 * BASE_SECONDS).div_ceil(seconds) + 1,
        })
    }
    pub fn validate(&self) -> Result<()> {
        ensure!(
            *self == Self::new(self.seconds)?,
            "noncanonical coupled regional parameters"
        );
        Ok(())
    }
    pub fn reward_spendable_height(&self, mined_at: u128) -> Result<u128> {
        self.validate()?;
        mined_at
            .checked_add(self.coinbase_maturity.into())
            .ok_or_else(|| anyhow::anyhow!("reward maturity overflow"))
    }
    pub fn contest_deadline(&self, closed_at: u128) -> Result<u128> {
        self.validate()?;
        closed_at
            .checked_add(self.contest_blocks.into())
            .ok_or_else(|| anyhow::anyhow!("contest height overflow"))
    }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct TimingRules {
    pub source: RegionTiming,
    pub destination: RegionTiming,
}
impl TimingRules {
    pub fn new(source_seconds: u64, destination_seconds: u64) -> Result<Self> {
        Ok(Self {
            source: RegionTiming::new(source_seconds)?,
            destination: RegionTiming::new(destination_seconds)?,
        })
    }
    pub fn validate(&self) -> Result<()> {
        self.source.validate()?;
        self.destination.validate()
    }
    pub fn id(&self) -> Result<Hash> {
        self.validate()?;
        let mut h = Sha256::new();
        h.update(b"RLD-NEXT-MAINNET-REGIONAL-TIMING-V1\0");
        h.update(serde_json::to_vec(self)?);
        Ok(Hash(h.finalize().into()))
    }
}

/// Amount/sequence claims cannot establish a migration. Construct this from a
/// native replay and revalidate it on use; importing assets remains separate.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct SourceIssuance {
    #[serde(with = "decimal")]
    activation_sequence: u128,
    activation_emitted: Amount,
    timing: RegionTiming,
}
impl SourceIssuance {
    pub fn from_emission(sequence: u128, emitted: Amount, timing: RegionTiming) -> Result<Self> {
        let s = Self {
            activation_sequence: sequence,
            activation_emitted: emitted,
            timing,
        };
        s.validate()?;
        Ok(s)
    }
    pub fn validate(&self) -> Result<()> {
        self.timing.validate()?;
        ensure!(
            self.activation_emitted.0 == legacy_cumulative_emission(self.activation_sequence),
            "activation emission is not the old canonical issuance"
        );
        Ok(())
    }
    pub fn first_period_blocks(&self) -> Result<u64> {
        self.validate()?;
        let remaining_old_blocks = 200_000 - (self.activation_sequence % 200_000) as u64;
        Ok((remaining_old_blocks * BASE_SECONDS).div_ceil(self.timing.seconds))
    }
    /// New sequence 0 is the migrated monetary checkpoint: no new reward.
    /// The first partial era uses only its remaining budget and nominal time.
    /// Future eras release half of the then remaining cap, without rounding dust.
    pub fn cumulative(&self, new_sequence: u128) -> Result<Amount> {
        self.validate()?;
        let old_era = self.activation_sequence / 200_000;
        if old_era >= 128 {
            return Ok(Amount(TOTAL_SUPPLY_RUNLAI));
        }
        let old_remaining = TOTAL_SUPPLY_RUNLAI >> old_era as u32;
        let era_end = TOTAL_SUPPLY_RUNLAI - (old_remaining >> 1);
        let first_blocks = self.first_period_blocks()? as u128;
        if new_sequence <= first_blocks {
            let budget = era_end - self.activation_emitted.0;
            return Ok(Amount(
                self.activation_emitted.0 + distribute(budget, new_sequence, first_blocks)?,
            ));
        }
        let following = new_sequence - first_blocks;
        let blocks = self.timing.era_blocks as u128;
        let completed = following / blocks;
        let era = old_era + 1 + completed;
        if era >= 128 {
            return Ok(Amount(TOTAL_SUPPLY_RUNLAI));
        }
        let remaining = TOTAL_SUPPLY_RUNLAI >> era as u32;
        let budget = remaining - (remaining >> 1);
        Ok(Amount(
            TOTAL_SUPPLY_RUNLAI - remaining + distribute(budget, following % blocks, blocks)?,
        ))
    }
    pub fn subsidy(&self, new_sequence: u128) -> Result<Amount> {
        ensure!(new_sequence > 0, "activation checkpoint has no reward");
        let after = self.cumulative(new_sequence)?.0;
        let before = self.cumulative(new_sequence - 1)?.0;
        Ok(Amount(
            after
                .checked_sub(before)
                .ok_or_else(|| anyhow::anyhow!("issuance decreased"))?,
        ))
    }
    pub fn verify_reward(&self, new_sequence: u128, claimed: Amount) -> Result<()> {
        ensure!(
            claimed == self.subsidy(new_sequence)?,
            "block reward differs from the activated remaining budget"
        );
        Ok(())
    }
}
fn distribute(budget: u128, elapsed: u128, blocks: u128) -> Result<u128> {
    ensure!(blocks > 0 && elapsed <= blocks, "invalid issuance fraction");
    // Divide first: budget * elapsed would overflow u128 for fast-era lengths.
    let whole = (budget / blocks)
        .checked_mul(elapsed)
        .ok_or_else(|| anyhow::anyhow!("issuance multiplication overflow"))?;
    let dust = (budget % blocks)
        .checked_mul(elapsed)
        .ok_or_else(|| anyhow::anyhow!("issuance dust overflow"))?
        / blocks;
    whole
        .checked_add(dust)
        .ok_or_else(|| anyhow::anyhow!("issuance addition overflow"))
}

pub fn verify_destination_reward(claimed: Amount) -> Result<()> {
    ensure!(
        claimed.is_zero(),
        "destination regions have no native issuance"
    );
    Ok(())
}

pub fn legacy_cumulative_emission(blocks: u128) -> u128 {
    let era = blocks / 200_000;
    let offset = blocks % 200_000;
    if era >= 128 {
        return TOTAL_SUPPLY_RUNLAI;
    }
    let remaining = TOTAL_SUPPLY_RUNLAI >> era as u32;
    let budget = remaining - (remaining >> 1);
    TOTAL_SUPPLY_RUNLAI - remaining
        + (budget / 200_000) * offset
        + ((budget % 200_000) * offset) / 200_000
}
pub mod decimal {
    use serde::{Deserialize, Deserializer, Serializer};
    pub fn serialize<S: Serializer>(n: &u128, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&n.to_string())
    }
    pub fn deserialize<'de, D: Deserializer<'de>>(d: D) -> Result<u128, D::Error> {
        let s = String::deserialize(d)?;
        if s.is_empty()
            || (s.len() > 1 && s.starts_with('0'))
            || !s.bytes().all(|b| b.is_ascii_digit())
        {
            return Err(serde::de::Error::custom(
                "canonical unsigned decimal string required",
            ));
        }
        s.parse().map_err(serde::de::Error::custom)
    }
}
