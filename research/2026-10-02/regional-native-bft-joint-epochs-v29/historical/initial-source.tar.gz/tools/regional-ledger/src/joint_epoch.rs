//! Separately admitted, controller-carried joint epoch ground candidate.
//! Old BFT first certifies one plan in a normal block. Only that exact plan can
//! seal the old journal and gather 3-of-4 old/new activation approvals.
use super::*;

pub const ACTIVATION: &str = "RLD-BFT-JOINT-EPOCH-V1";

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Plan {
    pub currency: Hash,
    pub region: Hash,
    pub previous_epoch: Hash,
    pub number: u64,
    pub validators: Vec<String>,
}
impl Plan {
    pub fn validate(&self, trust: &Trust, registry: &epoch::Registry) -> Result<()> {
        let (previous, number, keys, _) = registry.latest(trust, self.region)?;
        require(
            trust.region(self.region)?.rules == bft::JOINT_RULES
                && self.currency == trust.currency()?
                && self.previous_epoch == previous
                && self.number == number + 1
                && self.number <= epoch::MAX_EPOCHS as u64
                && self.validators.len() == 4
                && self.validators.windows(2).all(|k| k[0] < k[1])
                && self.validators.iter().all(|k| !keys.contains(k)),
            "joint plan requires the current epoch and four ordered fresh keys",
        )?;
        for key in &self.validators {
            validate_ed25519_public_key(key)?;
        }
        registry.fresh_bft_keys(trust, self.region, &self.validators)
    }
    pub fn matches(&self, s: &epoch::EpochStatement) -> bool {
        self.currency == s.currency
            && self.region == s.region
            && self.previous_epoch == s.previous_epoch
            && self.number == s.number
            && self.validators == s.validators
            && s.activation.as_deref() == Some(ACTIVATION)
    }
}

pub(crate) fn selected(block: &Block) -> Result<Option<&Plan>> {
    let mut result = None;
    for command in &block.commands {
        if let Command::Reconfigure(plan) = command {
            require(result.is_none(), "at most one joint plan per block")?;
            result = Some(plan.as_ref());
        }
    }
    Ok(result)
}

/// Execution uses only the verified epoch prefix active at this exact height;
/// later carried epochs cannot retroactively select a different old key set.
pub(crate) fn validate_command(
    plan: &Plan,
    region: Hash,
    height: u64,
    trust: &Trust,
    evidence: &VerifiedEvidence,
) -> Result<()> {
    require(plan.region == region, "joint plan wrong execution region")?;
    let proofs = evidence.epoch_proofs(region);
    let active: Vec<_> = proofs
        .into_iter()
        .take_while(|p| p.statement.closing_height < height)
        .collect();
    let registry = epoch::Registry::verify_chain(trust, region, &active)?;
    plan.validate(trust, &registry)
}

pub(crate) fn selection_matches(proof: &epoch::Transition, snapshot: &Snapshot) -> Result<()> {
    require(
        proof.selection.as_deref() == snapshot.blocks.last(),
        "joint activation selection differs from fully replayed closing block",
    )
}

/// A certified plan stops old-era successors, including timeout signing.
/// Only a complete, already native-verified exact activation permits progress.
pub(crate) fn next_epoch(
    chain: &Chain,
    trust: &Trust,
    evidence: &VerifiedEvidence,
) -> Result<Hash> {
    if trust.region(chain.region)?.rules != bft::JOINT_RULES {
        return Ok(chain.epoch);
    }
    let Some(block) = chain.blocks.last() else {
        return Ok(chain.epoch);
    };
    let Some(plan) = selected(block)? else {
        return Ok(chain.epoch);
    };
    let proof = evidence
        .epochs
        .regions
        .get(&chain.region)
        .and_then(|list| {
            list.iter().find(|p| {
                plan.matches(&p.statement)
                    && p.statement.closing_height == chain.height()
                    && p.selection.as_deref() == Some(block)
            })
        })
        .ok_or("certified joint plan pauses old consensus until complete activation")?;
    let snapshot = evidence.snapshot(proof.statement.closing_checkpoint)?;
    require(
        snapshot.blocks == chain.blocks
            && snapshot.statement.state == chain.ledger.root()?
            && snapshot.statement.block == chain.tip()?
            && epoch::Anchor::from_snapshot(snapshot) == proof.closing,
        "joint activation lacks exact native-replayed closing state",
    )?;
    let next = proof.statement.id()?;
    require(
        chain.epoch == plan.previous_epoch || chain.epoch == next,
        "joint successor has unrelated epoch",
    )?;
    Ok(next)
}

pub(crate) fn signing_context(
    c: &bft::Context,
    trust: &Trust,
    evidence: &VerifiedEvidence,
) -> Result<()> {
    if trust.region(c.region)?.rules != bft::JOINT_RULES {
        return Ok(());
    }
    if let Some(previous) = c.previous {
        let parent = evidence.snapshot(previous)?;
        if let Some(plan) = parent.blocks.last().map(selected).transpose()?.flatten() {
            require(
                parent.statement.height == c.parent_height
                    && parent.statement.block == c.parent_block
                    && parent.statement.state == c.parent_state
                    && plan.previous_epoch != c.epoch,
                "selected joint plan forbids every old-era successor signature",
            )?;
        }
    }
    Ok(())
}

pub(crate) fn approvals(votes: &[Approval], keys: &[String], bytes: &[u8]) -> Result<()> {
    require(
        keys.len() == 4
            && keys.windows(2).all(|k| k[0] < k[1])
            && (3..=4).contains(&votes.len())
            && votes.windows(2).all(|v| v[0].key < v[1].key),
        "joint activation requires three distinct ordered old and new approvals",
    )?;
    for vote in votes {
        require(
            keys.contains(&vote.key),
            "joint activation wrong signer role",
        )?;
        verify_bytes(&vote.key, bytes, &vote.signature)?;
    }
    Ok(())
}
