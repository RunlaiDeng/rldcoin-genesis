use std::collections::{BTreeMap, BTreeSet};

use serde::{Deserialize, Serialize};
use thiserror::Error;

use crate::verify_consensus_stake_slash_evidence_v1;
use crate::{
    action_payload_hash, build_ledger_stake_authority_state_v1, consensus_stake_slash_nullifier_v1,
    consensus_stake_slash_terms_payload_hash_v2,
    crypto::{hash_bytes, hash_parts},
    derive_ledger_stake_epoch_v1, deterministic_round_zero_leader,
    extend_stake_position_liability_horizons_v1, ledger_stake_authority_genesis_anchor_v1,
    rebuild_stake_position_liability_horizons_v1, required_quorum, ubo_control_commitment_v1,
    validate_ledger_stake_authority_state_v1, ActivateStakeStateResourcePolicyV1,
    AdaptiveVoyageEscrow, AdmissionCheckpointProofV1, AdmissionCheckpointProposalPlanV1,
    AdmissionHash32, Amount, AmountError, AuditProofBundle,
    AuthenticatedAdmissionCheckpointProposalV1, CausalDecision, CausalEnvelope, CausalFirewall,
    CoinObject, CoinState, CompleteConsensusStakeUnbondV1, ConsensusCommand, ConsensusCommit,
    ConsensusEpochAnchor, ConsensusOutcome, ConsensusProposal, ConsensusStakePosition,
    ConsensusStakePositionKind, ConsensusStakeSlashPolicyV2, ConsensusStakeSlashRecordV1,
    ConsensusStakeSlashTermsV2, ConsensusStakeUnbondRecordV1, ConsensusStakeUnbondStatusV1,
    ContinuityCheckpoint, CreateGatewayBondRequest, CreateLiquidityOfferRequest,
    CreateRouteQuoteRequest, CryptoSuiteDescriptor, DeriveNextStakeEpochOutcomeV2,
    DeriveNextStakeEpochRequestV1, DeriveNextStakeEpochRequestV2, DestinationImportReceipt,
    DestinationRejectionProof, DestinationRejectionReason, DestinationSpendabilityCertificate,
    EconomicControlAttestation, EconomicControlRole, EconomicPriceAttestation,
    EconomicReleasePolicy, EpochFeePool, EraContinuityCertificate, ExitConsensusValidatorRequestV1,
    GatewayBond, GatewayBondStatus, LedgerAdmissionStateV1, LedgerDerivedStakeEpochV1,
    LedgerStakeAuthorityStateV1, LedgerStakeAuthorityUpdateV1, LiquidityOffer,
    LiquidityOfferStatus, LockConsensusStakeOutcomeV3, LockConsensusStakeRequestV1,
    LockConsensusStakeRequestV2, LockConsensusStakeRequestV3, M0NetworkBirthStateV2,
    MigrateConsensusCandidateResourceOutcomeV1, MigrateConsensusCandidateResourceRequestV1,
    MigrateConsensusStakeResourceOutcomeV1, MigrateConsensusStakeResourceRequestV1,
    MigrateConsensusStakeSlashTermsV2, NetworkHeartbeatV1, NodeEarnings, OperationalProof,
    PaymentRecord, PaymentRequest, PaymentStatus, ProductionCommand,
    ProposeStakeStateResourcePolicyV1, ProtocolReserveCommitment, ProtocolReservePoolKind,
    ProtocolReservePools, ProtocolReserveReleaseRecord, ProtocolReserveReleaseRequest,
    ProtocolServiceBond, ProtocolServiceBondLockRequest, ProtocolServiceBondSlash,
    ProtocolServiceBondStatus, ProtocolServiceCompletionClaim, ProtocolServiceOrderRequest,
    QuorumCertificate, RecipientReceipt, RegisterConsensusValidatorOutcomeV2,
    RegisterConsensusValidatorRequestV1, RegisterConsensusValidatorRequestV2,
    RenewStakeStateResourceBondOutcomeV1, RenewStakeStateResourceBondRequestV1,
    RequestConsensusStakeUnbondV1, RerouteRouteQuoteRequest, ResourcePriceSchedule, ResourceVector,
    RouteQuote, RouteQuoteStatus, ServiceLease, ServiceOrder, ServiceReceipt, ServiceRole,
    ServiceStatus, SignedActionAuthorization, SlashConsensusStakeV1,
    SpendabilityCertificateRequest, StakeAuthorityGovernanceUpdateV1, StakeAuthorityStateStatus,
    StakeLedgerContextV1, StakePositionLiabilityHorizonStateV1, StakePositionLiabilityHorizonV1,
    StakePositionTypeV1, StakeStateBondStatusV1, StakeStateResourceAccountingV1,
    StakeStateResourceAdmissionOutcomeV1, StakeStateResourceAdmissionRequestV1,
    StakeStateResourceContextV1, StakeStateResourceKindV1, StakeStateResourcePolicyV1,
    StakeStateResourceUsageV1, SupplyBuckets, SupplyConservationCertificate,
    TakeLiquidityOfferRequest, TransitCapsule, TransportClass, TravelerCarryCapsule,
    UniversalPaymentIntent, ValidatorCandidateRecord, ValueCap, ValueRiskPolicy,
    ValueRiskPolicyUpdate, VerifiedAdmissionCheckpointTransitionV1, VoyageServiceReceipt,
    VoyageStatus, ZoneAdvertisement, ZoneDescriptor, ZoneTrustPolicy,
    ACCEPT_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2, CONSENSUS_PROTOCOL_VERSION_V1,
    CONSENSUS_SLASH_SAFETY_POOL_V2, CURRENT_VALUE_RISK_POLICY_VERSION,
    CURRENT_ZONE_IDENTITY_VERSION, DERIVE_NEXT_STAKE_EPOCH_ACTION_V2,
    EXIT_CONSENSUS_VALIDATOR_ACTION_V1, LOCK_CONSENSUS_STAKE_ACTION_V1,
    LOCK_CONSENSUS_STAKE_ACTION_V2, LOCK_CONSENSUS_STAKE_ACTION_V3,
    MAX_ECONOMIC_CONTROL_GROUP_VALIDATOR_BPS, MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_ACTION_V1,
    MIGRATE_CONSENSUS_STAKE_RESOURCE_ACTION_V1, MIGRATE_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
    MIN_PROTOCOL_SERVICE_BOND_COVERAGE_BPS, MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS,
    REGISTER_CONSENSUS_VALIDATOR_ACTION_V1, REGISTER_CONSENSUS_VALIDATOR_ACTION_V2,
    REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1, RLDCOIN_MAINNET_DOMAIN, RLDCOIN_TESTNET_DOMAIN,
    ZONE_IDENTITY_HASH_SUITE,
};
use crate::{
    derive_next_stake_epoch_persistent_bytes_v2, derive_next_stake_epoch_state_reads_v2,
    derive_next_stake_epoch_state_writes_v2, lock_consensus_stake_persistent_bytes_v3,
    migrate_consensus_candidate_resource_persistent_bytes_v1,
    migrate_consensus_stake_resource_persistent_bytes_v1,
    register_consensus_validator_persistent_bytes_v2,
    renew_stake_state_resource_bond_persistent_bytes_v1, stake_liability_horizon_usage_delta_v1,
    stake_state_resource_policy_commitment_v1, stake_state_resource_subject_hash_v1,
    validate_stake_state_resource_policy_v1, StakeLiabilityHorizonUsageDeltaV1,
    DERIVE_NEXT_STAKE_EPOCH_SIGNATURE_CHECKS_V2, LOCK_CONSENSUS_STAKE_SIGNATURE_CHECKS_V3,
    LOCK_CONSENSUS_STAKE_STATE_READS_V3, LOCK_CONSENSUS_STAKE_STATE_WRITES_V3,
    MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_SIGNATURE_CHECKS_V1,
    MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_READS_V1,
    MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_WRITES_V1,
    MIGRATE_CONSENSUS_STAKE_RESOURCE_SIGNATURE_CHECKS_V1,
    MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_READS_V1,
    MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_WRITES_V1,
    REGISTER_CONSENSUS_VALIDATOR_SIGNATURE_CHECKS_V2, REGISTER_CONSENSUS_VALIDATOR_STATE_READS_V2,
    REGISTER_CONSENSUS_VALIDATOR_STATE_WRITES_V2,
    RENEW_STAKE_STATE_RESOURCE_BOND_SIGNATURE_CHECKS_V1,
    RENEW_STAKE_STATE_RESOURCE_BOND_STATE_READS_V1,
    RENEW_STAKE_STATE_RESOURCE_BOND_STATE_WRITES_V1,
};

pub const LOCAL_PAYMENT_PRICING_EPOCH: u64 = 1;
pub const LOCAL_PAYMENT_MAX_FEE_RUNLAI: u128 = 1_000_000_000_000_000_000;
/// Fail-closed bound until authenticated governance-history compaction exists.
const MAX_STAKE_RESOURCE_GOVERNANCE_RECORDS_V1: usize = 8_192;
const CONSENSUS_INSTANCE_LOCK_PREFIX: &str = "instance-v2:";

#[derive(Clone, Copy)]
enum ValueRiskPath {
    LocalPayment,
    CrossZone,
    DestinationSpendability,
}

struct ConsensusStakeLockInput {
    position_id: String,
    zone_id: String,
    currency_genesis_root: String,
    protocol_era: u64,
    crypto_era: u64,
    proposed_height: u64,
    expires_at_height: u64,
    expected_authority_sequence: u64,
    expected_authority_commitment: String,
    position_type: StakePositionTypeV1,
    validator_id: String,
    owner: String,
    source_coin_id: String,
    amount: Amount,
    committed_through_height: u64,
    action: &'static str,
    payload_hash: String,
    slash_terms_authorization: Option<SignedActionAuthorization>,
    authorization: SignedActionAuthorization,
}

fn is_canonical_sha256_hex(value: &str) -> bool {
    value.len() == 64
        && value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}

fn consensus_instance_lock_key(parent_height: u64, parent_state_root: &str) -> String {
    format!("{CONSENSUS_INSTANCE_LOCK_PREFIX}{parent_height}:{parent_state_root}")
}

fn parse_consensus_vote_lock_key(key: &str) -> Result<(u64, String), LedgerError> {
    if let Some(current) = key.strip_prefix(CONSENSUS_INSTANCE_LOCK_PREFIX) {
        let (height, root) = current.split_once(':').ok_or_else(|| {
            LedgerError::InvalidQuorum("malformed consensus instance vote-lock key".into())
        })?;
        let height = height.parse::<u64>().map_err(|_| {
            LedgerError::InvalidQuorum("malformed consensus instance vote-lock height".into())
        })?;
        if root.is_empty() {
            return Err(LedgerError::InvalidQuorum(
                "consensus instance vote-lock root is empty".into(),
            ));
        }
        return Ok((height, root.to_owned()));
    }

    let mut fields = key.rsplitn(3, ':');
    let (Some(round), Some(root), Some(height)) = (fields.next(), fields.next(), fields.next())
    else {
        return Err(LedgerError::InvalidQuorum(
            "unrecognized legacy consensus vote-lock key".into(),
        ));
    };
    let height = height.parse::<u64>().map_err(|_| {
        LedgerError::InvalidQuorum("malformed legacy consensus vote-lock height".into())
    })?;
    round.parse::<u64>().map_err(|_| {
        LedgerError::InvalidQuorum("malformed legacy consensus vote-lock round".into())
    })?;
    if root.is_empty() {
        return Err(LedgerError::InvalidQuorum(
            "legacy consensus vote-lock root is empty".into(),
        ));
    }
    Ok((height, root.to_owned()))
}

pub fn local_payment_price_schedule() -> ResourcePriceSchedule {
    ResourcePriceSchedule {
        pricing_epoch: LOCAL_PAYMENT_PRICING_EPOCH,
        ingress_byte_price: Amount::from_runlai(1_000_000_000),
        signature_check_classic_price: Amount::from_runlai(1_000_000_000_000_000),
        signature_check_pq_price: Amount::from_runlai(10_000_000_000_000_000),
        state_read_price: Amount::from_runlai(100_000_000_000_000),
        state_write_price: Amount::from_runlai(200_000_000_000_000),
        new_state_byte_price: Amount::from_runlai(100_000_000),
        proof_byte_price: Amount::from_runlai(1_000_000_000),
        proof_verification_unit_price: Amount::from_runlai(5_000_000_000_000_000),
        consensus_unit_price: Amount::from_runlai(500_000_000_000_000),
        archive_byte_epoch_price: Amount::from_runlai(1),
    }
}

#[derive(Debug, Error)]
pub enum LedgerError {
    #[error("amount error: {0}")]
    Amount(#[from] AmountError),
    #[error("coin not found: {0}")]
    CoinNotFound(String),
    #[error("coin is not spendable")]
    CoinNotSpendable,
    #[error("coin owner does not match signer")]
    OwnerMismatch,
    #[error("invalid signature: {0}")]
    InvalidSignature(String),
    #[error("invalid request: {0}")]
    Invalid(String),
    #[error("duplicate identifier: {0}")]
    Duplicate(String),
    #[error("transit not found: {0}")]
    TransitNotFound(String),
    #[error("transit has already been imported")]
    TransitAlreadyImported,
    #[error("quorum certificate rejected: {0}")]
    InvalidQuorum(String),
    #[error("causal firewall quarantined the message: {0}")]
    CausalQuarantine(String),
    #[error("service order not found: {0}")]
    ServiceOrderNotFound(String),
    #[error("service lease not found: {0}")]
    ServiceLeaseNotFound(String),
    #[error("service order is not in the required state")]
    ServiceState,
    #[error("testnet-only operation")]
    TestnetOnly,
    #[error("supply conservation failure: {0}")]
    Supply(String),
    #[error("operational proof rejected: {0}")]
    InvalidOperationalProof(String),
    #[error("source Zone is quarantined: {0}")]
    SourceZoneQuarantined(String),
    #[error("voyage escrow not found: {0}")]
    VoyageNotFound(String),
    #[error("liquidity offer not found: {0}")]
    LiquidityOfferNotFound(String),
    #[error("route quote not found: {0}")]
    RouteQuoteNotFound(String),
    #[error("era transition rejected: {0}")]
    EraTransition(String),
    #[error("real-value risk policy rejected: {0}")]
    ValueRisk(String),
    #[error("economic reserve release rejected: {0}")]
    Economic(String),
    #[error("stake-state resource policy or accounting rejected: {0}")]
    StakeResource(String),
}

/// Private-field capability for finishing consensus metadata after an
/// externally assisted command transition while freezing every Ledger field
/// that the state root does not directly commit.
///
/// Some future commands need authenticated node-local evidence while they are
/// replayed. The caller may produce their state-rooted transition, but it must
/// not synthesize or edit Era-certificate history, derived checkpoints,
/// durable vote locks or the commit inventory. Only a capability created from
/// the exact prestate can install the commit-specific successor metadata.
#[derive(Clone, Debug)]
pub struct AuthenticatedConsensusCommitMetadataV1 {
    commit: ConsensusCommit,
    commit_hash: String,
    prior_unrooted_bytes: Vec<u8>,
    successor_vote_locks: BTreeMap<String, String>,
    expected_height: u64,
    expected_state_root: String,
}

/// Private-field capability for installing exactly one tag-28 vote lock after
/// the signed proposal and its node-local Admission proof have both been
/// authenticated against the current Ledger prestate.
///
/// The type has no deserializer. It freezes all existing unrooted consensus
/// bookkeeping and the only permitted successor lock map, so a persistence
/// adapter cannot use node-local evidence as a generic Ledger mutation hook.
#[derive(Clone, Debug)]
pub struct AuthenticatedAdmissionCheckpointVoteLockV1 {
    proposal_hash: String,
    parent_height: u64,
    parent_state_root: String,
    prior_unrooted_bytes: Vec<u8>,
    successor_vote_locks: BTreeMap<String, String>,
}

impl AuthenticatedAdmissionCheckpointVoteLockV1 {
    pub fn proposal_hash(&self) -> &str {
        &self.proposal_hash
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Ledger {
    pub descriptor: ZoneDescriptor,
    pub height: u64,
    pub anchor_supply: Amount,
    pub reserve: Amount,
    #[serde(default)]
    pub reserve_pools: ProtocolReservePools,
    pub imported_total: Amount,
    pub finalized_export_total: Amount,
    #[serde(default)]
    pub value_risk_policy: ValueRiskPolicy,
    /// Immutable, consensus-rooted M0 fail-closed identity and command profile.
    /// Once present, omitting a node CLI flag cannot enable value or governance.
    #[serde(default)]
    pub m0_network_birth: Option<M0NetworkBirthStateV2>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub m0_network_birth_v3: Option<crate::M0NetworkBirthStateV3>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub m0_active_protocol: Option<crate::M0ActiveProtocolStateV1>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub m0_pending_upgrade: Option<crate::genesis::upgrade_pending::PendingUpgradeV1>,
    /// Consensus-rooted, bounded permissionless-admission trust state.  The
    /// unfinalized fork graph and sidecars are deliberately not embedded here.
    #[serde(default)]
    pub admission_state: Option<LedgerAdmissionStateV1>,
    #[serde(default)]
    pub consensus_stake_authority: Option<LedgerStakeAuthorityStateV1>,
    /// Exact owner-authorized stake escrows keyed by escrow Coin id.  An
    /// authority view may count a position only when it matches this registry.
    #[serde(default)]
    pub consensus_stake_escrows: BTreeMap<String, ConsensusStakePosition>,
    /// Immutable owner-authorized withdrawal facts and their completion state,
    /// keyed by request id.
    #[serde(default)]
    pub consensus_stake_unbonds: BTreeMap<String, ConsensusStakeUnbondRecordV1>,
    /// Immutable, evidence-addressed records for completed objective-fault
    /// slashes, keyed by slash id.
    #[serde(default)]
    pub consensus_stake_slashes: BTreeMap<String, ConsensusStakeSlashRecordV1>,
    /// One exact evidence/liability pair may affect state at most once. The
    /// same validator-fault evidence can cover several frozen liabilities.
    #[serde(default)]
    pub consensus_stake_evidence_nullifiers: BTreeSet<String>,
    #[serde(default)]
    pub derived_stake_epochs: BTreeMap<u64, LedgerDerivedStakeEpochV1>,
    /// O(1) authenticated index of each position's complete historical Epoch
    /// liability horizon. The append-only history below makes every monotonic
    /// update independently reconstructible from retained Epoch records.
    #[serde(default)]
    pub stake_position_liability_horizons: BTreeMap<String, StakePositionLiabilityHorizonV1>,
    #[serde(default)]
    pub stake_position_liability_horizon_history:
        BTreeMap<String, Vec<StakePositionLiabilityHorizonV1>>,
    /// The first resource-bound Epoch that atomically materialized the full
    /// horizon index. This removes replay ambiguity between a one-time legacy
    /// bootstrap and an ordinary single-Epoch append.
    #[serde(default)]
    pub stake_liability_horizon_activation_epoch: Option<u64>,
    /// Immutable accepted proposal records, keyed by proposal id, so a
    /// certified command remains exactly replayable after activation or expiry.
    #[serde(default)]
    pub stake_resource_policy_proposals: BTreeMap<String, ProposeStakeStateResourcePolicyV1>,
    /// Immutable accepted activation records, keyed by activation id.
    #[serde(default)]
    pub stake_resource_policy_activations: BTreeMap<String, ActivateStakeStateResourcePolicyV1>,
    /// At most one delayed, dual-QC resource-policy proposal may be pending.
    /// This state authorizes no fees or membership change by itself.
    #[serde(default)]
    pub pending_stake_resource_policy: Option<ProposeStakeStateResourcePolicyV1>,
    /// Consensus-rooted resource policy/accounting state. R6.19 admits only
    /// resource-bound candidate and position creation plus exact legacy-position
    /// migration; every later value-bearing lifecycle requires its own
    /// internally metered successor command.
    #[serde(default)]
    pub stake_resource_accounting: Option<StakeStateResourceAccountingV1>,
    pub coins: BTreeMap<String, CoinObject>,
    pub payments: BTreeMap<String, PaymentRecord>,
    #[serde(default)]
    pub epoch_fee_pools: BTreeMap<u64, EpochFeePool>,
    #[serde(default)]
    pub payment_requests: BTreeMap<String, PaymentRequest>,
    #[serde(default)]
    pub consumed_payment_requests: BTreeSet<String>,
    #[serde(default)]
    pub recipient_receipts: BTreeMap<String, RecipientReceipt>,
    pub transits: BTreeMap<String, TransitCapsule>,
    pub transit_coin_ids: BTreeMap<String, String>,
    pub import_receipts: BTreeMap<String, DestinationImportReceipt>,
    #[serde(default)]
    pub rejection_proofs: BTreeMap<String, DestinationRejectionProof>,
    #[serde(default)]
    pub rejected_transit_nullifiers: BTreeSet<String>,
    pub spendability_certificates: BTreeMap<String, DestinationSpendabilityCertificate>,
    #[serde(default)]
    pub liquidity_offers: BTreeMap<String, LiquidityOffer>,
    #[serde(default)]
    pub route_quotes: BTreeMap<String, RouteQuote>,
    pub transit_nullifiers: BTreeSet<String>,
    #[serde(default)]
    pub source_object_nullifiers: BTreeSet<String>,
    #[serde(default)]
    pub authorization_nullifiers: BTreeSet<String>,
    #[serde(default)]
    pub zone_trust_policies: BTreeMap<String, ZoneTrustPolicy>,
    #[serde(default)]
    pub trusted_zone_checkpoints: BTreeMap<String, BTreeSet<String>>,
    #[serde(default)]
    pub gateway_bonds: BTreeMap<String, GatewayBond>,
    #[serde(default)]
    pub quarantined_zones: BTreeSet<String>,
    #[serde(default)]
    pub zone_advertisements: BTreeMap<String, ZoneAdvertisement>,
    #[serde(default)]
    pub traveler_capsules: BTreeMap<String, TravelerCarryCapsule>,
    #[serde(default)]
    pub voyage_escrows: BTreeMap<String, AdaptiveVoyageEscrow>,
    #[serde(default)]
    pub voyage_receipts: BTreeMap<String, VoyageServiceReceipt>,
    #[serde(default)]
    pub era_certificates: Vec<EraContinuityCertificate>,
    #[serde(default)]
    pub era_continuity_accumulator: String,
    pub service_orders: BTreeMap<String, ServiceOrder>,
    pub service_leases: BTreeMap<String, ServiceLease>,
    #[serde(default)]
    pub protocol_reserve_commitments: BTreeMap<String, ProtocolReserveCommitment>,
    #[serde(default)]
    pub economic_control_attestations: BTreeMap<String, EconomicControlAttestation>,
    #[serde(default)]
    pub economic_price_attestations: BTreeMap<String, EconomicPriceAttestation>,
    #[serde(default)]
    pub economic_release_policies: BTreeMap<String, EconomicReleasePolicy>,
    #[serde(default)]
    pub protocol_service_bonds: BTreeMap<String, ProtocolServiceBond>,
    #[serde(default)]
    pub protocol_reserve_releases: BTreeMap<String, ProtocolReserveReleaseRecord>,
    #[serde(default)]
    pub economic_consumed_work_ids: BTreeSet<String>,
    #[serde(default)]
    pub economic_consumed_fee_receipts: BTreeSet<String>,
    #[serde(default)]
    pub economic_consumed_completion_qcs: BTreeSet<String>,
    #[serde(default)]
    pub economic_bond_slash_ids: BTreeSet<String>,
    #[serde(default)]
    pub matched_service_receipts: BTreeSet<String>,
    pub service_receipts: BTreeMap<String, ServiceReceipt>,
    pub node_earnings: BTreeMap<String, NodeEarnings>,
    pub checkpoints: Vec<ContinuityCheckpoint>,
    pub causal_firewall: CausalFirewall,
    pub bootstrap_claims: BTreeSet<String>,
    #[serde(default)]
    pub consensus_vote_locks: BTreeMap<String, String>,
    #[serde(default)]
    pub consensus_commits: BTreeMap<String, ConsensusCommit>,
    sequence: u64,
}

impl Ledger {
    #[allow(dead_code)]
    fn stake_context_at(
        &self,
        finalized_height: u128,
        finalized_state_root: String,
    ) -> StakeLedgerContextV1 {
        StakeLedgerContextV1 {
            network_domain: self.descriptor.network_domain.clone(),
            zone_id: self.descriptor.zone_id.clone(),
            currency_genesis_root: self.descriptor.currency_genesis_root.clone(),
            protocol_era: self.descriptor.protocol_era,
            crypto_era: self.descriptor.crypto_era,
            consensus_protocol_version: CONSENSUS_PROTOCOL_VERSION_V1,
            finalized_height,
            finalized_state_root,
        }
    }

    fn ensure_stake_positions_registered(
        &self,
        positions: &[ConsensusStakePosition],
    ) -> Result<(), LedgerError> {
        for position in positions {
            if self.consensus_stake_escrows.get(&position.escrow_coin_id) != Some(position) {
                return Err(LedgerError::Invalid(format!(
                    "stake position {} has no exact owner-authorized escrow registration",
                    position.position_id
                )));
            }
        }
        Ok(())
    }

    fn validate_consensus_stake_escrows(&self) -> Result<(), LedgerError> {
        let mut escrow_ids = BTreeSet::new();
        let mut source_ids = BTreeSet::new();
        let mut position_ids = BTreeSet::new();
        for (escrow_id, position) in &self.consensus_stake_escrows {
            if escrow_id != &position.escrow_coin_id
                || !position_ids.insert(position.position_id.as_str())
                || !escrow_ids.insert(position.escrow_coin_id.as_str())
                || !source_ids.insert(position.source_coin_id.as_str())
            {
                return Err(LedgerError::Invalid(
                    "stake escrow registry key, source or escrow is duplicated".into(),
                ));
            }
            let source = self
                .coins
                .get(&position.source_coin_id)
                .ok_or_else(|| LedgerError::CoinNotFound(position.source_coin_id.clone()))?;
            let escrow = self
                .coins
                .get(&position.escrow_coin_id)
                .ok_or_else(|| LedgerError::CoinNotFound(position.escrow_coin_id.clone()))?;
            let expected_version = Self::checked_next_coin_version(source.version)?;
            if source.state != CoinState::Consumed
                || source.owner != position.owner
                || source.amount < position.amount
                || escrow.state != CoinState::Reserved
                || escrow.owner != position.owner
                || escrow.amount != position.amount
                || escrow.parent_ids != [position.source_coin_id.clone()]
                || escrow.lineage_root != source.lineage_root
                || escrow.version != expected_version
                || u128::from(escrow.created_height) != position.locked_height
                || escrow.transit_id.is_some()
                || escrow.zone_id != self.descriptor.zone_id
                || escrow.origin_genesis_root != self.descriptor.currency_genesis_root
            {
                return Err(LedgerError::Invalid(format!(
                    "stake escrow {} does not match its consumed source Coin and position",
                    position.position_id
                )));
            }
        }
        let mut unbonded_positions = BTreeSet::new();
        let mut completion_ids = BTreeSet::new();
        for (request_id, record) in &self.consensus_stake_unbonds {
            if request_id != &record.request_id
                || record.owner != record.position.owner
                || record.beneficiary != record.owner
                || record.request_commitment != record.compute_request_commitment()
                || !unbonded_positions.insert(record.position.position_id.as_str())
            {
                return Err(LedgerError::Invalid(
                    "stake unbond record identity, owner or commitment mismatch".into(),
                ));
            }
            let escrow = self
                .coins
                .get(&record.position.escrow_coin_id)
                .ok_or_else(|| LedgerError::CoinNotFound(record.position.escrow_coin_id.clone()))?;
            match record.status {
                ConsensusStakeUnbondStatusV1::Pending => {
                    if record.completion_id.is_some()
                        || record.completed_height.is_some()
                        || record.payout_coin_id.is_some()
                        || record.slash_id.is_some()
                        || !record.slashed_amount.is_zero()
                        || self
                            .consensus_stake_escrows
                            .get(&record.position.escrow_coin_id)
                            != Some(&record.position)
                        || escrow.state != CoinState::Reserved
                    {
                        return Err(LedgerError::Invalid(
                            "pending stake unbond does not retain its exact Reserved escrow".into(),
                        ));
                    }
                }
                ConsensusStakeUnbondStatusV1::Completed => {
                    let completion_id = record.completion_id.as_deref().ok_or_else(|| {
                        LedgerError::Invalid("completed stake unbond has no completion id".into())
                    })?;
                    if !completion_ids.insert(completion_id)
                        || record.completed_height.is_none()
                        || record.slash_id.is_some()
                        || !record.slashed_amount.is_zero()
                        || self
                            .consensus_stake_escrows
                            .contains_key(&record.position.escrow_coin_id)
                        || escrow.state != CoinState::Consumed
                    {
                        return Err(LedgerError::Invalid(
                            "completed stake unbond retained an active escrow or invalid state"
                                .into(),
                        ));
                    }
                    let payout_id = record.payout_coin_id.as_ref().ok_or_else(|| {
                        LedgerError::Invalid("completed stake unbond has no payout Coin".into())
                    })?;
                    let payout = self
                        .coins
                        .get(payout_id)
                        .ok_or_else(|| LedgerError::CoinNotFound(payout_id.clone()))?;
                    if !matches!(payout.state, CoinState::Spendable | CoinState::Consumed)
                        || payout.owner != record.beneficiary
                        || payout.amount != record.position.amount
                        || payout.parent_ids != [record.position.escrow_coin_id.clone()]
                        || payout.lineage_root != escrow.lineage_root
                        || payout.version != Self::checked_next_coin_version(escrow.version)?
                        || payout.created_height != record.completed_height.unwrap()
                        || payout.transit_id.is_some()
                    {
                        return Err(LedgerError::Invalid(
                            "completed stake unbond payout does not match its escrow".into(),
                        ));
                    }
                }
                ConsensusStakeUnbondStatusV1::FullySlashed => {
                    let slash_id = record.slash_id.as_deref().ok_or_else(|| {
                        LedgerError::Invalid("fully slashed unbond has no slash id".into())
                    })?;
                    if record.completion_id.is_some()
                        || record.completed_height.is_none()
                        || record.payout_coin_id.is_some()
                        || record.slashed_amount != record.position.amount
                        || self
                            .consensus_stake_escrows
                            .contains_key(&record.position.escrow_coin_id)
                        || escrow.state != CoinState::Consumed
                        || self
                            .consensus_stake_slashes
                            .get(slash_id)
                            .is_none_or(|slash| slash.position != record.position)
                    {
                        return Err(LedgerError::Invalid(
                            "fully slashed unbond retained value or lost its slash lineage".into(),
                        ));
                    }
                }
            }
        }
        if let Some(authority) = &self.consensus_stake_authority {
            self.ensure_stake_positions_registered(&authority.positions)?;
            if authority.positions.iter().any(|position| {
                self.consensus_stake_unbonds
                    .values()
                    .any(|record| record.position.position_id == position.position_id)
            }) {
                return Err(LedgerError::Invalid(
                    "stake authority reintroduced a position with an unbond request".into(),
                ));
            }
        }
        Ok(())
    }

    fn validate_stake_position_liability_horizons(&self) -> Result<(), LedgerError> {
        let current_empty = self.stake_position_liability_horizons.is_empty();
        let history_empty = self.stake_position_liability_horizon_history.is_empty();
        if current_empty && history_empty {
            if self.stake_liability_horizon_activation_epoch.is_some() {
                return Err(LedgerError::Invalid(
                    "empty stake liability horizon has an activation Epoch".into(),
                ));
            }
            // Historical pre-horizon ledgers remain byte-for-byte replayable.
            // Resource-bound unbond V2 will require a populated exact index.
            return Ok(());
        }
        let activation_epoch = self
            .stake_liability_horizon_activation_epoch
            .filter(|epoch| *epoch != 0 && self.derived_stake_epochs.contains_key(epoch));
        if current_empty != history_empty || activation_epoch.is_none() {
            return Err(LedgerError::Invalid(
                "stake liability horizon index, history or activation Epoch diverges".into(),
            ));
        }
        let (expected_current, expected_history) =
            rebuild_stake_position_liability_horizons_v1(self.derived_stake_epochs.values())
                .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if self.stake_position_liability_horizons != expected_current
            || self.stake_position_liability_horizon_history != expected_history
        {
            return Err(LedgerError::Invalid(
                "stake liability horizons do not exactly rebuild from retained Epochs".into(),
            ));
        }
        Ok(())
    }

    fn preview_stake_liability_horizon_update(
        &self,
        record: &LedgerDerivedStakeEpochV1,
    ) -> Result<StakePositionLiabilityHorizonStateV1, LedgerError> {
        self.validate_stake_position_liability_horizons()?;
        if self.stake_position_liability_horizons.is_empty() {
            let mut epochs = self.derived_stake_epochs.clone();
            if epochs
                .insert(record.descriptor.consensus_epoch, record.clone())
                .is_some()
            {
                return Err(LedgerError::Invalid(
                    "liability horizon preview would replace an Epoch".into(),
                ));
            }
            rebuild_stake_position_liability_horizons_v1(epochs.values())
                .map_err(|error| LedgerError::StakeResource(error.to_string()))
        } else {
            let mut horizons = self.stake_position_liability_horizons.clone();
            let mut history = self.stake_position_liability_horizon_history.clone();
            extend_stake_position_liability_horizons_v1(&mut horizons, &mut history, record)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
            Ok((horizons, history))
        }
    }

    fn recorded_stake_liability_horizon_usage(
        &self,
        consensus_epoch: u64,
    ) -> Result<StakeLiabilityHorizonUsageDeltaV1, LedgerError> {
        let Some(activation_epoch) = self.stake_liability_horizon_activation_epoch else {
            return Ok(StakeLiabilityHorizonUsageDeltaV1::default());
        };
        if consensus_epoch < activation_epoch {
            return Ok(StakeLiabilityHorizonUsageDeltaV1::default());
        }
        let empty_current = BTreeMap::new();
        let empty_history = BTreeMap::new();
        let (previous_current, previous_history) = if consensus_epoch == activation_epoch {
            (empty_current, empty_history)
        } else {
            rebuild_stake_position_liability_horizons_v1(
                self.derived_stake_epochs
                    .values()
                    .filter(|record| record.descriptor.consensus_epoch < consensus_epoch),
            )
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?
        };
        let (next_current, next_history) = rebuild_stake_position_liability_horizons_v1(
            self.derived_stake_epochs
                .values()
                .filter(|record| record.descriptor.consensus_epoch <= consensus_epoch),
        )
        .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        stake_liability_horizon_usage_delta_v1(
            &previous_current,
            &previous_history,
            &next_current,
            &next_history,
        )
        .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))
    }

    fn validate_consensus_stake_slashes(&self) -> Result<(), LedgerError> {
        if self.consensus_stake_slashes.len() != self.consensus_stake_evidence_nullifiers.len() {
            return Err(LedgerError::Invalid(
                "stake slash records and evidence nullifiers diverge".into(),
            ));
        }
        let mut evidence_nullifiers = BTreeSet::new();
        let mut positions = BTreeSet::new();
        let mut safety_coins = BTreeSet::new();
        for (slash_id, record) in &self.consensus_stake_slashes {
            let evidence_nullifier = consensus_stake_slash_nullifier_v1(
                &record.evidence_hash,
                &record.liability_commitment,
            );
            let epoch = self
                .derived_stake_epochs
                .get(&record.consensus_epoch)
                .filter(|epoch| epoch.record_hash == record.derived_epoch_record_hash);
            let liability = epoch.and_then(|epoch| {
                epoch
                    .stake_liabilities
                    .iter()
                    .find(|liability| liability.liability_commitment == record.liability_commitment)
            });
            let verified_evidence = epoch.and_then(|epoch| {
                verify_consensus_stake_slash_evidence_v1(
                    epoch,
                    &record.position.position_id,
                    &record.liability_commitment,
                    &record.evidence,
                )
                .ok()
            });
            if slash_id != &record.slash_id
                || record.record_hash != record.compute_record_hash()
                || !evidence_nullifiers.insert(evidence_nullifier.clone())
                || !positions.insert(record.position.position_id.as_str())
                || !safety_coins.insert(record.safety_pool_coin_id.as_str())
                || !self
                    .consensus_stake_evidence_nullifiers
                    .contains(&evidence_nullifier)
                || record.slash_bps != 10_000
                || record.slashed_amount != record.position.amount
                || record.source_escrow_coin_id != record.position.escrow_coin_id
                || self
                    .consensus_stake_escrows
                    .contains_key(&record.source_escrow_coin_id)
                || liability.is_none_or(|liability| {
                    liability.position != record.position
                        || u128::from(record.applied_height) < liability.activation_height
                        || u128::from(record.applied_height) >= liability.evidence_deadline_height
                })
                || verified_evidence.as_ref().is_none_or(|verified| {
                    verified.evidence_hash != record.evidence_hash
                        || verified.kind != record.evidence_kind
                        || verified.slash_bps != record.slash_bps
                        || verified.fault_height > u128::from(record.applied_height)
                })
            {
                return Err(LedgerError::Invalid(
                    "stake slash identity, evidence, liability, amount, nullifier or source mismatch"
                        .into(),
                ));
            }
            let source = self
                .coins
                .get(&record.source_escrow_coin_id)
                .ok_or_else(|| LedgerError::CoinNotFound(record.source_escrow_coin_id.clone()))?;
            let safety = self
                .coins
                .get(&record.safety_pool_coin_id)
                .ok_or_else(|| LedgerError::CoinNotFound(record.safety_pool_coin_id.clone()))?;
            if source.state != CoinState::Consumed
                || safety.state != CoinState::Reserved
                || safety.owner != CONSENSUS_SLASH_SAFETY_POOL_V2
                || safety.amount != record.slashed_amount
                || safety.parent_ids != [source.object_id.clone()]
                || safety.lineage_root != source.lineage_root
                || safety.version != Self::checked_next_coin_version(source.version)?
                || safety.created_height != record.applied_height
                || safety.transit_id.is_some()
            {
                return Err(LedgerError::Invalid(
                    "stake slash safety-pool Coin does not preserve exact escrow lineage".into(),
                ));
            }
        }
        Ok(())
    }

    /// Installs one already-authorized, canonical, predecessor-linked
    /// stake-authority view into ledger state.  Callers must validate the
    /// content-addressed governance wrapper before reaching this mutation.
    pub(crate) fn stage_ledger_stake_authority(
        &mut self,
        update: LedgerStakeAuthorityUpdateV1,
    ) -> Result<LedgerStakeAuthorityStateV1, LedgerError> {
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        let effective_height = source_height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake authority height overflow".into()))?;
        let context = self.stake_context_at(source_height, source_state_root);
        self.ensure_stake_positions_registered(&update.positions)?;
        let state = build_ledger_stake_authority_state_v1(
            &context,
            effective_height,
            self.consensus_stake_authority.as_ref(),
            update,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.consensus_stake_authority = Some(state.clone());
        Ok(state)
    }

    /// Derives and stores exactly the next candidate Epoch from the current
    /// ledger-owned authority state and pre-transition state root. The record
    /// remains `DERIVED_ONLY`; this method never changes runtime membership.
    pub(crate) fn derive_and_store_next_stake_epoch(
        &mut self,
    ) -> Result<LedgerDerivedStakeEpochV1, LedgerError> {
        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        self.ensure_stake_positions_registered(&authority.positions)?;
        if u128::from(self.height) < authority.effective_height {
            return Err(LedgerError::Invalid(
                "stake authority is not yet effective".into(),
            ));
        }

        let snapshot_height = u128::from(self.height);
        let snapshot_state_root = self.state_root()?;
        let context = self.stake_context_at(snapshot_height, snapshot_state_root.clone());
        let previous = self.derived_stake_epochs.values().next_back();
        let (consensus_epoch, activation_height, record_chain_anchor) =
            if let Some(previous) = previous {
                (
                    previous
                        .descriptor
                        .consensus_epoch
                        .checked_add(1)
                        .ok_or_else(|| LedgerError::Invalid("stake Epoch overflow".into()))?,
                    previous.descriptor.exit_height,
                    previous.record_hash.clone(),
                )
            } else {
                (
                    1,
                    snapshot_height
                        .checked_add(authority.policy.activation_delay_blocks)
                        .ok_or_else(|| {
                            LedgerError::Invalid("stake activation height overflow".into())
                        })?,
                    ledger_stake_authority_genesis_anchor_v1(&context),
                )
            };
        let anchor = ConsensusEpochAnchor {
            consensus_epoch,
            activation_height,
            stake_snapshot_height: snapshot_height,
            stake_snapshot_state_root: snapshot_state_root,
            record_chain_anchor,
        };
        let record = derive_ledger_stake_epoch_v1(
            &context,
            &authority.policy,
            &anchor,
            previous,
            &authority.candidates,
            &authority.positions,
            &authority.ubo_control,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if self
            .derived_stake_epochs
            .contains_key(&record.descriptor.consensus_epoch)
        {
            return Err(LedgerError::Duplicate(format!(
                "stake-epoch-{}",
                record.descriptor.consensus_epoch
            )));
        }
        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.derived_stake_epochs
            .insert(record.descriptor.consensus_epoch, record.clone());
        Ok(record)
    }

    fn reconstruct_stake_authority_command_state(
        &self,
        request: &StakeAuthorityGovernanceUpdateV1,
        source_height: u128,
        source_state_root: String,
        effective_height: u128,
    ) -> Result<LedgerStakeAuthorityStateV1, LedgerError> {
        let update = request.to_ledger_update().map_err(LedgerError::Invalid)?;
        let state = LedgerStakeAuthorityStateV1 {
            authority_version: update.authority_version,
            status: StakeAuthorityStateStatus::StagedOnly,
            network_domain: self.descriptor.network_domain.clone(),
            zone_id: request.zone_id.clone(),
            currency_genesis_root: request.currency_genesis_root.clone(),
            protocol_era: request.protocol_era,
            crypto_era: request.crypto_era,
            consensus_protocol_version: CONSENSUS_PROTOCOL_VERSION_V1,
            sequence: update.sequence,
            previous_commitment: update.expected_previous_commitment,
            source_height,
            source_state_root,
            effective_height,
            policy: update.policy,
            candidates: update.candidates,
            positions: update.positions,
            ubo_control: update.ubo_control,
            commitment: request.prospective_authority_commitment.clone(),
        };
        validate_ledger_stake_authority_state_v1(&state)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        Ok(state)
    }

    /// Stages a ledger-owned authority view through a dual-governance command.
    /// This command cannot activate runtime membership and is permitted only
    /// while the real-value gate remains closed.
    pub fn submit_stake_authority_update(
        &mut self,
        request: StakeAuthorityGovernanceUpdateV1,
    ) -> Result<LedgerStakeAuthorityStateV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "stake authority staging requires VALUE_CAP_0".into(),
            ));
        }
        if request.update_id.trim().is_empty() {
            return Err(LedgerError::Invalid(
                "stake authority update id is required".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "stake authority Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "stake authority proposal height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "stake authority governance request expired".into(),
            ));
        }
        if self
            .descriptor
            .validator_keys
            .iter()
            .any(|key| self.descriptor.notary_keys.contains(key))
        {
            return Err(LedgerError::InvalidQuorum(
                "validator and independent notary sets overlap".into(),
            ));
        }

        let update = request.to_ledger_update().map_err(LedgerError::Invalid)?;
        if self.consensus_stake_authority.is_some() {
            return Err(LedgerError::Invalid(
                "broad stake governance is bootstrap-only and cannot change candidate lifecycle, policy, positions or UBO after bootstrap".into(),
            ));
        }
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        let effective_height = source_height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake authority height overflow".into()))?;
        let context = self.stake_context_at(source_height, source_state_root);
        let prospective = build_ledger_stake_authority_state_v1(
            &context,
            effective_height,
            self.consensus_stake_authority.as_ref(),
            update.clone(),
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if request.prospective_authority_commitment != prospective.commitment {
            return Err(LedgerError::Invalid(
                "prospective stake authority commitment mismatch".into(),
            ));
        }
        let subject = request.compute_subject_hash();
        if request.subject_hash != subject {
            return Err(LedgerError::Invalid(
                "stake authority governance subject commitment mismatch".into(),
            ));
        }
        self.verify_local_dual_quorum(&subject, &request.validator_qc, &request.notary_qc)?;
        self.ensure_stake_positions_registered(&update.positions)?;

        let mut staged = self.clone();
        let stored = staged.stage_ledger_stake_authority(update)?;
        if stored != prospective {
            return Err(LedgerError::Invalid(
                "stake authority changed between validation and storage".into(),
            ));
        }
        staged.assert_conservation()?;
        *self = staged;
        Ok(stored)
    }

    /// Atomically consumes one owner-authorized spendable Coin, creates a
    /// stake-specific reserved escrow and advances the staged authority view.
    /// Runtime validator membership remains unchanged.
    pub fn lock_consensus_stake(
        &mut self,
        request: LockConsensusStakeRequestV1,
    ) -> Result<ConsensusStakePosition, LedgerError> {
        if self.stake_resource_accounting.is_some() {
            return Err(LedgerError::StakeResource(
                "legacy consensus stake locking is disabled after resource-policy activation; use V3"
                    .into(),
            ));
        }
        let mut staged = self.clone();
        let payload_hash = request.payload_hash();
        let position = staged.apply_consensus_stake_lock(ConsensusStakeLockInput {
            position_id: request.position_id,
            zone_id: request.zone_id,
            currency_genesis_root: request.currency_genesis_root,
            protocol_era: request.protocol_era,
            crypto_era: request.crypto_era,
            proposed_height: request.proposed_height,
            expires_at_height: request.expires_at_height,
            expected_authority_sequence: request.expected_authority_sequence,
            expected_authority_commitment: request.expected_authority_commitment,
            position_type: request.position_type,
            validator_id: request.validator_id,
            owner: request.owner,
            source_coin_id: request.source_coin_id,
            amount: request.amount,
            committed_through_height: request.committed_through_height,
            action: LOCK_CONSENSUS_STAKE_ACTION_V1,
            payload_hash,
            slash_terms_authorization: None,
            authorization: request.authorization,
        })?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(position)
    }

    pub fn lock_consensus_stake_v2(
        &mut self,
        request: LockConsensusStakeRequestV2,
    ) -> Result<ConsensusStakePosition, LedgerError> {
        if self.stake_resource_accounting.is_some() {
            return Err(LedgerError::StakeResource(
                "unmetered V2 consensus stake locking is disabled after resource-policy activation; use V3"
                    .into(),
            ));
        }
        let mut staged = self.clone();
        let payload_hash = request.payload_hash();
        let position = staged.apply_consensus_stake_lock(ConsensusStakeLockInput {
            position_id: request.position_id,
            zone_id: request.zone_id,
            currency_genesis_root: request.currency_genesis_root,
            protocol_era: request.protocol_era,
            crypto_era: request.crypto_era,
            proposed_height: request.proposed_height,
            expires_at_height: request.expires_at_height,
            expected_authority_sequence: request.expected_authority_sequence,
            expected_authority_commitment: request.expected_authority_commitment,
            position_type: request.position_type,
            validator_id: request.validator_id,
            owner: request.owner,
            source_coin_id: request.source_coin_id,
            amount: request.amount,
            committed_through_height: request.committed_through_height,
            action: LOCK_CONSENSUS_STAKE_ACTION_V2,
            payload_hash,
            slash_terms_authorization: Some(request.slash_terms_authorization),
            authorization: request.authorization,
        })?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(position)
    }

    fn apply_consensus_stake_lock(
        &mut self,
        request: ConsensusStakeLockInput,
    ) -> Result<ConsensusStakePosition, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus stake locking requires VALUE_CAP_0".into(),
            ));
        }
        if request.position_id.trim().is_empty()
            || request.validator_id.trim().is_empty()
            || request.owner.trim().is_empty()
            || request.source_coin_id.trim().is_empty()
            || request.amount.is_zero()
        {
            return Err(LedgerError::Invalid(
                "consensus stake lock request is incomplete".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "consensus stake lock Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "consensus stake lock height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "consensus stake lock request expired".into(),
            ));
        }
        if self
            .consensus_stake_escrows
            .values()
            .any(|position| position.position_id == request.position_id)
        {
            return Err(LedgerError::Duplicate(request.position_id));
        }

        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "consensus stake authority precondition mismatch".into(),
            ));
        }
        if authority
            .positions
            .iter()
            .any(|position| position.position_id == request.position_id)
        {
            return Err(LedgerError::Duplicate(request.position_id));
        }
        if authority.policy.policy_version == 2 && request.slash_terms_authorization.is_none() {
            return Err(LedgerError::Invalid(
                "derivation-policy v2 forbids legacy unslashable stake admission".into(),
            ));
        }
        let candidate = authority
            .candidates
            .iter()
            .find(|candidate| candidate.validator_id == request.validator_id)
            .ok_or_else(|| {
                LedgerError::Invalid("stake target is not a staged validator candidate".into())
            })?;
        if candidate.exit_height.is_some() {
            return Err(LedgerError::Invalid(
                "new stake cannot target a validator candidate that has requested exit".into(),
            ));
        }
        match request.position_type {
            StakePositionTypeV1::SelfBond => {
                if request.owner != candidate.owner {
                    return Err(LedgerError::OwnerMismatch);
                }
                if request.amount < authority.policy.minimum_self_bond {
                    return Err(LedgerError::Invalid(
                        "self-bond is below the staged policy minimum".into(),
                    ));
                }
            }
            StakePositionTypeV1::Delegation => {
                if request.amount < authority.policy.minimum_delegation {
                    return Err(LedgerError::Invalid(
                        "delegation is below the staged policy minimum".into(),
                    ));
                }
            }
        }

        let lock_height = u128::from(self.height)
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake lock height overflow".into()))?;
        let stake_mature_height = lock_height
            .checked_add(authority.policy.stake_maturity_blocks)
            .ok_or_else(|| LedgerError::Invalid("stake maturity height overflow".into()))?;
        let candidate_mature_height = candidate
            .registered_height
            .checked_add(authority.policy.candidate_maturity_blocks)
            .ok_or_else(|| LedgerError::Invalid("candidate maturity height overflow".into()))?;
        let minimum_commitment_height = stake_mature_height
            .max(candidate_mature_height)
            .checked_add(authority.policy.activation_delay_blocks)
            .and_then(|height| height.checked_add(authority.policy.epoch_length_blocks))
            .and_then(|height| height.checked_add(authority.policy.evidence_window_blocks))
            .ok_or_else(|| LedgerError::Invalid("stake commitment height overflow".into()))?;
        if u128::from(request.committed_through_height) < minimum_commitment_height {
            return Err(LedgerError::Invalid(
                "stake commitment does not cover maturity, one Epoch and its evidence window"
                    .into(),
            ));
        }

        let position_kind = match request.position_type {
            StakePositionTypeV1::SelfBond => ConsensusStakePositionKind::SelfBond {
                validator_id: request.validator_id.clone(),
            },
            StakePositionTypeV1::Delegation => ConsensusStakePositionKind::Delegation {
                validator_id: request.validator_id.clone(),
            },
        };
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            request.action,
            &request.payload_hash,
        )?;
        let slash_terms = if let Some(authorization) = &request.slash_terms_authorization {
            if authorization.authorization_id == request.authorization.authorization_id {
                return Err(LedgerError::Duplicate(
                    authorization.authorization_id.clone(),
                ));
            }
            let slash_policy = ConsensusStakeSlashPolicyV2::protocol_v2();
            let payload_hash = consensus_stake_slash_terms_payload_hash_v2(
                &request.position_id,
                &position_kind,
                &request.owner,
                &request.source_coin_id,
                request.amount,
                u128::from(request.committed_through_height),
                &slash_policy,
            );
            self.verify_owner_authorization(
                authorization,
                &request.owner,
                ACCEPT_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
                &payload_hash,
            )?;
            Some(ConsensusStakeSlashTermsV2 {
                terms_version: slash_policy.policy_version,
                slash_policy,
                owner_authorization: authorization.clone(),
            })
        } else {
            None
        };
        let input = self
            .coins
            .get(&request.source_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(request.source_coin_id.clone()))?;
        if input.state != CoinState::Spendable || input.owner != request.owner {
            return Err(LedgerError::CoinNotSpendable);
        }
        if request.amount > input.amount {
            return Err(LedgerError::Invalid(
                "stake amount exceeds its spendable input".into(),
            ));
        }
        if self.consensus_stake_escrows.values().any(|position| {
            position.source_coin_id == request.source_coin_id
                || position.escrow_coin_id == request.source_coin_id
        }) {
            return Err(LedgerError::Duplicate(request.source_coin_id));
        }

        self.ensure_counter_headroom(1, 2)?;
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        self.consume_authorization(&request.authorization)?;
        if let Some(authorization) = &request.slash_terms_authorization {
            self.consume_authorization(authorization)?;
        }
        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let escrow = self.make_coin(
            request.owner.clone(),
            request.amount,
            CoinState::Reserved,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins.insert(escrow.object_id.clone(), escrow.clone());
        let change = input.amount.checked_sub(request.amount)?;
        if !change.is_zero() {
            let change_coin = self.make_coin(
                request.owner.clone(),
                change,
                CoinState::Spendable,
                vec![input.object_id.clone()],
                Some(input.lineage_root.clone()),
                None,
                input.imported_from.clone(),
                next_version,
            )?;
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let position = ConsensusStakePosition {
            position_id: request.position_id.clone(),
            kind: position_kind,
            owner: request.owner,
            source_coin_id: input.object_id,
            escrow_coin_id: escrow.object_id,
            amount: request.amount,
            locked_height: u128::from(self.height),
            committed_through_height: u128::from(request.committed_through_height),
            slash_terms,
        };
        self.consensus_stake_escrows
            .insert(position.escrow_coin_id.clone(), position.clone());

        let mut positions = authority.positions.clone();
        positions.push(position.clone());
        let mut ubo_control = authority.ubo_control.clone();
        ubo_control.predecessor_commitment = ubo_control_commitment_v1(&authority.ubo_control)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        ubo_control.sequence = ubo_control
            .sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake UBO sequence overflow".into()))?;
        let update = LedgerStakeAuthorityUpdateV1 {
            authority_version: authority.authority_version,
            sequence: authority
                .sequence
                .checked_add(1)
                .ok_or_else(|| LedgerError::Invalid("stake authority sequence overflow".into()))?,
            expected_previous_commitment: authority.commitment.clone(),
            policy: authority.policy.clone(),
            candidates: authority.candidates.clone(),
            positions,
            ubo_control,
        };
        let context = self.stake_context_at(source_height, source_state_root);
        let next_authority = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(self.height),
            Some(&authority),
            update,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        self.consensus_stake_authority = Some(next_authority);
        Ok(position)
    }

    fn prepare_position_resource_admission(
        &self,
        request: StakeStateResourceAdmissionRequestV1,
        admission_height: u64,
    ) -> Result<
        (
            StakeStateResourceAccountingV1,
            StakeStateResourceAdmissionOutcomeV1,
        ),
        LedgerError,
    > {
        let funding_coin = self
            .coins
            .get(&request.envelope.funding_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(request.envelope.funding_coin_id.clone()))?;
        let mut protected_coin_ids = self
            .consensus_stake_escrows
            .keys()
            .cloned()
            .collect::<BTreeSet<_>>();
        let mut accounting = self
            .stake_resource_accounting
            .clone()
            .ok_or_else(|| LedgerError::StakeResource("no active stake resource policy".into()))?;
        protected_coin_ids.extend(
            accounting
                .bonds()
                .values()
                .map(|record| record.bond_coin_id.clone()),
        );
        let admission = accounting
            .admit(
                request,
                &funding_coin,
                &protected_coin_ids,
                admission_height,
            )
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        Ok((accounting, admission))
    }

    fn commit_position_resource_admission(
        &mut self,
        accounting: StakeStateResourceAccountingV1,
        admission: &StakeStateResourceAdmissionOutcomeV1,
        sponsor_authorization: &SignedActionAuthorization,
    ) -> Result<(), LedgerError> {
        let mut output_ids = BTreeSet::new();
        for coin in std::iter::once(&admission.bond_coin).chain(admission.change_coin.iter()) {
            if !output_ids.insert(coin.object_id.as_str())
                || self.coins.contains_key(&coin.object_id)
                || coin.object_id == admission.consumed_funding_coin.object_id
            {
                return Err(LedgerError::Duplicate(coin.object_id.clone()));
            }
        }
        let funding = self
            .coins
            .get(&admission.consumed_funding_coin.object_id)
            .ok_or_else(|| {
                LedgerError::CoinNotFound(admission.consumed_funding_coin.object_id.clone())
            })?;
        if funding.state != CoinState::Spendable
            || funding.version != admission.consumed_funding_coin.version
            || funding.amount != admission.consumed_funding_coin.amount
            || funding.owner != admission.consumed_funding_coin.owner
        {
            return Err(LedgerError::StakeResource(
                "resource funding Coin changed between admission and atomic commit".into(),
            ));
        }
        self.consume_authorization(sponsor_authorization)?;
        self.coins.insert(
            admission.consumed_funding_coin.object_id.clone(),
            admission.consumed_funding_coin.clone(),
        );
        self.coins.insert(
            admission.bond_coin.object_id.clone(),
            admission.bond_coin.clone(),
        );
        if let Some(change_coin) = &admission.change_coin {
            self.coins
                .insert(change_coin.object_id.clone(), change_coin.clone());
        }
        self.stake_resource_accounting = Some(accounting);
        Ok(())
    }

    /// Atomically creates one slashable stake position and a separately funded
    /// state-responsibility bond. The caller cannot provide resource counters,
    /// and the resource funding Coin cannot alias the stake principal.
    pub fn lock_consensus_stake_v3(
        &mut self,
        request: LockConsensusStakeRequestV3,
    ) -> Result<LockConsensusStakeOutcomeV3, LedgerError> {
        let mut staged = self.clone();
        let outcome = staged.apply_consensus_stake_lock_v3(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(outcome)
    }

    fn apply_consensus_stake_lock_v3(
        &mut self,
        request: LockConsensusStakeRequestV3,
    ) -> Result<LockConsensusStakeOutcomeV3, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "resource-bound consensus stake locking requires VALUE_CAP_0".into(),
            ));
        }
        if request.source_coin_id == request.resource_envelope.funding_coin_id {
            return Err(LedgerError::StakeResource(
                "stake principal and resource funding must be distinct Coins".into(),
            ));
        }
        let sponsor_authorization = &request.resource_envelope.authorization;
        let authorization_ids = [
            request.authorization.authorization_id.as_str(),
            request.slash_terms_authorization.authorization_id.as_str(),
            sponsor_authorization.authorization_id.as_str(),
        ];
        if authorization_ids[0] == authorization_ids[1]
            || authorization_ids[0] == authorization_ids[2]
            || authorization_ids[1] == authorization_ids[2]
            || self
                .authorization_nullifiers
                .contains(sponsor_authorization.authorization_id.as_str())
        {
            return Err(LedgerError::Duplicate(
                sponsor_authorization.authorization_id.clone(),
            ));
        }
        let accounting = self
            .stake_resource_accounting
            .as_ref()
            .ok_or_else(|| LedgerError::StakeResource("no active stake resource policy".into()))?;
        self.validate_stake_resource_policy_covers_inventory(
            accounting.active_policy(),
            None,
            Some(&request.owner),
        )?;
        let required_lease_end = request
            .committed_through_height
            .checked_add(accounting.active_policy().terminal_retention_blocks)
            .ok_or_else(|| LedgerError::StakeResource("position resource lease overflow".into()))?;
        if request.resource_envelope.lease_end_height < required_lease_end {
            return Err(LedgerError::StakeResource(
                "position resource lease does not cover stake liability plus terminal retention"
                    .into(),
            ));
        }
        let source = self
            .coins
            .get(&request.source_coin_id)
            .ok_or_else(|| LedgerError::CoinNotFound(request.source_coin_id.clone()))?;
        if source.zone_id != self.descriptor.zone_id
            || source.origin_genesis_root != self.descriptor.currency_genesis_root
            || !is_canonical_sha256_hex(&source.lineage_root)
            || source.transit_id.is_some()
        {
            return Err(LedgerError::Invalid(
                "stake principal Coin has noncanonical Zone, currency, lineage or transit state"
                    .into(),
            ));
        }
        let wire_bytes = ConsensusCommand::LockConsensusStakeV3(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::StakeResource("stake V3 command exceeds the u32 wire meter".into())
            })?,
            persistent_bytes: lock_consensus_stake_persistent_bytes_v3(&request)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            signature_checks: LOCK_CONSENSUS_STAKE_SIGNATURE_CHECKS_V3,
            state_reads: LOCK_CONSENSUS_STAKE_STATE_READS_V3,
            state_writes: LOCK_CONSENSUS_STAKE_STATE_WRITES_V3,
        };
        let resource_key = format!("POSITION/{}", request.position_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Position,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let admission_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::StakeResource("stake V3 height overflow".into()))?;
        let (next_accounting, admission) =
            self.prepare_position_resource_admission(admission_request, admission_height)?;
        let payload_hash = request.payload_hash();
        let position = self.apply_consensus_stake_lock(ConsensusStakeLockInput {
            position_id: request.position_id,
            zone_id: request.zone_id,
            currency_genesis_root: request.currency_genesis_root,
            protocol_era: request.protocol_era,
            crypto_era: request.crypto_era,
            proposed_height: request.proposed_height,
            expires_at_height: request.expires_at_height,
            expected_authority_sequence: request.expected_authority_sequence,
            expected_authority_commitment: request.expected_authority_commitment,
            position_type: request.position_type,
            validator_id: request.validator_id,
            owner: request.owner,
            source_coin_id: request.source_coin_id,
            amount: request.amount,
            committed_through_height: request.committed_through_height,
            action: LOCK_CONSENSUS_STAKE_ACTION_V3,
            payload_hash,
            slash_terms_authorization: Some(request.slash_terms_authorization),
            authorization: request.authorization,
        })?;
        if self.height != admission_height {
            return Err(LedgerError::StakeResource(
                "stake and resource admission heights diverged".into(),
            ));
        }
        self.commit_position_resource_admission(
            next_accounting,
            &admission,
            sponsor_authorization,
        )?;
        Ok(LockConsensusStakeOutcomeV3 {
            position,
            resource_key,
            bond_id: admission.bond_record.bond_id.clone(),
            bond_coin_id: admission.bond_record.bond_coin_id.clone(),
            charged_fee: admission.charged_fee,
            locked_bond: admission.locked_bond,
            initial_bond_record_hash: admission.bond_record.initial_record_hash(),
        })
    }

    /// Adds resource responsibility to one exact active pre-policy position.
    /// The finite authority inventory and its exact position commitment are
    /// both bound; principal, escrow and authority membership remain unchanged.
    pub fn migrate_consensus_stake_resource(
        &mut self,
        request: MigrateConsensusStakeResourceRequestV1,
    ) -> Result<MigrateConsensusStakeResourceOutcomeV1, LedgerError> {
        let mut staged = self.clone();
        let outcome = staged.apply_consensus_stake_resource_migration(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(outcome)
    }

    fn apply_consensus_stake_resource_migration(
        &mut self,
        request: MigrateConsensusStakeResourceRequestV1,
    ) -> Result<MigrateConsensusStakeResourceOutcomeV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus stake resource migration requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.position_id.trim().is_empty()
            || request.escrow_coin_id.trim().is_empty()
            || request.owner.trim().is_empty()
            || !is_canonical_sha256_hex(&request.expected_position_commitment)
        {
            return Err(LedgerError::Invalid(
                "stake resource migration request is incomplete or noncanonical".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "stake resource migration Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height || request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "stake resource migration height is stale or expired".into(),
            ));
        }
        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "stake resource migration authority precondition mismatch".into(),
            ));
        }
        let position = authority
            .positions
            .iter()
            .find(|position| {
                position.position_id == request.position_id
                    && position.escrow_coin_id == request.escrow_coin_id
            })
            .cloned()
            .ok_or_else(|| LedgerError::Invalid("active legacy position was not found".into()))?;
        if position.owner != request.owner {
            return Err(LedgerError::OwnerMismatch);
        }
        if position.slash_terms.is_none()
            || position.resource_commitment_v1() != request.expected_position_commitment
        {
            return Err(LedgerError::Invalid(
                "stake resource migration does not bind the exact slashable position".into(),
            ));
        }
        if !self
            .consensus_stake_escrows
            .get(&position.escrow_coin_id)
            .is_some_and(|retained| retained == &position)
            || self
                .consensus_stake_unbonds
                .values()
                .any(|record| record.position.position_id == position.position_id)
            || self
                .consensus_stake_slashes
                .values()
                .any(|record| record.position.position_id == position.position_id)
        {
            return Err(LedgerError::Invalid(
                "only an exact active, nonterminal position can enter resource accounting".into(),
            ));
        }
        let escrow = self
            .coins
            .get(&position.escrow_coin_id)
            .ok_or_else(|| LedgerError::CoinNotFound(position.escrow_coin_id.clone()))?;
        if escrow.state != CoinState::Reserved
            || escrow.owner != position.owner
            || escrow.amount != position.amount
            || escrow.parent_ids != [position.source_coin_id.clone()]
        {
            return Err(LedgerError::Invalid(
                "migrated position escrow is not the exact protected principal".into(),
            ));
        }
        let sponsor_authorization = &request.resource_envelope.authorization;
        if request.authorization.authorization_id == sponsor_authorization.authorization_id
            || self
                .authorization_nullifiers
                .contains(sponsor_authorization.authorization_id.as_str())
        {
            return Err(LedgerError::Duplicate(
                sponsor_authorization.authorization_id.clone(),
            ));
        }
        let accounting = self
            .stake_resource_accounting
            .as_ref()
            .ok_or_else(|| LedgerError::StakeResource("no active stake resource policy".into()))?;
        self.validate_stake_resource_policy_covers_inventory(
            accounting.active_policy(),
            None,
            None,
        )?;
        let required_lease_end = u64::try_from(position.committed_through_height)
            .ok()
            .and_then(|height| {
                height.checked_add(accounting.active_policy().terminal_retention_blocks)
            })
            .ok_or_else(|| {
                LedgerError::StakeResource("migrated position resource lease overflow".into())
            })?;
        if request.resource_envelope.lease_end_height < required_lease_end {
            return Err(LedgerError::StakeResource(
                "migrated position lease does not cover liability plus terminal retention".into(),
            ));
        }
        let payload_hash = request.payload_hash();
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            MIGRATE_CONSENSUS_STAKE_RESOURCE_ACTION_V1,
            &payload_hash,
        )?;
        let wire_bytes = ConsensusCommand::MigrateConsensusStakeResource(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::StakeResource(
                    "stake resource migration exceeds the u32 wire meter".into(),
                )
            })?,
            persistent_bytes: migrate_consensus_stake_resource_persistent_bytes_v1(
                &request, &position,
            )
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            signature_checks: MIGRATE_CONSENSUS_STAKE_RESOURCE_SIGNATURE_CHECKS_V1,
            state_reads: MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_READS_V1,
            state_writes: MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_WRITES_V1,
        };
        let resource_key = format!("POSITION/{}", position.position_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Position,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let admission_height = self.height.checked_add(1).ok_or_else(|| {
            LedgerError::StakeResource("resource migration height overflow".into())
        })?;
        let (next_accounting, admission) =
            self.prepare_position_resource_admission(admission_request, admission_height)?;
        self.ensure_counter_headroom(1, 0)?;
        self.consume_authorization(&request.authorization)?;
        self.advance()?;
        self.commit_position_resource_admission(
            next_accounting,
            &admission,
            sponsor_authorization,
        )?;
        Ok(MigrateConsensusStakeResourceOutcomeV1 {
            position,
            resource_key,
            bond_id: admission.bond_record.bond_id.clone(),
            bond_coin_id: admission.bond_record.bond_coin_id.clone(),
            charged_fee: admission.charged_fee,
            locked_bond: admission.locked_bond,
            initial_bond_record_hash: admission.bond_record.initial_record_hash(),
        })
    }

    /// Adds resource responsibility to one exact active pre-policy candidate.
    /// The authority and runtime validator sets are immutable across this
    /// bounded migration.
    pub fn migrate_consensus_candidate_resource(
        &mut self,
        request: MigrateConsensusCandidateResourceRequestV1,
    ) -> Result<MigrateConsensusCandidateResourceOutcomeV1, LedgerError> {
        let mut staged = self.clone();
        let outcome = staged.apply_consensus_candidate_resource_migration(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(outcome)
    }

    fn apply_consensus_candidate_resource_migration(
        &mut self,
        request: MigrateConsensusCandidateResourceRequestV1,
    ) -> Result<MigrateConsensusCandidateResourceOutcomeV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus candidate resource migration requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.validator_id.trim().is_empty()
            || request.owner.trim().is_empty()
            || request.public_key.trim().is_empty()
            || request.proof_of_possession.trim().is_empty()
            || !is_canonical_sha256_hex(&request.expected_candidate_commitment)
        {
            return Err(LedgerError::Invalid(
                "candidate resource migration request is incomplete or noncanonical".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "candidate resource migration Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height || request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "candidate resource migration height is stale or expired".into(),
            ));
        }
        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "candidate resource migration authority precondition mismatch".into(),
            ));
        }
        let candidate = authority
            .candidates
            .iter()
            .find(|candidate| candidate.validator_id == request.validator_id)
            .cloned()
            .ok_or_else(|| LedgerError::Invalid("active legacy candidate was not found".into()))?;
        if candidate.owner != request.owner {
            return Err(LedgerError::OwnerMismatch);
        }
        let requested_candidate = ValidatorCandidateRecord {
            validator_id: request.validator_id.clone(),
            owner: request.owner.clone(),
            public_key: request.public_key.clone(),
            key_era: request.key_era,
            registered_height: u128::from(request.registered_height),
            exit_height: request.exit_height.map(u128::from),
            proof_of_possession: request.proof_of_possession.clone(),
        };
        if candidate != requested_candidate
            || candidate.resource_commitment_v1() != request.expected_candidate_commitment
        {
            return Err(LedgerError::Invalid(
                "candidate resource migration does not bind the exact retained candidate".into(),
            ));
        }
        if candidate
            .exit_height
            .is_some_and(|exit_height| exit_height <= u128::from(self.height))
        {
            return Err(LedgerError::Invalid(
                "terminal candidate cannot enter active resource accounting".into(),
            ));
        }
        let sponsor_authorization = &request.resource_envelope.authorization;
        if request.authorization.authorization_id == sponsor_authorization.authorization_id
            || self
                .authorization_nullifiers
                .contains(sponsor_authorization.authorization_id.as_str())
        {
            return Err(LedgerError::Duplicate(
                sponsor_authorization.authorization_id.clone(),
            ));
        }
        let accounting = self
            .stake_resource_accounting
            .as_ref()
            .ok_or_else(|| LedgerError::StakeResource("no active stake resource policy".into()))?;
        self.validate_stake_resource_policy_covers_inventory(
            accounting.active_policy(),
            None,
            None,
        )?;
        let payload_hash = request.payload_hash();
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_ACTION_V1,
            &payload_hash,
        )?;
        let wire_bytes =
            ConsensusCommand::MigrateConsensusCandidateResource(Box::new(request.clone()))
                .wire_v1_command_bytes(&self.descriptor.network_domain)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::StakeResource("candidate migration exceeds the u32 wire meter".into())
            })?,
            persistent_bytes: migrate_consensus_candidate_resource_persistent_bytes_v1(
                &request, &candidate,
            )
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            signature_checks: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_SIGNATURE_CHECKS_V1,
            state_reads: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_READS_V1,
            state_writes: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_WRITES_V1,
        };
        let resource_key = format!("CANDIDATE/{}", candidate.validator_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Candidate,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let admission_height = self.height.checked_add(1).ok_or_else(|| {
            LedgerError::StakeResource("candidate migration height overflow".into())
        })?;
        let (next_accounting, admission) =
            self.prepare_position_resource_admission(admission_request, admission_height)?;
        let runtime_validator_keys = self.descriptor.validator_keys.clone();
        self.ensure_counter_headroom(1, 0)?;
        self.consume_authorization(&request.authorization)?;
        self.advance()?;
        self.commit_position_resource_admission(
            next_accounting,
            &admission,
            sponsor_authorization,
        )?;
        if self.descriptor.validator_keys != runtime_validator_keys
            || self.consensus_stake_authority.as_ref() != Some(&authority)
        {
            return Err(LedgerError::StakeResource(
                "candidate resource migration changed authority or runtime membership".into(),
            ));
        }
        Ok(MigrateConsensusCandidateResourceOutcomeV1 {
            candidate,
            resource_key,
            bond_id: admission.bond_record.bond_id.clone(),
            bond_coin_id: admission.bond_record.bond_coin_id.clone(),
            charged_fee: admission.charged_fee,
            locked_bond: admission.locked_bond,
            initial_bond_record_hash: admission.bond_record.initial_record_hash(),
        })
    }

    /// Attaches the protocol-fixed objective-fault slash terms to one exact
    /// active legacy position. Coin ownership and amount are unchanged.
    pub fn migrate_consensus_stake_slash_terms(
        &mut self,
        request: MigrateConsensusStakeSlashTermsV2,
    ) -> Result<ConsensusStakePosition, LedgerError> {
        let mut staged = self.clone();
        let position = staged.apply_consensus_stake_slash_terms_migration(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(position)
    }

    fn apply_consensus_stake_slash_terms_migration(
        &mut self,
        request: MigrateConsensusStakeSlashTermsV2,
    ) -> Result<ConsensusStakePosition, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus stake slash-terms migration requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.position_id.trim().is_empty()
            || request.escrow_coin_id.trim().is_empty()
            || request.owner.trim().is_empty()
        {
            return Err(LedgerError::Invalid(
                "consensus stake slash-terms migration is incomplete".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "stake slash-terms migration Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "stake slash-terms migration height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "stake slash-terms migration request expired".into(),
            ));
        }

        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "stake slash-terms migration authority precondition mismatch".into(),
            ));
        }
        let mut position = self
            .consensus_stake_escrows
            .get(&request.escrow_coin_id)
            .filter(|position| position.position_id == request.position_id)
            .cloned()
            .ok_or_else(|| {
                LedgerError::Invalid("registered stake position was not found".into())
            })?;
        if position.owner != request.owner {
            return Err(LedgerError::OwnerMismatch);
        }
        if position.slash_terms.is_some() {
            return Err(LedgerError::Duplicate(request.position_id));
        }
        if !authority.positions.contains(&position) {
            return Err(LedgerError::Invalid(
                "stake position is not active in the current authority".into(),
            ));
        }
        if self.consensus_stake_unbonds.values().any(|record| {
            record.position.position_id == position.position_id
                || record.position.escrow_coin_id == position.escrow_coin_id
        }) {
            return Err(LedgerError::Invalid(
                "stake position already has an unbond record".into(),
            ));
        }
        let escrow = self
            .coins
            .get(&position.escrow_coin_id)
            .ok_or_else(|| LedgerError::CoinNotFound(position.escrow_coin_id.clone()))?;
        if escrow.state != CoinState::Reserved
            || escrow.owner != position.owner
            || escrow.amount != position.amount
        {
            return Err(LedgerError::Invalid(
                "stake migration escrow is not the exact protected Reserved Coin".into(),
            ));
        }
        if request.slash_terms_authorization.authorization_id
            == request.authorization.authorization_id
        {
            return Err(LedgerError::Duplicate(
                request.authorization.authorization_id.clone(),
            ));
        }

        let slash_policy = ConsensusStakeSlashPolicyV2::protocol_v2();
        let slash_terms_payload_hash = position.slash_terms_payload_hash_v2();
        self.verify_owner_authorization(
            &request.slash_terms_authorization,
            &request.owner,
            ACCEPT_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
            &slash_terms_payload_hash,
        )?;
        let payload_hash = request.payload_hash(&position);
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            MIGRATE_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
            &payload_hash,
        )?;

        self.ensure_counter_headroom(1, 0)?;
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        position.slash_terms = Some(ConsensusStakeSlashTermsV2 {
            terms_version: slash_policy.policy_version,
            slash_policy,
            owner_authorization: request.slash_terms_authorization.clone(),
        });
        let mut positions = authority.positions.clone();
        let position_slot = positions
            .iter_mut()
            .find(|existing| existing.position_id == position.position_id)
            .expect("active position was checked");
        *position_slot = position.clone();

        self.consume_authorization(&request.authorization)?;
        self.consume_authorization(&request.slash_terms_authorization)?;
        self.advance()?;
        self.consensus_stake_escrows
            .insert(position.escrow_coin_id.clone(), position.clone());

        let mut ubo_control = authority.ubo_control.clone();
        ubo_control.predecessor_commitment = ubo_control_commitment_v1(&authority.ubo_control)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        ubo_control.sequence = ubo_control
            .sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake UBO sequence overflow".into()))?;
        let update = LedgerStakeAuthorityUpdateV1 {
            authority_version: authority.authority_version,
            sequence: authority
                .sequence
                .checked_add(1)
                .ok_or_else(|| LedgerError::Invalid("stake authority sequence overflow".into()))?,
            expected_previous_commitment: authority.commitment.clone(),
            policy: authority.policy.clone(),
            candidates: authority.candidates.clone(),
            positions,
            ubo_control,
        };
        let context = self.stake_context_at(source_height, source_state_root);
        let next_authority = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(self.height),
            Some(&authority),
            update,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if !next_authority.positions.contains(&position) {
            return Err(LedgerError::Invalid(
                "migrated position disappeared during canonicalization".into(),
            ));
        }
        self.consensus_stake_authority = Some(next_authority);
        Ok(position)
    }

    /// Atomically applies one objective-fault slash against an exact historical
    /// V2 liability. Evidence is permissionless; neither the reporter nor the
    /// current authority selects the penalty or destination.
    pub fn slash_consensus_stake(
        &mut self,
        request: SlashConsensusStakeV1,
    ) -> Result<ConsensusStakeSlashRecordV1, LedgerError> {
        let mut staged = self.clone();
        let record = staged.apply_consensus_stake_slash(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(record)
    }

    fn apply_consensus_stake_slash(
        &mut self,
        request: SlashConsensusStakeV1,
    ) -> Result<ConsensusStakeSlashRecordV1, LedgerError> {
        // Consensus-significant failure priority: envelope, replay, authority,
        // Epoch/liability, evidence/deadline, live escrow/unbond, accounting.
        if request.slash_id.trim().is_empty()
            || request.position_id.trim().is_empty()
            || request.escrow_coin_id.trim().is_empty()
            || request.expected_position_amount.is_zero()
            || !is_canonical_sha256_hex(&request.derived_epoch_record_hash)
            || !is_canonical_sha256_hex(&request.liability_commitment)
            || !is_canonical_sha256_hex(&request.evidence_hash)
            || request
                .expected_unbond_request_commitment
                .as_ref()
                .is_some_and(|hash| !is_canonical_sha256_hex(hash))
        {
            return Err(LedgerError::Invalid(
                "consensus stake slash envelope is incomplete or noncanonical".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "consensus stake slash Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "consensus stake slash height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "consensus stake slash request expired".into(),
            ));
        }
        if self.consensus_stake_slashes.contains_key(&request.slash_id) {
            return Err(LedgerError::Duplicate(request.slash_id));
        }
        let evidence_nullifier = consensus_stake_slash_nullifier_v1(
            &request.evidence_hash,
            &request.liability_commitment,
        );
        if self
            .consensus_stake_evidence_nullifiers
            .contains(&evidence_nullifier)
        {
            return Err(LedgerError::Duplicate(evidence_nullifier));
        }
        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "consensus stake slash authority precondition mismatch".into(),
            ));
        }

        let epoch = self
            .derived_stake_epochs
            .get(&request.consensus_epoch)
            .filter(|record| record.record_hash == request.derived_epoch_record_hash)
            .cloned()
            .ok_or_else(|| {
                LedgerError::Invalid("referenced derived stake Epoch was not found".into())
            })?;
        let verified = verify_consensus_stake_slash_evidence_v1(
            &epoch,
            &request.position_id,
            &request.liability_commitment,
            &request.evidence,
        )
        .map_err(|error| LedgerError::Invalid(format!("stake slash evidence rejected: {error}")))?;
        if verified.evidence_hash != request.evidence_hash {
            return Err(LedgerError::Invalid(
                "stake slash evidence hash mismatch".into(),
            ));
        }
        if verified.fault_height > u128::from(self.height) {
            return Err(LedgerError::Invalid(
                "stake slash evidence claims a future fault height".into(),
            ));
        }
        if u128::from(self.height) >= verified.liability.evidence_deadline_height {
            return Err(LedgerError::Invalid(
                "stake slash evidence window has closed".into(),
            ));
        }
        if verified.slash_bps != 10_000 {
            return Err(LedgerError::Invalid(
                "stake slash policy is not the supported full objective-fault penalty".into(),
            ));
        }

        let position = self
            .consensus_stake_escrows
            .get(&request.escrow_coin_id)
            .filter(|position| position.position_id == request.position_id)
            .cloned()
            .ok_or_else(|| {
                LedgerError::Invalid("slashable consensus stake escrow was not found".into())
            })?;
        if position != verified.liability.position
            || position.amount != request.expected_position_amount
            || position.escrow_coin_id != request.escrow_coin_id
        {
            return Err(LedgerError::Invalid(
                "live stake position does not equal the historical liability".into(),
            ));
        }
        if self
            .consensus_stake_slashes
            .values()
            .any(|record| record.position.position_id == position.position_id)
        {
            return Err(LedgerError::Duplicate(position.position_id));
        }
        let pending_unbond_id = self
            .consensus_stake_unbonds
            .iter()
            .find(|(_, record)| record.position.position_id == position.position_id)
            .map(|(request_id, _)| request_id.clone());
        let unbond_request_commitment = match (
            request.expected_unbond_request_commitment.as_deref(),
            pending_unbond_id.as_deref(),
        ) {
            (None, None) => None,
            (Some(expected), Some(request_id)) => {
                let record = self
                    .consensus_stake_unbonds
                    .get(request_id)
                    .expect("unbond request was found");
                if record.status != ConsensusStakeUnbondStatusV1::Pending
                    || record.request_commitment != expected
                {
                    return Err(LedgerError::Invalid(
                        "stake slash pending-unbond precondition mismatch".into(),
                    ));
                }
                Some(record.request_commitment.clone())
            }
            _ => {
                return Err(LedgerError::Invalid(
                    "stake slash must bind the exact pending-unbond state".into(),
                ));
            }
        };
        let escrow = self
            .coins
            .get(&position.escrow_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(position.escrow_coin_id.clone()))?;
        if escrow.state != CoinState::Reserved
            || escrow.owner != position.owner
            || escrow.amount != position.amount
            || escrow.parent_ids != [position.source_coin_id.clone()]
        {
            return Err(LedgerError::Invalid(
                "stake slash escrow is not the exact protected Reserved Coin".into(),
            ));
        }

        self.ensure_counter_headroom(1, 1)?;
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        let next_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake slash height overflow".into()))?;
        let next_authority = if authority.positions.contains(&position) {
            let mut positions = authority.positions.clone();
            positions.retain(|candidate| candidate.position_id != position.position_id);
            let mut ubo_control = authority.ubo_control.clone();
            ubo_control.predecessor_commitment = ubo_control_commitment_v1(&authority.ubo_control)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?;
            ubo_control.sequence = ubo_control
                .sequence
                .checked_add(1)
                .ok_or_else(|| LedgerError::Invalid("stake UBO sequence overflow".into()))?;
            let update = LedgerStakeAuthorityUpdateV1 {
                authority_version: authority.authority_version,
                sequence: authority.sequence.checked_add(1).ok_or_else(|| {
                    LedgerError::Invalid("stake authority sequence overflow".into())
                })?,
                expected_previous_commitment: authority.commitment.clone(),
                policy: authority.policy.clone(),
                candidates: authority.candidates.clone(),
                positions,
                ubo_control,
            };
            let context = self.stake_context_at(source_height, source_state_root);
            Some(
                build_ledger_stake_authority_state_v1(
                    &context,
                    u128::from(next_height),
                    Some(&authority),
                    update,
                    &self.coins,
                )
                .map_err(|error| LedgerError::Invalid(error.to_string()))?,
            )
        } else {
            None
        };

        let next_version = Self::checked_next_coin_version(escrow.version)?;
        self.advance()?;
        self.consensus_stake_escrows.remove(&escrow.object_id);
        self.coins
            .get_mut(&escrow.object_id)
            .expect("stake slash escrow was checked")
            .state = CoinState::Consumed;
        let safety_coin = self.make_coin(
            CONSENSUS_SLASH_SAFETY_POOL_V2.into(),
            position.amount,
            CoinState::Reserved,
            vec![escrow.object_id.clone()],
            Some(escrow.lineage_root.clone()),
            None,
            escrow.imported_from.clone(),
            next_version,
        )?;
        self.coins
            .insert(safety_coin.object_id.clone(), safety_coin.clone());
        if let Some(authority) = next_authority {
            self.consensus_stake_authority = Some(authority);
        }
        if let Some(request_id) = pending_unbond_id {
            let record = self
                .consensus_stake_unbonds
                .get_mut(&request_id)
                .expect("pending unbond was checked");
            record.status = ConsensusStakeUnbondStatusV1::FullySlashed;
            record.completed_height = Some(self.height);
            record.slash_id = Some(request.slash_id.clone());
            record.slashed_amount = position.amount;
        }

        let mut record = ConsensusStakeSlashRecordV1 {
            slash_id: request.slash_id.clone(),
            evidence_kind: verified.kind,
            evidence_hash: verified.evidence_hash.clone(),
            evidence: request.evidence,
            consensus_epoch: request.consensus_epoch,
            derived_epoch_record_hash: request.derived_epoch_record_hash,
            liability_commitment: request.liability_commitment,
            position,
            unbond_request_commitment,
            slash_bps: verified.slash_bps,
            slashed_amount: request.expected_position_amount,
            source_escrow_coin_id: escrow.object_id,
            safety_pool_coin_id: safety_coin.object_id,
            applied_height: self.height,
            record_hash: String::new(),
        };
        record.record_hash = record.compute_record_hash();
        self.consensus_stake_evidence_nullifiers
            .insert(evidence_nullifier);
        self.consensus_stake_slashes
            .insert(record.slash_id.clone(), record.clone());
        Ok(record)
    }

    /// Owner-authorized first phase of delayed withdrawal. The position is
    /// removed from the authority in the same atomic transition, so no later
    /// derived Epoch can count it while the Reserved Coin remains protected.
    pub fn request_consensus_stake_unbond(
        &mut self,
        request: RequestConsensusStakeUnbondV1,
    ) -> Result<ConsensusStakeUnbondRecordV1, LedgerError> {
        let mut staged = self.clone();
        let record = staged.apply_consensus_stake_unbond_request(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(record)
    }

    fn apply_consensus_stake_unbond_request(
        &mut self,
        request: RequestConsensusStakeUnbondV1,
    ) -> Result<ConsensusStakeUnbondRecordV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus stake unbond requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.position_id.trim().is_empty()
            || request.escrow_coin_id.trim().is_empty()
            || request.owner.trim().is_empty()
            || request.beneficiary.trim().is_empty()
        {
            return Err(LedgerError::Invalid(
                "consensus stake unbond request is incomplete".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "consensus stake unbond Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "consensus stake unbond height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "consensus stake unbond request expired".into(),
            ));
        }
        if request.beneficiary != request.owner {
            return Err(LedgerError::OwnerMismatch);
        }
        if self
            .consensus_stake_unbonds
            .contains_key(&request.request_id)
            || self.consensus_stake_unbonds.values().any(|record| {
                record.position.position_id == request.position_id
                    || record.position.escrow_coin_id == request.escrow_coin_id
            })
        {
            return Err(LedgerError::Duplicate(request.request_id));
        }

        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "consensus stake unbond authority precondition mismatch".into(),
            ));
        }
        let position = self
            .consensus_stake_escrows
            .get(&request.escrow_coin_id)
            .filter(|position| position.position_id == request.position_id)
            .cloned()
            .ok_or_else(|| {
                LedgerError::Invalid("registered stake position was not found".into())
            })?;
        if position.owner != request.owner {
            return Err(LedgerError::OwnerMismatch);
        }
        if !authority.positions.contains(&position) {
            return Err(LedgerError::Invalid(
                "stake position is not active in the current authority".into(),
            ));
        }
        let escrow = self
            .coins
            .get(&position.escrow_coin_id)
            .ok_or_else(|| LedgerError::CoinNotFound(position.escrow_coin_id.clone()))?;
        if escrow.state != CoinState::Reserved
            || escrow.owner != position.owner
            || escrow.amount != position.amount
        {
            return Err(LedgerError::Invalid(
                "stake unbond escrow is not the exact protected Reserved Coin".into(),
            ));
        }

        let requested_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake unbond request height overflow".into()))?;
        let notice_end = u128::from(requested_height)
            .checked_add(authority.policy.activation_delay_blocks)
            .ok_or_else(|| LedgerError::Invalid("stake unbond notice height overflow".into()))?;
        let validator_id = match &position.kind {
            ConsensusStakePositionKind::SelfBond { validator_id }
            | ConsensusStakePositionKind::Delegation { validator_id } => validator_id,
        };
        let mut protected_epoch_end = 0u128;
        for record in self.derived_stake_epochs.values().filter(|record| {
            record.stake_snapshot_height >= position.locked_height
                && record
                    .descriptor
                    .validators
                    .iter()
                    .any(|validator| validator.validator_id == *validator_id)
        }) {
            let validator_unbonding = record
                .descriptor
                .validators
                .iter()
                .find(|validator| validator.validator_id == *validator_id)
                .expect("filtered validator exists")
                .unbonding_height;
            protected_epoch_end = protected_epoch_end.max(validator_unbonding);
        }
        let minimum_withdrawal = notice_end
            .max(position.committed_through_height)
            .max(protected_epoch_end);
        if u128::from(request.requested_withdraw_after_height) < minimum_withdrawal {
            return Err(LedgerError::Invalid(
                "stake unbond withdrawal truncates notice, commitment or Epoch evidence window"
                    .into(),
            ));
        }

        let payload_hash = request.payload_hash();
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
            &payload_hash,
        )?;
        self.ensure_counter_headroom(1, 0)?;
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        let mut positions = authority.positions.clone();
        positions.retain(|candidate| candidate.position_id != position.position_id);
        let mut ubo_control = authority.ubo_control.clone();
        ubo_control.predecessor_commitment = ubo_control_commitment_v1(&authority.ubo_control)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        ubo_control.sequence = ubo_control
            .sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake UBO sequence overflow".into()))?;
        let update = LedgerStakeAuthorityUpdateV1 {
            authority_version: authority.authority_version,
            sequence: authority
                .sequence
                .checked_add(1)
                .ok_or_else(|| LedgerError::Invalid("stake authority sequence overflow".into()))?,
            expected_previous_commitment: authority.commitment.clone(),
            policy: authority.policy.clone(),
            candidates: authority.candidates.clone(),
            positions,
            ubo_control,
        };
        let context = self.stake_context_at(source_height, source_state_root);
        let next_authority = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(requested_height),
            Some(&authority),
            update,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        let mut record = ConsensusStakeUnbondRecordV1 {
            request_id: request.request_id.clone(),
            position,
            owner: request.owner,
            beneficiary: request.beneficiary,
            requested_height,
            withdraw_after_height: request.requested_withdraw_after_height,
            request_commitment: String::new(),
            status: ConsensusStakeUnbondStatusV1::Pending,
            completion_id: None,
            completed_height: None,
            payout_coin_id: None,
            slash_id: None,
            slashed_amount: Amount::ZERO,
        };
        record.request_commitment = record.compute_request_commitment();
        self.consume_authorization(&request.authorization)?;
        self.advance()?;
        self.consensus_stake_authority = Some(next_authority);
        self.consensus_stake_unbonds
            .insert(record.request_id.clone(), record.clone());
        Ok(record)
    }

    /// Completes one matured request by atomically consuming the protected
    /// escrow and creating an equal Spendable descendant for the fixed owner.
    pub fn complete_consensus_stake_unbond(
        &mut self,
        request: CompleteConsensusStakeUnbondV1,
    ) -> Result<ConsensusStakeUnbondRecordV1, LedgerError> {
        let mut staged = self.clone();
        let record = staged.apply_consensus_stake_unbond_completion(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(record)
    }

    fn apply_consensus_stake_unbond_completion(
        &mut self,
        request: CompleteConsensusStakeUnbondV1,
    ) -> Result<ConsensusStakeUnbondRecordV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus stake unbond completion requires VALUE_CAP_0".into(),
            ));
        }
        if request.completion_id.trim().is_empty()
            || request.request_id.trim().is_empty()
            || request.beneficiary.trim().is_empty()
        {
            return Err(LedgerError::Invalid(
                "consensus stake unbond completion is incomplete".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "stake unbond completion Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "stake unbond completion height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "stake unbond completion request expired".into(),
            ));
        }
        if self
            .consensus_stake_unbonds
            .values()
            .any(|record| record.completion_id.as_deref() == Some(request.completion_id.as_str()))
        {
            return Err(LedgerError::Duplicate(request.completion_id));
        }
        let mut record = self
            .consensus_stake_unbonds
            .get(&request.request_id)
            .cloned()
            .ok_or_else(|| LedgerError::Invalid("stake unbond request was not found".into()))?;
        if record.status != ConsensusStakeUnbondStatusV1::Pending {
            return Err(LedgerError::Duplicate(request.request_id));
        }
        if request.expected_unbond_request_commitment != record.request_commitment
            || request.beneficiary != record.beneficiary
            || record.beneficiary != record.owner
        {
            return Err(LedgerError::Invalid(
                "stake unbond completion changed the request commitment or beneficiary".into(),
            ));
        }
        if self.height < record.withdraw_after_height {
            return Err(LedgerError::Invalid(
                "stake unbond has not reached its withdrawal height".into(),
            ));
        }
        if self
            .consensus_stake_authority
            .as_ref()
            .is_some_and(|authority| {
                authority.positions.iter().any(|position| {
                    position.position_id == record.position.position_id
                        || position.escrow_coin_id == record.position.escrow_coin_id
                })
            })
        {
            return Err(LedgerError::Invalid(
                "stake unbond position is still active in the authority".into(),
            ));
        }
        if self
            .consensus_stake_escrows
            .get(&record.position.escrow_coin_id)
            != Some(&record.position)
        {
            return Err(LedgerError::Invalid(
                "stake unbond active escrow registry mismatch".into(),
            ));
        }
        let escrow = self
            .coins
            .get(&record.position.escrow_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(record.position.escrow_coin_id.clone()))?;
        if escrow.state != CoinState::Reserved
            || escrow.owner != record.owner
            || escrow.amount != record.position.amount
        {
            return Err(LedgerError::Invalid(
                "stake unbond escrow is no longer an exact Reserved Coin".into(),
            ));
        }

        self.ensure_counter_headroom(1, 1)?;
        let next_version = Self::checked_next_coin_version(escrow.version)?;
        self.advance()?;
        self.coins
            .get_mut(&escrow.object_id)
            .expect("stake unbond escrow was checked")
            .state = CoinState::Consumed;
        let payout = self.make_coin(
            record.beneficiary.clone(),
            escrow.amount,
            CoinState::Spendable,
            vec![escrow.object_id.clone()],
            Some(escrow.lineage_root.clone()),
            None,
            escrow.imported_from.clone(),
            next_version,
        )?;
        self.coins.insert(payout.object_id.clone(), payout.clone());
        self.consensus_stake_escrows.remove(&escrow.object_id);
        record.status = ConsensusStakeUnbondStatusV1::Completed;
        record.completion_id = Some(request.completion_id);
        record.completed_height = Some(self.height);
        record.payout_coin_id = Some(payout.object_id);
        self.consensus_stake_unbonds
            .insert(record.request_id.clone(), record.clone());
        Ok(record)
    }

    /// Appends one candidate through owner authorization and a proof made by
    /// the candidate consensus key. The registration height is assigned by
    /// the ledger and cannot be backdated by the request.
    pub fn register_consensus_validator(
        &mut self,
        request: RegisterConsensusValidatorRequestV1,
    ) -> Result<ValidatorCandidateRecord, LedgerError> {
        let mut staged = self.clone();
        let candidate = staged.apply_consensus_validator_registration(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(candidate)
    }

    fn apply_consensus_validator_registration(
        &mut self,
        request: RegisterConsensusValidatorRequestV1,
    ) -> Result<ValidatorCandidateRecord, LedgerError> {
        if self.stake_resource_accounting.is_some() {
            return Err(LedgerError::StakeResource(
                "legacy validator registration is disabled after resource-policy activation; use V2"
                    .into(),
            ));
        }
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus validator registration requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.validator_id.trim().is_empty()
            || request.owner.trim().is_empty()
            || request.public_key.trim().is_empty()
            || request.proof_of_possession.trim().is_empty()
        {
            return Err(LedgerError::Invalid(
                "consensus validator registration request is incomplete".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
            || request.key_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "consensus validator registration Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "consensus validator registration height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "consensus validator registration request expired".into(),
            ));
        }

        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "consensus validator registration authority precondition mismatch".into(),
            ));
        }
        if authority
            .candidates
            .iter()
            .any(|candidate| candidate.validator_id == request.validator_id)
        {
            return Err(LedgerError::Duplicate(request.validator_id));
        }
        if authority
            .candidates
            .iter()
            .any(|candidate| candidate.public_key == request.public_key)
        {
            return Err(LedgerError::Duplicate(request.public_key));
        }
        if !authority
            .ubo_control
            .validators
            .contains_key(&request.validator_id)
        {
            return Err(LedgerError::Invalid(
                "candidate has no separately governed UBO control record".into(),
            ));
        }

        let payload_hash = request.payload_hash();
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V1,
            &payload_hash,
        )?;
        self.ensure_counter_headroom(1, 0)?;
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        let registered_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("candidate registration height overflow".into()))?;
        let candidate = ValidatorCandidateRecord {
            validator_id: request.validator_id,
            owner: request.owner,
            public_key: request.public_key,
            key_era: request.key_era,
            registered_height: u128::from(registered_height),
            exit_height: None,
            proof_of_possession: request.proof_of_possession,
        };
        self.consume_authorization(&request.authorization)?;
        self.advance()?;

        let mut candidates = authority.candidates.clone();
        candidates.push(candidate.clone());
        let mut ubo_control = authority.ubo_control.clone();
        ubo_control.predecessor_commitment = ubo_control_commitment_v1(&authority.ubo_control)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        ubo_control.sequence = ubo_control
            .sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake UBO sequence overflow".into()))?;
        let update = LedgerStakeAuthorityUpdateV1 {
            authority_version: authority.authority_version,
            sequence: authority
                .sequence
                .checked_add(1)
                .ok_or_else(|| LedgerError::Invalid("stake authority sequence overflow".into()))?,
            expected_previous_commitment: authority.commitment.clone(),
            policy: authority.policy.clone(),
            candidates,
            positions: authority.positions.clone(),
            ubo_control,
        };
        let context = self.stake_context_at(source_height, source_state_root);
        let next_authority = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(self.height),
            Some(&authority),
            update,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if !next_authority.candidates.contains(&candidate) {
            return Err(LedgerError::Invalid(
                "registered candidate disappeared during canonicalization".into(),
            ));
        }
        self.consensus_stake_authority = Some(next_authority);
        Ok(candidate)
    }

    /// Appends one candidate only after consensus derives and charges its
    /// exact resource responsibility. Candidate membership remains staged;
    /// this transition never changes the runtime validator key set.
    pub fn register_consensus_validator_v2(
        &mut self,
        request: RegisterConsensusValidatorRequestV2,
    ) -> Result<RegisterConsensusValidatorOutcomeV2, LedgerError> {
        let mut staged = self.clone();
        let outcome = staged.apply_consensus_validator_registration_v2(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(outcome)
    }

    fn apply_consensus_validator_registration_v2(
        &mut self,
        request: RegisterConsensusValidatorRequestV2,
    ) -> Result<RegisterConsensusValidatorOutcomeV2, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "resource-bound validator registration requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.validator_id.trim().is_empty()
            || request.owner.trim().is_empty()
            || request.public_key.trim().is_empty()
            || request.proof_of_possession.trim().is_empty()
        {
            return Err(LedgerError::Invalid(
                "resource-bound validator registration request is incomplete".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
            || request.key_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "resource-bound validator registration Zone, currency or era binding mismatch"
                    .into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "resource-bound validator registration height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "resource-bound validator registration request expired".into(),
            ));
        }

        let accounting = self
            .stake_resource_accounting
            .clone()
            .ok_or_else(|| LedgerError::StakeResource("no active stake resource policy".into()))?;
        self.validate_stake_resource_policy_covers_inventory(
            accounting.active_policy(),
            Some(&request.owner),
            None,
        )?;
        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "resource-bound validator registration authority precondition mismatch".into(),
            ));
        }
        if authority
            .candidates
            .iter()
            .any(|candidate| candidate.validator_id == request.validator_id)
        {
            return Err(LedgerError::Duplicate(request.validator_id));
        }
        if authority
            .candidates
            .iter()
            .any(|candidate| candidate.public_key == request.public_key)
        {
            return Err(LedgerError::Duplicate(request.public_key));
        }
        if !authority
            .ubo_control
            .validators
            .contains_key(&request.validator_id)
        {
            return Err(LedgerError::Invalid(
                "candidate has no separately governed UBO control record".into(),
            ));
        }

        let sponsor_authorization = &request.resource_envelope.authorization;
        if sponsor_authorization.authorization_id == request.authorization.authorization_id
            || self
                .authorization_nullifiers
                .contains(&sponsor_authorization.authorization_id)
        {
            return Err(LedgerError::Duplicate(
                sponsor_authorization.authorization_id.clone(),
            ));
        }
        let payload_hash = request.payload_hash();
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V2,
            &payload_hash,
        )?;

        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        let registered_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("candidate registration height overflow".into()))?;
        let candidate = ValidatorCandidateRecord {
            validator_id: request.validator_id.clone(),
            owner: request.owner.clone(),
            public_key: request.public_key.clone(),
            key_era: request.key_era,
            registered_height: u128::from(registered_height),
            exit_height: None,
            proof_of_possession: request.proof_of_possession.clone(),
        };
        let mut candidates = authority.candidates.clone();
        candidates.push(candidate.clone());
        let mut ubo_control = authority.ubo_control.clone();
        ubo_control.predecessor_commitment = ubo_control_commitment_v1(&authority.ubo_control)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        ubo_control.sequence = ubo_control
            .sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake UBO sequence overflow".into()))?;
        let update = LedgerStakeAuthorityUpdateV1 {
            authority_version: authority.authority_version,
            sequence: authority
                .sequence
                .checked_add(1)
                .ok_or_else(|| LedgerError::Invalid("stake authority sequence overflow".into()))?,
            expected_previous_commitment: authority.commitment.clone(),
            policy: authority.policy.clone(),
            candidates,
            positions: authority.positions.clone(),
            ubo_control,
        };
        let context = self.stake_context_at(source_height, source_state_root);
        let next_authority = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(registered_height),
            Some(&authority),
            update,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if !next_authority.candidates.contains(&candidate) {
            return Err(LedgerError::Invalid(
                "registered candidate disappeared during canonicalization".into(),
            ));
        }

        let wire_bytes = ConsensusCommand::RegisterConsensusValidatorV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::StakeResource("candidate command exceeds the u32 wire meter".into())
            })?,
            persistent_bytes: register_consensus_validator_persistent_bytes_v2(&request)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            signature_checks: REGISTER_CONSENSUS_VALIDATOR_SIGNATURE_CHECKS_V2,
            state_reads: REGISTER_CONSENSUS_VALIDATOR_STATE_READS_V2,
            state_writes: REGISTER_CONSENSUS_VALIDATOR_STATE_WRITES_V2,
        };
        let resource_key = format!("CANDIDATE/{}", request.validator_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Candidate,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let funding_coin = self
            .coins
            .get(&request.resource_envelope.funding_coin_id)
            .cloned()
            .ok_or_else(|| {
                LedgerError::CoinNotFound(request.resource_envelope.funding_coin_id.clone())
            })?;
        let mut protected_coin_ids = self
            .consensus_stake_escrows
            .keys()
            .cloned()
            .collect::<BTreeSet<_>>();
        protected_coin_ids.extend(
            accounting
                .bonds()
                .values()
                .map(|record| record.bond_coin_id.clone()),
        );
        let mut next_accounting = accounting;
        let admission = next_accounting
            .admit(
                admission_request,
                &funding_coin,
                &protected_coin_ids,
                registered_height,
            )
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;

        let mut output_ids = BTreeSet::new();
        for coin in std::iter::once(&admission.bond_coin).chain(admission.change_coin.iter()) {
            if !output_ids.insert(coin.object_id.as_str())
                || self.coins.contains_key(&coin.object_id)
                || coin.object_id == funding_coin.object_id
            {
                return Err(LedgerError::Duplicate(coin.object_id.clone()));
            }
        }
        self.ensure_counter_headroom(1, 0)?;
        let runtime_validator_keys = self.descriptor.validator_keys.clone();
        self.consume_authorization(&request.authorization)?;
        self.consume_authorization(sponsor_authorization)?;
        self.advance()?;
        self.coins.insert(
            admission.consumed_funding_coin.object_id.clone(),
            admission.consumed_funding_coin.clone(),
        );
        self.coins.insert(
            admission.bond_coin.object_id.clone(),
            admission.bond_coin.clone(),
        );
        if let Some(change_coin) = &admission.change_coin {
            self.coins
                .insert(change_coin.object_id.clone(), change_coin.clone());
        }
        self.stake_resource_accounting = Some(next_accounting);
        self.consensus_stake_authority = Some(next_authority);
        if self.descriptor.validator_keys != runtime_validator_keys {
            return Err(LedgerError::StakeResource(
                "candidate admission changed runtime validator membership".into(),
            ));
        }

        Ok(RegisterConsensusValidatorOutcomeV2 {
            candidate,
            resource_key,
            bond_id: admission.bond_record.bond_id.clone(),
            bond_coin_id: admission.bond_record.bond_coin_id.clone(),
            charged_fee: admission.charged_fee,
            locked_bond: admission.locked_bond,
            initial_bond_record_hash: admission.bond_record.initial_record_hash(),
        })
    }

    fn replay_consensus_validator_registration_v2(
        &self,
        request: &RegisterConsensusValidatorRequestV2,
        expected_height: u64,
    ) -> Result<RegisterConsensusValidatorOutcomeV2, LedgerError> {
        let accounting = self.stake_resource_accounting.as_ref().ok_or_else(|| {
            LedgerError::InvalidQuorum(
                "recorded resource-bound candidate has no accounting state".into(),
            )
        })?;
        let wire_bytes = ConsensusCommand::RegisterConsensusValidatorV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::InvalidQuorum("recorded candidate wire meter overflow".into())
            })?,
            persistent_bytes: register_consensus_validator_persistent_bytes_v2(request)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
            signature_checks: REGISTER_CONSENSUS_VALIDATOR_SIGNATURE_CHECKS_V2,
            state_reads: REGISTER_CONSENSUS_VALIDATOR_STATE_READS_V2,
            state_writes: REGISTER_CONSENSUS_VALIDATOR_STATE_WRITES_V2,
        };
        let resource_key = format!("CANDIDATE/{}", request.validator_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Candidate,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let expected_subject =
            stake_state_resource_subject_hash_v1(accounting.context(), &admission_request);
        let record = accounting.bonds().get(&resource_key).ok_or_else(|| {
            LedgerError::InvalidQuorum(
                "recorded resource-bound candidate has no retained bond record".into(),
            )
        })?;
        if record.resource_kind != StakeStateResourceKindV1::Candidate
            || record.resource_owner != request.owner
            || record.resource_policy_sequence != request.resource_envelope.resource_policy_sequence
            || record.resource_policy_commitment
                != request.resource_envelope.resource_policy_commitment
            || record.resource_subject_hash != expected_subject
            || record.resource_subject_hash != request.resource_envelope.resource_subject_hash
            || record.sponsor != request.resource_envelope.sponsor
            || record.sponsor_authorization_id
                != request.resource_envelope.authorization.authorization_id
            || record.funding_source_coin_id != request.resource_envelope.funding_coin_id
            || record.created_height != expected_height
            || record.charged_wire_bytes != usage.wire_bytes
            || record.charged_persistent_bytes != usage.persistent_bytes
            || record.charged_signature_checks != usage.signature_checks
            || record.charged_state_reads != usage.state_reads
            || record.charged_state_writes != usage.state_writes
        {
            return Err(LedgerError::InvalidQuorum(
                "recorded resource-bound candidate does not match its immutable admission".into(),
            ));
        }
        Ok(RegisterConsensusValidatorOutcomeV2 {
            candidate: ValidatorCandidateRecord {
                validator_id: request.validator_id.clone(),
                owner: request.owner.clone(),
                public_key: request.public_key.clone(),
                key_era: request.key_era,
                registered_height: u128::from(expected_height),
                exit_height: None,
                proof_of_possession: request.proof_of_possession.clone(),
            },
            resource_key,
            bond_id: record.bond_id.clone(),
            bond_coin_id: record.bond_coin_id.clone(),
            charged_fee: record.charged_creation_fee,
            locked_bond: record.locked_amount,
            initial_bond_record_hash: record.initial_record_hash(),
        })
    }

    fn retained_consensus_stake_position(
        &self,
        position_id: &str,
        escrow_coin_id: Option<&str>,
    ) -> Option<ConsensusStakePosition> {
        let matches = |position: &&ConsensusStakePosition| {
            position.position_id == position_id
                && escrow_coin_id.is_none_or(|coin_id| position.escrow_coin_id == coin_id)
        };
        self.consensus_stake_escrows
            .values()
            .find(matches)
            .or_else(|| {
                self.consensus_stake_unbonds
                    .values()
                    .map(|record| &record.position)
                    .find(matches)
            })
            .or_else(|| {
                self.consensus_stake_slashes
                    .values()
                    .map(|record| &record.position)
                    .find(matches)
            })
            .cloned()
    }

    fn verify_recorded_position_resource_admission(
        &self,
        admission_request: &StakeStateResourceAdmissionRequestV1,
        expected_height: u64,
    ) -> Result<&crate::StakeStateBondRecordV2, LedgerError> {
        let accounting = self.stake_resource_accounting.as_ref().ok_or_else(|| {
            LedgerError::InvalidQuorum(
                "recorded resource-bound position has no accounting state".into(),
            )
        })?;
        let expected_subject =
            stake_state_resource_subject_hash_v1(accounting.context(), admission_request);
        let record = accounting
            .bonds()
            .get(&admission_request.resource_key)
            .ok_or_else(|| {
                LedgerError::InvalidQuorum(
                    "recorded resource-bound position has no retained bond record".into(),
                )
            })?;
        let envelope = &admission_request.envelope;
        let usage = admission_request.usage;
        if record.resource_kind != StakeStateResourceKindV1::Position
            || record.resource_owner != admission_request.resource_owner
            || record.resource_policy_sequence != envelope.resource_policy_sequence
            || record.resource_policy_commitment != envelope.resource_policy_commitment
            || record.resource_subject_hash != expected_subject
            || record.resource_subject_hash != envelope.resource_subject_hash
            || record.sponsor != envelope.sponsor
            || record.sponsor_authorization_id != envelope.authorization.authorization_id
            || record.funding_source_coin_id != envelope.funding_coin_id
            || record.created_height != expected_height
            || record.charged_wire_bytes != usage.wire_bytes
            || record.charged_persistent_bytes != usage.persistent_bytes
            || record.charged_signature_checks != usage.signature_checks
            || record.charged_state_reads != usage.state_reads
            || record.charged_state_writes != usage.state_writes
        {
            return Err(LedgerError::InvalidQuorum(
                "recorded position does not match its immutable resource admission".into(),
            ));
        }
        Ok(record)
    }

    fn verify_recorded_resource_admission(
        &self,
        admission_request: &StakeStateResourceAdmissionRequestV1,
        expected_height: u64,
        expected_kind: StakeStateResourceKindV1,
        label: &str,
    ) -> Result<&crate::StakeStateBondRecordV2, LedgerError> {
        let accounting = self.stake_resource_accounting.as_ref().ok_or_else(|| {
            LedgerError::InvalidQuorum(format!("recorded {label} has no resource accounting state"))
        })?;
        let expected_subject =
            stake_state_resource_subject_hash_v1(accounting.context(), admission_request);
        let record = accounting
            .bonds()
            .get(&admission_request.resource_key)
            .ok_or_else(|| {
                LedgerError::InvalidQuorum(format!(
                    "recorded {label} has no retained resource bond"
                ))
            })?;
        let envelope = &admission_request.envelope;
        let usage = admission_request.usage;
        if record.resource_kind != expected_kind
            || record.resource_owner != admission_request.resource_owner
            || record.resource_policy_sequence != envelope.resource_policy_sequence
            || record.resource_policy_commitment != envelope.resource_policy_commitment
            || record.resource_subject_hash != expected_subject
            || record.resource_subject_hash != envelope.resource_subject_hash
            || record.sponsor != envelope.sponsor
            || record.sponsor_authorization_id != envelope.authorization.authorization_id
            || record.funding_source_coin_id != envelope.funding_coin_id
            || record.created_height != expected_height
            || record.charged_wire_bytes != usage.wire_bytes
            || record.charged_persistent_bytes != usage.persistent_bytes
            || record.charged_signature_checks != usage.signature_checks
            || record.charged_state_reads != usage.state_reads
            || record.charged_state_writes != usage.state_writes
        {
            return Err(LedgerError::InvalidQuorum(format!(
                "recorded {label} does not match its immutable resource admission"
            )));
        }
        Ok(record)
    }

    fn replay_consensus_stake_lock_v3(
        &self,
        request: &LockConsensusStakeRequestV3,
        expected_height: u64,
    ) -> Result<LockConsensusStakeOutcomeV3, LedgerError> {
        let position = self
            .retained_consensus_stake_position(&request.position_id, None)
            .ok_or_else(|| {
                LedgerError::InvalidQuorum(
                    "recorded V3 lock has no retained position or permanent tombstone".into(),
                )
            })?;
        let expected_kind = match request.position_type {
            StakePositionTypeV1::SelfBond => ConsensusStakePositionKind::SelfBond {
                validator_id: request.validator_id.clone(),
            },
            StakePositionTypeV1::Delegation => ConsensusStakePositionKind::Delegation {
                validator_id: request.validator_id.clone(),
            },
        };
        let expected_terms = ConsensusStakeSlashTermsV2 {
            terms_version: ConsensusStakeSlashPolicyV2::protocol_v2().policy_version,
            slash_policy: ConsensusStakeSlashPolicyV2::protocol_v2(),
            owner_authorization: request.slash_terms_authorization.clone(),
        };
        if position.kind != expected_kind
            || position.owner != request.owner
            || position.source_coin_id != request.source_coin_id
            || position.amount != request.amount
            || position.locked_height != u128::from(expected_height)
            || position.committed_through_height != u128::from(request.committed_through_height)
            || position.slash_terms.as_ref() != Some(&expected_terms)
        {
            return Err(LedgerError::InvalidQuorum(
                "recorded V3 lock does not match its immutable position".into(),
            ));
        }
        let wire_bytes = ConsensusCommand::LockConsensusStakeV3(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::InvalidQuorum("recorded V3 stake wire meter overflow".into())
            })?,
            persistent_bytes: lock_consensus_stake_persistent_bytes_v3(request)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
            signature_checks: LOCK_CONSENSUS_STAKE_SIGNATURE_CHECKS_V3,
            state_reads: LOCK_CONSENSUS_STAKE_STATE_READS_V3,
            state_writes: LOCK_CONSENSUS_STAKE_STATE_WRITES_V3,
        };
        let resource_key = format!("POSITION/{}", request.position_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Position,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let record =
            self.verify_recorded_position_resource_admission(&admission_request, expected_height)?;
        Ok(LockConsensusStakeOutcomeV3 {
            position,
            resource_key,
            bond_id: record.bond_id.clone(),
            bond_coin_id: record.bond_coin_id.clone(),
            charged_fee: record.charged_creation_fee,
            locked_bond: record.locked_amount,
            initial_bond_record_hash: record.initial_record_hash(),
        })
    }

    fn replay_consensus_stake_resource_migration(
        &self,
        request: &MigrateConsensusStakeResourceRequestV1,
        expected_height: u64,
    ) -> Result<MigrateConsensusStakeResourceOutcomeV1, LedgerError> {
        let position = self
            .retained_consensus_stake_position(&request.position_id, Some(&request.escrow_coin_id))
            .filter(|position| {
                position.owner == request.owner
                    && position.resource_commitment_v1() == request.expected_position_commitment
            })
            .ok_or_else(|| {
                LedgerError::InvalidQuorum(
                    "recorded resource migration has no exact retained position".into(),
                )
            })?;
        let wire_bytes = ConsensusCommand::MigrateConsensusStakeResource(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::InvalidQuorum("recorded resource migration wire overflow".into())
            })?,
            persistent_bytes: migrate_consensus_stake_resource_persistent_bytes_v1(
                request, &position,
            )
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
            signature_checks: MIGRATE_CONSENSUS_STAKE_RESOURCE_SIGNATURE_CHECKS_V1,
            state_reads: MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_READS_V1,
            state_writes: MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_WRITES_V1,
        };
        let resource_key = format!("POSITION/{}", request.position_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Position,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let record =
            self.verify_recorded_position_resource_admission(&admission_request, expected_height)?;
        Ok(MigrateConsensusStakeResourceOutcomeV1 {
            position,
            resource_key,
            bond_id: record.bond_id.clone(),
            bond_coin_id: record.bond_coin_id.clone(),
            charged_fee: record.charged_creation_fee,
            locked_bond: record.locked_amount,
            initial_bond_record_hash: record.initial_record_hash(),
        })
    }

    fn replay_consensus_candidate_resource_migration(
        &self,
        request: &MigrateConsensusCandidateResourceRequestV1,
        expected_height: u64,
    ) -> Result<MigrateConsensusCandidateResourceOutcomeV1, LedgerError> {
        let candidate = ValidatorCandidateRecord {
            validator_id: request.validator_id.clone(),
            owner: request.owner.clone(),
            public_key: request.public_key.clone(),
            key_era: request.key_era,
            registered_height: u128::from(request.registered_height),
            exit_height: request.exit_height.map(u128::from),
            proof_of_possession: request.proof_of_possession.clone(),
        };
        if candidate.resource_commitment_v1() != request.expected_candidate_commitment {
            return Err(LedgerError::InvalidQuorum(
                "recorded candidate migration commitment is not self-consistent".into(),
            ));
        }
        let retained = self
            .consensus_stake_authority
            .as_ref()
            .and_then(|authority| {
                authority
                    .candidates
                    .iter()
                    .find(|current| current.validator_id == candidate.validator_id)
            })
            .ok_or_else(|| {
                LedgerError::InvalidQuorum(
                    "recorded candidate migration has no retained candidate".into(),
                )
            })?;
        let exit_history_matches = match candidate.exit_height {
            Some(recorded_exit) => retained.exit_height == Some(recorded_exit),
            None => true,
        };
        if retained.owner != candidate.owner
            || retained.public_key != candidate.public_key
            || retained.key_era != candidate.key_era
            || retained.registered_height != candidate.registered_height
            || retained.proof_of_possession != candidate.proof_of_possession
            || !exit_history_matches
        {
            return Err(LedgerError::InvalidQuorum(
                "retained candidate diverges from recorded migration history".into(),
            ));
        }
        let wire_bytes =
            ConsensusCommand::MigrateConsensusCandidateResource(Box::new(request.clone()))
                .wire_v1_command_bytes(&self.descriptor.network_domain)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::InvalidQuorum("recorded candidate migration wire overflow".into())
            })?,
            persistent_bytes: migrate_consensus_candidate_resource_persistent_bytes_v1(
                request, &candidate,
            )
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
            signature_checks: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_SIGNATURE_CHECKS_V1,
            state_reads: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_READS_V1,
            state_writes: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_WRITES_V1,
        };
        let resource_key = format!("CANDIDATE/{}", request.validator_id);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Candidate,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let record = self.verify_recorded_resource_admission(
            &admission_request,
            expected_height,
            StakeStateResourceKindV1::Candidate,
            "candidate migration",
        )?;
        Ok(MigrateConsensusCandidateResourceOutcomeV1 {
            candidate,
            resource_key,
            bond_id: record.bond_id.clone(),
            bond_coin_id: record.bond_coin_id.clone(),
            charged_fee: record.charged_creation_fee,
            locked_bond: record.locked_amount,
            initial_bond_record_hash: record.initial_record_hash(),
        })
    }

    fn replay_next_stake_epoch_v2(
        &self,
        request: &DeriveNextStakeEpochRequestV2,
        expected_height: u64,
    ) -> Result<DeriveNextStakeEpochOutcomeV2, LedgerError> {
        let epoch = self
            .derived_stake_epochs
            .get(&request.expected_consensus_epoch)
            .filter(|record| record.record_hash == request.expected_derived_record_hash)
            .cloned()
            .ok_or_else(|| {
                LedgerError::InvalidQuorum(
                    "recorded resource-bound Epoch has no exact retained record".into(),
                )
            })?;
        let wire_bytes = ConsensusCommand::DeriveNextStakeEpochV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        let horizon_usage =
            self.recorded_stake_liability_horizon_usage(epoch.descriptor.consensus_epoch)?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::InvalidQuorum("recorded Epoch V2 wire overflow".into())
            })?,
            persistent_bytes: derive_next_stake_epoch_persistent_bytes_v2(
                request,
                &epoch,
                horizon_usage,
            )
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
            signature_checks: DERIVE_NEXT_STAKE_EPOCH_SIGNATURE_CHECKS_V2,
            state_reads: derive_next_stake_epoch_state_reads_v2(&epoch, horizon_usage)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
            state_writes: derive_next_stake_epoch_state_writes_v2(horizon_usage)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
        };
        let resource_key = format!("EPOCH/{}", request.expected_consensus_epoch);
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Epoch,
            resource_owner: request.payer.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: epoch.previous_record_hash.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let record = self.verify_recorded_resource_admission(
            &admission_request,
            expected_height,
            StakeStateResourceKindV1::Epoch,
            "resource-bound Epoch",
        )?;
        Ok(DeriveNextStakeEpochOutcomeV2 {
            epoch,
            resource_key,
            bond_id: record.bond_id.clone(),
            bond_coin_id: record.bond_coin_id.clone(),
            charged_fee: record.charged_creation_fee,
            locked_bond: record.locked_amount,
            initial_bond_record_hash: record.initial_record_hash(),
        })
    }

    /// Sets a candidate's immutable exit height. Both the owner wallet and the
    /// candidate consensus key authorize the exact updated record.
    pub fn exit_consensus_validator(
        &mut self,
        request: ExitConsensusValidatorRequestV1,
    ) -> Result<ValidatorCandidateRecord, LedgerError> {
        let mut staged = self.clone();
        let candidate = staged.apply_consensus_validator_exit(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(candidate)
    }

    fn apply_consensus_validator_exit(
        &mut self,
        request: ExitConsensusValidatorRequestV1,
    ) -> Result<ValidatorCandidateRecord, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "consensus validator exit requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.validator_id.trim().is_empty()
            || request.owner.trim().is_empty()
            || request.public_key.trim().is_empty()
            || request.proof_of_possession.trim().is_empty()
        {
            return Err(LedgerError::Invalid(
                "consensus validator exit request is incomplete".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "consensus validator exit Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height {
            return Err(LedgerError::Invalid(
                "consensus validator exit height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "consensus validator exit request expired".into(),
            ));
        }

        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "consensus validator exit authority precondition mismatch".into(),
            ));
        }
        let mut candidate = authority
            .candidates
            .iter()
            .find(|candidate| candidate.validator_id == request.validator_id)
            .cloned()
            .ok_or_else(|| LedgerError::Invalid("validator candidate was not found".into()))?;
        if candidate.owner != request.owner {
            return Err(LedgerError::OwnerMismatch);
        }
        if candidate.public_key != request.public_key
            || candidate.key_era != request.key_era
            || candidate.registered_height != u128::from(request.registered_height)
        {
            return Err(LedgerError::Invalid(
                "candidate exit does not bind the exact registered candidate".into(),
            ));
        }
        if candidate.exit_height.is_some() {
            return Err(LedgerError::Invalid(
                "validator candidate exit is already final".into(),
            ));
        }
        let effective_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("candidate exit height overflow".into()))?;
        let notice_end = u128::from(effective_height)
            .checked_add(authority.policy.activation_delay_blocks)
            .ok_or_else(|| LedgerError::Invalid("candidate exit notice overflow".into()))?;
        let protected_epoch_end = self
            .derived_stake_epochs
            .values()
            .filter(|record| {
                record
                    .descriptor
                    .validators
                    .iter()
                    .any(|validator| validator.validator_id == candidate.validator_id)
            })
            .map(|record| record.descriptor.exit_height)
            .max()
            .unwrap_or(0);
        let minimum_exit_height = notice_end.max(protected_epoch_end);
        if u128::from(request.exit_height) < minimum_exit_height
            || u128::from(request.exit_height) <= candidate.registered_height
        {
            return Err(LedgerError::Invalid(
                "candidate exit does not preserve notice and already-derived Epoch windows".into(),
            ));
        }
        candidate.exit_height = Some(u128::from(request.exit_height));
        candidate.proof_of_possession = request.proof_of_possession.clone();

        let payload_hash = request.payload_hash();
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            EXIT_CONSENSUS_VALIDATOR_ACTION_V1,
            &payload_hash,
        )?;
        self.ensure_counter_headroom(1, 0)?;
        let source_height = u128::from(self.height);
        let source_state_root = self.state_root()?;
        self.consume_authorization(&request.authorization)?;
        self.advance()?;

        let mut candidates = authority.candidates.clone();
        let candidate_slot = candidates
            .iter_mut()
            .find(|existing| existing.validator_id == candidate.validator_id)
            .expect("candidate was checked");
        *candidate_slot = candidate.clone();
        let mut ubo_control = authority.ubo_control.clone();
        ubo_control.predecessor_commitment = ubo_control_commitment_v1(&authority.ubo_control)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        ubo_control.sequence = ubo_control
            .sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake UBO sequence overflow".into()))?;
        let update = LedgerStakeAuthorityUpdateV1 {
            authority_version: authority.authority_version,
            sequence: authority
                .sequence
                .checked_add(1)
                .ok_or_else(|| LedgerError::Invalid("stake authority sequence overflow".into()))?,
            expected_previous_commitment: authority.commitment.clone(),
            policy: authority.policy.clone(),
            candidates,
            positions: authority.positions.clone(),
            ubo_control,
        };
        let context = self.stake_context_at(source_height, source_state_root);
        let next_authority = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(self.height),
            Some(&authority),
            update,
            &self.coins,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if !next_authority.candidates.contains(&candidate) {
            return Err(LedgerError::Invalid(
                "exited candidate disappeared during canonicalization".into(),
            ));
        }
        self.consensus_stake_authority = Some(next_authority);
        Ok(candidate)
    }

    /// Persists exactly the deterministic next candidate Epoch.  The request
    /// carries only preconditions; it cannot supply a validator set and it
    /// never changes the runtime descriptor's validator keys.
    pub fn derive_next_stake_epoch(
        &mut self,
        request: DeriveNextStakeEpochRequestV1,
    ) -> Result<LedgerDerivedStakeEpochV1, LedgerError> {
        if self.stake_resource_accounting.is_some() {
            return Err(LedgerError::StakeResource(
                "legacy stake Epoch derivation is disabled after resource-policy activation; use V2"
                    .into(),
            ));
        }
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "stake Epoch derivation requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty() {
            return Err(LedgerError::Invalid(
                "stake Epoch derivation request id is required".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "stake Epoch request Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height || request.expected_snapshot_height != self.height
        {
            return Err(LedgerError::Invalid(
                "stake Epoch request height does not match current state".into(),
            ));
        }
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "stake Epoch derivation request expired".into(),
            ));
        }
        let authority = self
            .consensus_stake_authority
            .as_ref()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "stake Epoch request authority precondition mismatch".into(),
            ));
        }
        let expected_epoch = self
            .derived_stake_epochs
            .keys()
            .next_back()
            .copied()
            .unwrap_or(0)
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake Epoch overflow".into()))?;
        if request.expected_consensus_epoch != expected_epoch {
            return Err(LedgerError::Invalid(
                "stake Epoch request sequence precondition mismatch".into(),
            ));
        }
        let root = self.state_root()?;
        if request.expected_snapshot_state_root != root {
            return Err(LedgerError::Invalid(
                "stake Epoch request state-root precondition mismatch".into(),
            ));
        }
        let runtime_validator_keys = self.descriptor.validator_keys.clone();
        let mut staged = self.clone();
        let record = staged.derive_and_store_next_stake_epoch()?;
        if record.descriptor.consensus_epoch != expected_epoch
            || staged.descriptor.validator_keys != runtime_validator_keys
        {
            return Err(LedgerError::Invalid(
                "stake Epoch derivation changed an immutable precondition".into(),
            ));
        }
        *self = staged;
        Ok(record)
    }

    /// Persists one deterministic Epoch only when every selected candidate,
    /// every retained liability and the new Epoch record itself have funded
    /// resource responsibility through the evidence/retention boundary.
    pub fn derive_next_stake_epoch_v2(
        &mut self,
        request: DeriveNextStakeEpochRequestV2,
    ) -> Result<DeriveNextStakeEpochOutcomeV2, LedgerError> {
        let mut staged = self.clone();
        let outcome = staged.apply_next_stake_epoch_v2(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(outcome)
    }

    fn apply_next_stake_epoch_v2(
        &mut self,
        request: DeriveNextStakeEpochRequestV2,
    ) -> Result<DeriveNextStakeEpochOutcomeV2, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "resource-bound stake Epoch derivation requires VALUE_CAP_0".into(),
            ));
        }
        if request.request_id.trim().is_empty()
            || request.payer.trim().is_empty()
            || !is_canonical_sha256_hex(&request.expected_derived_record_hash)
        {
            return Err(LedgerError::Invalid(
                "resource-bound stake Epoch request is incomplete or noncanonical".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "resource-bound stake Epoch Zone, currency or era binding mismatch".into(),
            ));
        }
        if request.proposed_height != self.height
            || request.expected_snapshot_height != self.height
            || request.expires_at_height <= self.height
        {
            return Err(LedgerError::Invalid(
                "resource-bound stake Epoch height is stale or expired".into(),
            ));
        }
        let authority = self
            .consensus_stake_authority
            .clone()
            .ok_or_else(|| LedgerError::Invalid("ledger has no staged stake authority".into()))?;
        validate_ledger_stake_authority_state_v1(&authority)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if authority.sequence != request.expected_authority_sequence
            || authority.commitment != request.expected_authority_commitment
        {
            return Err(LedgerError::Invalid(
                "resource-bound stake Epoch authority precondition mismatch".into(),
            ));
        }
        let expected_epoch = self
            .derived_stake_epochs
            .keys()
            .next_back()
            .copied()
            .unwrap_or(0)
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("stake Epoch overflow".into()))?;
        if request.expected_consensus_epoch != expected_epoch {
            return Err(LedgerError::Invalid(
                "resource-bound stake Epoch sequence precondition mismatch".into(),
            ));
        }
        let snapshot_root = self.state_root()?;
        if request.expected_snapshot_state_root != snapshot_root {
            return Err(LedgerError::Invalid(
                "resource-bound stake Epoch state-root precondition mismatch".into(),
            ));
        }

        // Preview on an isolated copy. The output hash is signed by the payer
        // and sponsor before any Coin, nullifier or Epoch record is mutated.
        let mut preview_ledger = self.clone();
        let preview = preview_ledger.derive_and_store_next_stake_epoch()?;
        if preview.derivation_version != crate::STAKE_EPOCH_DERIVATION_VERSION_V2
            || preview.descriptor.consensus_epoch != expected_epoch
            || preview.record_hash != request.expected_derived_record_hash
        {
            return Err(LedgerError::Invalid(
                "resource-bound stake Epoch requires derivation v2 and an exact output commitment"
                    .into(),
            ));
        }
        let (preview_horizons, preview_horizon_history) =
            self.preview_stake_liability_horizon_update(&preview)?;
        let horizon_usage = stake_liability_horizon_usage_delta_v1(
            &self.stake_position_liability_horizons,
            &self.stake_position_liability_horizon_history,
            &preview_horizons,
            &preview_horizon_history,
        )
        .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let accounting = self
            .stake_resource_accounting
            .as_ref()
            .ok_or_else(|| LedgerError::StakeResource("no active stake resource policy".into()))?;
        self.validate_stake_resource_policy_covers_inventory(
            accounting.active_policy(),
            None,
            None,
        )?;
        let evidence_deadline = preview
            .descriptor
            .exit_height
            .checked_add(authority.policy.evidence_window_blocks)
            .ok_or_else(|| LedgerError::StakeResource("Epoch evidence deadline overflow".into()))?;
        let required_lease_end_u128 = evidence_deadline
            .checked_add(u128::from(
                accounting.active_policy().terminal_retention_blocks,
            ))
            .ok_or_else(|| {
                LedgerError::StakeResource("Epoch retention deadline overflow".into())
            })?;
        let required_lease_end = u64::try_from(required_lease_end_u128).map_err(|_| {
            LedgerError::StakeResource("Epoch retention deadline exceeds runtime height".into())
        })?;
        if request.resource_envelope.lease_end_height < required_lease_end {
            return Err(LedgerError::StakeResource(
                "Epoch resource lease does not cover exit, evidence and terminal retention".into(),
            ));
        }
        for validator in &preview.descriptor.validators {
            let candidate = authority
                .candidates
                .iter()
                .find(|candidate| candidate.validator_id == validator.validator_id)
                .ok_or_else(|| {
                    LedgerError::StakeResource(
                        "derived validator has no exact retained candidate".into(),
                    )
                })?;
            let resource_key = format!("CANDIDATE/{}", validator.validator_id);
            let bond = accounting.bonds().get(&resource_key).ok_or_else(|| {
                LedgerError::StakeResource(format!(
                    "selected candidate lacks resource responsibility: {}",
                    validator.validator_id
                ))
            })?;
            if bond.resource_kind != StakeStateResourceKindV1::Candidate
                || bond.resource_owner != candidate.owner
                || bond.status != StakeStateBondStatusV1::Locked
                || accounting.effective_lease_end_height(&resource_key) < Some(required_lease_end)
            {
                return Err(LedgerError::StakeResource(format!(
                    "selected candidate resource bond is ineligible or too short: {}",
                    validator.validator_id
                )));
            }
        }
        for liability in &preview.stake_liabilities {
            let resource_key = format!("POSITION/{}", liability.position.position_id);
            let bond = accounting.bonds().get(&resource_key).ok_or_else(|| {
                LedgerError::StakeResource(format!(
                    "Epoch liability lacks resource responsibility: {}",
                    liability.position.position_id
                ))
            })?;
            if bond.resource_kind != StakeStateResourceKindV1::Position
                || bond.resource_owner != liability.position.owner
                || bond.status != StakeStateBondStatusV1::Locked
                || accounting.effective_lease_end_height(&resource_key) < Some(required_lease_end)
            {
                return Err(LedgerError::StakeResource(format!(
                    "Epoch liability resource bond is ineligible or too short: {}",
                    liability.position.position_id
                )));
            }
        }

        let sponsor_authorization = &request.resource_envelope.authorization;
        if request.authorization.authorization_id == sponsor_authorization.authorization_id
            || self
                .authorization_nullifiers
                .contains(sponsor_authorization.authorization_id.as_str())
        {
            return Err(LedgerError::Duplicate(
                sponsor_authorization.authorization_id.clone(),
            ));
        }
        let payload_hash = request.payload_hash();
        self.verify_owner_authorization(
            &request.authorization,
            &request.payer,
            DERIVE_NEXT_STAKE_EPOCH_ACTION_V2,
            &payload_hash,
        )?;
        let wire_bytes = ConsensusCommand::DeriveNextStakeEpochV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len()).map_err(|_| {
                LedgerError::StakeResource("Epoch V2 command exceeds the u32 wire meter".into())
            })?,
            persistent_bytes: derive_next_stake_epoch_persistent_bytes_v2(
                &request,
                &preview,
                horizon_usage,
            )
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            signature_checks: DERIVE_NEXT_STAKE_EPOCH_SIGNATURE_CHECKS_V2,
            state_reads: derive_next_stake_epoch_state_reads_v2(&preview, horizon_usage)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            state_writes: derive_next_stake_epoch_state_writes_v2(horizon_usage)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
        };
        let resource_key = format!("EPOCH/{expected_epoch}");
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: resource_key.clone(),
            resource_kind: StakeStateResourceKindV1::Epoch,
            resource_owner: request.payer.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: preview.previous_record_hash.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let admission_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::StakeResource("Epoch V2 height overflow".into()))?;
        let (next_accounting, admission) =
            self.prepare_position_resource_admission(admission_request, admission_height)?;
        let runtime_validator_keys = self.descriptor.validator_keys.clone();
        let actual = self.derive_and_store_next_stake_epoch()?;
        if actual != preview || self.height != admission_height {
            return Err(LedgerError::StakeResource(
                "Epoch derivation diverged from the funded preview".into(),
            ));
        }
        self.stake_position_liability_horizons = preview_horizons;
        self.stake_position_liability_horizon_history = preview_horizon_history;
        self.stake_liability_horizon_activation_epoch
            .get_or_insert(expected_epoch);
        self.consume_authorization(&request.authorization)?;
        self.commit_position_resource_admission(
            next_accounting,
            &admission,
            sponsor_authorization,
        )?;
        if self.descriptor.validator_keys != runtime_validator_keys {
            return Err(LedgerError::StakeResource(
                "resource-bound Epoch changed runtime validator membership".into(),
            ));
        }
        Ok(DeriveNextStakeEpochOutcomeV2 {
            epoch: actual,
            resource_key,
            bond_id: admission.bond_record.bond_id.clone(),
            bond_coin_id: admission.bond_record.bond_coin_id.clone(),
            charged_fee: admission.charged_fee,
            locked_bond: admission.locked_bond,
            initial_bond_record_hash: admission.bond_record.initial_record_hash(),
        })
    }

    fn stake_resource_context(&self) -> StakeStateResourceContextV1 {
        StakeStateResourceContextV1 {
            network_domain: self.descriptor.network_domain.clone(),
            zone_id: self.descriptor.zone_id.clone(),
            currency_genesis_root: self.descriptor.currency_genesis_root.clone(),
            protocol_era: self.descriptor.protocol_era,
            crypto_era: self.descriptor.crypto_era,
        }
    }

    /// Extends only the lease of one already-accounted resource. The covered
    /// candidate/position/Epoch and its original bond record remain untouched.
    pub fn renew_stake_state_resource_bond(
        &mut self,
        request: RenewStakeStateResourceBondRequestV1,
    ) -> Result<RenewStakeStateResourceBondOutcomeV1, LedgerError> {
        let mut staged = self.clone();
        let outcome = staged.apply_stake_state_resource_bond_renewal(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(outcome)
    }

    fn apply_stake_state_resource_bond_renewal(
        &mut self,
        request: RenewStakeStateResourceBondRequestV1,
    ) -> Result<RenewStakeStateResourceBondOutcomeV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "resource-bond renewal requires VALUE_CAP_0".into(),
            ));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
            || request.proposed_height != self.height
            || request.expires_at_height < self.height
            || request.expires_at_height <= request.proposed_height
        {
            return Err(LedgerError::StakeResource(
                "renewal context, era or height mismatch".into(),
            ));
        }
        let accounting = self
            .stake_resource_accounting
            .as_ref()
            .ok_or_else(|| LedgerError::StakeResource("no active stake resource policy".into()))?;
        let original = accounting
            .bonds()
            .get(&request.resource_key)
            .ok_or_else(|| {
                LedgerError::StakeResource("renewal refers to an unknown resource".into())
            })?;
        let subject_exists = match request.resource_kind {
            StakeStateResourceKindV1::Candidate => self
                .consensus_stake_authority
                .as_ref()
                .is_some_and(|authority| {
                    authority.candidates.iter().any(|candidate| {
                        request.resource_key == format!("CANDIDATE/{}", candidate.validator_id)
                            && candidate.owner == request.resource_owner
                    })
                }),
            StakeStateResourceKindV1::Position => {
                let exact = |position: &ConsensusStakePosition| {
                    request.resource_key == format!("POSITION/{}", position.position_id)
                        && position.owner == request.resource_owner
                        && position.slash_terms.is_some()
                };
                self.consensus_stake_escrows.values().any(exact)
                    || self
                        .consensus_stake_unbonds
                        .values()
                        .any(|record| exact(&record.position))
                    || self
                        .consensus_stake_slashes
                        .values()
                        .any(|record| exact(&record.position))
            }
            StakeStateResourceKindV1::Epoch => self.derived_stake_epochs.values().any(|record| {
                request.resource_key == format!("EPOCH/{}", record.descriptor.consensus_epoch)
            }),
            StakeStateResourceKindV1::Unbond | StakeStateResourceKindV1::SlashEvidence => false,
        };
        if !subject_exists
            || original.resource_kind != request.resource_kind
            || original.resource_owner != request.resource_owner
        {
            return Err(LedgerError::StakeResource(
                "renewal resource subject is missing or does not match retained state".into(),
            ));
        }
        let wire_bytes = ConsensusCommand::RenewStakeStateResourceBond(Box::new(request.clone()))
            .wire_v1_command_bytes(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: u32::try_from(wire_bytes.len())
                .map_err(|_| LedgerError::StakeResource("renewal wire length overflow".into()))?,
            persistent_bytes: renew_stake_state_resource_bond_persistent_bytes_v1(&request)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            signature_checks: RENEW_STAKE_STATE_RESOURCE_BOND_SIGNATURE_CHECKS_V1,
            state_reads: RENEW_STAKE_STATE_RESOURCE_BOND_STATE_READS_V1,
            state_writes: RENEW_STAKE_STATE_RESOURCE_BOND_STATE_WRITES_V1,
        };
        let funding_coin = self
            .coins
            .get(&request.funding_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(request.funding_coin_id.clone()))?;
        let mut protected_coin_ids = self
            .consensus_stake_escrows
            .keys()
            .cloned()
            .collect::<BTreeSet<_>>();
        protected_coin_ids.extend(
            accounting
                .bonds()
                .values()
                .map(|record| record.bond_coin_id.clone()),
        );
        protected_coin_ids.extend(
            accounting
                .renewals()
                .values()
                .map(|record| record.bond_coin_id.clone()),
        );
        let renewal_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::StakeResource("renewal height overflow".into()))?;
        let mut next_accounting = accounting.clone();
        let renewal = next_accounting
            .renew(
                &request,
                usage,
                &funding_coin,
                &protected_coin_ids,
                renewal_height,
            )
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let mut output_ids = BTreeSet::new();
        for coin in std::iter::once(&renewal.bond_coin).chain(renewal.change_coin.iter()) {
            if !output_ids.insert(coin.object_id.as_str())
                || self.coins.contains_key(&coin.object_id)
                || coin.object_id == renewal.consumed_funding_coin.object_id
            {
                return Err(LedgerError::Duplicate(coin.object_id.clone()));
            }
        }
        let current_funding = self
            .coins
            .get(&renewal.consumed_funding_coin.object_id)
            .ok_or_else(|| {
                LedgerError::CoinNotFound(renewal.consumed_funding_coin.object_id.clone())
            })?;
        if current_funding.state != CoinState::Spendable
            || current_funding.version != renewal.consumed_funding_coin.version
            || current_funding.amount != renewal.consumed_funding_coin.amount
            || current_funding.owner != renewal.consumed_funding_coin.owner
        {
            return Err(LedgerError::StakeResource(
                "renewal funding Coin changed before atomic commit".into(),
            ));
        }
        self.ensure_counter_headroom(1, 0)?;
        self.consume_authorization(&request.authorization)?;
        self.advance()?;
        self.coins.insert(
            renewal.consumed_funding_coin.object_id.clone(),
            renewal.consumed_funding_coin.clone(),
        );
        self.coins.insert(
            renewal.bond_coin.object_id.clone(),
            renewal.bond_coin.clone(),
        );
        if let Some(change) = &renewal.change_coin {
            self.coins.insert(change.object_id.clone(), change.clone());
        }
        self.stake_resource_accounting = Some(next_accounting);
        Ok(RenewStakeStateResourceBondOutcomeV1 {
            renewal_id: request.renewal_id,
            resource_key: request.resource_key,
            previous_renewal_hash: renewal.renewal_record.previous_renewal_hash,
            renewal_record_hash: renewal.renewal_record.record_hash,
            bond_coin_id: renewal.renewal_record.bond_coin_id,
            charged_fee: renewal.charged_fee,
            additional_bond: renewal.additional_bond,
            previous_lease_end_height: renewal.renewal_record.previous_lease_end_height,
            new_lease_end_height: renewal.renewal_record.new_lease_end_height,
        })
    }

    fn replay_stake_state_resource_bond_renewal(
        &self,
        request: &RenewStakeStateResourceBondRequestV1,
    ) -> Result<RenewStakeStateResourceBondOutcomeV1, LedgerError> {
        let accounting = self
            .stake_resource_accounting
            .as_ref()
            .ok_or_else(|| LedgerError::StakeResource("no resource accounting state".into()))?;
        let record = accounting
            .renewals()
            .get(&request.renewal_id)
            .filter(|record| {
                record.resource_key == request.resource_key
                    && record.resource_kind == request.resource_kind
                    && record.resource_owner == request.resource_owner
                    && record.original_bond_id == request.expected_bond_id
                    && record.initial_bond_record_hash == request.expected_initial_bond_record_hash
                    && record.previous_renewal_hash == request.expected_previous_renewal_hash
                    && record.previous_lease_end_height == request.expected_current_lease_end_height
                    && record.new_lease_end_height == request.new_lease_end_height
                    && record.resource_policy_sequence == request.resource_policy_sequence
                    && record.resource_policy_commitment == request.resource_policy_commitment
                    && record.sponsor == request.sponsor
                    && record.sponsor_authorization_id == request.authorization.authorization_id
                    && record.funding_source_coin_id == request.funding_coin_id
            })
            .ok_or_else(|| {
                LedgerError::InvalidQuorum(
                    "recorded commit has no exact resource-bond renewal".into(),
                )
            })?;
        Ok(RenewStakeStateResourceBondOutcomeV1 {
            renewal_id: record.renewal_id.clone(),
            resource_key: record.resource_key.clone(),
            previous_renewal_hash: record.previous_renewal_hash.clone(),
            renewal_record_hash: record.record_hash.clone(),
            bond_coin_id: record.bond_coin_id.clone(),
            charged_fee: record.charged_renewal_fee,
            additional_bond: record.additional_locked_amount,
            previous_lease_end_height: record.previous_lease_end_height,
            new_lease_end_height: record.new_lease_end_height,
        })
    }

    fn current_stake_resource_policy_identity(&self) -> (u64, String) {
        self.stake_resource_accounting.as_ref().map_or_else(
            || (0, crate::stake_resource_accounting::ZERO_SHA256.into()),
            |accounting| {
                (
                    accounting.active_policy().sequence,
                    accounting.active_policy_commitment().to_owned(),
                )
            },
        )
    }

    /// A resource policy may never start below already retained stake state.
    /// Candidate registration also calls this with one prospective owner so
    /// legacy and resource-accounted records share the same global limits.
    fn validate_stake_resource_policy_covers_inventory(
        &self,
        policy: &StakeStateResourcePolicyV1,
        additional_candidate_owner: Option<&str>,
        additional_position_owner: Option<&str>,
    ) -> Result<(), LedgerError> {
        fn check_owner_limit<'a>(
            owners: impl Iterator<Item = &'a str>,
            limit: u32,
            label: &str,
        ) -> Result<(), LedgerError> {
            let mut counts = BTreeMap::<&str, u64>::new();
            for owner in owners {
                let count = counts.entry(owner).or_default();
                *count = count.checked_add(1).ok_or_else(|| {
                    LedgerError::StakeResource(format!("{label} owner count overflow"))
                })?;
            }
            if counts.values().any(|count| *count > u64::from(limit)) {
                return Err(LedgerError::StakeResource(format!(
                    "resource policy {label} owner limit is below retained state"
                )));
            }
            Ok(())
        }

        let candidates = self
            .consensus_stake_authority
            .as_ref()
            .map_or(&[][..], |authority| authority.candidates.as_slice());
        let candidate_total = u64::try_from(candidates.len())
            .ok()
            .and_then(|count| count.checked_add(u64::from(additional_candidate_owner.is_some())))
            .ok_or_else(|| LedgerError::StakeResource("candidate count overflow".into()))?;
        if candidate_total > u64::from(policy.maximum_active_candidates) {
            return Err(LedgerError::StakeResource(
                "resource policy candidate limit is below retained state".into(),
            ));
        }
        check_owner_limit(
            candidates
                .iter()
                .map(|candidate| candidate.owner.as_str())
                .chain(additional_candidate_owner),
            policy.maximum_candidates_per_owner,
            "candidate",
        )?;

        let positions = self
            .consensus_stake_authority
            .as_ref()
            .map_or(&[][..], |authority| authority.positions.as_slice());
        let position_total = positions
            .len()
            .checked_add(usize::from(additional_position_owner.is_some()))
            .ok_or_else(|| LedgerError::StakeResource("position count overflow".into()))?;
        if position_total > policy.maximum_active_positions as usize {
            return Err(LedgerError::StakeResource(
                "resource policy position limit is below retained state".into(),
            ));
        }
        check_owner_limit(
            positions
                .iter()
                .map(|position| position.owner.as_str())
                .chain(additional_position_owner),
            policy.maximum_positions_per_owner,
            "position",
        )?;

        let pending_unbonds = self
            .consensus_stake_unbonds
            .values()
            .filter(|record| record.status == ConsensusStakeUnbondStatusV1::Pending)
            .collect::<Vec<_>>();
        if pending_unbonds.len() > policy.maximum_pending_unbonds as usize {
            return Err(LedgerError::StakeResource(
                "resource policy pending-unbond limit is below retained state".into(),
            ));
        }
        check_owner_limit(
            pending_unbonds.iter().map(|record| record.owner.as_str()),
            policy.maximum_pending_unbonds_per_owner,
            "pending-unbond",
        )
    }

    fn stake_resource_signer_sets_for_era(
        &self,
        protocol_era: u64,
        crypto_era: u64,
    ) -> Option<(&[String], &[String])> {
        if protocol_era == self.descriptor.protocol_era && crypto_era == self.descriptor.crypto_era
        {
            return Some((
                self.descriptor.validator_keys.as_slice(),
                self.descriptor.notary_keys.as_slice(),
            ));
        }
        self.era_certificates.iter().find_map(|certificate| {
            if protocol_era == certificate.previous_protocol_era
                && crypto_era == certificate.previous_crypto_era
            {
                Some((
                    certificate.previous_validator_keys.as_slice(),
                    certificate.previous_notary_keys.as_slice(),
                ))
            } else if protocol_era == certificate.new_protocol_era
                && crypto_era == certificate.new_crypto_era
            {
                Some((
                    certificate.new_validator_keys.as_slice(),
                    certificate.new_notary_keys.as_slice(),
                ))
            } else {
                None
            }
        })
    }

    fn verify_stake_resource_dual_quorum_for_era(
        &self,
        protocol_era: u64,
        crypto_era: u64,
        subject: &str,
        validator_qc: &QuorumCertificate,
        notary_qc: &QuorumCertificate,
    ) -> Result<(), LedgerError> {
        if validator_qc.subject_hash != subject || notary_qc.subject_hash != subject {
            return Err(LedgerError::StakeResource(
                "resource-policy quorum subject mismatch".into(),
            ));
        }
        let (validator_keys, notary_keys) = self
            .stake_resource_signer_sets_for_era(protocol_era, crypto_era)
            .ok_or_else(|| {
                LedgerError::StakeResource(
                    "resource-policy governance record refers to an unknown era".into(),
                )
            })?;
        let simulated = validator_qc.testnet_simulated && notary_qc.testnet_simulated;
        if simulated {
            if self.descriptor.testnet && validator_keys.is_empty() && notary_keys.is_empty() {
                return Ok(());
            }
            return Err(LedgerError::StakeResource(
                "simulated resource-policy quorum is forbidden for this signer set".into(),
            ));
        }
        if validator_qc.testnet_simulated || notary_qc.testnet_simulated {
            return Err(LedgerError::StakeResource(
                "resource-policy validator and notary quorum modes differ".into(),
            ));
        }
        validator_qc
            .verify(validator_keys)
            .map_err(LedgerError::StakeResource)?;
        notary_qc
            .verify(notary_keys)
            .map_err(LedgerError::StakeResource)
    }

    fn validate_stored_stake_resource_policy_proposal(
        &self,
        request: &ProposeStakeStateResourcePolicyV1,
    ) -> Result<(), LedgerError> {
        if request.proposal_id.trim().is_empty()
            || request.proposed_height >= request.expires_at_height
            || request.activate_after_height > request.expires_at_height
            || request.network_domain != self.descriptor.network_domain
            || request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
        {
            return Err(LedgerError::StakeResource(
                "stored resource-policy proposal identity, context or height is invalid".into(),
            ));
        }
        validate_stake_state_resource_policy_v1(&request.proposed_policy)
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        let proposed_commitment =
            stake_state_resource_policy_commitment_v1(&request.proposed_policy)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        if request.proposed_policy_commitment != proposed_commitment
            || request.proposed_policy.sequence
                != request
                    .expected_current_policy_sequence
                    .checked_add(1)
                    .ok_or_else(|| {
                        LedgerError::StakeResource(
                            "stored resource-policy proposal sequence overflow".into(),
                        )
                    })?
            || request.proposed_policy.previous_policy_commitment
                != request.expected_current_policy_commitment
        {
            return Err(LedgerError::StakeResource(
                "stored resource-policy proposal predecessor or commitment mismatch".into(),
            ));
        }
        let subject = request.compute_subject_hash();
        if request.subject_hash != subject {
            return Err(LedgerError::StakeResource(
                "stored resource-policy proposal subject mismatch".into(),
            ));
        }
        self.verify_stake_resource_dual_quorum_for_era(
            request.protocol_era,
            request.crypto_era,
            &subject,
            &request.validator_qc,
            &request.notary_qc,
        )
    }

    fn validate_stake_resource_policy_proposal(
        &self,
        request: &ProposeStakeStateResourcePolicyV1,
    ) -> Result<(), LedgerError> {
        if request.proposal_id.trim().is_empty()
            || request.proposed_height >= request.expires_at_height
            || request.activate_after_height > request.expires_at_height
        {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal identity or height window is invalid".into(),
            ));
        }
        if request.network_domain != self.descriptor.network_domain
            || request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal network, Zone, currency or era mismatch".into(),
            ));
        }
        validate_stake_state_resource_policy_v1(&request.proposed_policy)
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        self.validate_stake_resource_policy_covers_inventory(&request.proposed_policy, None, None)?;
        let (current_sequence, current_commitment) = self.current_stake_resource_policy_identity();
        let expected_next_sequence = current_sequence.checked_add(1).ok_or_else(|| {
            LedgerError::StakeResource("resource-policy sequence overflow".into())
        })?;
        let proposed_commitment =
            stake_state_resource_policy_commitment_v1(&request.proposed_policy)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        if request.expected_current_policy_sequence != current_sequence
            || request.expected_current_policy_commitment != current_commitment
            || request.proposed_policy.sequence != expected_next_sequence
            || request.proposed_policy.previous_policy_commitment != current_commitment
            || request.proposed_policy_commitment != proposed_commitment
        {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal predecessor or commitment mismatch".into(),
            ));
        }
        let subject = request.compute_subject_hash();
        if request.subject_hash != subject {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal subject mismatch".into(),
            ));
        }
        self.verify_local_dual_quorum(&subject, &request.validator_qc, &request.notary_qc)
    }

    /// Stores one bounded, delayed resource-policy proposal. This transition
    /// charges no user funds, installs no fee market and cannot change runtime
    /// validator membership.
    pub fn propose_stake_state_resource_policy(
        &mut self,
        request: ProposeStakeStateResourcePolicyV1,
    ) -> Result<ProposeStakeStateResourcePolicyV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "stake resource-policy proposal requires VALUE_CAP_0".into(),
            ));
        }
        self.validate_stake_resource_policy_proposal(&request)?;
        if request.proposed_height != self.height {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal height does not match current state".into(),
            ));
        }
        if self
            .pending_stake_resource_policy
            .as_ref()
            .is_some_and(|pending| self.height <= pending.expires_at_height)
        {
            return Err(LedgerError::StakeResource(
                "an unexpired resource-policy proposal is already pending".into(),
            ));
        }
        if self
            .stake_resource_policy_proposals
            .contains_key(&request.proposal_id)
        {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal id was already used".into(),
            ));
        }
        if self.stake_resource_policy_proposals.len() >= MAX_STAKE_RESOURCE_GOVERNANCE_RECORDS_V1 {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal history reached its fail-closed bound".into(),
            ));
        }
        let controlling_delay = self.stake_resource_accounting.as_ref().map_or(
            request.proposed_policy.activation_delay_blocks,
            |accounting| accounting.active_policy().activation_delay_blocks,
        );
        let minimum_activation = self.height.checked_add(controlling_delay).ok_or_else(|| {
            LedgerError::StakeResource("resource-policy activation height overflow".into())
        })?;
        if request.activate_after_height < minimum_activation
            || request.expires_at_height < request.activate_after_height
        {
            return Err(LedgerError::StakeResource(
                "resource-policy proposal does not preserve the controlling activation delay"
                    .into(),
            ));
        }
        self.ensure_counter_headroom(1, 0)?;
        let mut staged = self.clone();
        staged.pending_stake_resource_policy = Some(request.clone());
        staged
            .stake_resource_policy_proposals
            .insert(request.proposal_id.clone(), request.clone());
        staged.advance()?;
        staged.validate_stake_resource_policy_state()?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(request)
    }

    /// Activates exactly the pending policy after its delay and a fresh dual
    /// quorum. Resource-bearing lifecycle commands remain unavailable, so
    /// activation alone cannot charge a Coin or create a bond.
    pub fn activate_stake_state_resource_policy(
        &mut self,
        request: ActivateStakeStateResourcePolicyV1,
    ) -> Result<StakeStateResourcePolicyV1, LedgerError> {
        if self.value_risk_policy.current_cap != ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "stake resource-policy activation requires VALUE_CAP_0".into(),
            ));
        }
        if request.activation_id.trim().is_empty()
            || request.network_domain != self.descriptor.network_domain
            || request.zone_id != self.descriptor.zone_id
            || request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
            || request.proposed_height != self.height
            || request.expires_at_height < self.height
        {
            return Err(LedgerError::StakeResource(
                "resource-policy activation identity, context or height is invalid".into(),
            ));
        }
        let pending = self
            .pending_stake_resource_policy
            .clone()
            .ok_or_else(|| LedgerError::StakeResource("no resource policy is pending".into()))?;
        if self
            .stake_resource_policy_activations
            .contains_key(&request.activation_id)
        {
            return Err(LedgerError::StakeResource(
                "resource-policy activation id was already used".into(),
            ));
        }
        if self.stake_resource_policy_activations.len() >= MAX_STAKE_RESOURCE_GOVERNANCE_RECORDS_V1
        {
            return Err(LedgerError::StakeResource(
                "resource-policy activation history reached its fail-closed bound".into(),
            ));
        }
        self.validate_stake_resource_policy_proposal(&pending)?;
        let (current_sequence, current_commitment) = self.current_stake_resource_policy_identity();
        if request.proposal_id != pending.proposal_id
            || request.expected_pending_policy_commitment != pending.proposed_policy_commitment
            || request.expected_current_policy_sequence != current_sequence
            || request.expected_current_policy_commitment != current_commitment
            || request.expires_at_height != pending.expires_at_height
            || self.height < pending.activate_after_height
            || self.height > pending.expires_at_height
        {
            return Err(LedgerError::StakeResource(
                "resource-policy activation does not match the delayed pending proposal".into(),
            ));
        }
        let subject = request.compute_subject_hash();
        if request.subject_hash != subject {
            return Err(LedgerError::StakeResource(
                "resource-policy activation subject mismatch".into(),
            ));
        }
        self.verify_local_dual_quorum(&subject, &request.validator_qc, &request.notary_qc)?;
        self.ensure_counter_headroom(1, 0)?;
        let mut staged = self.clone();
        staged.advance()?;
        let activation_height = staged.height;
        if let Some(accounting) = staged.stake_resource_accounting.as_mut() {
            accounting
                .activate_policy(pending.proposed_policy.clone(), activation_height)
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        } else {
            staged.stake_resource_accounting = Some(
                StakeStateResourceAccountingV1::new(
                    staged.stake_resource_context(),
                    pending.proposed_policy.clone(),
                    staged.height,
                )
                .map_err(|error| LedgerError::StakeResource(error.to_string()))?,
            );
        }
        staged
            .stake_resource_policy_activations
            .insert(request.activation_id.clone(), request);
        staged.pending_stake_resource_policy = None;
        staged.validate_stake_resource_policy_state()?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(pending.proposed_policy)
    }

    fn validate_stake_resource_policy_state(&self) -> Result<(), LedgerError> {
        if self.stake_resource_policy_proposals.len() > MAX_STAKE_RESOURCE_GOVERNANCE_RECORDS_V1
            || self.stake_resource_policy_activations.len()
                > MAX_STAKE_RESOURCE_GOVERNANCE_RECORDS_V1
        {
            return Err(LedgerError::StakeResource(
                "resource-policy governance history exceeds its fail-closed bound".into(),
            ));
        }
        for (proposal_id, proposal) in &self.stake_resource_policy_proposals {
            if proposal_id != &proposal.proposal_id {
                return Err(LedgerError::StakeResource(
                    "resource-policy proposal history key mismatch".into(),
                ));
            }
            self.validate_stored_stake_resource_policy_proposal(proposal)?;
        }

        let mut activation_order = self
            .stake_resource_policy_activations
            .iter()
            .collect::<Vec<_>>();
        activation_order.sort_by(|(left_id, left), (right_id, right)| {
            (left.proposed_height, left_id).cmp(&(right.proposed_height, right_id))
        });
        let mut activated_proposals = BTreeSet::new();
        let mut active_by_era = BTreeMap::<(u64, u64), (u64, String)>::new();
        for (activation_id, activation) in activation_order {
            if activation_id != &activation.activation_id
                || activation.activation_id.trim().is_empty()
                || activation.network_domain != self.descriptor.network_domain
                || activation.zone_id != self.descriptor.zone_id
                || activation.currency_genesis_root != self.descriptor.currency_genesis_root
                || activation.proposed_height > activation.expires_at_height
            {
                return Err(LedgerError::StakeResource(
                    "resource-policy activation history identity or context mismatch".into(),
                ));
            }
            let proposal = self
                .stake_resource_policy_proposals
                .get(&activation.proposal_id)
                .ok_or_else(|| {
                    LedgerError::StakeResource(
                        "resource-policy activation has no immutable proposal".into(),
                    )
                })?;
            if !activated_proposals.insert(activation.proposal_id.as_str())
                || activation.network_domain != proposal.network_domain
                || activation.zone_id != proposal.zone_id
                || activation.currency_genesis_root != proposal.currency_genesis_root
                || activation.protocol_era != proposal.protocol_era
                || activation.crypto_era != proposal.crypto_era
                || activation.expires_at_height != proposal.expires_at_height
                || activation.proposed_height < proposal.activate_after_height
                || activation.proposed_height > proposal.expires_at_height
                || activation.expected_pending_policy_commitment
                    != proposal.proposed_policy_commitment
                || activation.expected_current_policy_sequence
                    != proposal.expected_current_policy_sequence
                || activation.expected_current_policy_commitment
                    != proposal.expected_current_policy_commitment
            {
                return Err(LedgerError::StakeResource(
                    "resource-policy activation does not match its immutable proposal".into(),
                ));
            }
            let subject = activation.compute_subject_hash();
            if activation.subject_hash != subject {
                return Err(LedgerError::StakeResource(
                    "resource-policy activation history subject mismatch".into(),
                ));
            }
            self.verify_stake_resource_dual_quorum_for_era(
                activation.protocol_era,
                activation.crypto_era,
                &subject,
                &activation.validator_qc,
                &activation.notary_qc,
            )?;
            let era_key = (activation.protocol_era, activation.crypto_era);
            let expected = active_by_era
                .get(&era_key)
                .cloned()
                .unwrap_or_else(|| (0, crate::stake_resource_accounting::ZERO_SHA256.to_owned()));
            if activation.expected_current_policy_sequence != expected.0
                || activation.expected_current_policy_commitment != expected.1
            {
                return Err(LedgerError::StakeResource(
                    "resource-policy activation history is not a contiguous era-local chain".into(),
                ));
            }
            active_by_era.insert(
                era_key,
                (
                    proposal.proposed_policy.sequence,
                    proposal.proposed_policy_commitment.clone(),
                ),
            );
        }

        let (current_sequence, current_commitment) = self.current_stake_resource_policy_identity();
        if let Some(pending) = &self.pending_stake_resource_policy {
            self.validate_stake_resource_policy_proposal(pending)?;
            if self
                .stake_resource_policy_proposals
                .get(&pending.proposal_id)
                != Some(pending)
                || pending.expected_current_policy_sequence != current_sequence
                || pending.expected_current_policy_commitment != current_commitment
            {
                return Err(LedgerError::StakeResource(
                    "pending resource policy is not immutable or no longer binds the active policy"
                        .into(),
                ));
            }
        }
        let current_era = (self.descriptor.protocol_era, self.descriptor.crypto_era);
        let activated_current = active_by_era.get(&current_era);
        let Some(accounting) = &self.stake_resource_accounting else {
            if activated_current.is_some() {
                return Err(LedgerError::StakeResource(
                    "current-era resource-policy history exists without accounting state".into(),
                ));
            }
            return Ok(());
        };
        accounting
            .validate()
            .map_err(|error| LedgerError::StakeResource(error.to_string()))?;
        if accounting.context() != &self.stake_resource_context() {
            return Err(LedgerError::StakeResource(
                "resource accounting context is not the current ledger context".into(),
            ));
        }
        if activated_current.is_none_or(|(sequence, commitment)| {
            accounting.active_policy().sequence != *sequence
                || accounting.active_policy_commitment() != commitment
                || accounting.policy_generations() != *sequence as usize
                || (1..=*sequence)
                    .any(|generation| accounting.policy_commitment(generation).is_none())
        }) {
            return Err(LedgerError::StakeResource(
                "resource accounting policy registry does not match activation history".into(),
            ));
        }
        if !accounting
            .consumed_authorization_ids()
            .is_subset(&self.authorization_nullifiers)
        {
            return Err(LedgerError::StakeResource(
                "resource authorization nullifiers are missing from the ledger".into(),
            ));
        }
        for record in accounting.bonds().values() {
            let source = self
                .coins
                .get(&record.funding_source_coin_id)
                .ok_or_else(|| {
                    LedgerError::StakeResource("resource funding Coin is missing".into())
                })?;
            let bond = self.coins.get(&record.bond_coin_id).ok_or_else(|| {
                LedgerError::StakeResource("resource bond Coin is missing".into())
            })?;
            let required = record
                .charged_creation_fee
                .checked_add(record.locked_amount)
                .map_err(LedgerError::Amount)?;
            let change = source
                .amount
                .checked_sub(required)
                .map_err(LedgerError::Amount)?;
            let expected_change_id = if change.is_zero() {
                None
            } else {
                Some(format!(
                    "stake-state-change:{}",
                    hash_parts(&[
                        b"RLD-STAKE-STATE-RESOURCE-CHANGE-COIN-V1",
                        source.object_id.as_bytes(),
                        record.bond_id.as_bytes(),
                        &change.0.to_be_bytes(),
                    ])
                ))
            };
            let direct_change = self
                .coins
                .values()
                .filter(|coin| {
                    coin.parent_ids == [source.object_id.clone()]
                        && coin.object_id != record.bond_coin_id
                })
                .collect::<Vec<_>>();
            if source.state != CoinState::Consumed
                || source.owner != record.sponsor
                || source.amount < required
                || bond.owner != record.sponsor
                || bond.amount != record.locked_amount
                || bond.parent_ids != [source.object_id.clone()]
                || bond.lineage_root != source.lineage_root
                || source.version.checked_add(1) != Some(bond.version)
                || bond.created_height != record.created_height
                || bond.zone_id != self.descriptor.zone_id
                || bond.origin_genesis_root != self.descriptor.currency_genesis_root
                || bond.transit_id.is_some()
                || direct_change.len() != usize::from(expected_change_id.is_some())
                || direct_change.first().is_some_and(|coin| {
                    Some(coin.object_id.as_str()) != expected_change_id.as_deref()
                        || coin.owner != record.sponsor
                        || coin.amount != change
                        || coin.lineage_root != source.lineage_root
                        || source.version.checked_add(1) != Some(coin.version)
                        || coin.created_height != record.created_height
                        || coin.zone_id != self.descriptor.zone_id
                        || coin.origin_genesis_root != self.descriptor.currency_genesis_root
                        || coin.transit_id.is_some()
                })
            {
                return Err(LedgerError::StakeResource(
                    "resource bond or change is not an exact descendant of its funding Coin".into(),
                ));
            }
            let refund_children = self
                .coins
                .values()
                .filter(|coin| coin.parent_ids == [bond.object_id.clone()])
                .collect::<Vec<_>>();
            match record.status {
                StakeStateBondStatusV1::Locked | StakeStateBondStatusV1::Releaseable => {
                    if bond.state != CoinState::Reserved || !refund_children.is_empty() {
                        return Err(LedgerError::StakeResource(
                            "live resource bond Coin or descendants are inconsistent".into(),
                        ));
                    }
                }
                StakeStateBondStatusV1::Refunded => {
                    if bond.state != CoinState::Consumed
                        || refund_children.len() != 1
                        || refund_children[0].owner != record.sponsor
                        || refund_children[0].amount != record.locked_amount
                        || refund_children[0].lineage_root != bond.lineage_root
                        || bond.version.checked_add(1) != Some(refund_children[0].version)
                    {
                        return Err(LedgerError::StakeResource(
                            "refunded resource bond lineage is inconsistent".into(),
                        ));
                    }
                }
                StakeStateBondStatusV1::Forfeited => {
                    if bond.state != CoinState::Consumed || !refund_children.is_empty() {
                        return Err(LedgerError::StakeResource(
                            "forfeited resource bond has an invalid refund descendant".into(),
                        ));
                    }
                }
            }
        }
        Ok(())
    }

    pub fn ensure_current_checkpoint(&mut self) -> Result<bool, LedgerError> {
        let current_root = self.state_root()?;
        if self
            .latest_checkpoint()
            .is_some_and(|checkpoint| checkpoint.state_root == current_root)
        {
            return Ok(false);
        }
        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.create_checkpoint()?;
        Ok(true)
    }

    pub fn ensure_reserve_pools(&mut self) -> Result<(), LedgerError> {
        let recorded_total = self.reserve_pools.total().map_err(LedgerError::Supply)?;
        if recorded_total == self.reserve {
            return Ok(());
        }
        if !recorded_total.is_zero() {
            return Err(LedgerError::Supply(
                "persisted protocol reserve pools do not equal the reserve".into(),
            ));
        }

        let mut migrated = protocol_reserve_pools(self.anchor_supply)?;
        let bootstrap_spent = self
            .service_receipts
            .values()
            .filter(|receipt| receipt.bootstrap)
            .try_fold(Amount::ZERO, |total, receipt| {
                total.checked_add(receipt.amount)
            })?;
        migrated.startup_services = migrated
            .startup_services
            .checked_sub(bootstrap_spent)
            .map_err(|_| {
                LedgerError::Supply(
                    "historical bootstrap rewards exceed the startup service pool".into(),
                )
            })?;
        if migrated.total().map_err(LedgerError::Supply)? != self.reserve {
            return Err(LedgerError::Supply(
                "migrated protocol reserve pools do not equal the persisted reserve".into(),
            ));
        }

        self.ensure_counter_headroom(1, 0)?;

        for receipt in self
            .service_receipts
            .values()
            .filter(|receipt| receipt.bootstrap)
        {
            self.service_orders
                .entry(receipt.order_id.clone())
                .or_insert_with(|| ServiceOrder {
                    order_id: receipt.order_id.clone(),
                    buyer: "rld:protocol:startup-services".into(),
                    role: receipt.role.clone(),
                    budget: receipt.amount,
                    escrow_coin_id: format!(
                        "protocol-reserve:startup-services:{}",
                        receipt.order_id
                    ),
                    description: "migrated testnet bootstrap verified network service".into(),
                    status: ServiceStatus::Completed,
                    created_height: receipt.completed_height,
                });
            self.service_leases
                .entry(receipt.lease_id.clone())
                .or_insert_with(|| ServiceLease {
                    lease_id: receipt.lease_id.clone(),
                    order_id: receipt.order_id.clone(),
                    node_id: receipt.node_id.clone(),
                    accepted_quote: receipt.amount,
                    accepted_height: receipt.completed_height,
                });
        }

        self.reserve_pools = migrated;
        self.advance()?;
        self.create_checkpoint()?;
        Ok(())
    }

    pub fn new(
        display_name: impl Into<String>,
        anchor_supply: Amount,
        validator_keys: Vec<String>,
        notary_keys: Vec<String>,
        testnet: bool,
    ) -> Result<Self, LedgerError> {
        let display_name = display_name.into();
        let identity_version = CURRENT_ZONE_IDENTITY_VERSION;
        let identity_hash_suite = ZONE_IDENTITY_HASH_SUITE.to_owned();
        let network_domain = if testnet {
            RLDCOIN_TESTNET_DOMAIN
        } else {
            RLDCOIN_MAINNET_DOMAIN
        }
        .to_owned();
        let currency_genesis_root = currency_genesis_root();
        let genesis_root = ZoneDescriptor::genesis_root_for_v2(
            &display_name,
            anchor_supply,
            &validator_keys,
            &notary_keys,
            &currency_genesis_root,
            &identity_hash_suite,
            &network_domain,
        );
        let zone_id =
            ZoneDescriptor::self_certifying_id(identity_version, &display_name, &genesis_root);
        let descriptor = ZoneDescriptor {
            zone_id,
            display_name,
            genesis_root,
            identity_version,
            identity_hash_suite,
            network_domain,
            anchor_supply,
            genesis_validator_keys: validator_keys.clone(),
            genesis_notary_keys: notary_keys.clone(),
            currency_genesis_root,
            validator_keys,
            notary_keys,
            protocol_era: 1,
            crypto_era: 1,
            testnet,
        };
        let era_continuity_accumulator = hash_parts(&[
            b"RLD-GENESIS-ERA",
            descriptor.zone_id.as_bytes(),
            &descriptor.protocol_era.to_be_bytes(),
            &descriptor.crypto_era.to_be_bytes(),
        ]);
        let reserve_pools = protocol_reserve_pools(anchor_supply)?;
        let mut ledger = Self {
            descriptor,
            height: 0,
            anchor_supply,
            reserve: anchor_supply,
            reserve_pools,
            imported_total: Amount::ZERO,
            finalized_export_total: Amount::ZERO,
            value_risk_policy: ValueRiskPolicy::default(),
            m0_network_birth: None,
            m0_network_birth_v3: None,
            m0_active_protocol: None,
            m0_pending_upgrade: None,
            admission_state: None,
            consensus_stake_authority: None,
            consensus_stake_escrows: BTreeMap::new(),
            consensus_stake_unbonds: BTreeMap::new(),
            consensus_stake_slashes: BTreeMap::new(),
            consensus_stake_evidence_nullifiers: BTreeSet::new(),
            derived_stake_epochs: BTreeMap::new(),
            stake_position_liability_horizons: BTreeMap::new(),
            stake_position_liability_horizon_history: BTreeMap::new(),
            stake_liability_horizon_activation_epoch: None,
            stake_resource_policy_proposals: BTreeMap::new(),
            stake_resource_policy_activations: BTreeMap::new(),
            pending_stake_resource_policy: None,
            stake_resource_accounting: None,
            coins: BTreeMap::new(),
            payments: BTreeMap::new(),
            epoch_fee_pools: BTreeMap::new(),
            payment_requests: BTreeMap::new(),
            consumed_payment_requests: BTreeSet::new(),
            recipient_receipts: BTreeMap::new(),
            transits: BTreeMap::new(),
            transit_coin_ids: BTreeMap::new(),
            import_receipts: BTreeMap::new(),
            rejection_proofs: BTreeMap::new(),
            rejected_transit_nullifiers: BTreeSet::new(),
            spendability_certificates: BTreeMap::new(),
            liquidity_offers: BTreeMap::new(),
            route_quotes: BTreeMap::new(),
            transit_nullifiers: BTreeSet::new(),
            source_object_nullifiers: BTreeSet::new(),
            authorization_nullifiers: BTreeSet::new(),
            zone_trust_policies: BTreeMap::new(),
            trusted_zone_checkpoints: BTreeMap::new(),
            gateway_bonds: BTreeMap::new(),
            quarantined_zones: BTreeSet::new(),
            zone_advertisements: BTreeMap::new(),
            traveler_capsules: BTreeMap::new(),
            voyage_escrows: BTreeMap::new(),
            voyage_receipts: BTreeMap::new(),
            era_certificates: Vec::new(),
            era_continuity_accumulator,
            service_orders: BTreeMap::new(),
            service_leases: BTreeMap::new(),
            protocol_reserve_commitments: BTreeMap::new(),
            economic_control_attestations: BTreeMap::new(),
            economic_price_attestations: BTreeMap::new(),
            economic_release_policies: BTreeMap::new(),
            protocol_service_bonds: BTreeMap::new(),
            protocol_reserve_releases: BTreeMap::new(),
            economic_consumed_work_ids: BTreeSet::new(),
            economic_consumed_fee_receipts: BTreeSet::new(),
            economic_consumed_completion_qcs: BTreeSet::new(),
            economic_bond_slash_ids: BTreeSet::new(),
            matched_service_receipts: BTreeSet::new(),
            service_receipts: BTreeMap::new(),
            node_earnings: BTreeMap::new(),
            checkpoints: Vec::new(),
            causal_firewall: CausalFirewall::default(),
            bootstrap_claims: BTreeSet::new(),
            consensus_vote_locks: BTreeMap::new(),
            consensus_commits: BTreeMap::new(),
            sequence: 0,
        };
        ledger.create_checkpoint()?;
        Ok(ledger)
    }

    pub fn genesis_zone(
        display_name: impl Into<String>,
        validator_keys: Vec<String>,
        notary_keys: Vec<String>,
        testnet: bool,
    ) -> Result<Self, LedgerError> {
        Self::new(
            display_name,
            Amount::TOTAL_SUPPLY,
            validator_keys,
            notary_keys,
            testnet,
        )
    }

    pub fn bind_m0_network_birth(
        &mut self,
        binding: M0NetworkBirthStateV2,
    ) -> Result<(), LedgerError> {
        if self.m0_network_birth_v3.is_some() || self.m0_active_protocol.is_some() {
            return Err(LedgerError::Invalid(
                "V3 birth cannot be rebound as V2".into(),
            ));
        }
        binding
            .validate_for_descriptor(&self.descriptor)
            .map_err(LedgerError::Invalid)?;
        if let Some(existing) = &self.m0_network_birth {
            if existing == &binding {
                let admission = self.admission_state.as_ref().ok_or_else(|| {
                    LedgerError::Invalid(
                        "M0 network birth exists without its admission trust state".into(),
                    )
                })?;
                admission
                    .validate_for_descriptor(&self.descriptor)
                    .map_err(|error| LedgerError::Invalid(error.to_string()))?;
                if admission.genesis != binding.admission_genesis {
                    return Err(LedgerError::Invalid(
                        "M0 network birth and admission genesis differ".into(),
                    ));
                }
                return Ok(());
            }
            return Err(LedgerError::Invalid(
                "M0 network-birth binding is immutable".into(),
            ));
        }
        let pristine = Self::genesis_zone(
            &self.descriptor.display_name,
            self.descriptor.genesis_validator_keys.clone(),
            self.descriptor.genesis_notary_keys.clone(),
            false,
        )?;
        if self.descriptor != pristine.descriptor || self.state_root()? != pristine.state_root()? {
            return Err(LedgerError::Invalid(
                "M0 network-birth binding can only be installed on exact pristine genesis state"
                    .into(),
            ));
        }
        let mut candidate = self.clone();
        candidate.m0_network_birth = Some(binding.clone());
        candidate.admission_state = None;
        let initial_asset_root =
            AdmissionHash32::from_hex(&candidate.state_root_before_admission()?)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        candidate.admission_state = Some(
            LedgerAdmissionStateV1::new(binding.admission_genesis, initial_asset_root)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?,
        );
        candidate.checkpoints.clear();
        candidate.create_checkpoint()?;
        *self = candidate;
        Ok(())
    }

    pub fn m0_profile_active(&self) -> bool {
        self.m0_network_birth.is_some()
            || self.m0_network_birth_v3.is_some()
            || self.m0_active_protocol.is_some()
    }

    pub fn m0_admission_genesis(&self) -> Result<Option<&crate::AdmissionGenesisV1>, LedgerError> {
        if let Some(pending) = &self.m0_pending_upgrade {
            let birth = self
                .m0_network_birth_v3
                .as_ref()
                .ok_or_else(|| LedgerError::Invalid("pending upgrade requires V3 birth".into()))?;
            let active = self.m0_active_protocol.as_ref().ok_or_else(|| {
                LedgerError::Invalid("pending upgrade requires active state".into())
            })?;
            pending
                .validate(&self.descriptor, birth, active, u128::from(self.height))
                .map_err(LedgerError::Invalid)?;
        }
        match (
            &self.m0_network_birth,
            &self.m0_network_birth_v3,
            &self.m0_active_protocol,
        ) {
            (None, None, None) => Ok(None),
            (Some(birth), None, None) => {
                birth
                    .validate_for_descriptor(&self.descriptor)
                    .map_err(LedgerError::Invalid)?;
                Ok(Some(&birth.admission_genesis))
            }
            (None, Some(birth), Some(active)) => {
                birth
                    .validate_for_descriptor(&self.descriptor)
                    .map_err(LedgerError::Invalid)?;
                active
                    .validate_for_birth(birth)
                    .map_err(LedgerError::Invalid)?;
                Ok(Some(&birth.admission_genesis))
            }
            _ => Err(LedgerError::Invalid(
                "mixed, missing or downgraded M0 birth/active state".into(),
            )),
        }
    }

    pub fn bind_m0_network_birth_v3(
        &mut self,
        birth: crate::M0NetworkBirthStateV3,
    ) -> Result<(), LedgerError> {
        birth
            .validate_for_descriptor(&self.descriptor)
            .map_err(LedgerError::Invalid)?;
        if self.m0_network_birth_v3.as_ref() == Some(&birth) {
            self.validated_admission_state()?;
            return Ok(());
        }
        if self.m0_profile_active() {
            return Err(LedgerError::Invalid(
                "M0 birth cannot be replaced or upgraded in place".into(),
            ));
        }
        let pristine = Self::genesis_zone(
            &self.descriptor.display_name,
            self.descriptor.genesis_validator_keys.clone(),
            self.descriptor.genesis_notary_keys.clone(),
            false,
        )?;
        if serde_json::to_vec(self).map_err(|e| LedgerError::Invalid(e.to_string()))?
            != serde_json::to_vec(&pristine).map_err(|e| LedgerError::Invalid(e.to_string()))?
        {
            return Err(LedgerError::Invalid(
                "V3 birth requires exact pristine genesis including unrooted bookkeeping".into(),
            ));
        }
        let mut candidate = self.clone();
        candidate.m0_active_protocol =
            Some(crate::M0ActiveProtocolStateV1::at_birth(&birth).map_err(LedgerError::Invalid)?);
        candidate.m0_network_birth_v3 = Some(birth.clone());
        let initial_asset_root =
            AdmissionHash32::from_hex(&candidate.state_root_before_admission()?)
                .map_err(|e| LedgerError::Invalid(e.to_string()))?;
        candidate.admission_state = Some(
            LedgerAdmissionStateV1::new(birth.admission_genesis, initial_asset_root)
                .map_err(|e| LedgerError::Invalid(e.to_string()))?,
        );
        candidate.checkpoints.clear();
        candidate.create_checkpoint()?;
        *self = candidate;
        Ok(())
    }

    /// Applies one already-verified admission-control fact to the bounded
    /// Ledger extension. This is deliberately not a command route: the future
    /// tag-28 transition must call it only after proof verification, and the
    /// containing authenticated main-WAL commit supplies the finality anchor.
    /// Keeping that anchor outside the fact avoids a commit-hash/state-root
    /// self-reference.
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn apply_admission_ledger_control_fact(
        &mut self,
        fact: &crate::AdmissionLedgerControlFactV1,
    ) -> Result<(), LedgerError> {
        let admission_genesis = self.m0_admission_genesis()?.ok_or_else(|| {
            LedgerError::Invalid(
                "admission Ledger-control facts require the signed M0 trust root".into(),
            )
        })?;
        let prestate_root = AdmissionHash32::from_hex(&self.state_root()?)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if let crate::AdmissionLedgerControlFactV1::RolloverAuthorization(authorization) = fact {
            if authorization.finalized_ledger_state_root != prestate_root {
                return Err(LedgerError::Invalid(
                    "rollover authorization must bind the exact finalized Ledger prestate root"
                        .into(),
                ));
            }
        }
        let admission = self.admission_state.as_ref().ok_or_else(|| {
            LedgerError::Invalid("signed M0 trust root has no admission Ledger state".into())
        })?;
        if &admission.genesis != admission_genesis {
            return Err(LedgerError::Invalid(
                "admission Ledger state differs from the signed M0 trust root".into(),
            ));
        }
        let mut candidate = admission.control.clone();
        candidate
            .apply_exact_fact(fact, &admission.genesis.config)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        candidate
            .validate_recovered(&admission.genesis.config)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        self.admission_state
            .as_mut()
            .expect("admission state was checked above")
            .control = candidate;
        Ok(())
    }

    /// Executes one already-verified tag-28 checkpoint result against the exact
    /// authenticated proposal prestate and successor commitment. The live
    /// Ledger changes only after admission mutation, height advancement and the
    /// signed expected state root all agree.
    ///
    /// Pure `ConsensusCommand` dispatch remains deliberately fail-closed: the
    /// node route must supply exact retained history and authenticated main-WAL
    /// anchors before this external-evidence transition can execute.
    #[cfg_attr(not(test), allow(dead_code))]
    pub fn execute_authenticated_admission_checkpoint_transition(
        &mut self,
        proposal_context: &AuthenticatedAdmissionCheckpointProposalV1,
        transition: &VerifiedAdmissionCheckpointTransitionV1,
    ) -> Result<(), LedgerError> {
        let parent_state_root = self.state_root()?;
        if proposal_context.parent_height() != self.height
            || proposal_context.parent_state_root() != parent_state_root
            || proposal_context.committing_ledger_height()
                != u128::from(self.height.checked_add(1).ok_or_else(|| {
                    LedgerError::Invalid("tag-28 proposal successor height overflows U64".into())
                })?)
            || proposal_context.proof_id() != transition.proof_id
            || proposal_context.committing_ledger_height() != transition.committing_ledger_height
        {
            return Err(LedgerError::Invalid(
                "verified admission transition does not match the authenticated tag-28 proposal context"
                    .into(),
            ));
        }

        let mut staged = self.clone();
        staged.apply_verified_admission_checkpoint_transition_inner(transition)?;
        staged.advance()?;
        if u128::from(staged.height) != proposal_context.committing_ledger_height()
            || staged.state_root()? != proposal_context.expected_state_root()
        {
            return Err(LedgerError::Invalid(
                "tag-28 execution result does not match the authenticated proposal successor"
                    .into(),
            ));
        }
        *self = staged;
        Ok(())
    }

    /// Computes the exact tag-28 successor commitment after a proof has been
    /// verified against local Admission history. This does not mutate the
    /// Ledger or authenticate a proposal; it lets a proposer commit the same
    /// height/root that replay will later enforce.
    pub fn admission_checkpoint_successor_commitment(
        &self,
        transition: &VerifiedAdmissionCheckpointTransitionV1,
    ) -> Result<(u64, String), LedgerError> {
        let mut expected = self.clone();
        expected.apply_verified_admission_checkpoint_transition_inner(transition)?;
        expected.advance()?;
        Ok((expected.height, expected.state_root()?))
    }

    /// Computes a tag-28 successor only when the Ledger-minted pre-signing plan
    /// still names this exact current prestate and the locally verified proof.
    /// A plan cannot survive an intervening Ledger commit or be reused for a
    /// substituted checkpoint proof.
    pub fn admission_checkpoint_successor_commitment_from_plan(
        &self,
        plan: &AdmissionCheckpointProposalPlanV1,
        transition: &VerifiedAdmissionCheckpointTransitionV1,
    ) -> Result<(u64, String), LedgerError> {
        let current_root = self.state_root()?;
        let expected_height = self.height.checked_add(1).ok_or_else(|| {
            LedgerError::Invalid("tag-28 proposal-plan successor height overflows U64".into())
        })?;
        if plan.parent_height() != self.height
            || plan.parent_state_root() != current_root
            || plan.expected_height() != expected_height
            || plan.proof_id() != transition.proof_id
            || plan.committing_ledger_height() != transition.committing_ledger_height
        {
            return Err(LedgerError::Invalid(
                "tag-28 proposal plan is stale or differs from the locally verified transition"
                    .into(),
            ));
        }
        let successor = self.admission_checkpoint_successor_commitment(transition)?;
        if successor.0 != plan.expected_height() {
            return Err(LedgerError::Invalid(
                "tag-28 successor differs from the Ledger-minted proposal plan".into(),
            ));
        }
        Ok(successor)
    }

    fn apply_verified_admission_checkpoint_transition_inner(
        &mut self,
        transition: &VerifiedAdmissionCheckpointTransitionV1,
    ) -> Result<(), LedgerError> {
        let admission_genesis = self.m0_admission_genesis()?.ok_or_else(|| {
            LedgerError::Invalid(
                "verified admission checkpoint requires the signed M0 trust root".into(),
            )
        })?;
        let current_asset_root = AdmissionHash32::from_hex(&self.state_root_before_admission()?)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        let admission = self.admission_state.as_ref().ok_or_else(|| {
            LedgerError::Invalid("signed M0 trust root has no admission Ledger state".into())
        })?;
        if &admission.genesis != admission_genesis {
            return Err(LedgerError::Invalid(
                "admission Ledger state differs from the signed M0 trust root".into(),
            ));
        }
        let mut candidate = admission.clone();
        candidate
            .apply_verified_checkpoint_transition(transition, current_asset_root)
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        self.admission_state = Some(candidate);
        Ok(())
    }

    #[cfg(test)]
    pub(crate) fn test_authenticated_admission_checkpoint_proposal(
        &self,
        transition: &VerifiedAdmissionCheckpointTransitionV1,
    ) -> Result<AuthenticatedAdmissionCheckpointProposalV1, LedgerError> {
        let (expected_height, expected_state_root) =
            self.admission_checkpoint_successor_commitment(transition)?;
        AuthenticatedAdmissionCheckpointProposalV1::from_authenticated_proposal(
            hash_bytes(b"RLD-TEST-AUTHENTICATED-ADMISSION-PROPOSAL"),
            hash_bytes(b"RLD-TEST-AUTHENTICATED-ADMISSION-COMMAND"),
            transition.proof_id,
            self.height,
            self.state_root()?,
            expected_height,
            expected_state_root,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))
    }

    fn ensure_m0_consensus_command_allowed(
        &self,
        command: &ConsensusCommand,
    ) -> Result<(), LedgerError> {
        self.ensure_consensus_upgrade_boundary(command)?;
        self.ensure_m0_consensus_command_profile_allowed(command)
    }

    fn ensure_consensus_upgrade_boundary(
        &self,
        command: &ConsensusCommand,
    ) -> Result<(), LedgerError> {
        if let ConsensusCommand::ActivateUpgrade(activation) = command {
            self.validate_supported_upgrade_activation(activation)
                .map_err(LedgerError::Invalid)
        } else {
            self.ensure_upgrade_height_boundary(1)
        }
    }

    fn ensure_m0_consensus_command_profile_allowed(
        &self,
        command: &ConsensusCommand,
    ) -> Result<(), LedgerError> {
        self.validated_admission_state()?;
        if self.m0_profile_active()
            && !matches!(
                command,
                ConsensusCommand::NetworkHeartbeat(_)
                    | ConsensusCommand::CommitAdmissionCheckpoint(_)
                    | ConsensusCommand::ScheduleUpgrade(_)
                    | ConsensusCommand::ActivateUpgrade(_)
            )
        {
            return Err(LedgerError::ValueRisk(
                "consensus-rooted M0 profile permits only value-free NETWORK_HEARTBEAT; all value, governance, membership and production commands fail closed".into(),
            ));
        }
        Ok(())
    }

    fn validated_admission_state(&self) -> Result<Option<&LedgerAdmissionStateV1>, LedgerError> {
        match (self.m0_admission_genesis()?, &self.admission_state) {
            (None, None) => Ok(None),
            (Some(admission_genesis), Some(admission)) => {
                admission
                    .validate_for_descriptor(&self.descriptor)
                    .map_err(|error| {
                        LedgerError::ValueRisk(format!(
                            "consensus-rooted M0 admission trust state is invalid; all commands fail closed: {error}"
                        ))
                    })?;
                if &admission.genesis != admission_genesis {
                    return Err(LedgerError::ValueRisk(
                        "consensus-rooted M0 binding and admission genesis differ; all commands fail closed"
                            .into(),
                    ));
                }
                Ok(Some(admission))
            }
            (Some(_), None) => Err(LedgerError::ValueRisk(
                "consensus-rooted M0 binding has no admission trust state; all commands fail closed"
                    .into(),
            )),
            (None, Some(_)) => Err(LedgerError::ValueRisk(
                "admission trust state exists without its M0 network-birth binding; all commands fail closed"
                    .into(),
            )),
        }
    }

    pub fn admission_may_sign_consensus(&self) -> Result<bool, LedgerError> {
        Ok(self
            .validated_admission_state()?
            .is_none_or(|admission| admission.censorship_guard.may_sign_consensus()))
    }

    pub fn admission_may_accept_value_eligible_finality(&self) -> Result<bool, LedgerError> {
        Ok(self.validated_admission_state()?.is_none_or(|admission| {
            admission
                .censorship_guard
                .may_accept_value_eligible_finality()
        }))
    }

    pub fn admission_may_raise_value_cap(&self) -> Result<bool, LedgerError> {
        Ok(self
            .validated_admission_state()?
            .is_none_or(|admission| admission.censorship_guard.may_raise_value_cap()))
    }

    fn ensure_admission_may_raise_value_cap(&self) -> Result<(), LedgerError> {
        if !self.admission_may_raise_value_cap()? {
            return Err(LedgerError::ValueRisk(
                "CENSORSHIP_STALLED blocks every value-cap or value-limit risk increase".into(),
            ));
        }
        Ok(())
    }

    pub fn empty_zone(
        display_name: impl Into<String>,
        validator_keys: Vec<String>,
        notary_keys: Vec<String>,
        testnet: bool,
    ) -> Result<Self, LedgerError> {
        Self::new(
            display_name,
            Amount::ZERO,
            validator_keys,
            notary_keys,
            testnet,
        )
    }

    pub fn balance(&self, owner: &str) -> Result<Amount, LedgerError> {
        self.coins
            .values()
            .filter(|coin| coin.owner == owner && coin.state == CoinState::Spendable)
            .try_fold(Amount::ZERO, |sum, coin| sum.checked_add(coin.amount))
            .map_err(LedgerError::from)
    }

    /// Finalizes one explicitly value-free liveness block. Consensus itself is
    /// the authorization; the command cannot mint, transfer, reserve, unlock,
    /// govern, or alter membership.
    pub fn network_heartbeat(
        &mut self,
        heartbeat: NetworkHeartbeatV1,
    ) -> Result<NetworkHeartbeatV1, LedgerError> {
        if heartbeat.heartbeat_id.is_empty()
            || heartbeat.heartbeat_id.len() > 128
            || !heartbeat
                .heartbeat_id
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b':'))
        {
            return Err(LedgerError::Invalid(
                "network heartbeat id is not a bounded canonical identifier".into(),
            ));
        }
        if heartbeat.zone_id != self.descriptor.zone_id
            || heartbeat.currency_genesis_root != self.descriptor.currency_genesis_root
            || heartbeat.protocol_era != self.descriptor.protocol_era
            || heartbeat.crypto_era != self.descriptor.crypto_era
            || heartbeat.parent_height != self.height
        {
            return Err(LedgerError::Invalid(
                "network heartbeat does not extend the exact local ledger context".into(),
            ));
        }
        if !is_canonical_sha256_hex(&heartbeat.note_hash) {
            return Err(LedgerError::Invalid(
                "network heartbeat note hash must be lowercase SHA-256 hex".into(),
            ));
        }
        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        Ok(heartbeat)
    }

    pub fn coins_for_owner(&self, owner: &str) -> Vec<CoinObject> {
        self.coins
            .values()
            .filter(|coin| coin.owner == owner && coin.state.carries_supply())
            .cloned()
            .collect()
    }

    pub fn register_zone_advertisement(
        &mut self,
        advertisement: ZoneAdvertisement,
    ) -> Result<ZoneAdvertisement, LedgerError> {
        advertisement.verify().map_err(LedgerError::InvalidQuorum)?;
        let zone_id = advertisement.descriptor.zone_id.clone();
        if let Some(existing) = self.zone_advertisements.get(&zone_id) {
            if advertisement.sequence <= existing.sequence {
                return Err(LedgerError::Duplicate(format!(
                    "stale Zone advertisement for {zone_id}"
                )));
            }
            if advertisement.descriptor.genesis_root != existing.descriptor.genesis_root {
                return Err(LedgerError::Invalid(
                    "Zone advertisement attempts to replace the genesis root".into(),
                ));
            }
        }
        self.zone_advertisements
            .insert(zone_id, advertisement.clone());
        Ok(advertisement)
    }

    pub fn register_payment_request(
        &mut self,
        request: PaymentRequest,
    ) -> Result<PaymentRequest, LedgerError> {
        request.verify().map_err(LedgerError::InvalidSignature)?;
        if request.destination_zone != self.descriptor.zone_id {
            return Err(LedgerError::Invalid(
                "payment request destination Zone mismatch".into(),
            ));
        }
        self.validate_payment_request_context(&request)?;
        if request.expires_at_height <= self.height {
            return Err(LedgerError::Invalid("payment request has expired".into()));
        }
        if self.payment_requests.contains_key(&request.request_id)
            || self.consumed_payment_requests.contains(&request.request_id)
        {
            return Err(LedgerError::Duplicate(request.request_id));
        }
        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.payment_requests
            .insert(request.request_id.clone(), request.clone());
        Ok(request)
    }

    pub fn create_route_quote(
        &mut self,
        request: CreateRouteQuoteRequest,
    ) -> Result<RouteQuote, LedgerError> {
        let CreateRouteQuoteRequest {
            provider,
            destination_zone,
            route,
            transport,
            base_fee,
            authorized_reroute_budget,
            expires_at_height,
            authorization,
        } = request;
        if destination_zone == self.descriptor.zone_id
            || route.len() < 2
            || route.len() > 64
            || route.first() != Some(&self.descriptor.zone_id)
            || route.last() != Some(&destination_zone)
            || route.iter().any(|zone| zone.trim().is_empty())
            || route.iter().collect::<BTreeSet<_>>().len() != route.len()
            || expires_at_height <= self.height
            || transport == TransportClass::ChronologyUnsafe
        {
            return Err(LedgerError::Invalid(
                "invalid route quote path, expiry, or transport".into(),
            ));
        }
        let route_path = route.join("|");
        let payload_hash = action_payload_hash(
            "CREATE_ROUTE_QUOTE",
            &[
                provider.as_bytes(),
                destination_zone.as_bytes(),
                route_path.as_bytes(),
                transport_code(&transport).as_bytes(),
                &base_fee.0.to_be_bytes(),
                &authorized_reroute_budget.0.to_be_bytes(),
                &expires_at_height.to_be_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &authorization,
            &provider,
            "CREATE_ROUTE_QUOTE",
            &payload_hash,
        )?;
        self.ensure_counter_headroom(1, 1)?;
        self.consume_authorization(&authorization)?;
        self.advance()?;
        let quote = RouteQuote {
            quote_id: self.next_id("route-quote")?,
            provider,
            source_zone: self.descriptor.zone_id.clone(),
            destination_zone,
            route,
            transport,
            base_fee,
            authorized_reroute_budget,
            consumed_reroute_fee: Amount::ZERO,
            expires_at_height,
            status: RouteQuoteStatus::Open,
            locked_payment_id: None,
            created_height: self.height,
        };
        self.route_quotes
            .insert(quote.quote_id.clone(), quote.clone());
        Ok(quote)
    }

    pub fn reroute_route_quote(
        &mut self,
        quote_id: &str,
        request: RerouteRouteQuoteRequest,
    ) -> Result<RouteQuote, LedgerError> {
        let quote = self
            .route_quotes
            .get(quote_id)
            .cloned()
            .ok_or_else(|| LedgerError::RouteQuoteNotFound(quote_id.into()))?;
        if quote.status != RouteQuoteStatus::Open || quote.expires_at_height <= self.height {
            return Err(LedgerError::Invalid(
                "only a live open route quote can fail over".into(),
            ));
        }
        if !quote.route.contains(&request.failed_hop)
            || request.failed_hop == quote.source_zone
            || request.failed_hop == quote.destination_zone
            || request.replacement_route.len() < 2
            || request.replacement_route.len() > 64
            || request.replacement_route.first() != Some(&quote.source_zone)
            || request.replacement_route.last() != Some(&quote.destination_zone)
            || request
                .replacement_route
                .iter()
                .any(|zone| zone.trim().is_empty() || zone == &request.failed_hop)
            || request
                .replacement_route
                .iter()
                .collect::<BTreeSet<_>>()
                .len()
                != request.replacement_route.len()
        {
            return Err(LedgerError::Invalid(
                "replacement route must bypass one failed intermediate hop".into(),
            ));
        }
        let new_consumed = quote
            .consumed_reroute_fee
            .checked_add(request.incremental_fee)?;
        if new_consumed > quote.authorized_reroute_budget {
            return Err(LedgerError::Invalid(
                "reroute fee exceeds the payer-authorized budget".into(),
            ));
        }
        let route_path = request.replacement_route.join("|");
        let payload_hash = action_payload_hash(
            "REROUTE_ROUTE_QUOTE",
            &[
                quote_id.as_bytes(),
                request.failed_hop.as_bytes(),
                route_path.as_bytes(),
                &request.incremental_fee.0.to_be_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &request.authorization,
            &quote.provider,
            "REROUTE_ROUTE_QUOTE",
            &payload_hash,
        )?;
        self.ensure_counter_headroom(1, 0)?;
        self.consume_authorization(&request.authorization)?;
        self.advance()?;
        let stored = self
            .route_quotes
            .get_mut(quote_id)
            .expect("route quote was checked");
        stored.route = request.replacement_route;
        stored.consumed_reroute_fee = new_consumed;
        Ok(stored.clone())
    }

    pub fn accept_recipient_receipt(
        &mut self,
        receipt: RecipientReceipt,
    ) -> Result<RecipientReceipt, LedgerError> {
        receipt.verify().map_err(LedgerError::InvalidSignature)?;
        if receipt.destination_zone != self.descriptor.zone_id {
            return Err(LedgerError::Invalid(
                "recipient receipt destination Zone mismatch".into(),
            ));
        }
        if receipt.currency_genesis_root != self.descriptor.currency_genesis_root
            || receipt.protocol_era != self.descriptor.protocol_era
            || receipt.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "recipient receipt network or era context mismatch".into(),
            ));
        }
        if receipt.observed_destination_height > self.height {
            return Err(LedgerError::Invalid(
                "recipient receipt references a future height".into(),
            ));
        }
        if self.recipient_receipts.contains_key(&receipt.payment_id)
            || self
                .recipient_receipts
                .values()
                .any(|existing| existing.receipt_id == receipt.receipt_id)
        {
            return Err(LedgerError::Duplicate(receipt.receipt_id));
        }

        let local_match = self
            .payments
            .get(&receipt.payment_id)
            .is_some_and(|payment| {
                matches!(
                    payment.status,
                    PaymentStatus::LocalSpendable | PaymentStatus::UniversallySettled
                ) && payment.intent.recipient == receipt.recipient
                    && payment.intent.amount == receipt.amount
                    && receipt.settlement_reference == payment.intent.payment_id
            });
        let import_match = self.import_receipts.values().any(|import| {
            import.payment_id == receipt.payment_id
                && import.transit_id == receipt.settlement_reference
                && import.recipient == receipt.recipient
                && import.amount == receipt.amount
        });
        let spendability_match = self
            .spendability_certificates
            .get(&receipt.payment_id)
            .is_some_and(|certificate| {
                certificate.local_coin_id == receipt.settlement_reference
                    && certificate.recipient == receipt.recipient
                    && certificate.amount == receipt.amount
            });
        if !(local_match || import_match || spendability_match) {
            return Err(LedgerError::Invalid(
                "recipient receipt does not match a locally spendable settlement".into(),
            ));
        }

        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.recipient_receipts
            .insert(receipt.payment_id.clone(), receipt.clone());
        Ok(receipt)
    }

    pub fn bootstrap_service_reward(
        &mut self,
        node_id: String,
        owner: String,
        role: ServiceRole,
        proof_hash: String,
        amount: Amount,
    ) -> Result<(CoinObject, ServiceReceipt), LedgerError> {
        if !self.descriptor.testnet {
            return Err(LedgerError::TestnetOnly);
        }
        if self.bootstrap_claims.contains(&owner) {
            return Err(LedgerError::Duplicate("bootstrap owner".into()));
        }
        let max = Amount::from_rld_whole(100)?;
        if amount.is_zero() || amount > max {
            return Err(LedgerError::Invalid(
                "bootstrap reward must be between 1 runlai and 100 RLD".into(),
            ));
        }
        if proof_hash.trim().is_empty() {
            return Err(LedgerError::Invalid("work proof is required".into()));
        }
        self.ensure_counter_headroom(1, 4)?;
        self.reserve_pools.startup_services = self
            .reserve_pools
            .startup_services
            .checked_sub(amount)
            .map_err(|_| LedgerError::Supply("startup service pool is exhausted".into()))?;
        self.reserve = self.reserve.checked_sub(amount)?;
        self.advance()?;
        let coin = self.make_coin(
            owner.clone(),
            amount,
            CoinState::Spendable,
            Vec::new(),
            None,
            None,
            None,
            1,
        )?;
        self.coins.insert(coin.object_id.clone(), coin.clone());

        let order_id = self.next_id("bootstrap-order")?;
        let lease_id = self.next_id("bootstrap-lease")?;
        let order = ServiceOrder {
            order_id: order_id.clone(),
            buyer: "rld:protocol:startup-services".into(),
            role: role.clone(),
            budget: amount,
            escrow_coin_id: format!("protocol-reserve:startup-services:{order_id}"),
            description: "testnet bootstrap verified network service".into(),
            status: ServiceStatus::Completed,
            created_height: self.height,
        };
        let lease = ServiceLease {
            lease_id: lease_id.clone(),
            order_id: order_id.clone(),
            node_id: node_id.clone(),
            accepted_quote: amount,
            accepted_height: self.height,
        };
        let receipt = ServiceReceipt {
            receipt_id: self.next_id("service-receipt")?,
            order_id: order_id.clone(),
            lease_id: lease_id.clone(),
            node_id: node_id.clone(),
            role: role.clone(),
            amount,
            proof_hash,
            completed_height: self.height,
            bootstrap: true,
            protocol_reserve_pool: Some(ProtocolReservePoolKind::StartupServices),
        };
        self.service_orders.insert(order_id, order);
        self.service_leases.insert(lease_id, lease);
        self.service_receipts
            .insert(receipt.receipt_id.clone(), receipt.clone());
        self.record_earnings(&node_id, &role, amount, &receipt.receipt_id)?;
        self.bootstrap_claims.insert(owner);
        self.assert_conservation()?;
        Ok((coin, receipt))
    }

    pub fn local_payment(
        &mut self,
        intent: UniversalPaymentIntent,
    ) -> Result<PaymentRecord, LedgerError> {
        self.validate_intent(&intent, true)?;
        if self.payments.contains_key(&intent.payment_id) {
            return Err(LedgerError::Duplicate(intent.payment_id));
        }
        let input = self.spendable_owned_coin(&intent.coin_id, &intent.sender_public_key)?;
        let (fee_resources, charged_fee) = self.local_payment_fee_quote(&intent)?;
        if intent.max_fee < charged_fee {
            return Err(LedgerError::Invalid(format!(
                "payment max_fee {} is below deterministic resource fee {}",
                intent.max_fee, charged_fee
            )));
        }
        let required_input = intent.amount.checked_add(charged_fee)?;
        if intent.amount.is_zero() || required_input > input.amount {
            return Err(LedgerError::Invalid("invalid payment amount".into()));
        }
        let next_value_total =
            self.next_value_risk_total(ValueRiskPath::LocalPayment, intent.amount)?;
        let change = input.amount.checked_sub(required_input)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 1 + u64::from(!change.is_zero());
        let current_fee_pool = self
            .epoch_fee_pools
            .get(&LOCAL_PAYMENT_PRICING_EPOCH)
            .cloned()
            .unwrap_or_else(|| EpochFeePool {
                pricing_epoch: LOCAL_PAYMENT_PRICING_EPOCH,
                ..EpochFeePool::default()
            });
        let next_fee_collected = current_fee_pool.collected.checked_add(charged_fee)?;
        let next_charged_payments = current_fee_pool
            .charged_payments
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("epoch fee payment counter overflow".into()))?;
        self.ensure_counter_headroom(1, sequence_steps)?;

        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let recipient_coin = self.make_coin(
            intent.recipient.clone(),
            intent.amount,
            CoinState::Spendable,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            None,
            next_version,
        )?;
        let mut outputs = vec![recipient_coin.object_id.clone()];
        self.coins
            .insert(recipient_coin.object_id.clone(), recipient_coin);
        if !change.is_zero() {
            let change_coin = self.make_coin(
                input.owner,
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                None,
                next_version,
            )?;
            outputs.push(change_coin.object_id.clone());
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let fee_pool = self
            .epoch_fee_pools
            .entry(LOCAL_PAYMENT_PRICING_EPOCH)
            .or_insert(current_fee_pool);
        fee_pool.collected = next_fee_collected;
        fee_pool.charged_payments = next_charged_payments;
        let record = PaymentRecord {
            intent: intent.clone(),
            status: PaymentStatus::UniversallySettled,
            output_coin_ids: outputs,
            transit_id: None,
            updated_height: self.height,
            charged_fee,
            fee_resources,
            pricing_epoch: LOCAL_PAYMENT_PRICING_EPOCH,
        };
        self.consume_payment_request(&intent)?;
        self.payments.insert(intent.payment_id, record.clone());
        self.record_value_risk_total(ValueRiskPath::LocalPayment, next_value_total);
        self.assert_conservation()?;
        Ok(record)
    }

    pub fn local_payment_fee_quote(
        &self,
        intent: &UniversalPaymentIntent,
    ) -> Result<(ResourceVector, Amount), LedgerError> {
        let ingress_bytes = u64::try_from(
            serde_json::to_vec(intent)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?
                .len(),
        )
        .map_err(|_| LedgerError::Invalid("local payment envelope is too large".into()))?;
        let resources = ResourceVector {
            ingress_bytes,
            signature_checks_classic: 1 + u64::from(intent.payment_request.is_some()),
            signature_checks_pq: 0,
            state_reads: 3 + u64::from(intent.payment_request_id.is_some()),
            state_writes: 6 + u64::from(intent.payment_request_id.is_some()),
            new_state_bytes: ingress_bytes.checked_add(1_024).ok_or_else(|| {
                LedgerError::Invalid("local payment state-byte accounting overflow".into())
            })?,
            proof_bytes: 0,
            proof_verification_units: 0,
            consensus_units: 1,
            archive_byte_epochs: 0,
        };
        let fee = local_payment_price_schedule()
            .quote(&resources)
            .map_err(LedgerError::Invalid)?;
        Ok((resources, fee))
    }

    pub fn validate_consensus_proposal(
        &self,
        proposal: &ConsensusProposal,
    ) -> Result<ConsensusOutcome, LedgerError> {
        self.validate_consensus_proposal_envelope(proposal)?;

        let mut staged = self.clone();
        let record = staged.execute_consensus_command(proposal.command.clone())?;
        if staged.height != proposal.expected_height
            || staged.state_root()? != proposal.expected_state_root
        {
            return Err(LedgerError::InvalidQuorum(
                "proposal execution result does not match its state commitment".into(),
            ));
        }
        Ok(record)
    }

    /// Verifies the signed proposal, deterministic authority and exact
    /// prestate without attempting command execution. Only the external
    /// evidence path uses this for commands whose deterministic dependencies
    /// live outside the bounded Ledger state.
    fn validate_consensus_proposal_envelope(
        &self,
        proposal: &ConsensusProposal,
    ) -> Result<(), LedgerError> {
        if self.descriptor.testnet {
            proposal.verify().map_err(LedgerError::InvalidQuorum)?;
        } else {
            proposal
                .verify_wire_v1(&self.descriptor.network_domain)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        }
        self.validate_consensus_proposal_authority_and_prestate(proposal)?;
        Ok(())
    }

    /// Mints the only pre-signing context accepted by bounded tag-28 proof
    /// verification. It binds the canonical proof command to the exact current
    /// Ledger prestate without accepting caller-supplied heights or roots.
    pub fn plan_admission_checkpoint_proposal(
        &self,
        proof: &AdmissionCheckpointProofV1,
    ) -> Result<AdmissionCheckpointProposalPlanV1, LedgerError> {
        self.ensure_upgrade_height_boundary(1)?;
        if self.descriptor.testnet {
            return Err(LedgerError::InvalidQuorum(
                "tag-28 proposal planning is mainnet-wire only".into(),
            ));
        }
        if self.validated_admission_state()?.is_none() {
            return Err(LedgerError::Invalid(
                "tag-28 proposal planning requires signed M0 admission state".into(),
            ));
        }
        let expected_height = self.height.checked_add(1).ok_or_else(|| {
            LedgerError::Invalid("tag-28 proposal-plan successor height overflows U64".into())
        })?;
        let proof_id = proof
            .proof_id()
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        let command_hash = crate::command_wire::admission_checkpoint_candidate_command_hash_v1(
            &self.descriptor.network_domain,
            proof,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        AdmissionCheckpointProposalPlanV1::from_ledger_prestate(
            command_hash,
            proof_id,
            self.height,
            self.state_root()?,
            expected_height,
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))
    }

    /// Authenticates the signed proposal context needed by bounded tag-28 proof
    /// verification. The formal command is decodable, but pure Ledger dispatch
    /// remains fail-closed because retained Admission history is node-local.
    pub fn authenticate_admission_checkpoint_proposal(
        &self,
        proposal: &ConsensusProposal,
        proof: &AdmissionCheckpointProofV1,
    ) -> Result<AuthenticatedAdmissionCheckpointProposalV1, LedgerError> {
        if self.descriptor.testnet {
            return Err(LedgerError::InvalidQuorum(
                "tag-28 proposal authentication is mainnet-wire only".into(),
            ));
        }
        if self.validated_admission_state()?.is_none() {
            return Err(LedgerError::Invalid(
                "tag-28 proposal authentication requires signed M0 admission state".into(),
            ));
        }
        let ConsensusCommand::CommitAdmissionCheckpoint(committed_proof) = &proposal.command else {
            return Err(LedgerError::InvalidQuorum(
                "tag-28 authentication requires the formal admission-checkpoint command".into(),
            ));
        };
        if committed_proof.as_ref() != proof {
            return Err(LedgerError::InvalidQuorum(
                "tag-28 proof differs from the decoded proposal command".into(),
            ));
        }
        self.validate_consensus_proposal_envelope(proposal)?;
        let expected_command_hash =
            crate::command_wire::admission_checkpoint_candidate_command_hash_v1(
                &self.descriptor.network_domain,
                proof,
            )
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if proposal.command_hash != expected_command_hash {
            return Err(LedgerError::InvalidQuorum(
                "proposal does not commit the exact reserved tag-28 checkpoint proof".into(),
            ));
        }
        let proposal_hash = proposal
            .wire_v1_proposal_hash(&self.descriptor.network_domain)
            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        AuthenticatedAdmissionCheckpointProposalV1::from_authenticated_proposal(
            proposal_hash,
            expected_command_hash,
            proof
                .proof_id()
                .map_err(|error| LedgerError::Invalid(error.to_string()))?,
            proposal.parent_height,
            proposal.parent_state_root.clone(),
            proposal.expected_height,
            proposal.expected_state_root.clone(),
        )
        .map_err(|error| LedgerError::Invalid(error.to_string()))
    }

    pub(crate) fn validate_consensus_proposal_authority_and_prestate(
        &self,
        proposal: &ConsensusProposal,
    ) -> Result<(), LedgerError> {
        self.ensure_consensus_upgrade_boundary(&proposal.command)?;
        if self.descriptor.validator_keys.is_empty() {
            return Err(LedgerError::InvalidQuorum(
                "consensus requires a configured validator set".into(),
            ));
        }
        let expected_leader = deterministic_round_zero_leader(
            &self.descriptor.validator_keys,
            proposal.parent_height,
        )
        .map_err(LedgerError::InvalidQuorum)?;
        if proposal.zone_id != self.descriptor.zone_id
            || proposal.currency_genesis_root != self.descriptor.currency_genesis_root
            || proposal.protocol_era != self.descriptor.protocol_era
            || proposal.crypto_era != self.descriptor.crypto_era
            || proposal.proposer_public_key != expected_leader
        {
            return Err(LedgerError::InvalidQuorum(
                "proposal Zone is not authorized or proposer is not the deterministic round-zero leader"
                    .into(),
            ));
        }
        if proposal.parent_height != self.height
            || proposal.parent_state_root != self.state_root()?
        {
            return Err(LedgerError::InvalidQuorum(
                "proposal does not extend the current finalized state".into(),
            ));
        }
        Ok(())
    }

    pub fn lock_consensus_vote(&mut self, proposal: &ConsensusProposal) -> Result<(), LedgerError> {
        let mut locks = self.normalized_consensus_vote_locks()?;
        self.validate_consensus_proposal(proposal)?;
        let lock_key =
            consensus_instance_lock_key(proposal.parent_height, &proposal.parent_state_root);
        let proposal_hash = self.consensus_proposal_hash(proposal)?;
        if let Some(existing) = locks.get(&lock_key) {
            if existing != &proposal_hash {
                return Err(LedgerError::InvalidQuorum(
                    "validator already voted for a conflicting proposal in this consensus instance"
                        .into(),
                ));
            }
            self.consensus_vote_locks = locks;
            return Ok(());
        }
        locks.insert(lock_key, proposal_hash);
        self.consensus_vote_locks = locks;
        Ok(())
    }

    /// Freezes the only vote-lock mutation permitted for an externally
    /// verified tag-28 proposal. The authenticated proposal capability proves
    /// signature/leader/prestate binding; executing the verified transition on
    /// a throwaway clone proves the proposal's exact successor root before a
    /// lock can be minted.
    pub fn authenticate_admission_checkpoint_vote_lock(
        &self,
        proposal_context: &AuthenticatedAdmissionCheckpointProposalV1,
        transition: &VerifiedAdmissionCheckpointTransitionV1,
    ) -> Result<AuthenticatedAdmissionCheckpointVoteLockV1, LedgerError> {
        let mut successor = self.clone();
        successor
            .execute_authenticated_admission_checkpoint_transition(proposal_context, transition)?;
        let prior_unrooted_bytes = serde_json::to_vec(&(
            &self.era_certificates,
            &self.checkpoints,
            &self.consensus_vote_locks,
            &self.consensus_commits,
        ))
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        let mut successor_vote_locks = self.normalized_consensus_vote_locks()?;
        let lock_key = consensus_instance_lock_key(
            proposal_context.parent_height(),
            proposal_context.parent_state_root(),
        );
        let proposal_hash = proposal_context.proposal_hash().to_owned();
        if successor_vote_locks
            .get(&lock_key)
            .is_some_and(|existing| existing != &proposal_hash)
        {
            return Err(LedgerError::InvalidQuorum(
                "validator already voted for a conflicting proposal in this consensus instance"
                    .into(),
            ));
        }
        successor_vote_locks.insert(lock_key, proposal_hash.clone());
        Ok(AuthenticatedAdmissionCheckpointVoteLockV1 {
            proposal_hash,
            parent_height: proposal_context.parent_height(),
            parent_state_root: proposal_context.parent_state_root().into(),
            prior_unrooted_bytes,
            successor_vote_locks,
        })
    }

    /// Applies only the lock map frozen by
    /// `authenticate_admission_checkpoint_vote_lock`. Any intervening Ledger
    /// change or edit to other unrooted consensus metadata invalidates the
    /// capability before mutation.
    pub fn apply_authenticated_admission_checkpoint_vote_lock(
        &mut self,
        authenticated: AuthenticatedAdmissionCheckpointVoteLockV1,
    ) -> Result<(), LedgerError> {
        if self.height != authenticated.parent_height
            || self.state_root()? != authenticated.parent_state_root
        {
            return Err(LedgerError::InvalidQuorum(
                "authenticated tag-28 vote lock no longer names the current Ledger prestate".into(),
            ));
        }
        let current_unrooted_bytes = serde_json::to_vec(&(
            &self.era_certificates,
            &self.checkpoints,
            &self.consensus_vote_locks,
            &self.consensus_commits,
        ))
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if current_unrooted_bytes != authenticated.prior_unrooted_bytes {
            return Err(LedgerError::InvalidQuorum(
                "authenticated tag-28 vote lock does not match current consensus bookkeeping"
                    .into(),
            ));
        }
        self.consensus_vote_locks = authenticated.successor_vote_locks;
        Ok(())
    }

    /// Re-authenticates a formal tag-28 proposal and proves that this exact
    /// proposal hash is already present in the recovered durable vote-lock
    /// state. This is the only external-evidence substitute for pure proposal
    /// execution when constructing an unsigned vote.
    pub fn authenticate_locked_admission_checkpoint_proposal(
        &self,
        proposal: &ConsensusProposal,
        proof: &AdmissionCheckpointProofV1,
    ) -> Result<AuthenticatedAdmissionCheckpointProposalV1, LedgerError> {
        let proposal_context = self.authenticate_admission_checkpoint_proposal(proposal, proof)?;
        let locks = self.normalized_consensus_vote_locks()?;
        let lock_key = consensus_instance_lock_key(
            proposal_context.parent_height(),
            proposal_context.parent_state_root(),
        );
        if locks.get(&lock_key).map(String::as_str) != Some(proposal_context.proposal_hash()) {
            return Err(LedgerError::InvalidQuorum(
                "tag-28 vote construction requires this exact authenticated durable vote lock"
                    .into(),
            ));
        }
        Ok(proposal_context)
    }

    /// Converts legacy `height:root:round` vote locks to one lock per
    /// consensus instance. Conflicting legacy history is not repairable and
    /// therefore prevents startup.
    pub fn migrate_consensus_vote_locks(&mut self) -> Result<bool, LedgerError> {
        let normalized = self.normalized_consensus_vote_locks()?;
        if normalized == self.consensus_vote_locks {
            return Ok(false);
        }
        self.consensus_vote_locks = normalized;
        Ok(true)
    }

    fn normalized_consensus_vote_locks(&self) -> Result<BTreeMap<String, String>, LedgerError> {
        let mut normalized = BTreeMap::new();
        for (stored_key, proposal_hash) in &self.consensus_vote_locks {
            if proposal_hash.trim().is_empty() {
                return Err(LedgerError::InvalidQuorum(
                    "consensus vote lock contains an empty proposal commitment".into(),
                ));
            }
            let (parent_height, parent_state_root) = parse_consensus_vote_lock_key(stored_key)?;
            let instance_key = consensus_instance_lock_key(parent_height, &parent_state_root);
            if let Some(existing) = normalized.get(&instance_key) {
                if existing != proposal_hash {
                    return Err(LedgerError::InvalidQuorum(format!(
                        "conflicting durable vote locks exist for consensus instance {parent_height}:{parent_state_root}"
                    )));
                }
            } else {
                normalized.insert(instance_key, proposal_hash.clone());
            }
        }
        Ok(normalized)
    }

    fn consensus_proposal_hash(&self, proposal: &ConsensusProposal) -> Result<String, LedgerError> {
        if self.descriptor.testnet {
            Ok(proposal.proposal_hash())
        } else {
            proposal
                .wire_v1_proposal_hash(&self.descriptor.network_domain)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))
        }
    }

    /// Authenticates a new consensus commit against the exact current prestate
    /// and freezes every field omitted from the state root plus the only
    /// permitted successor for vote-lock and commit metadata. This capability
    /// has private fields and no deserializer.
    ///
    /// It does not execute the command. It exists for bounded recovery adapters
    /// whose state-rooted transition needs node-local evidence unavailable to
    /// the pure Ledger command dispatcher.
    pub fn authenticate_consensus_commit_for_external_execution(
        &self,
        commit: &ConsensusCommit,
    ) -> Result<AuthenticatedConsensusCommitMetadataV1, LedgerError> {
        self.ensure_m0_consensus_command_allowed(&commit.proposal.command)?;
        let legacy_commit_hash = commit.commit_hash();
        let commit_hash = if self.descriptor.testnet {
            legacy_commit_hash.clone()
        } else {
            commit
                .wire_v1_commit_hash(&self.descriptor.network_domain)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?
        };
        if self.consensus_commits.contains_key(&commit_hash)
            || (!self.descriptor.testnet
                && self
                    .consensus_commits
                    .get(&legacy_commit_hash)
                    .is_some_and(|existing| existing == commit))
        {
            return Err(LedgerError::InvalidQuorum(
                "external consensus execution requires a new commit at the exact prestate".into(),
            ));
        }
        if self.descriptor.testnet {
            commit
                .verify(&self.descriptor.validator_keys)
                .map_err(LedgerError::InvalidQuorum)?;
        } else {
            commit
                .verify_wire_v1(
                    &self.descriptor.validator_keys,
                    &self.descriptor.network_domain,
                )
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        }
        if matches!(
            commit.proposal.command,
            ConsensusCommand::CommitAdmissionCheckpoint(_)
        ) {
            self.validate_consensus_proposal_envelope(&commit.proposal)?;
        } else {
            self.validate_consensus_proposal(&commit.proposal)?;
        }
        let prior_unrooted_bytes = serde_json::to_vec(&(
            &self.era_certificates,
            &self.checkpoints,
            &self.consensus_vote_locks,
            &self.consensus_commits,
        ))
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        let mut successor_vote_locks = self.normalized_consensus_vote_locks()?;
        let lock_key = consensus_instance_lock_key(
            commit.proposal.parent_height,
            &commit.proposal.parent_state_root,
        );
        let proposal_hash = self.consensus_proposal_hash(&commit.proposal)?;
        if successor_vote_locks
            .get(&lock_key)
            .is_some_and(|existing| existing != &proposal_hash)
        {
            return Err(LedgerError::InvalidQuorum(
                "certified commit conflicts with this validator's durable vote lock".into(),
            ));
        }
        successor_vote_locks.remove(&lock_key);
        Ok(AuthenticatedConsensusCommitMetadataV1 {
            commit: commit.clone(),
            commit_hash,
            prior_unrooted_bytes,
            successor_vote_locks,
            expected_height: commit.proposal.expected_height,
            expected_state_root: commit.proposal.expected_state_root.clone(),
        })
    }

    /// Installs only the consensus metadata frozen by
    /// `authenticate_consensus_commit_for_external_execution` after the caller
    /// has produced the exact state-rooted successor. Any callback edit to the
    /// pre-existing unrooted bookkeeping is rejected atomically.
    pub fn finalize_externally_executed_consensus_commit(
        &mut self,
        authenticated: AuthenticatedConsensusCommitMetadataV1,
    ) -> Result<(), LedgerError> {
        if self.height != authenticated.expected_height
            || self.state_root()? != authenticated.expected_state_root
        {
            return Err(LedgerError::InvalidQuorum(
                "externally executed commit does not match its certified state successor".into(),
            ));
        }
        let current_unrooted_bytes = serde_json::to_vec(&(
            &self.era_certificates,
            &self.checkpoints,
            &self.consensus_vote_locks,
            &self.consensus_commits,
        ))
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        if current_unrooted_bytes != authenticated.prior_unrooted_bytes {
            return Err(LedgerError::InvalidQuorum(
                "external consensus execution changed protected unrooted Ledger bookkeeping".into(),
            ));
        }
        let mut staged = self.clone();
        staged.consensus_vote_locks = authenticated.successor_vote_locks;
        if staged
            .consensus_commits
            .insert(authenticated.commit_hash, authenticated.commit)
            .is_some()
        {
            return Err(LedgerError::InvalidQuorum(
                "external consensus execution conflicts with an existing commit".into(),
            ));
        }
        *self = staged;
        Ok(())
    }

    pub fn apply_consensus_commit(
        &mut self,
        commit: ConsensusCommit,
    ) -> Result<ConsensusOutcome, LedgerError> {
        // An authenticated exact retry reads a durable outcome; it does not
        // cross the next-height boundary of a pending upgrade.
        self.ensure_m0_consensus_command_profile_allowed(&commit.proposal.command)?;
        let legacy_commit_hash = commit.commit_hash();
        let commit_hash = if self.descriptor.testnet {
            legacy_commit_hash.clone()
        } else {
            commit
                .wire_v1_commit_hash(&self.descriptor.network_domain)
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?
        };
        // Mainnet may read an exact pre-migration record under its legacy key,
        // but new records and non-identical replays never fall back to legacy.
        let current_record_exists = self.consensus_commits.contains_key(&commit_hash);
        let existing = self.consensus_commits.get(&commit_hash).or_else(|| {
            (!self.descriptor.testnet)
                .then(|| self.consensus_commits.get(&legacy_commit_hash))
                .flatten()
                .filter(|existing| *existing == &commit)
        });
        if let Some(existing) = existing {
            if !self.descriptor.testnet && current_record_exists {
                commit
                    .verify_wire_v1(
                        &self.descriptor.validator_keys,
                        &self.descriptor.network_domain,
                    )
                    .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
            }
            return match &existing.proposal.command {
                ConsensusCommand::LocalPayment(intent) => self
                    .payments
                    .get(&intent.payment_id)
                    .cloned()
                    .map(ConsensusOutcome::LocalPayment)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no finalized payment".into(),
                        )
                    }),
                ConsensusCommand::ExportPayment { intent, .. } => self
                    .payments
                    .get(&intent.payment_id)
                    .and_then(|record| record.transit_id.as_ref())
                    .and_then(|transit_id| self.transits.get(transit_id))
                    .cloned()
                    .map(Box::new)
                    .map(ConsensusOutcome::ExportPayment)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no finalized export capsule".into(),
                        )
                    }),
                ConsensusCommand::ImportCapsule(capsule) => self
                    .import_receipts
                    .get(&capsule.transit_id)
                    .cloned()
                    .map(ConsensusOutcome::ImportCapsule)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no finalized import receipt".into(),
                        )
                    }),
                ConsensusCommand::FinalizeExport(receipt) => self
                    .payments
                    .get(&receipt.payment_id)
                    .cloned()
                    .map(ConsensusOutcome::FinalizeExport)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no finalized source payment".into(),
                        )
                    }),
                ConsensusCommand::SubmitValueRiskPolicyUpdate(_)
                | ConsensusCommand::ActivatePendingValueRiskPolicy => Ok(
                    ConsensusOutcome::ValueRiskPolicy(self.value_risk_policy.clone()),
                ),
                ConsensusCommand::SubmitStakeAuthorityUpdate(request) => self
                    .reconstruct_stake_authority_command_state(
                        request,
                        u128::from(existing.proposal.parent_height),
                        existing.proposal.parent_state_root.clone(),
                        u128::from(existing.proposal.expected_height),
                    )
                    .map(ConsensusOutcome::StakeAuthority),
                ConsensusCommand::DeriveNextStakeEpoch(request) => self
                    .derived_stake_epochs
                    .get(&request.expected_consensus_epoch)
                    .cloned()
                    .map(ConsensusOutcome::DerivedStakeEpoch)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no derived stake Epoch".into(),
                        )
                    }),
                ConsensusCommand::LockConsensusStake(request) => {
                    let exact_position = |position: &&ConsensusStakePosition| {
                        let expected_kind = match request.position_type {
                            StakePositionTypeV1::SelfBond => ConsensusStakePositionKind::SelfBond {
                                validator_id: request.validator_id.clone(),
                            },
                            StakePositionTypeV1::Delegation => {
                                ConsensusStakePositionKind::Delegation {
                                    validator_id: request.validator_id.clone(),
                                }
                            }
                        };
                        position.position_id == request.position_id
                            && position.owner == request.owner
                            && position.kind == expected_kind
                            && position.source_coin_id == request.source_coin_id
                            && position.amount == request.amount
                            && position.committed_through_height
                                == u128::from(request.committed_through_height)
                            && position.slash_terms.is_none()
                    };
                    self.consensus_stake_escrows
                        .values()
                        .find(|position| exact_position(position))
                        .or_else(|| {
                            self.consensus_stake_unbonds
                                .values()
                                .map(|record| &record.position)
                                .find(|position| exact_position(position))
                        })
                        .cloned()
                        .map(ConsensusOutcome::ConsensusStake)
                        .ok_or_else(|| {
                            LedgerError::InvalidQuorum(
                                "recorded commit has no exact consensus stake position or permanent unbond tombstone".into(),
                            )
                        })
                }
                ConsensusCommand::LockConsensusStakeV2(request) => {
                    let exact_position = |position: &&ConsensusStakePosition| {
                        let expected_kind = match request.position_type {
                            StakePositionTypeV1::SelfBond => ConsensusStakePositionKind::SelfBond {
                                validator_id: request.validator_id.clone(),
                            },
                            StakePositionTypeV1::Delegation => {
                                ConsensusStakePositionKind::Delegation {
                                    validator_id: request.validator_id.clone(),
                                }
                            }
                        };
                        let slash_policy = ConsensusStakeSlashPolicyV2::protocol_v2();
                        let expected_terms = ConsensusStakeSlashTermsV2 {
                            terms_version: slash_policy.policy_version,
                            slash_policy,
                            owner_authorization: request.slash_terms_authorization.clone(),
                        };
                        position.position_id == request.position_id
                            && position.owner == request.owner
                            && position.kind == expected_kind
                            && position.source_coin_id == request.source_coin_id
                            && position.amount == request.amount
                            && position.committed_through_height
                                == u128::from(request.committed_through_height)
                            && position.slash_terms.as_ref() == Some(&expected_terms)
                    };
                    self.consensus_stake_escrows
                        .values()
                        .find(|position| exact_position(position))
                        .or_else(|| {
                            self.consensus_stake_unbonds
                                .values()
                                .map(|record| &record.position)
                                .find(|position| exact_position(position))
                        })
                        .cloned()
                        .map(ConsensusOutcome::ConsensusStake)
                        .ok_or_else(|| {
                            LedgerError::InvalidQuorum(
                                "recorded commit has no exact slashable consensus stake position or permanent unbond tombstone".into(),
                            )
                        })
                }
                ConsensusCommand::MigrateConsensusStakeSlashTerms(request) => {
                    let slash_policy = ConsensusStakeSlashPolicyV2::protocol_v2();
                    let expected_terms = ConsensusStakeSlashTermsV2 {
                        terms_version: slash_policy.policy_version,
                        slash_policy,
                        owner_authorization: request.slash_terms_authorization.clone(),
                    };
                    let exact_position = |position: &&ConsensusStakePosition| {
                        position.position_id == request.position_id
                            && position.escrow_coin_id == request.escrow_coin_id
                            && position.owner == request.owner
                            && position.slash_terms.as_ref() == Some(&expected_terms)
                    };
                    self.consensus_stake_escrows
                        .values()
                        .find(|position| exact_position(position))
                        .or_else(|| {
                            self.consensus_stake_unbonds
                                .values()
                                .map(|record| &record.position)
                                .find(|position| exact_position(position))
                        })
                        .cloned()
                        .map(ConsensusOutcome::ConsensusStake)
                        .ok_or_else(|| {
                            LedgerError::InvalidQuorum(
                                "recorded commit has no exact migrated slash-terms position or permanent unbond tombstone".into(),
                            )
                        })
                }
                ConsensusCommand::SlashConsensusStake(request) => self
                    .consensus_stake_slashes
                    .get(&request.slash_id)
                    .filter(|record| {
                        record.evidence_hash == request.evidence_hash
                            && record.consensus_epoch == request.consensus_epoch
                            && record.derived_epoch_record_hash == request.derived_epoch_record_hash
                            && record.liability_commitment == request.liability_commitment
                            && record.position.position_id == request.position_id
                            && record.position.escrow_coin_id == request.escrow_coin_id
                            && record.position.amount == request.expected_position_amount
                            && record.unbond_request_commitment
                                == request.expected_unbond_request_commitment
                    })
                    .cloned()
                    .map(Box::new)
                    .map(ConsensusOutcome::ConsensusStakeSlash)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no exact consensus stake slash record".into(),
                        )
                    }),
                ConsensusCommand::RegisterConsensusValidator(request) => {
                    Ok(ConsensusOutcome::StakeCandidate(ValidatorCandidateRecord {
                        validator_id: request.validator_id.clone(),
                        owner: request.owner.clone(),
                        public_key: request.public_key.clone(),
                        key_era: request.key_era,
                        registered_height: u128::from(existing.proposal.expected_height),
                        exit_height: None,
                        proof_of_possession: request.proof_of_possession.clone(),
                    }))
                }
                ConsensusCommand::RegisterConsensusValidatorV2(request) => self
                    .replay_consensus_validator_registration_v2(
                        request,
                        existing.proposal.expected_height,
                    )
                    .map(Box::new)
                    .map(ConsensusOutcome::StakeCandidateResourceRegistration),
                ConsensusCommand::LockConsensusStakeV3(request) => self
                    .replay_consensus_stake_lock_v3(request, existing.proposal.expected_height)
                    .map(Box::new)
                    .map(ConsensusOutcome::ConsensusStakeResourceLock),
                ConsensusCommand::MigrateConsensusStakeResource(request) => self
                    .replay_consensus_stake_resource_migration(
                        request,
                        existing.proposal.expected_height,
                    )
                    .map(Box::new)
                    .map(ConsensusOutcome::ConsensusStakeResourceMigration),
                ConsensusCommand::MigrateConsensusCandidateResource(request) => self
                    .replay_consensus_candidate_resource_migration(
                        request,
                        existing.proposal.expected_height,
                    )
                    .map(Box::new)
                    .map(ConsensusOutcome::ConsensusCandidateResourceMigration),
                ConsensusCommand::DeriveNextStakeEpochV2(request) => self
                    .replay_next_stake_epoch_v2(request, existing.proposal.expected_height)
                    .map(Box::new)
                    .map(ConsensusOutcome::DerivedStakeEpochResource),
                ConsensusCommand::RenewStakeStateResourceBond(request) => self
                    .replay_stake_state_resource_bond_renewal(request)
                    .map(Box::new)
                    .map(ConsensusOutcome::StakeStateResourceBondRenewal),
                ConsensusCommand::ExitConsensusValidator(request) => {
                    Ok(ConsensusOutcome::StakeCandidate(ValidatorCandidateRecord {
                        validator_id: request.validator_id.clone(),
                        owner: request.owner.clone(),
                        public_key: request.public_key.clone(),
                        key_era: request.key_era,
                        registered_height: u128::from(request.registered_height),
                        exit_height: Some(u128::from(request.exit_height)),
                        proof_of_possession: request.proof_of_possession.clone(),
                    }))
                }
                ConsensusCommand::RequestConsensusStakeUnbond(request) => {
                    let current = self
                        .consensus_stake_unbonds
                        .get(&request.request_id)
                        .filter(|record| {
                            record.position.position_id == request.position_id
                                && record.position.escrow_coin_id == request.escrow_coin_id
                                && record.owner == request.owner
                                && record.beneficiary == request.beneficiary
                                && record.withdraw_after_height
                                    == request.requested_withdraw_after_height
                        })
                        .ok_or_else(|| {
                            LedgerError::InvalidQuorum(
                                "recorded commit has no exact stake unbond request".into(),
                            )
                        })?;
                    let mut historical = current.clone();
                    historical.requested_height = existing.proposal.expected_height;
                    historical.status = ConsensusStakeUnbondStatusV1::Pending;
                    historical.completion_id = None;
                    historical.completed_height = None;
                    historical.payout_coin_id = None;
                    historical.slash_id = None;
                    historical.slashed_amount = Amount::ZERO;
                    historical.request_commitment = historical.compute_request_commitment();
                    Ok(ConsensusOutcome::ConsensusStakeUnbond(historical))
                }
                ConsensusCommand::CompleteConsensusStakeUnbond(request) => self
                    .consensus_stake_unbonds
                    .get(&request.request_id)
                    .filter(|record| {
                        record.status == ConsensusStakeUnbondStatusV1::Completed
                            && record.completion_id.as_deref()
                                == Some(request.completion_id.as_str())
                            && record.request_commitment
                                == request.expected_unbond_request_commitment
                            && record.beneficiary == request.beneficiary
                    })
                    .cloned()
                    .map(ConsensusOutcome::ConsensusStakeUnbond)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no exact completed stake unbond".into(),
                        )
                    }),
                ConsensusCommand::ProposeStakeStateResourcePolicy(request) => self
                    .stake_resource_policy_proposals
                    .get(&request.proposal_id)
                    .filter(|record| *record == request.as_ref())
                    .cloned()
                    .map(Box::new)
                    .map(ConsensusOutcome::StakeStateResourcePolicyProposal)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no exact resource-policy proposal".into(),
                        )
                    }),
                ConsensusCommand::ActivateStakeStateResourcePolicy(request) => self
                    .stake_resource_policy_activations
                    .get(&request.activation_id)
                    .filter(|record| *record == request.as_ref())
                    .and_then(|record| {
                        self.stake_resource_policy_proposals
                            .get(&record.proposal_id)
                    })
                    .map(|proposal| proposal.proposed_policy.clone())
                    .map(ConsensusOutcome::StakeStateResourcePolicy)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded commit has no exact resource-policy activation".into(),
                        )
                    }),
                ConsensusCommand::ScheduleUpgrade(schedule) => {
                    Ok(ConsensusOutcome::UpgradeScheduled(
                        crate::genesis::upgrade_pending::PendingUpgradeV1 {
                            format_version: "RLD-PENDING-UPGRADE-V1".into(),
                            scheduled_height: u128::from(existing.proposal.expected_height),
                            scheduled_parent_root: AdmissionHash32::from_hex(
                                &existing.proposal.parent_state_root,
                            )
                            .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?,
                            schedule: schedule.as_ref().clone(),
                        },
                    ))
                }
                ConsensusCommand::ActivateUpgrade(activation) => self
                    .m0_active_protocol
                    .as_ref()
                    .filter(|active| {
                        active.upgrade_sequence == activation.sequence
                            && active.last_activated_upgrade.as_deref()
                                == Some(activation.intent_id.to_hex().as_str())
                    })
                    .cloned()
                    .map(ConsensusOutcome::UpgradeActivated)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum(
                            "recorded activation has no exact active successor".into(),
                        )
                    }),
                ConsensusCommand::NetworkHeartbeat(heartbeat) => {
                    Ok(ConsensusOutcome::NetworkHeartbeat(heartbeat.clone()))
                }
                ConsensusCommand::CommitAdmissionCheckpoint(proof) => proof
                    .proof_id()
                    .map(ConsensusOutcome::AdmissionCheckpoint)
                    .map_err(|error| LedgerError::InvalidQuorum(error.to_string())),
                ConsensusCommand::Production(command) => self
                    .replay_production_command(command)
                    .map(ConsensusOutcome::Production),
            };
        }
        self.ensure_consensus_upgrade_boundary(&commit.proposal.command)?;
        if self.descriptor.testnet {
            commit
                .verify(&self.descriptor.validator_keys)
                .map_err(LedgerError::InvalidQuorum)?;
        } else {
            commit
                .verify_wire_v1(
                    &self.descriptor.validator_keys,
                    &self.descriptor.network_domain,
                )
                .map_err(|error| LedgerError::InvalidQuorum(error.to_string()))?;
        }
        self.validate_consensus_proposal(&commit.proposal)?;
        let mut locks = self.normalized_consensus_vote_locks()?;
        let lock_key = consensus_instance_lock_key(
            commit.proposal.parent_height,
            &commit.proposal.parent_state_root,
        );
        let proposal_hash = self.consensus_proposal_hash(&commit.proposal)?;
        if locks
            .get(&lock_key)
            .is_some_and(|existing| existing != &proposal_hash)
        {
            return Err(LedgerError::InvalidQuorum(
                "certified commit conflicts with this validator's durable vote lock".into(),
            ));
        }
        // Execute and compare the certified post-state on a clone so any
        // command failure or expected-root mismatch is failure-atomic for the
        // live ledger, including across future command variants.
        let mut staged = self.clone();
        let record = staged.execute_consensus_command(commit.proposal.command.clone())?;
        if staged.height != commit.proposal.expected_height
            || staged.state_root()? != commit.proposal.expected_state_root
        {
            return Err(LedgerError::InvalidQuorum(
                "committed execution diverged from the certified state root".into(),
            ));
        }
        locks.remove(&lock_key);
        staged.consensus_vote_locks = locks;
        staged.consensus_commits.insert(commit_hash, commit);
        *self = staged;
        Ok(record)
    }

    pub fn execute_consensus_command(
        &mut self,
        command: ConsensusCommand,
    ) -> Result<ConsensusOutcome, LedgerError> {
        self.ensure_m0_consensus_command_allowed(&command)?;
        match command {
            ConsensusCommand::LocalPayment(intent) => self
                .local_payment(intent)
                .map(ConsensusOutcome::LocalPayment),
            ConsensusCommand::ExportPayment { intent, transport } => self
                .export_payment(intent, transport)
                .map(Box::new)
                .map(ConsensusOutcome::ExportPayment),
            ConsensusCommand::ImportCapsule(capsule) => self
                .import_capsule(*capsule)
                .map(ConsensusOutcome::ImportCapsule),
            ConsensusCommand::FinalizeExport(receipt) => self
                .finalize_export(&receipt)
                .map(ConsensusOutcome::FinalizeExport),
            ConsensusCommand::SubmitValueRiskPolicyUpdate(update) => self
                .submit_value_risk_policy_update(*update)
                .map(ConsensusOutcome::ValueRiskPolicy),
            ConsensusCommand::ActivatePendingValueRiskPolicy => self
                .activate_pending_value_risk_policy()
                .map(ConsensusOutcome::ValueRiskPolicy),
            ConsensusCommand::SubmitStakeAuthorityUpdate(update) => self
                .submit_stake_authority_update(*update)
                .map(ConsensusOutcome::StakeAuthority),
            ConsensusCommand::DeriveNextStakeEpoch(request) => self
                .derive_next_stake_epoch(*request)
                .map(ConsensusOutcome::DerivedStakeEpoch),
            ConsensusCommand::LockConsensusStake(request) => self
                .lock_consensus_stake(*request)
                .map(ConsensusOutcome::ConsensusStake),
            ConsensusCommand::RegisterConsensusValidator(request) => self
                .register_consensus_validator(*request)
                .map(ConsensusOutcome::StakeCandidate),
            ConsensusCommand::RegisterConsensusValidatorV2(request) => self
                .register_consensus_validator_v2(*request)
                .map(Box::new)
                .map(ConsensusOutcome::StakeCandidateResourceRegistration),
            ConsensusCommand::ExitConsensusValidator(request) => self
                .exit_consensus_validator(*request)
                .map(ConsensusOutcome::StakeCandidate),
            ConsensusCommand::RequestConsensusStakeUnbond(request) => self
                .request_consensus_stake_unbond(*request)
                .map(ConsensusOutcome::ConsensusStakeUnbond),
            ConsensusCommand::CompleteConsensusStakeUnbond(request) => self
                .complete_consensus_stake_unbond(*request)
                .map(ConsensusOutcome::ConsensusStakeUnbond),
            ConsensusCommand::LockConsensusStakeV2(request) => self
                .lock_consensus_stake_v2(*request)
                .map(ConsensusOutcome::ConsensusStake),
            ConsensusCommand::MigrateConsensusStakeSlashTerms(request) => self
                .migrate_consensus_stake_slash_terms(*request)
                .map(ConsensusOutcome::ConsensusStake),
            ConsensusCommand::SlashConsensusStake(request) => self
                .slash_consensus_stake(*request)
                .map(Box::new)
                .map(ConsensusOutcome::ConsensusStakeSlash),
            ConsensusCommand::ProposeStakeStateResourcePolicy(request) => self
                .propose_stake_state_resource_policy(*request)
                .map(Box::new)
                .map(ConsensusOutcome::StakeStateResourcePolicyProposal),
            ConsensusCommand::ActivateStakeStateResourcePolicy(request) => self
                .activate_stake_state_resource_policy(*request)
                .map(ConsensusOutcome::StakeStateResourcePolicy),
            ConsensusCommand::LockConsensusStakeV3(request) => self
                .lock_consensus_stake_v3(*request)
                .map(Box::new)
                .map(ConsensusOutcome::ConsensusStakeResourceLock),
            ConsensusCommand::MigrateConsensusStakeResource(request) => self
                .migrate_consensus_stake_resource(*request)
                .map(Box::new)
                .map(ConsensusOutcome::ConsensusStakeResourceMigration),
            ConsensusCommand::MigrateConsensusCandidateResource(request) => self
                .migrate_consensus_candidate_resource(*request)
                .map(Box::new)
                .map(ConsensusOutcome::ConsensusCandidateResourceMigration),
            ConsensusCommand::DeriveNextStakeEpochV2(request) => self
                .derive_next_stake_epoch_v2(*request)
                .map(Box::new)
                .map(ConsensusOutcome::DerivedStakeEpochResource),
            ConsensusCommand::RenewStakeStateResourceBond(request) => self
                .renew_stake_state_resource_bond(*request)
                .map(Box::new)
                .map(ConsensusOutcome::StakeStateResourceBondRenewal),
            ConsensusCommand::ScheduleUpgrade(schedule) => {
                crate::genesis::upgrade_migration::validate_first_schedule_artifacts(&schedule).map_err(LedgerError::Invalid)?;
                let next = self.preview_upgrade_schedule(&schedule)?;
                let outcome = next.m0_pending_upgrade.clone().ok_or_else(|| LedgerError::Invalid("missing schedule successor".into()))?;
                *self = next;
                Ok(ConsensusOutcome::UpgradeScheduled(outcome))
            }
            ConsensusCommand::ActivateUpgrade(activation) => {
                let next = self.preview_supported_upgrade_activation(&activation).map_err(LedgerError::Invalid)?;
                let outcome = next.m0_active_protocol.clone().ok_or_else(|| LedgerError::Invalid("missing activation successor".into()))?;
                *self = next;
                Ok(ConsensusOutcome::UpgradeActivated(outcome))
            }
            ConsensusCommand::NetworkHeartbeat(heartbeat) => self
                .network_heartbeat(heartbeat)
                .map(ConsensusOutcome::NetworkHeartbeat),
            ConsensusCommand::CommitAdmissionCheckpoint(_) => Err(LedgerError::Invalid(
                "tag-28 admission checkpoint requires authenticated node-local history; pure Ledger dispatch is fail-closed"
                    .into(),
            )),
            ConsensusCommand::Production(command) => self
                .execute_production_command(*command)
                .map(ConsensusOutcome::Production),
        }
    }

    pub fn execute_production_command(
        &mut self,
        command: ProductionCommand,
    ) -> Result<serde_json::Value, LedgerError> {
        fn output<T: Serialize>(value: T) -> Result<serde_json::Value, LedgerError> {
            serde_json::to_value(value).map_err(|error| LedgerError::Invalid(error.to_string()))
        }

        match command {
            ProductionCommand::ZoneAdvertisement(advertisement) => {
                output(self.register_zone_advertisement(advertisement)?)
            }
            ProductionCommand::RouteQuoteCreate(request) => {
                output(self.create_route_quote(request)?)
            }
            ProductionCommand::RouteQuoteReroute { quote_id, request } => {
                output(self.reroute_route_quote(&quote_id, request)?)
            }
            ProductionCommand::PaymentRequest(request) => {
                output(self.register_payment_request(request)?)
            }
            ProductionCommand::RecipientReceipt(receipt) => {
                output(self.accept_recipient_receipt(receipt)?)
            }
            ProductionCommand::GatewayBond(request) => output(self.create_gateway_bond(request)?),
            ProductionCommand::RejectionCreate { capsule, reason } => {
                output(self.create_destination_rejection(*capsule, reason)?)
            }
            ProductionCommand::RejectionCertify {
                transit_id,
                validator_qc,
                notary_qc,
            } => {
                output(self.certify_destination_rejection(&transit_id, validator_qc, notary_qc)?)
            }
            ProductionCommand::ReturnBegin(proof) => {
                output(self.begin_return_from_rejection(proof)?)
            }
            ProductionCommand::ReturnFinalize(transit_id) => {
                output(self.finalize_return(&transit_id)?)
            }
            ProductionCommand::TransitCertify {
                transit_id,
                validator_qc,
                notary_qc,
            } => output(self.certify_transit(&transit_id, validator_qc, notary_qc)?),
            ProductionCommand::TravelerCreate { intent, transport } => {
                output(self.create_traveler_capsule(intent, transport)?)
            }
            ProductionCommand::TravelerImport(capsule) => {
                output(self.import_traveler_capsule(*capsule)?)
            }
            ProductionCommand::DscIssue(request) => {
                output(self.issue_spendability_certificate(request)?)
            }
            ProductionCommand::LiquidityOfferCreate(request) => {
                output(self.create_liquidity_offer(request)?)
            }
            ProductionCommand::LiquidityOfferTake(request) => {
                output(self.take_liquidity_offer(*request)?)
            }
            ProductionCommand::ProtocolServiceOrder(request) => {
                output(self.create_protocol_service_order(request)?)
            }
            ProductionCommand::ServiceOrder {
                buyer,
                coin_id,
                role,
                budget,
                description,
                authorization,
            } => output(self.create_service_order(
                buyer,
                coin_id,
                role,
                budget,
                description,
                authorization,
            )?),
            ProductionCommand::ServiceLease {
                order_id,
                node_id,
                accepted_quote,
                authorization,
            } => output(self.lease_service(&order_id, node_id, accepted_quote, authorization)?),
            ProductionCommand::ServiceComplete {
                lease_id,
                proof_hash,
                authorization,
                validator_qc,
                notary_qc,
            } => match (validator_qc, notary_qc) {
                (Some(validator_qc), Some(notary_qc)) => output(self.complete_protocol_service(
                    &lease_id,
                    proof_hash,
                    authorization,
                    validator_qc,
                    notary_qc,
                )?),
                (None, None) => {
                    output(self.complete_service(&lease_id, proof_hash, authorization)?)
                }
                _ => Err(LedgerError::Invalid(
                    "protocol completion requires both validator and notary QCs".into(),
                )),
            },
            ProductionCommand::EconomicControlAttestation(attestation) => {
                output(self.register_economic_control_attestation(attestation)?)
            }
            ProductionCommand::EconomicPriceAttestation(attestation) => {
                output(self.register_economic_price_attestation(attestation)?)
            }
            ProductionCommand::EconomicReleasePolicy(policy) => {
                output(self.set_economic_release_policy(policy)?)
            }
            ProductionCommand::ProtocolServiceBondLock(request) => {
                output(self.lock_protocol_service_bond(request)?)
            }
            ProductionCommand::ProtocolServiceBondSlash(slash) => {
                output(self.slash_protocol_service_bond(slash)?)
            }
            ProductionCommand::ProtocolServiceBondUnbond {
                bond_id,
                authorization,
            } => output(self.unbond_protocol_service_bond(&bond_id, authorization)?),
            ProductionCommand::ProtocolReserveRelease(request) => {
                output(self.release_protocol_reserve(*request)?)
            }
            ProductionCommand::VoyageOpen {
                payer,
                coin_id,
                transit_id,
                budget,
                max_reward_per_hop,
                authorization,
            } => output(self.open_voyage_escrow(
                payer,
                coin_id,
                transit_id,
                budget,
                max_reward_per_hop,
                authorization,
            )?),
            ProductionCommand::VoyageSettle {
                escrow_id,
                node_id,
                amount,
                downstream_receipt_hash,
                authorization,
            } => output(self.settle_voyage_hop(
                &escrow_id,
                node_id,
                amount,
                downstream_receipt_hash,
                authorization,
            )?),
            ProductionCommand::EraTransition(certificate) => {
                output(self.apply_era_transition(*certificate)?)
            }
        }
    }

    fn replay_production_command(
        &self,
        command: &ProductionCommand,
    ) -> Result<serde_json::Value, LedgerError> {
        fn output<T: Serialize>(value: T) -> Result<serde_json::Value, LedgerError> {
            serde_json::to_value(value).map_err(|error| LedgerError::Invalid(error.to_string()))
        }

        match command {
            ProductionCommand::EconomicControlAttestation(attestation) => self
                .economic_control_attestations
                .get(&attestation.attestation_id)
                .cloned()
                .ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "recorded commit has no economic control attestation".into(),
                    )
                })
                .and_then(output),
            ProductionCommand::EconomicPriceAttestation(attestation) => self
                .economic_price_attestations
                .get(&attestation.attestation_id)
                .cloned()
                .ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "recorded commit has no economic price attestation".into(),
                    )
                })
                .and_then(output),
            ProductionCommand::EconomicReleasePolicy(policy) => self
                .economic_release_policies
                .get(&policy.policy_id)
                .cloned()
                .ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "recorded commit has no economic release policy".into(),
                    )
                })
                .and_then(output),
            ProductionCommand::ProtocolServiceBondLock(request) => self
                .protocol_service_bonds
                .get(&request.bond_id)
                .cloned()
                .ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "recorded commit has no protocol service bond".into(),
                    )
                })
                .and_then(output),
            ProductionCommand::ProtocolServiceBondSlash(slash) => self
                .protocol_service_bonds
                .get(&slash.bond_id)
                .cloned()
                .ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "recorded commit has no slashed protocol service bond".into(),
                    )
                })
                .and_then(output),
            ProductionCommand::ProtocolServiceBondUnbond { bond_id, .. } => self
                .protocol_service_bonds
                .get(bond_id)
                .cloned()
                .ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "recorded commit has no unbonded protocol service bond".into(),
                    )
                })
                .and_then(output),
            ProductionCommand::ProtocolReserveRelease(request) => self
                .protocol_reserve_releases
                .get(&request.release_id)
                .cloned()
                .ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "recorded commit has no protocol reserve release".into(),
                    )
                })
                .and_then(output),
            _ => Ok(serde_json::Value::Null),
        }
    }

    pub fn export_payment(
        &mut self,
        intent: UniversalPaymentIntent,
        transport: TransportClass,
    ) -> Result<TransitCapsule, LedgerError> {
        self.validate_intent(&intent, false)?;
        if transport == TransportClass::ChronologyUnsafe {
            return Err(LedgerError::CausalQuarantine(
                "chronology-unsafe route".into(),
            ));
        }
        let next_cross_zone_exposure =
            self.next_value_risk_total(ValueRiskPath::CrossZone, intent.amount)?;
        if !self.descriptor.testnet {
            return Err(LedgerError::InvalidQuorum(
                "reference node requires external BFT QC integration outside testnet".into(),
            ));
        }
        if self.payments.contains_key(&intent.payment_id) {
            return Err(LedgerError::Duplicate(intent.payment_id));
        }
        let route_quote = if let Some(quote_id) = &intent.route_quote_id {
            let quote = self
                .route_quotes
                .get(quote_id)
                .cloned()
                .ok_or_else(|| LedgerError::RouteQuoteNotFound(quote_id.clone()))?;
            if quote.status != RouteQuoteStatus::Open
                || quote.source_zone != self.descriptor.zone_id
                || quote.destination_zone != intent.destination_zone
                || quote.transport != transport
                || quote.expires_at_height <= self.height
            {
                return Err(LedgerError::Invalid(
                    "route quote is not valid for this payment".into(),
                ));
            }
            let authorized_total = quote
                .base_fee
                .checked_add(quote.authorized_reroute_budget)?;
            if authorized_total > intent.max_fee {
                return Err(LedgerError::Invalid(
                    "payment max fee is below the locked route quote".into(),
                ));
            }
            Some(quote)
        } else {
            None
        };
        let validator_qc = outbound_qc(&self.descriptor.validator_keys)?;
        let notary_qc = outbound_qc(&self.descriptor.notary_keys)?;
        let input = self.spendable_owned_coin(&intent.coin_id, &intent.sender_public_key)?;
        let route_fee = route_quote
            .as_ref()
            .map(|quote| quote.base_fee.checked_add(quote.consumed_reroute_fee))
            .transpose()?
            .unwrap_or(Amount::ZERO);
        let required_input = intent.amount.checked_add(route_fee)?;
        if intent.amount.is_zero() || required_input > input.amount {
            return Err(LedgerError::Invalid("invalid export amount".into()));
        }
        let change = input.amount.checked_sub(required_input)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 2 + u64::from(!route_fee.is_zero()) + u64::from(!change.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;

        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let transit_id = self.next_id("transit")?;
        let transit_coin = self.make_coin(
            intent.recipient.clone(),
            intent.amount,
            CoinState::InTransit,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            Some(transit_id.clone()),
            None,
            next_version,
        )?;
        let transit_coin_id = transit_coin.object_id.clone();
        self.coins
            .insert(transit_coin.object_id.clone(), transit_coin.clone());
        self.transit_coin_ids
            .insert(transit_id.clone(), transit_coin_id.clone());

        let mut outputs = vec![transit_coin_id.clone()];
        if let Some(quote) = &route_quote {
            if !route_fee.is_zero() {
                let fee_coin = self.make_coin(
                    quote.provider.clone(),
                    route_fee,
                    CoinState::Spendable,
                    vec![input.object_id.clone()],
                    Some(input.lineage_root.clone()),
                    None,
                    input.imported_from.clone(),
                    next_version,
                )?;
                outputs.push(fee_coin.object_id.clone());
                self.coins.insert(fee_coin.object_id.clone(), fee_coin);
            }
        }
        if !change.is_zero() {
            let change_coin = self.make_coin(
                input.owner,
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                None,
                next_version,
            )?;
            outputs.push(change_coin.object_id.clone());
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }

        let checkpoint = self.create_checkpoint()?;
        let object_hash = hash_bytes(
            &serde_json::to_vec(&transit_coin)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?,
        );
        let supply_certificate_hash = hash_bytes(
            &serde_json::to_vec(&checkpoint.supply)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?,
        );
        let era_certificate = self.era_certificates.last().cloned();
        let era_certificate_hash = era_certificate
            .as_ref()
            .map(|certificate| certificate.certificate_hash.clone())
            .unwrap_or_else(|| {
                hash_parts(&[
                    b"RLD-GENESIS-ERA",
                    self.descriptor.zone_id.as_bytes(),
                    &self.descriptor.protocol_era.to_be_bytes(),
                    &self.descriptor.crypto_era.to_be_bytes(),
                ])
            });
        let continuity_accumulator = hash_parts(&[
            b"RLD-CONTINUITY-V1",
            transit_coin.origin_genesis_root.as_bytes(),
            self.era_continuity_accumulator.as_bytes(),
        ]);
        let transit_nullifier_commitment = hash_parts(&[
            b"RLD-TRANSIT-NULLIFIER-V1",
            self.descriptor.zone_id.as_bytes(),
            transit_id.as_bytes(),
        ]);
        let operational_proof = OperationalProof {
            checkpoint_hash: checkpoint.checkpoint_hash.clone(),
            object_hash,
            continuity_accumulator,
            lineage_merkle_path: transit_coin
                .parent_ids
                .iter()
                .map(|parent| hash_bytes(parent.as_bytes()))
                .collect(),
            transition_hashes: vec![hash_bytes(&intent.signing_bytes())],
            protocol_era: self.descriptor.protocol_era,
            crypto_era: self.descriptor.crypto_era,
            era_certificate_hash,
            supply_certificate_hash,
            transit_nullifier_commitment,
        };
        operational_proof
            .validate_bounds()
            .map_err(LedgerError::InvalidOperationalProof)?;
        let mut capsule = TransitCapsule {
            transit_id: transit_id.clone(),
            payment_id: intent.payment_id.clone(),
            payment_request_id: intent.payment_request_id.clone(),
            payment_request: intent.payment_request.clone(),
            route_quote_id: intent.route_quote_id.clone(),
            source_zone: self.descriptor.zone_id.clone(),
            destination_zone: intent.destination_zone.clone(),
            source_descriptor: self.descriptor.clone(),
            recipient: intent.recipient.clone(),
            amount: intent.amount,
            lineage_root: transit_coin.lineage_root.clone(),
            source_object_id: transit_coin_id,
            source_object_version: transit_coin.version,
            source_object: transit_coin.clone(),
            source_supply: checkpoint.supply.clone(),
            origin_genesis_root: transit_coin.origin_genesis_root.clone(),
            source_checkpoint: checkpoint.checkpoint_hash.clone(),
            validator_qc,
            notary_qc,
            operational_proof,
            era_certificate,
            gateway_endorsement: None,
            transport,
        };
        let subject_hash = capsule.subject_hash();
        capsule.validator_qc.subject_hash.clone_from(&subject_hash);
        capsule.notary_qc.subject_hash = subject_hash;
        self.consume_payment_request(&intent)?;
        if let Some(quote) = route_quote {
            let stored = self
                .route_quotes
                .get_mut(&quote.quote_id)
                .expect("route quote was checked");
            stored.status = RouteQuoteStatus::Locked;
            stored.locked_payment_id = Some(intent.payment_id.clone());
        }
        self.transits.insert(transit_id.clone(), capsule.clone());
        self.payments.insert(
            intent.payment_id.clone(),
            PaymentRecord {
                intent,
                status: PaymentStatus::InTransit,
                output_coin_ids: outputs,
                transit_id: Some(transit_id),
                updated_height: self.height,
                charged_fee: route_fee,
                fee_resources: ResourceVector::default(),
                pricing_epoch: 0,
            },
        );
        self.record_value_risk_total(ValueRiskPath::CrossZone, next_cross_zone_exposure);
        self.assert_conservation()?;
        Ok(capsule)
    }

    pub fn certify_transit(
        &mut self,
        transit_id: &str,
        validator_qc: QuorumCertificate,
        notary_qc: QuorumCertificate,
    ) -> Result<TransitCapsule, LedgerError> {
        let mut capsule = self
            .transits
            .get(transit_id)
            .cloned()
            .ok_or_else(|| LedgerError::TransitNotFound(transit_id.into()))?;
        let subject = capsule.subject_hash();
        if validator_qc.subject_hash != subject || notary_qc.subject_hash != subject {
            return Err(LedgerError::InvalidQuorum("subject hash mismatch".into()));
        }
        validator_qc
            .verify(&self.descriptor.validator_keys)
            .map_err(LedgerError::InvalidQuorum)?;
        notary_qc
            .verify(&self.descriptor.notary_keys)
            .map_err(LedgerError::InvalidQuorum)?;

        capsule.validator_qc = validator_qc;
        capsule.notary_qc = notary_qc;
        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        if let Some(record) = self
            .payments
            .values_mut()
            .find(|record| record.transit_id.as_deref() == Some(transit_id))
        {
            record.updated_height = self.height;
        }
        self.transits.insert(transit_id.into(), capsule.clone());
        Ok(capsule)
    }

    pub fn create_destination_rejection(
        &mut self,
        capsule: TransitCapsule,
        reason: DestinationRejectionReason,
    ) -> Result<DestinationRejectionProof, LedgerError> {
        if capsule.destination_zone != self.descriptor.zone_id {
            return Err(LedgerError::Invalid("capsule destination mismatch".into()));
        }
        if self.transit_nullifiers.contains(&capsule.transit_id)
            || self
                .rejected_transit_nullifiers
                .contains(&capsule.transit_id)
            || self
                .spendability_certificates
                .contains_key(&capsule.payment_id)
        {
            return Err(LedgerError::Invalid(
                "an imported, rejected or liquidity-settled transit cannot be rejected".into(),
            ));
        }

        // Validate exactly the same capsule acceptance path on an isolated state copy.
        // The real destination commits only the rejection nullifier, never an imported coin.
        let mut verifier = self.clone();
        verifier.import_capsule(capsule.clone())?;

        self.ensure_counter_headroom(1, 1)?;
        self.advance()?;
        let checkpoint = self.create_checkpoint()?;
        let validator_qc = outbound_qc(&self.descriptor.validator_keys)?;
        let notary_qc = outbound_qc(&self.descriptor.notary_keys)?;
        let mut proof = DestinationRejectionProof {
            rejection_id: self.next_id("destination-rejection")?,
            transit_id: capsule.transit_id,
            payment_id: capsule.payment_id,
            source_zone: capsule.source_zone,
            destination_zone: self.descriptor.zone_id.clone(),
            source_object_id: capsule.source_object_id,
            source_object_version: capsule.source_object_version,
            recipient: capsule.recipient,
            amount: capsule.amount,
            reason,
            destination_descriptor: self.descriptor.clone(),
            destination_height: self.height,
            destination_checkpoint: checkpoint.checkpoint_hash,
            validator_qc,
            notary_qc,
        };
        let subject = proof.subject_hash();
        proof.validator_qc.subject_hash.clone_from(&subject);
        proof.notary_qc.subject_hash = subject;
        if proof.validator_qc.testnet_simulated && proof.notary_qc.testnet_simulated {
            self.rejected_transit_nullifiers
                .insert(proof.transit_id.clone());
        }
        self.rejection_proofs
            .insert(proof.rejection_id.clone(), proof.clone());
        self.assert_conservation()?;
        Ok(proof)
    }

    pub fn certify_destination_rejection(
        &mut self,
        rejection_id: &str,
        validator_qc: QuorumCertificate,
        notary_qc: QuorumCertificate,
    ) -> Result<DestinationRejectionProof, LedgerError> {
        let mut proof = self
            .rejection_proofs
            .get(rejection_id)
            .cloned()
            .ok_or_else(|| LedgerError::Invalid("destination rejection not found".into()))?;
        if self.transit_nullifiers.contains(&proof.transit_id)
            || self.rejected_transit_nullifiers.contains(&proof.transit_id)
        {
            return Err(LedgerError::Invalid(
                "an imported or already rejected transit cannot be certified for rejection".into(),
            ));
        }
        let subject = proof.subject_hash();
        if validator_qc.subject_hash != subject || notary_qc.subject_hash != subject {
            return Err(LedgerError::InvalidQuorum("subject hash mismatch".into()));
        }
        validator_qc
            .verify(&self.descriptor.validator_keys)
            .map_err(LedgerError::InvalidQuorum)?;
        notary_qc
            .verify(&self.descriptor.notary_keys)
            .map_err(LedgerError::InvalidQuorum)?;
        proof.validator_qc = validator_qc;
        proof.notary_qc = notary_qc;
        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.rejected_transit_nullifiers
            .insert(proof.transit_id.clone());
        self.rejection_proofs
            .insert(rejection_id.into(), proof.clone());
        Ok(proof)
    }

    pub fn begin_return_from_rejection(
        &mut self,
        proof: DestinationRejectionProof,
    ) -> Result<PaymentRecord, LedgerError> {
        if self.rejection_proofs.contains_key(&proof.rejection_id) {
            return Err(LedgerError::Duplicate(proof.rejection_id));
        }
        proof
            .destination_descriptor
            .validate_identity()
            .map_err(LedgerError::InvalidOperationalProof)?;
        let capsule = self
            .transits
            .get(&proof.transit_id)
            .cloned()
            .ok_or_else(|| LedgerError::TransitNotFound(proof.transit_id.clone()))?;
        if proof.transit_id != capsule.transit_id
            || proof.payment_id != capsule.payment_id
            || proof.source_zone != self.descriptor.zone_id
            || proof.destination_zone != capsule.destination_zone
            || proof.destination_descriptor.zone_id != capsule.destination_zone
            || proof.source_object_id != capsule.source_object_id
            || proof.source_object_version != capsule.source_object_version
            || proof.recipient != capsule.recipient
            || proof.amount != capsule.amount
            || proof.destination_checkpoint.trim().is_empty()
            || proof.destination_height == 0
        {
            return Err(LedgerError::Invalid(
                "destination rejection does not bind the open transit".into(),
            ));
        }
        let subject = proof.subject_hash();
        if proof.validator_qc.subject_hash != subject || proof.notary_qc.subject_hash != subject {
            return Err(LedgerError::InvalidQuorum("subject hash mismatch".into()));
        }
        let simulated = proof.validator_qc.testnet_simulated && proof.notary_qc.testnet_simulated;
        let simulation_allowed = self.descriptor.testnet
            && proof.destination_descriptor.testnet
            && proof.destination_descriptor.validator_keys.is_empty()
            && proof.destination_descriptor.notary_keys.is_empty();
        if simulated && !simulation_allowed {
            return Err(LedgerError::InvalidQuorum(
                "simulated rejection quorum is forbidden for a configured signer set".into(),
            ));
        }
        if !simulated {
            proof
                .validator_qc
                .verify(&proof.destination_descriptor.validator_keys)
                .map_err(LedgerError::InvalidQuorum)?;
            proof
                .notary_qc
                .verify(&proof.destination_descriptor.notary_keys)
                .map_err(LedgerError::InvalidQuorum)?;
        }
        let coin_id = self
            .transit_coin_ids
            .get(&proof.transit_id)
            .cloned()
            .ok_or_else(|| LedgerError::TransitNotFound(proof.transit_id.clone()))?;
        let coin = self
            .coins
            .get(&coin_id)
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.clone()))?;
        if coin.state != CoinState::InTransit {
            return Err(LedgerError::Invalid("transit is not returnable".into()));
        }
        let next_version = Self::checked_next_coin_version(coin.version)?;
        if !self.payments.contains_key(&proof.payment_id) {
            return Err(LedgerError::Invalid("payment record missing".into()));
        }
        self.ensure_counter_headroom(1, 0)?;

        self.advance()?;
        let coin = self.coins.get_mut(&coin_id).expect("coin was checked");
        coin.state = CoinState::Returning;
        coin.version = next_version;
        let record = self
            .payments
            .get_mut(&proof.payment_id)
            .expect("payment record was checked");
        record.status = PaymentStatus::Returning;
        record.updated_height = self.height;
        let result = record.clone();
        self.rejection_proofs
            .insert(proof.rejection_id.clone(), proof);
        self.assert_conservation()?;
        Ok(result)
    }

    pub fn finalize_return(&mut self, transit_id: &str) -> Result<PaymentRecord, LedgerError> {
        let capsule = self
            .transits
            .get(transit_id)
            .cloned()
            .ok_or_else(|| LedgerError::TransitNotFound(transit_id.into()))?;
        if !self
            .rejection_proofs
            .values()
            .any(|proof| proof.transit_id == transit_id)
        {
            return Err(LedgerError::Invalid(
                "return requires a verified destination rejection proof".into(),
            ));
        }
        let coin_id = self
            .transit_coin_ids
            .get(transit_id)
            .cloned()
            .ok_or_else(|| LedgerError::TransitNotFound(transit_id.into()))?;
        let coin = self
            .coins
            .get(&coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.clone()))?;
        if coin.state != CoinState::Returning {
            return Err(LedgerError::Invalid(
                "transit has not entered RETURNING".into(),
            ));
        }
        let payment = self
            .payments
            .get(&capsule.payment_id)
            .cloned()
            .ok_or_else(|| LedgerError::Invalid("payment record missing".into()))?;
        let sender = format!(
            "rld:{}:{}",
            self.descriptor.zone_id, payment.intent.sender_public_key
        );
        let next_version = Self::checked_next_coin_version(coin.version)?;
        self.ensure_counter_headroom(1, 1)?;

        self.advance()?;
        self.consume_coin(&coin_id)?;
        let returned_coin = self.make_coin(
            sender,
            coin.amount,
            CoinState::Spendable,
            vec![coin.object_id],
            Some(coin.lineage_root),
            None,
            coin.imported_from,
            next_version,
        )?;
        self.coins
            .insert(returned_coin.object_id.clone(), returned_coin.clone());
        let record = self
            .payments
            .get_mut(&capsule.payment_id)
            .expect("payment was checked");
        record.status = PaymentStatus::Returned;
        record.output_coin_ids.push(returned_coin.object_id);
        record.updated_height = self.height;
        let result = record.clone();
        self.assert_conservation()?;
        Ok(result)
    }

    pub fn import_capsule(
        &mut self,
        capsule: TransitCapsule,
    ) -> Result<DestinationImportReceipt, LedgerError> {
        if capsule.destination_zone != self.descriptor.zone_id {
            return Err(LedgerError::Invalid("capsule destination mismatch".into()));
        }
        let settlement_certificate = self
            .spendability_certificates
            .get(&capsule.payment_id)
            .filter(|certificate| {
                certificate.settlement_claim_transit_id == capsule.transit_id
                    && certificate.recipient == capsule.recipient
                    && certificate.amount == capsule.amount
            })
            .cloned();
        let (next_cross_zone_exposure, next_dsc_exposure) =
            if !self.descriptor.testnet && settlement_certificate.is_some() {
                let cross = self
                    .value_risk_policy
                    .exposure
                    .cross_zone_exposure
                    .checked_add(capsule.amount)
                    .map_err(|error| LedgerError::ValueRisk(error.to_string()))?;
                let dsc = self
                    .value_risk_policy
                    .exposure
                    .dsc_exposure
                    .checked_sub(capsule.amount)
                    .map_err(|_| {
                        LedgerError::ValueRisk(
                            "settlement exceeds recorded destination-spendability exposure".into(),
                        )
                    })?;
                (Some(cross), Some(dsc))
            } else {
                (
                    self.next_value_risk_total(ValueRiskPath::CrossZone, capsule.amount)?,
                    None,
                )
            };
        if capsule.source_zone != capsule.source_descriptor.zone_id {
            return Err(LedgerError::Invalid("source descriptor mismatch".into()));
        }
        capsule
            .source_descriptor
            .validate_identity()
            .map_err(LedgerError::InvalidOperationalProof)?;
        if capsule.source_descriptor.network_domain != self.descriptor.network_domain
            || capsule.source_descriptor.testnet != self.descriptor.testnet
        {
            return Err(LedgerError::InvalidOperationalProof(
                "cross-network Zone identity is forbidden".into(),
            ));
        }
        if self.quarantined_zones.contains(&capsule.source_zone) {
            return Err(LedgerError::SourceZoneQuarantined(capsule.source_zone));
        }
        let trust_policy = self
            .zone_trust_policies
            .get(&capsule.source_zone)
            .cloned()
            .unwrap_or(ZoneTrustPolicy::DualQc);
        if matches!(
            trust_policy,
            ZoneTrustPolicy::ObserveOnly | ZoneTrustPolicy::Quarantined
        ) {
            return Err(LedgerError::SourceZoneQuarantined(capsule.source_zone));
        }
        if self.transit_nullifiers.contains(&capsule.transit_id) {
            return Err(LedgerError::TransitAlreadyImported);
        }
        if self
            .rejected_transit_nullifiers
            .contains(&capsule.transit_id)
        {
            return Err(LedgerError::Invalid(
                "transit was permanently rejected by this destination".into(),
            ));
        }
        if capsule.transport == TransportClass::ChronologyUnsafe {
            return Err(LedgerError::CausalQuarantine(
                "chronology-unsafe route".into(),
            ));
        }
        capsule
            .operational_proof
            .validate_bounds()
            .map_err(LedgerError::InvalidOperationalProof)?;
        if capsule.operational_proof.checkpoint_hash != capsule.source_checkpoint
            || capsule.operational_proof.protocol_era != capsule.source_descriptor.protocol_era
            || capsule.operational_proof.crypto_era != capsule.source_descriptor.crypto_era
        {
            return Err(LedgerError::InvalidOperationalProof(
                "checkpoint or era binding mismatch".into(),
            ));
        }
        if capsule.origin_genesis_root != self.descriptor.currency_genesis_root
            || capsule.source_descriptor.currency_genesis_root
                != self.descriptor.currency_genesis_root
            || capsule.source_object.origin_genesis_root != self.descriptor.currency_genesis_root
        {
            return Err(LedgerError::InvalidOperationalProof(
                "currency genesis root mismatch".into(),
            ));
        }
        match (&capsule.payment_request_id, &capsule.payment_request) {
            (None, None) => {}
            (Some(request_id), Some(request)) => {
                if request_id != &request.request_id
                    || request.destination_zone != self.descriptor.zone_id
                    || request.recipient != capsule.recipient
                    || request.amount != capsule.amount
                {
                    return Err(LedgerError::Invalid(
                        "capsule payment request binding mismatch".into(),
                    ));
                }
                request.verify().map_err(LedgerError::InvalidSignature)?;
                self.validate_payment_request_context(request)?;
                if request.expires_at_height <= self.height {
                    return Err(LedgerError::Invalid("payment request has expired".into()));
                }
                if self.consumed_payment_requests.contains(request_id) {
                    return Err(LedgerError::Duplicate(request_id.clone()));
                }
            }
            _ => {
                return Err(LedgerError::Invalid(
                    "capsule payment request id and signed request must be supplied together"
                        .into(),
                ));
            }
        }
        if capsule.source_object.object_id != capsule.source_object_id
            || capsule.source_object.version != capsule.source_object_version
            || capsule.source_object.zone_id != capsule.source_zone
            || capsule.source_object.amount != capsule.amount
            || capsule.source_object.owner != capsule.recipient
            || capsule.source_object.state != CoinState::InTransit
            || capsule.source_object.transit_id.as_deref() != Some(&capsule.transit_id)
            || capsule.source_object.lineage_root != capsule.lineage_root
        {
            return Err(LedgerError::InvalidOperationalProof(
                "source object binding mismatch".into(),
            ));
        }
        let source_object_hash = hash_bytes(
            &serde_json::to_vec(&capsule.source_object)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?,
        );
        if source_object_hash != capsule.operational_proof.object_hash {
            return Err(LedgerError::InvalidOperationalProof(
                "source object hash mismatch".into(),
            ));
        }
        let supply_certificate_hash = hash_bytes(
            &serde_json::to_vec(&capsule.source_supply)
                .map_err(|error| LedgerError::Invalid(error.to_string()))?,
        );
        let recomputed_position = capsule
            .source_supply
            .buckets
            .conservation_position()
            .map_err(LedgerError::Supply)?;
        let recomputed_reserve_pool_total = capsule
            .source_supply
            .reserve_pools
            .total()
            .map_err(LedgerError::Supply)?;
        if !capsule.source_supply.valid
            || capsule.source_supply.zone_id != capsule.source_zone
            || recomputed_position != capsule.source_supply.conservation_position
            || recomputed_position != capsule.source_supply.anchor_supply
            || recomputed_reserve_pool_total != capsule.source_supply.buckets.reserve
            || supply_certificate_hash != capsule.operational_proof.supply_certificate_hash
        {
            return Err(LedgerError::InvalidOperationalProof(
                "source supply certificate mismatch".into(),
            ));
        }
        self.verify_era_certificate(&capsule)?;
        let source_spend_nullifier = capsule.source_spend_nullifier();
        if self
            .source_object_nullifiers
            .contains(&source_spend_nullifier)
        {
            self.quarantined_zones.insert(capsule.source_zone.clone());
            self.zone_trust_policies
                .insert(capsule.source_zone.clone(), ZoneTrustPolicy::Quarantined);
            return Err(LedgerError::SourceZoneQuarantined(capsule.source_zone));
        }
        let subject = capsule.subject_hash();
        self.verify_source_acceptance(&capsule, &subject, &trust_policy)?;
        let next_version = Self::checked_next_coin_version(capsule.source_object_version)?;
        self.ensure_counter_headroom(1, 1)?;

        let envelope = CausalEnvelope {
            envelope_id: capsule.transit_id.clone(),
            parent_ids: Vec::new(),
            object_id: capsule.source_object_id.clone(),
            object_version: capsule.source_object_version,
            source_checkpoint: capsule.source_checkpoint.clone(),
            transport: capsule.transport.clone(),
            payload_hash: subject,
        };
        match self.causal_firewall.submit(envelope) {
            CausalDecision::Accepted => {}
            CausalDecision::Quarantined(reason) => {
                return Err(LedgerError::CausalQuarantine(reason));
            }
            CausalDecision::PendingMissingParents(parents) => {
                return Err(LedgerError::Invalid(format!(
                    "missing causal parents: {}",
                    parents.join(",")
                )));
            }
            CausalDecision::Duplicate => return Err(LedgerError::TransitAlreadyImported),
        }

        let settlement_owner = settlement_certificate
            .as_ref()
            .map(|certificate| certificate.liquidity_provider.clone())
            .unwrap_or_else(|| capsule.recipient.clone());
        self.advance()?;
        let mut coin = self.make_coin(
            settlement_owner,
            capsule.amount,
            CoinState::Spendable,
            vec![capsule.source_object_id.clone()],
            Some(capsule.lineage_root.clone()),
            None,
            Some(capsule.source_zone.clone()),
            next_version,
        )?;
        coin.origin_zone
            .clone_from(&capsule.source_object.origin_zone);
        coin.origin_genesis_root
            .clone_from(&capsule.origin_genesis_root);
        self.imported_total = self.imported_total.checked_add(capsule.amount)?;
        self.transit_nullifiers.insert(capsule.transit_id.clone());
        self.source_object_nullifiers.insert(source_spend_nullifier);
        if let Some(request_id) = &capsule.payment_request_id {
            self.consumed_payment_requests.insert(request_id.clone());
        }
        self.coins.insert(coin.object_id.clone(), coin.clone());
        self.record_value_risk_total(ValueRiskPath::CrossZone, next_cross_zone_exposure);
        if let Some(next_dsc_exposure) = next_dsc_exposure {
            self.value_risk_policy.exposure.dsc_exposure = next_dsc_exposure;
        }
        let checkpoint = self.create_checkpoint()?;
        let receipt = DestinationImportReceipt {
            transit_id: capsule.transit_id.clone(),
            payment_id: capsule.payment_id.clone(),
            destination_zone: self.descriptor.zone_id.clone(),
            destination_coin_id: coin.object_id,
            recipient: capsule.recipient,
            amount: capsule.amount,
            destination_height: self.height,
            checkpoint_hash: checkpoint.checkpoint_hash,
        };
        self.import_receipts
            .insert(capsule.transit_id, receipt.clone());
        self.assert_conservation()?;
        Ok(receipt)
    }

    pub fn finalize_export(
        &mut self,
        receipt: &DestinationImportReceipt,
    ) -> Result<PaymentRecord, LedgerError> {
        let capsule = self
            .transits
            .get(&receipt.transit_id)
            .cloned()
            .ok_or_else(|| LedgerError::TransitNotFound(receipt.transit_id.clone()))?;
        if receipt.destination_zone != capsule.destination_zone
            || receipt.payment_id != capsule.payment_id
            || receipt.amount != capsule.amount
            || receipt.recipient != capsule.recipient
        {
            return Err(LedgerError::Invalid("destination receipt mismatch".into()));
        }
        let coin_id = self
            .transit_coin_ids
            .get(&receipt.transit_id)
            .cloned()
            .ok_or_else(|| LedgerError::TransitNotFound(receipt.transit_id.clone()))?;
        let coin = self
            .coins
            .get(&coin_id)
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.clone()))?;
        if coin.state != CoinState::InTransit {
            return Err(LedgerError::Invalid("transit is not open".into()));
        }
        let next_cross_zone_exposure = if self.descriptor.testnet {
            None
        } else {
            Some(
                self.value_risk_policy
                    .exposure
                    .cross_zone_exposure
                    .checked_sub(receipt.amount)
                    .map_err(|_| {
                        LedgerError::ValueRisk(
                            "finalization exceeds recorded cross-Zone exposure".into(),
                        )
                    })?,
            )
        };
        let payment_id = self
            .payments
            .iter()
            .find_map(|(id, record)| {
                (record.transit_id.as_deref() == Some(&receipt.transit_id)).then(|| id.clone())
            })
            .ok_or_else(|| LedgerError::Invalid("payment record missing".into()))?;
        self.ensure_counter_headroom(1, 0)?;

        self.advance()?;
        self.consume_coin(&coin_id)?;
        self.finalized_export_total = self.finalized_export_total.checked_add(receipt.amount)?;
        self.record_value_risk_total(ValueRiskPath::CrossZone, next_cross_zone_exposure);
        let record = self
            .payments
            .get_mut(&payment_id)
            .ok_or_else(|| LedgerError::Invalid("payment record missing".into()))?;
        record.status = PaymentStatus::UniversallySettled;
        record.updated_height = self.height;
        let result = record.clone();
        self.assert_conservation()?;
        Ok(result)
    }

    pub fn issue_spendability_certificate(
        &mut self,
        request: SpendabilityCertificateRequest,
    ) -> Result<DestinationSpendabilityCertificate, LedgerError> {
        let SpendabilityCertificateRequest {
            payment_id,
            provider_coin_id,
            liquidity_provider,
            recipient,
            amount,
            settlement_claim_transit_id,
            authorization,
        } = request;
        let payload_hash = action_payload_hash(
            "ISSUE_DSC",
            &[
                payment_id.as_bytes(),
                provider_coin_id.as_bytes(),
                liquidity_provider.as_bytes(),
                recipient.as_bytes(),
                &amount.0.to_be_bytes(),
                settlement_claim_transit_id.as_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &authorization,
            &liquidity_provider,
            "ISSUE_DSC",
            &payload_hash,
        )?;
        let input = self
            .coins
            .get(&provider_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(provider_coin_id.clone()))?;
        if input.state != CoinState::Spendable || input.owner != liquidity_provider {
            return Err(LedgerError::OwnerMismatch);
        }
        if amount.is_zero() || amount > input.amount {
            return Err(LedgerError::Invalid("invalid liquidity amount".into()));
        }
        if self.spendability_certificates.contains_key(&payment_id) {
            return Err(LedgerError::Duplicate(payment_id));
        }
        let next_dsc_exposure =
            self.next_value_risk_total(ValueRiskPath::DestinationSpendability, amount)?;
        let change = input.amount.checked_sub(amount)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 1 + u64::from(!change.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;
        self.consume_authorization(&authorization)?;
        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let local_coin = self.make_coin(
            recipient.clone(),
            amount,
            CoinState::Spendable,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins
            .insert(local_coin.object_id.clone(), local_coin.clone());
        if !change.is_zero() {
            let change_coin = self.make_coin(
                liquidity_provider.clone(),
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                input.imported_from,
                next_version,
            )?;
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let certificate = DestinationSpendabilityCertificate {
            payment_id: payment_id.clone(),
            destination_zone: self.descriptor.zone_id.clone(),
            recipient,
            local_coin_id: local_coin.object_id,
            liquidity_provider,
            amount,
            settlement_claim_transit_id,
            destination_height: self.height,
        };
        self.spendability_certificates
            .insert(payment_id, certificate.clone());
        self.record_value_risk_total(ValueRiskPath::DestinationSpendability, next_dsc_exposure);
        self.assert_conservation()?;
        Ok(certificate)
    }

    pub fn create_liquidity_offer(
        &mut self,
        request: CreateLiquidityOfferRequest,
    ) -> Result<LiquidityOffer, LedgerError> {
        let CreateLiquidityOfferRequest {
            provider,
            coin_id,
            amount,
            minimum,
            maximum,
            expires_at_height,
            authorization,
        } = request;
        if amount.is_zero()
            || minimum.is_zero()
            || minimum > maximum
            || maximum > amount
            || expires_at_height <= self.height
        {
            return Err(LedgerError::Invalid(
                "invalid liquidity offer bounds or expiry".into(),
            ));
        }
        let payload_hash = action_payload_hash(
            "CREATE_LIQUIDITY_OFFER",
            &[
                provider.as_bytes(),
                coin_id.as_bytes(),
                &amount.0.to_be_bytes(),
                &minimum.0.to_be_bytes(),
                &maximum.0.to_be_bytes(),
                &expires_at_height.to_be_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &authorization,
            &provider,
            "CREATE_LIQUIDITY_OFFER",
            &payload_hash,
        )?;
        let input = self
            .coins
            .get(&coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.clone()))?;
        if input.state != CoinState::Spendable || input.owner != provider {
            return Err(LedgerError::OwnerMismatch);
        }
        if amount > input.amount {
            return Err(LedgerError::Invalid(
                "liquidity offer exceeds the selected coin".into(),
            ));
        }
        let next_dsc_exposure =
            self.next_value_risk_total(ValueRiskPath::DestinationSpendability, amount)?;
        let change = input.amount.checked_sub(amount)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 2 + u64::from(!change.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;

        self.consume_authorization(&authorization)?;
        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let reserved = self.make_coin(
            provider.clone(),
            amount,
            CoinState::Reserved,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins
            .insert(reserved.object_id.clone(), reserved.clone());
        if !change.is_zero() {
            let change_coin = self.make_coin(
                provider.clone(),
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                input.imported_from,
                next_version,
            )?;
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let offer = LiquidityOffer {
            offer_id: self.next_id("liquidity-offer")?,
            provider,
            destination_zone: self.descriptor.zone_id.clone(),
            reserved_coin_id: Some(reserved.object_id),
            available: amount,
            minimum,
            maximum,
            expires_at_height,
            status: LiquidityOfferStatus::Open,
            created_height: self.height,
        };
        self.liquidity_offers
            .insert(offer.offer_id.clone(), offer.clone());
        self.record_value_risk_commitment(
            ValueRiskPath::DestinationSpendability,
            offer.offer_id.clone(),
            amount,
            next_dsc_exposure,
        );
        self.assert_conservation()?;
        Ok(offer)
    }

    pub fn take_liquidity_offer(
        &mut self,
        request: TakeLiquidityOfferRequest,
    ) -> Result<DestinationSpendabilityCertificate, LedgerError> {
        let offer = self
            .liquidity_offers
            .get(&request.offer_id)
            .cloned()
            .ok_or_else(|| LedgerError::LiquidityOfferNotFound(request.offer_id.clone()))?;
        if offer.status != LiquidityOfferStatus::Open
            || offer.expires_at_height <= self.height
            || request.settlement_claim.destination_zone != self.descriptor.zone_id
            || request.settlement_claim.amount < offer.minimum
            || request.settlement_claim.amount > offer.maximum
            || request.settlement_claim.amount > offer.available
        {
            return Err(LedgerError::Invalid(
                "liquidity offer is unavailable for this settlement claim".into(),
            ));
        }
        if self
            .spendability_certificates
            .contains_key(&request.settlement_claim.payment_id)
        {
            return Err(LedgerError::Duplicate(request.settlement_claim.payment_id));
        }
        self.require_dsc_value_commitment(&request.offer_id, request.settlement_claim.amount)?;
        let mut verifier = self.clone();
        verifier.spendability_certificates.insert(
            request.settlement_claim.payment_id.clone(),
            DestinationSpendabilityCertificate {
                payment_id: request.settlement_claim.payment_id.clone(),
                destination_zone: self.descriptor.zone_id.clone(),
                recipient: request.settlement_claim.recipient.clone(),
                local_coin_id: "precommitted-liquidity-validation".into(),
                liquidity_provider: offer.provider.clone(),
                amount: request.settlement_claim.amount,
                settlement_claim_transit_id: request.settlement_claim.transit_id.clone(),
                destination_height: self.height,
            },
        );
        verifier.import_capsule(request.settlement_claim.clone())?;

        let reserved_coin_id = offer
            .reserved_coin_id
            .clone()
            .ok_or_else(|| LedgerError::Invalid("liquidity reserve is empty".into()))?;
        let input = self
            .coins
            .get(&reserved_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(reserved_coin_id.clone()))?;
        if input.state != CoinState::Reserved
            || input.owner != offer.provider
            || input.amount != offer.available
        {
            return Err(LedgerError::Invalid(
                "liquidity reserve does not match its offer".into(),
            ));
        }

        let amount = request.settlement_claim.amount;
        let remaining = input.amount.checked_sub(amount)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 1 + u64::from(!remaining.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;
        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let local_coin = self.make_coin(
            request.settlement_claim.recipient.clone(),
            amount,
            CoinState::Spendable,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins
            .insert(local_coin.object_id.clone(), local_coin.clone());
        let next_reserved_coin_id = if remaining.is_zero() {
            None
        } else {
            let next = self.make_coin(
                offer.provider.clone(),
                remaining,
                CoinState::Reserved,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                input.imported_from,
                next_version,
            )?;
            let next_id = next.object_id.clone();
            self.coins.insert(next_id.clone(), next);
            Some(next_id)
        };
        let certificate = DestinationSpendabilityCertificate {
            payment_id: request.settlement_claim.payment_id.clone(),
            destination_zone: self.descriptor.zone_id.clone(),
            recipient: request.settlement_claim.recipient.clone(),
            local_coin_id: local_coin.object_id,
            liquidity_provider: offer.provider.clone(),
            amount,
            settlement_claim_transit_id: request.settlement_claim.transit_id.clone(),
            destination_height: self.height,
        };
        self.spendability_certificates
            .insert(request.settlement_claim.payment_id, certificate.clone());
        let offer = self
            .liquidity_offers
            .get_mut(&request.offer_id)
            .expect("offer was checked");
        offer.available = remaining;
        offer.reserved_coin_id = next_reserved_coin_id;
        if remaining.is_zero() || remaining < offer.minimum {
            offer.status = LiquidityOfferStatus::Depleted;
        }
        self.assert_conservation()?;
        Ok(certificate)
    }

    pub fn available_protocol_reserve(
        &self,
        pool: &ProtocolReservePoolKind,
    ) -> Result<Amount, LedgerError> {
        let balance = match pool {
            ProtocolReservePoolKind::StartupServices => self.reserve_pools.startup_services,
            ProtocolReservePoolKind::ContinuityServices => self.reserve_pools.continuity_services,
            ProtocolReservePoolKind::DemandMatching => self.reserve_pools.demand_matching,
        };
        let committed = self
            .protocol_reserve_commitments
            .values()
            .filter(|commitment| {
                commitment.reserve_pool == *pool && commitment.settled_amount.is_none()
            })
            .try_fold(Amount::ZERO, |total, commitment| {
                total.checked_add(commitment.committed_amount)
            })?;
        balance.checked_sub(committed).map_err(|_| {
            LedgerError::Supply(format!(
                "active {} commitments exceed their reserve pool",
                pool.wire_name()
            ))
        })
    }

    /// Submits a consensus-domain real-value policy update.
    ///
    /// Risk increases are only staged and must survive a signed challenge
    /// delay. Risk reductions apply immediately, preserve all existing assets
    /// and exposure counters, and only stop subsequent risk creation.
    pub fn submit_value_risk_policy_update(
        &mut self,
        update: ValueRiskPolicyUpdate,
    ) -> Result<ValueRiskPolicy, LedgerError> {
        self.verify_value_risk_policy_update(&update, true)?;
        if update.from_cap != self.value_risk_policy.current_cap
            || update.previous_policy_sequence != self.value_risk_policy.policy_sequence
        {
            return Err(LedgerError::ValueRisk(
                "policy update does not extend the active policy".into(),
            ));
        }
        update
            .limits
            .validate_for_cap(update.to_cap)
            .map_err(LedgerError::ValueRisk)?;
        let next_policy_sequence = self
            .value_risk_policy
            .policy_sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::ValueRisk("policy sequence overflow".into()))?;

        let increases_risk = self.value_risk_update_increases_risk(&update);
        if increases_risk {
            self.ensure_admission_may_raise_value_cap()?;
            let earliest = self
                .height
                .checked_add(MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS)
                .ok_or_else(|| LedgerError::ValueRisk("activation height overflow".into()))?;
            if update.activate_after_height < earliest {
                return Err(LedgerError::ValueRisk(format!(
                    "risk increase requires at least {MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS} blocks of notice"
                )));
            }
            if self
                .value_risk_policy
                .pending_update
                .as_ref()
                .is_some_and(|pending| pending.expires_at_height > self.height)
            {
                return Err(LedgerError::ValueRisk(
                    "an unexpired risk increase is already pending".into(),
                ));
            }
            self.ensure_counter_headroom(1, 0)?;
            self.advance()?;
            self.value_risk_policy.pending_update = Some(update);
            return Ok(self.value_risk_policy.clone());
        }

        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.apply_value_risk_policy(update, next_policy_sequence);
        Ok(self.value_risk_policy.clone())
    }

    pub fn activate_pending_value_risk_policy(&mut self) -> Result<ValueRiskPolicy, LedgerError> {
        let update = self
            .value_risk_policy
            .pending_update
            .clone()
            .ok_or_else(|| LedgerError::ValueRisk("no policy update is pending".into()))?;
        if self.height < update.activate_after_height {
            return Err(LedgerError::ValueRisk(
                "policy challenge delay has not elapsed".into(),
            ));
        }
        if self.height >= update.expires_at_height {
            return Err(LedgerError::ValueRisk(
                "pending policy update expired".into(),
            ));
        }
        if update.from_cap != self.value_risk_policy.current_cap
            || update.previous_policy_sequence != self.value_risk_policy.policy_sequence
        {
            return Err(LedgerError::ValueRisk(
                "pending policy no longer extends the active policy".into(),
            ));
        }
        self.verify_value_risk_policy_update(&update, false)?;
        update
            .limits
            .validate_for_cap(update.to_cap)
            .map_err(LedgerError::ValueRisk)?;
        let next_policy_sequence = self
            .value_risk_policy
            .policy_sequence
            .checked_add(1)
            .ok_or_else(|| LedgerError::ValueRisk("policy sequence overflow".into()))?;

        if self.value_risk_update_increases_risk(&update) {
            self.ensure_admission_may_raise_value_cap()?;
        }

        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        self.apply_value_risk_policy(update, next_policy_sequence);
        Ok(self.value_risk_policy.clone())
    }

    fn value_risk_update_increases_risk(&self, update: &ValueRiskPolicyUpdate) -> bool {
        update.to_cap > self.value_risk_policy.current_cap
            || update
                .limits
                .increases_any_limit_over(&self.value_risk_policy.limits)
            || (update.to_cap != ValueCap::ValueCap0
                && update.safety_case_valid_until_height
                    > self.value_risk_policy.safety_case_valid_until_height)
            || (update.to_cap != ValueCap::ValueCap0
                && update.safety_case_hash != self.value_risk_policy.safety_case_hash)
    }

    fn verify_value_risk_policy_update(
        &self,
        update: &ValueRiskPolicyUpdate,
        require_current_proposal_height: bool,
    ) -> Result<(), LedgerError> {
        if update.update_id.trim().is_empty() {
            return Err(LedgerError::ValueRisk(
                "policy update id is required".into(),
            ));
        }
        if update.zone_id != self.descriptor.zone_id
            || update.currency_genesis_root != self.descriptor.currency_genesis_root
            || update.protocol_era != self.descriptor.protocol_era
            || update.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::ValueRisk(
                "policy update Zone, currency or era binding mismatch".into(),
            ));
        }
        if update.policy_version != CURRENT_VALUE_RISK_POLICY_VERSION
            || self.value_risk_policy.version != CURRENT_VALUE_RISK_POLICY_VERSION
        {
            return Err(LedgerError::ValueRisk(
                "unsupported real-value policy version".into(),
            ));
        }
        if require_current_proposal_height && update.proposed_height != self.height {
            return Err(LedgerError::ValueRisk(
                "policy proposal height does not match current state".into(),
            ));
        }
        if update.expires_at_height <= update.activate_after_height
            || update.expires_at_height <= self.height
        {
            return Err(LedgerError::ValueRisk(
                "policy activation window is empty or expired".into(),
            ));
        }
        if update.to_cap == ValueCap::ValueCap0 {
            if !update.safety_case_hash.is_empty() || update.safety_case_valid_until_height != 0 {
                return Err(LedgerError::ValueRisk(
                    "VALUE_CAP_0 must use an empty safety-case commitment and zero validity".into(),
                ));
            }
        } else {
            if !is_canonical_sha256_hex(&update.safety_case_hash) {
                return Err(LedgerError::ValueRisk(
                    "safety-case commitment must be a 64-character lowercase SHA-256 hex digest"
                        .into(),
                ));
            }
            let activation_height = update
                .activate_after_height
                .checked_add(1)
                .ok_or_else(|| LedgerError::ValueRisk("activation height overflow".into()))?;
            let resulting_height = self
                .height
                .checked_add(1)
                .ok_or_else(|| LedgerError::ValueRisk("activation height overflow".into()))?;
            if update.safety_case_valid_until_height <= activation_height
                || update.safety_case_valid_until_height <= resulting_height
            {
                return Err(LedgerError::ValueRisk(
                    "safety-case evidence expires before policy activation".into(),
                ));
            }
        }
        let subject = update.compute_subject_hash();
        if update.subject_hash != subject {
            return Err(LedgerError::ValueRisk(
                "policy update subject commitment mismatch".into(),
            ));
        }
        self.verify_local_dual_quorum(&subject, &update.validator_qc, &update.notary_qc)
    }

    fn apply_value_risk_policy(&mut self, update: ValueRiskPolicyUpdate, next_sequence: u64) {
        self.value_risk_policy.policy_sequence = next_sequence;
        self.value_risk_policy.current_cap = update.to_cap;
        self.value_risk_policy.ever_enabled |= update.to_cap != ValueCap::ValueCap0;
        self.value_risk_policy.limits = update.limits;
        self.value_risk_policy.safety_case_hash = update.safety_case_hash;
        self.value_risk_policy.safety_case_valid_until_height =
            update.safety_case_valid_until_height;
        self.value_risk_policy.activated_height = self.height;
        self.value_risk_policy.pending_update = None;
    }

    fn next_value_risk_total(
        &self,
        path: ValueRiskPath,
        amount: Amount,
    ) -> Result<Option<Amount>, LedgerError> {
        if self.descriptor.testnet {
            return Ok(None);
        }
        let policy = &self.value_risk_policy;
        if policy.version != CURRENT_VALUE_RISK_POLICY_VERSION {
            return Err(LedgerError::ValueRisk(
                "unknown policy version fails closed outside testnet".into(),
            ));
        }
        policy
            .limits
            .validate_for_cap(policy.current_cap)
            .map_err(LedgerError::ValueRisk)?;
        if policy.current_cap == ValueCap::ValueCap0 {
            return Err(LedgerError::ValueRisk(
                "VALUE_CAP_0 blocks all spendable real-value transitions".into(),
            ));
        }
        let resulting_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::ValueRisk("transition height overflow".into()))?;
        if !is_canonical_sha256_hex(&policy.safety_case_hash)
            || resulting_height >= policy.safety_case_valid_until_height
        {
            return Err(LedgerError::ValueRisk(
                "active safety-case evidence is missing, malformed or expired".into(),
            ));
        }
        let (current, limit, label) = match path {
            ValueRiskPath::LocalPayment => (
                policy.exposure.local_value_total,
                policy.limits.max_local_value_total,
                "same-Zone value total",
            ),
            ValueRiskPath::CrossZone => (
                policy.exposure.cross_zone_exposure,
                policy.limits.max_cross_zone_exposure,
                "cross-Zone exposure",
            ),
            ValueRiskPath::DestinationSpendability => (
                policy.exposure.dsc_exposure,
                policy.limits.max_dsc_exposure,
                "destination-spendability exposure",
            ),
        };
        if limit.is_zero() {
            return Err(LedgerError::ValueRisk(format!(
                "the active policy disables the {label} path"
            )));
        }
        if amount.is_zero() || amount > policy.limits.max_single_transfer {
            return Err(LedgerError::ValueRisk(
                "transfer exceeds the active per-transaction value limit".into(),
            ));
        }
        let next = current
            .checked_add(amount)
            .map_err(|error| LedgerError::ValueRisk(error.to_string()))?;
        if next > limit {
            return Err(LedgerError::ValueRisk(format!(
                "transfer would exceed the active {label} limit"
            )));
        }
        Ok(Some(next))
    }

    fn record_value_risk_total(&mut self, path: ValueRiskPath, next: Option<Amount>) {
        let Some(next) = next else {
            return;
        };
        match path {
            ValueRiskPath::LocalPayment => {
                self.value_risk_policy.exposure.local_value_total = next;
            }
            ValueRiskPath::CrossZone => {
                self.value_risk_policy.exposure.cross_zone_exposure = next;
            }
            ValueRiskPath::DestinationSpendability => {
                self.value_risk_policy.exposure.dsc_exposure = next;
            }
        }
    }

    fn record_value_risk_commitment(
        &mut self,
        path: ValueRiskPath,
        commitment_id: String,
        amount: Amount,
        next: Option<Amount>,
    ) {
        if next.is_none() {
            return;
        }
        self.record_value_risk_total(path, next);
        match path {
            ValueRiskPath::LocalPayment => {
                self.value_risk_policy
                    .exposure
                    .local_commitment_amounts
                    .insert(commitment_id, amount);
            }
            ValueRiskPath::DestinationSpendability => {
                self.value_risk_policy
                    .exposure
                    .dsc_commitment_amounts
                    .insert(commitment_id, amount);
            }
            ValueRiskPath::CrossZone => {}
        }
    }

    fn require_local_value_commitment(
        &self,
        commitment_id: &str,
        amount: Amount,
    ) -> Result<(), LedgerError> {
        if self.descriptor.testnet {
            return Ok(());
        }
        if self
            .value_risk_policy
            .exposure
            .local_commitment_amounts
            .get(commitment_id)
            != Some(&amount)
        {
            return Err(LedgerError::ValueRisk(
                "closeout has no matching prepaid local-value commitment".into(),
            ));
        }
        Ok(())
    }

    fn require_dsc_value_commitment(
        &self,
        commitment_id: &str,
        amount: Amount,
    ) -> Result<(), LedgerError> {
        if self.descriptor.testnet {
            return Ok(());
        }
        if self
            .value_risk_policy
            .exposure
            .dsc_commitment_amounts
            .get(commitment_id)
            .is_none_or(|reserved| *reserved < amount)
        {
            return Err(LedgerError::ValueRisk(
                "closeout has no matching prepaid DSC commitment".into(),
            ));
        }
        Ok(())
    }

    fn validate_protocol_service_match(
        &self,
        request: &ProtocolServiceOrderRequest,
    ) -> Result<(), LedgerError> {
        let receipt_id = request.matched_service_receipt_id.as_ref().ok_or_else(|| {
            LedgerError::Invalid(
                "non-startup reserve work requires a real user-funded service receipt".into(),
            )
        })?;
        if self.matched_service_receipts.contains(receipt_id) {
            return Err(LedgerError::Duplicate(receipt_id.clone()));
        }
        let receipt = self
            .service_receipts
            .get(receipt_id)
            .ok_or_else(|| LedgerError::Invalid("matched service receipt was not found".into()))?;
        if receipt.bootstrap
            || receipt.protocol_reserve_pool.is_some()
            || receipt.role != request.role
            || request.budget > receipt.amount
        {
            return Err(LedgerError::Invalid(
                "reserve match must not exceed one genuine user-funded service receipt".into(),
            ));
        }
        let source_order = self
            .service_orders
            .get(&receipt.order_id)
            .ok_or_else(|| LedgerError::ServiceOrderNotFound(receipt.order_id.clone()))?;
        if source_order.buyer.rsplit(':').next() == Some(receipt.node_id.as_str()) {
            return Err(LedgerError::Invalid(
                "self-funded service traffic cannot receive a reserve match".into(),
            ));
        }
        Ok(())
    }

    pub fn create_protocol_service_order(
        &mut self,
        request: ProtocolServiceOrderRequest,
    ) -> Result<ServiceOrder, LedgerError> {
        if request.request_id.trim().is_empty()
            || request.description.trim().is_empty()
            || request.budget.is_zero()
        {
            return Err(LedgerError::Invalid(
                "protocol service order request is incomplete".into(),
            ));
        }
        if self.service_orders.contains_key(&request.request_id) {
            return Err(LedgerError::Duplicate(request.request_id));
        }
        if request.zone_id != self.descriptor.zone_id
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "protocol service order Zone or era mismatch".into(),
            ));
        }
        let subject = request.compute_subject_hash();
        if request.subject_hash != subject
            || request.validator_qc.subject_hash != subject
            || request.notary_qc.subject_hash != subject
        {
            return Err(LedgerError::InvalidQuorum(
                "protocol service order subject mismatch".into(),
            ));
        }
        self.verify_local_dual_quorum(&subject, &request.validator_qc, &request.notary_qc)?;

        match &request.reserve_pool {
            ProtocolReservePoolKind::StartupServices => {
                if request.matched_service_receipt_id.is_some() {
                    return Err(LedgerError::Invalid(
                        "startup service orders cannot claim a demand match".into(),
                    ));
                }
            }
            ProtocolReservePoolKind::ContinuityServices => {
                if !matches!(
                    &request.role,
                    ServiceRole::Storage | ServiceRole::Archive | ServiceRole::ContinuityCustodian
                ) {
                    return Err(LedgerError::Invalid(
                        "continuity pool is restricted to storage, archive and continuity custody"
                            .into(),
                    ));
                }
                self.validate_protocol_service_match(&request)?;
            }
            ProtocolReservePoolKind::DemandMatching => {
                self.validate_protocol_service_match(&request)?;
            }
        }

        if request.budget > self.available_protocol_reserve(&request.reserve_pool)? {
            return Err(LedgerError::Supply(format!(
                "{} reserve pool has insufficient uncommitted funds",
                request.reserve_pool.wire_name()
            )));
        }
        let next_value_total =
            self.next_value_risk_total(ValueRiskPath::LocalPayment, request.budget)?;

        self.ensure_counter_headroom(1, 0)?;
        self.advance()?;
        let order_id = request.request_id.clone();
        let order = ServiceOrder {
            order_id: order_id.clone(),
            buyer: format!("rld:protocol:{}", request.reserve_pool.wire_name()),
            role: request.role,
            budget: request.budget,
            escrow_coin_id: format!(
                "protocol-reserve:{}:{}",
                request.reserve_pool.wire_name(),
                order_id
            ),
            description: request.description,
            status: ServiceStatus::Open,
            created_height: self.height,
        };
        let commitment = ProtocolReserveCommitment {
            order_id: order_id.clone(),
            reserve_pool: request.reserve_pool,
            committed_amount: request.budget,
            matched_service_receipt_id: request.matched_service_receipt_id.clone(),
            authorization_subject_hash: subject,
            validator_qc: request.validator_qc,
            notary_qc: request.notary_qc,
            settled_amount: None,
        };
        if let Some(receipt_id) = request.matched_service_receipt_id {
            self.matched_service_receipts.insert(receipt_id);
        }
        self.service_orders.insert(order_id.clone(), order.clone());
        self.protocol_reserve_commitments
            .insert(order_id, commitment);
        self.record_value_risk_commitment(
            ValueRiskPath::LocalPayment,
            order.order_id.clone(),
            order.budget,
            next_value_total,
        );
        self.assert_conservation()?;
        Ok(order)
    }

    pub fn create_service_order(
        &mut self,
        buyer: String,
        coin_id: String,
        role: ServiceRole,
        budget: Amount,
        description: String,
        authorization: SignedActionAuthorization,
    ) -> Result<ServiceOrder, LedgerError> {
        let role_name = format!("{role:?}").to_uppercase();
        let payload_hash = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                buyer.as_bytes(),
                coin_id.as_bytes(),
                role_name.as_bytes(),
                &budget.0.to_be_bytes(),
                description.as_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &authorization,
            &buyer,
            "CREATE_SERVICE_ORDER",
            &payload_hash,
        )?;
        let input = self
            .coins
            .get(&coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.clone()))?;
        if input.state != CoinState::Spendable || input.owner != buyer {
            return Err(LedgerError::OwnerMismatch);
        }
        if budget.is_zero() || budget > input.amount {
            return Err(LedgerError::Invalid("invalid service budget".into()));
        }
        let next_value_total = self.next_value_risk_total(ValueRiskPath::LocalPayment, budget)?;
        let change = input.amount.checked_sub(budget)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 2 + u64::from(!change.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;
        self.consume_authorization(&authorization)?;
        self.advance()?;
        self.consume_coin(&coin_id)?;
        let escrow = self.make_coin(
            buyer.clone(),
            budget,
            CoinState::Reserved,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins.insert(escrow.object_id.clone(), escrow.clone());
        if !change.is_zero() {
            let change_coin = self.make_coin(
                buyer.clone(),
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                input.imported_from,
                next_version,
            )?;
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let order = ServiceOrder {
            order_id: self.next_id("service-order")?,
            buyer,
            role,
            budget,
            escrow_coin_id: escrow.object_id,
            description,
            status: ServiceStatus::Open,
            created_height: self.height,
        };
        self.service_orders
            .insert(order.order_id.clone(), order.clone());
        self.record_value_risk_commitment(
            ValueRiskPath::LocalPayment,
            order.order_id.clone(),
            order.budget,
            next_value_total,
        );
        self.assert_conservation()?;
        Ok(order)
    }

    pub fn lease_service(
        &mut self,
        order_id: &str,
        node_id: String,
        accepted_quote: Amount,
        authorization: SignedActionAuthorization,
    ) -> Result<ServiceLease, LedgerError> {
        let payload_hash = action_payload_hash(
            "LEASE_SERVICE",
            &[
                order_id.as_bytes(),
                node_id.as_bytes(),
                &accepted_quote.0.to_be_bytes(),
            ],
        );
        self.verify_node_authorization(&authorization, &node_id, "LEASE_SERVICE", &payload_hash)?;
        let order = self
            .service_orders
            .get(order_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceOrderNotFound(order_id.into()))?;
        if order.status != ServiceStatus::Open
            || accepted_quote.is_zero()
            || accepted_quote > order.budget
        {
            return Err(LedgerError::ServiceState);
        }
        if let Some(receipt_id) = self
            .protocol_reserve_commitments
            .get(order_id)
            .and_then(|commitment| commitment.matched_service_receipt_id.as_ref())
        {
            let matched = self.service_receipts.get(receipt_id).ok_or_else(|| {
                LedgerError::Invalid("matched service receipt was not found".into())
            })?;
            if matched.node_id != node_id {
                return Err(LedgerError::Invalid(
                    "demand-matched work must be leased to the original service node".into(),
                ));
            }
        }
        self.ensure_counter_headroom(1, 1)?;
        self.consume_authorization(&authorization)?;
        self.advance()?;
        let lease = ServiceLease {
            lease_id: self.next_id("service-lease")?,
            order_id: order_id.into(),
            node_id,
            accepted_quote,
            accepted_height: self.height,
        };
        self.service_leases
            .insert(lease.lease_id.clone(), lease.clone());
        self.service_orders
            .get_mut(order_id)
            .expect("order was checked")
            .status = ServiceStatus::Leased;
        Ok(lease)
    }

    pub fn complete_service(
        &mut self,
        lease_id: &str,
        proof_hash: String,
        authorization: SignedActionAuthorization,
    ) -> Result<ServiceReceipt, LedgerError> {
        if proof_hash.trim().is_empty() {
            return Err(LedgerError::Invalid("work proof is required".into()));
        }
        let lease = self
            .service_leases
            .get(lease_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceLeaseNotFound(lease_id.into()))?;
        let payload_hash = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                lease_id.as_bytes(),
                lease.node_id.as_bytes(),
                proof_hash.as_bytes(),
            ],
        );
        self.verify_node_authorization(
            &authorization,
            &lease.node_id,
            "COMPLETE_SERVICE",
            &payload_hash,
        )?;
        let order = self
            .service_orders
            .get(&lease.order_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceOrderNotFound(lease.order_id.clone()))?;
        if self
            .protocol_reserve_commitments
            .get(&order.order_id)
            .is_some_and(|commitment| commitment.settled_amount.is_none())
        {
            return Err(LedgerError::Invalid(
                "protocol-funded work requires dual-QC completion".into(),
            ));
        }
        if order.status != ServiceStatus::Leased {
            return Err(LedgerError::ServiceState);
        }
        let escrow = self
            .coins
            .get(&order.escrow_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(order.escrow_coin_id.clone()))?;
        if escrow.state != CoinState::Reserved {
            return Err(LedgerError::ServiceState);
        }
        self.require_local_value_commitment(&order.order_id, order.budget)?;
        let refund = order.budget.checked_sub(lease.accepted_quote)?;
        let next_version = Self::checked_next_coin_version(escrow.version)?;
        let sequence_steps = 2 + u64::from(!refund.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;

        self.consume_authorization(&authorization)?;
        self.advance()?;
        self.consume_coin(&escrow.object_id)?;
        let reward = self.make_coin(
            lease.node_id.clone(),
            lease.accepted_quote,
            CoinState::Spendable,
            vec![escrow.object_id.clone()],
            Some(escrow.lineage_root.clone()),
            None,
            escrow.imported_from.clone(),
            next_version,
        )?;
        self.coins.insert(reward.object_id.clone(), reward);
        if !refund.is_zero() {
            let refund_coin = self.make_coin(
                order.buyer.clone(),
                refund,
                CoinState::Spendable,
                vec![escrow.object_id],
                Some(escrow.lineage_root),
                None,
                escrow.imported_from,
                next_version,
            )?;
            self.coins
                .insert(refund_coin.object_id.clone(), refund_coin);
        }
        let receipt = ServiceReceipt {
            receipt_id: self.next_id("service-receipt")?,
            order_id: order.order_id.clone(),
            lease_id: lease.lease_id,
            node_id: lease.node_id.clone(),
            role: order.role.clone(),
            amount: lease.accepted_quote,
            proof_hash,
            completed_height: self.height,
            bootstrap: false,
            protocol_reserve_pool: None,
        };
        self.service_receipts
            .insert(receipt.receipt_id.clone(), receipt.clone());
        self.service_orders
            .get_mut(&order.order_id)
            .expect("order was checked")
            .status = ServiceStatus::Completed;
        self.record_earnings(
            &lease.node_id,
            &order.role,
            lease.accepted_quote,
            &receipt.receipt_id,
        )?;
        self.assert_conservation()?;
        Ok(receipt)
    }

    pub fn complete_protocol_service(
        &mut self,
        lease_id: &str,
        proof_hash: String,
        authorization: SignedActionAuthorization,
        validator_qc: QuorumCertificate,
        notary_qc: QuorumCertificate,
    ) -> Result<ServiceReceipt, LedgerError> {
        if !self.descriptor.testnet {
            return Err(LedgerError::Invalid(
                "mainnet protocol reserve release requires EconomicReleaseEvidence".into(),
            ));
        }
        if proof_hash.trim().is_empty() {
            return Err(LedgerError::Invalid("work proof is required".into()));
        }
        let lease = self
            .service_leases
            .get(lease_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceLeaseNotFound(lease_id.into()))?;
        let order = self
            .service_orders
            .get(&lease.order_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceOrderNotFound(lease.order_id.clone()))?;
        if order.status != ServiceStatus::Leased {
            return Err(LedgerError::ServiceState);
        }
        let commitment = self
            .protocol_reserve_commitments
            .get(&order.order_id)
            .cloned()
            .filter(|commitment| commitment.settled_amount.is_none())
            .ok_or_else(|| {
                LedgerError::Invalid(
                    "service order has no active protocol reserve commitment".into(),
                )
            })?;
        if lease.accepted_quote > commitment.committed_amount {
            return Err(LedgerError::Supply(
                "lease quote exceeds its protocol reserve commitment".into(),
            ));
        }
        if let Some(receipt_id) = &commitment.matched_service_receipt_id {
            let matched = self.service_receipts.get(receipt_id).ok_or_else(|| {
                LedgerError::Invalid("matched service receipt was not found".into())
            })?;
            if matched.node_id != lease.node_id || matched.proof_hash != proof_hash {
                return Err(LedgerError::Invalid(
                    "demand-matched completion must reuse the certified node and work proof".into(),
                ));
            }
        }
        self.require_local_value_commitment(&order.order_id, commitment.committed_amount)?;

        let completion_claim = ProtocolServiceCompletionClaim {
            zone_id: self.descriptor.zone_id.clone(),
            order_id: order.order_id.clone(),
            lease_id: lease.lease_id.clone(),
            node_id: lease.node_id.clone(),
            role: order.role.clone(),
            amount: lease.accepted_quote,
            proof_hash: proof_hash.clone(),
            protocol_era: self.descriptor.protocol_era,
            crypto_era: self.descriptor.crypto_era,
        };
        let completion_subject = completion_claim.subject_hash();
        self.verify_local_dual_quorum(&completion_subject, &validator_qc, &notary_qc)?;

        let payload_hash = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                lease_id.as_bytes(),
                lease.node_id.as_bytes(),
                proof_hash.as_bytes(),
            ],
        );
        self.verify_node_authorization(
            &authorization,
            &lease.node_id,
            "COMPLETE_SERVICE",
            &payload_hash,
        )?;
        self.ensure_counter_headroom(1, 2)?;
        self.consume_authorization(&authorization)?;
        self.advance()?;

        let pool = commitment.reserve_pool;
        let pool_balance = match &pool {
            ProtocolReservePoolKind::StartupServices => &mut self.reserve_pools.startup_services,
            ProtocolReservePoolKind::ContinuityServices => {
                &mut self.reserve_pools.continuity_services
            }
            ProtocolReservePoolKind::DemandMatching => &mut self.reserve_pools.demand_matching,
        };
        *pool_balance = pool_balance.checked_sub(lease.accepted_quote)?;
        self.reserve = self.reserve.checked_sub(lease.accepted_quote)?;
        let lineage_root = hash_parts(&[
            self.descriptor.currency_genesis_root.as_bytes(),
            pool.wire_name().as_bytes(),
            order.order_id.as_bytes(),
        ]);
        let reward = self.make_coin(
            lease.node_id.clone(),
            lease.accepted_quote,
            CoinState::Spendable,
            Vec::new(),
            Some(lineage_root),
            None,
            None,
            1,
        )?;
        self.coins.insert(reward.object_id.clone(), reward);

        let receipt = ServiceReceipt {
            receipt_id: self.next_id("service-receipt")?,
            order_id: order.order_id.clone(),
            lease_id: lease.lease_id,
            node_id: lease.node_id.clone(),
            role: order.role.clone(),
            amount: lease.accepted_quote,
            proof_hash,
            completed_height: self.height,
            bootstrap: false,
            protocol_reserve_pool: Some(pool),
        };
        self.service_receipts
            .insert(receipt.receipt_id.clone(), receipt.clone());
        self.service_orders
            .get_mut(&order.order_id)
            .expect("order was checked")
            .status = ServiceStatus::Completed;
        self.protocol_reserve_commitments
            .get_mut(&order.order_id)
            .expect("commitment was checked")
            .settled_amount = Some(lease.accepted_quote);
        self.record_earnings(
            &lease.node_id,
            &order.role,
            lease.accepted_quote,
            &receipt.receipt_id,
        )?;
        self.assert_conservation()?;
        Ok(receipt)
    }

    pub fn register_economic_control_attestation(
        &mut self,
        attestation: EconomicControlAttestation,
    ) -> Result<EconomicControlAttestation, LedgerError> {
        let mut staged = self.clone();
        let registered = staged.apply_economic_control_attestation(attestation)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(registered)
    }

    fn apply_economic_control_attestation(
        &mut self,
        attestation: EconomicControlAttestation,
    ) -> Result<EconomicControlAttestation, LedgerError> {
        self.ensure_economic_counter_headroom(1, 0)?;
        if attestation.attestation_id.trim().is_empty()
            || !is_canonical_sha256_hex(&attestation.evidence_hash)
            || attestation.auditor_public_key.trim().is_empty()
            || attestation.auditor_control_group_id.trim().is_empty()
            || attestation.members.is_empty()
        {
            return Err(LedgerError::Economic(
                "control attestation is incomplete".into(),
            ));
        }
        if self
            .economic_control_attestations
            .contains_key(&attestation.attestation_id)
        {
            return Err(LedgerError::Duplicate(attestation.attestation_id));
        }
        if attestation.zone_id != self.descriptor.zone_id
            || attestation.protocol_era != self.descriptor.protocol_era
            || attestation.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Economic(
                "control attestation Zone or era mismatch".into(),
            ));
        }
        if attestation.issued_height > self.height || attestation.valid_until_height <= self.height
        {
            return Err(LedgerError::Economic(
                "control attestation is not currently valid".into(),
            ));
        }
        if attestation.members.windows(2).any(|members| {
            members[0].subject_id.is_empty() || members[0].subject_id >= members[1].subject_id
        }) || attestation
            .members
            .last()
            .is_some_and(|member| member.subject_id.is_empty())
        {
            return Err(LedgerError::Economic(
                "control members must be nonempty, unique and sorted by subject id".into(),
            ));
        }

        let mut roles = BTreeSet::new();
        let mut validator_keys = BTreeSet::new();
        let mut notary_keys = BTreeSet::new();
        let mut validator_group_bps = BTreeMap::<String, u32>::new();
        let mut total_validator_bps = 0u32;
        for member in &attestation.members {
            if member.control_group_id.trim().is_empty()
                || member.control_group_id == attestation.auditor_control_group_id
            {
                return Err(LedgerError::Economic(
                    "control group is empty or affiliated with the auditor".into(),
                ));
            }
            roles.insert(member.role);
            if member.role == EconomicControlRole::Validator {
                validator_keys.insert(member.subject_id.clone());
                total_validator_bps = total_validator_bps
                    .checked_add(member.validator_vote_bps)
                    .ok_or_else(|| LedgerError::Economic("validator vote share overflow".into()))?;
                let group_bps = validator_group_bps
                    .entry(member.control_group_id.clone())
                    .or_default();
                *group_bps = group_bps
                    .checked_add(member.validator_vote_bps)
                    .ok_or_else(|| {
                        LedgerError::Economic("validator control-group share overflow".into())
                    })?;
                if *group_bps > MAX_ECONOMIC_CONTROL_GROUP_VALIDATOR_BPS {
                    return Err(LedgerError::Economic(
                        "one UBO control group exceeds the validator share cap".into(),
                    ));
                }
            } else if member.validator_vote_bps != 0 {
                return Err(LedgerError::Economic(
                    "only validator members may carry validator vote share".into(),
                ));
            }
            if member.role == EconomicControlRole::Notary {
                notary_keys.insert(member.subject_id.clone());
            }
        }
        let required_roles = [
            EconomicControlRole::Requester,
            EconomicControlRole::ServiceProvider,
            EconomicControlRole::Relay,
            EconomicControlRole::LiquidityProvider,
            EconomicControlRole::Validator,
            EconomicControlRole::Notary,
            EconomicControlRole::PriceSource,
        ];
        if required_roles.iter().any(|role| !roles.contains(role)) {
            return Err(LedgerError::Economic(
                "control attestation does not cover every economic role".into(),
            ));
        }
        if total_validator_bps != 10_000
            || validator_keys
                != self
                    .descriptor
                    .validator_keys
                    .iter()
                    .cloned()
                    .collect::<BTreeSet<_>>()
            || notary_keys
                != self
                    .descriptor
                    .notary_keys
                    .iter()
                    .cloned()
                    .collect::<BTreeSet<_>>()
        {
            return Err(LedgerError::Economic(
                "control attestation does not exactly map the configured validator/notary sets"
                    .into(),
            ));
        }

        let subject = attestation.subject_hash();
        crate::crypto::verify_bytes(
            &attestation.auditor_public_key,
            subject.as_bytes(),
            &attestation.auditor_signature,
        )
        .map_err(LedgerError::InvalidSignature)?;
        self.verify_local_dual_quorum(&subject, &attestation.validator_qc, &attestation.notary_qc)?;
        self.advance()?;
        self.economic_control_attestations
            .insert(attestation.attestation_id.clone(), attestation.clone());
        Ok(attestation)
    }

    pub fn register_economic_price_attestation(
        &mut self,
        attestation: EconomicPriceAttestation,
    ) -> Result<EconomicPriceAttestation, LedgerError> {
        let mut staged = self.clone();
        let registered = staged.apply_economic_price_attestation(attestation)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(registered)
    }

    fn apply_economic_price_attestation(
        &mut self,
        attestation: EconomicPriceAttestation,
    ) -> Result<EconomicPriceAttestation, LedgerError> {
        self.ensure_economic_counter_headroom(1, 0)?;
        if attestation.attestation_id.trim().is_empty()
            || attestation.work_id.trim().is_empty()
            || attestation.amount.is_zero()
            || !is_canonical_sha256_hex(&attestation.evidence_hash)
        {
            return Err(LedgerError::Economic(
                "price attestation is incomplete".into(),
            ));
        }
        if self
            .economic_price_attestations
            .contains_key(&attestation.attestation_id)
        {
            return Err(LedgerError::Duplicate(attestation.attestation_id));
        }
        if attestation.zone_id != self.descriptor.zone_id
            || attestation.issued_height > self.height
            || attestation.valid_until_height <= self.height
        {
            return Err(LedgerError::Economic(
                "price attestation is not currently valid for this Zone".into(),
            ));
        }
        let control = self
            .economic_control_attestations
            .get(&attestation.control_attestation_id)
            .ok_or_else(|| {
                LedgerError::Economic("price attestation has no persisted control record".into())
            })?;
        if control.valid_until_height < attestation.valid_until_height {
            return Err(LedgerError::Economic(
                "price validity exceeds its control attestation".into(),
            ));
        }
        let member = Self::economic_member(control, &attestation.source_public_key)?;
        if member.role != EconomicControlRole::PriceSource
            || member.control_group_id != attestation.source_control_group_id
        {
            return Err(LedgerError::Economic(
                "price signer is not bound to the declared independent control group".into(),
            ));
        }
        crate::crypto::verify_bytes(
            &attestation.source_public_key,
            attestation.subject_hash().as_bytes(),
            &attestation.signature,
        )
        .map_err(LedgerError::InvalidSignature)?;
        self.advance()?;
        self.economic_price_attestations
            .insert(attestation.attestation_id.clone(), attestation.clone());
        Ok(attestation)
    }

    pub fn set_economic_release_policy(
        &mut self,
        policy: EconomicReleasePolicy,
    ) -> Result<EconomicReleasePolicy, LedgerError> {
        let mut staged = self.clone();
        let registered = staged.apply_economic_release_policy(policy)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(registered)
    }

    fn apply_economic_release_policy(
        &mut self,
        policy: EconomicReleasePolicy,
    ) -> Result<EconomicReleasePolicy, LedgerError> {
        self.ensure_economic_counter_headroom(1, 0)?;
        if policy.policy_id.trim().is_empty()
            || policy.era_id.trim().is_empty()
            || policy.era_release_cap.is_zero()
            || !policy.released.is_zero()
            || policy.starts_at_height > policy.ends_after_height
            || policy.ends_after_height <= self.height
            || policy.minimum_bond_coverage_bps < MIN_PROTOCOL_SERVICE_BOND_COVERAGE_BPS
        {
            return Err(LedgerError::Economic(
                "release policy is incomplete or unsafe".into(),
            ));
        }
        if policy.zone_id != self.descriptor.zone_id
            || policy.protocol_era != self.descriptor.protocol_era
            || policy.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Economic(
                "release policy Zone or protocol era mismatch".into(),
            ));
        }
        if self
            .economic_release_policies
            .contains_key(&policy.policy_id)
            || self.economic_release_policies.values().any(|existing| {
                existing.era_id == policy.era_id && existing.reserve_pool == policy.reserve_pool
            })
        {
            return Err(LedgerError::Duplicate(policy.policy_id));
        }
        let pool_balance = self.protocol_reserve_pool_balance(policy.reserve_pool);
        if policy.era_release_cap > pool_balance {
            return Err(LedgerError::Economic(
                "Era release cap exceeds the selected reserve pool".into(),
            ));
        }
        let subject = policy.subject_hash();
        self.verify_local_dual_quorum(&subject, &policy.validator_qc, &policy.notary_qc)?;
        self.advance()?;
        self.economic_release_policies
            .insert(policy.policy_id.clone(), policy.clone());
        Ok(policy)
    }

    pub fn lock_protocol_service_bond(
        &mut self,
        request: ProtocolServiceBondLockRequest,
    ) -> Result<ProtocolServiceBond, LedgerError> {
        let mut staged = self.clone();
        let bond = staged.apply_protocol_service_bond_lock(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(bond)
    }

    fn apply_protocol_service_bond_lock(
        &mut self,
        request: ProtocolServiceBondLockRequest,
    ) -> Result<ProtocolServiceBond, LedgerError> {
        self.ensure_economic_counter_headroom(1, 2)?;
        if request.bond_id.trim().is_empty()
            || request.amount.is_zero()
            || !is_canonical_sha256_hex(&request.slash_conditions_hash)
            || request.challenge_end_height <= self.height
            || request.unbond_after_height <= request.challenge_end_height
        {
            return Err(LedgerError::Economic(
                "service bond request is incomplete or has no delayed unbond window".into(),
            ));
        }
        if self.protocol_service_bonds.contains_key(&request.bond_id)
            || self.protocol_service_bonds.values().any(|bond| {
                bond.order_id == request.order_id
                    && bond.lease_id == request.lease_id
                    && bond.status != ProtocolServiceBondStatus::Unbonded
            })
        {
            return Err(LedgerError::Duplicate(request.bond_id));
        }
        let lease = self
            .service_leases
            .get(&request.lease_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceLeaseNotFound(request.lease_id.clone()))?;
        let order = self
            .service_orders
            .get(&request.order_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceOrderNotFound(request.order_id.clone()))?;
        if lease.order_id != order.order_id
            || order.status != ServiceStatus::Leased
            || self
                .protocol_reserve_commitments
                .get(&order.order_id)
                .is_none_or(|commitment| commitment.settled_amount.is_some())
        {
            return Err(LedgerError::Economic(
                "service bond is not bound to an active protocol lease".into(),
            ));
        }
        let payload_hash = action_payload_hash(
            "LOCK_PROTOCOL_SERVICE_BOND",
            &[
                request.bond_id.as_bytes(),
                request.order_id.as_bytes(),
                request.lease_id.as_bytes(),
                request.coin_id.as_bytes(),
                &request.amount.0.to_be_bytes(),
                &request.challenge_end_height.to_be_bytes(),
                &request.unbond_after_height.to_be_bytes(),
                request.slash_conditions_hash.as_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            "LOCK_PROTOCOL_SERVICE_BOND",
            &payload_hash,
        )?;
        self.verify_node_authorization(
            &request.authorization,
            &lease.node_id,
            "LOCK_PROTOCOL_SERVICE_BOND",
            &payload_hash,
        )?;
        let input = self
            .coins
            .get(&request.coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(request.coin_id.clone()))?;
        if input.state != CoinState::Spendable || input.owner != request.owner {
            return Err(LedgerError::CoinNotSpendable);
        }
        if request.amount > input.amount {
            return Err(LedgerError::Economic(
                "service bond exceeds its spendable input".into(),
            ));
        }
        let next_version = Self::checked_next_coin_version(input.version)?;

        self.consume_authorization(&request.authorization)?;
        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let escrow = self.make_coin(
            request.owner.clone(),
            request.amount,
            CoinState::Reserved,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins.insert(escrow.object_id.clone(), escrow.clone());
        let change = input.amount.checked_sub(request.amount)?;
        if !change.is_zero() {
            let change_coin = self.make_coin(
                request.owner.clone(),
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                input.imported_from,
                next_version,
            )?;
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let bond = ProtocolServiceBond {
            bond_id: request.bond_id.clone(),
            order_id: order.order_id,
            lease_id: lease.lease_id,
            owner: request.owner,
            provider_node_id: lease.node_id,
            escrow_coin_id: Some(escrow.object_id),
            locked_amount: request.amount,
            slashable_remaining: request.amount,
            slashed_amount: Amount::ZERO,
            slashed_coin_ids: Vec::new(),
            challenge_end_height: request.challenge_end_height,
            unbond_after_height: request.unbond_after_height,
            slash_conditions_hash: request.slash_conditions_hash,
            created_height: self.height,
            status: ProtocolServiceBondStatus::Locked,
        };
        self.protocol_service_bonds
            .insert(bond.bond_id.clone(), bond.clone());
        Ok(bond)
    }

    pub fn slash_protocol_service_bond(
        &mut self,
        slash: ProtocolServiceBondSlash,
    ) -> Result<ProtocolServiceBond, LedgerError> {
        let mut staged = self.clone();
        let bond = staged.apply_protocol_service_bond_slash(slash)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(bond)
    }

    fn apply_protocol_service_bond_slash(
        &mut self,
        slash: ProtocolServiceBondSlash,
    ) -> Result<ProtocolServiceBond, LedgerError> {
        self.ensure_economic_counter_headroom(1, 2)?;
        if slash.slash_id.trim().is_empty()
            || slash.amount.is_zero()
            || !is_canonical_sha256_hex(&slash.evidence_hash)
        {
            return Err(LedgerError::Economic("bond slash is incomplete".into()));
        }
        if self.economic_bond_slash_ids.contains(&slash.slash_id) {
            return Err(LedgerError::Duplicate(slash.slash_id));
        }
        let bond = self
            .protocol_service_bonds
            .get(&slash.bond_id)
            .cloned()
            .ok_or_else(|| LedgerError::Economic("service bond was not found".into()))?;
        if !matches!(
            bond.status,
            ProtocolServiceBondStatus::Locked | ProtocolServiceBondStatus::PartiallySlashed
        ) || self.height >= bond.challenge_end_height
            || slash.amount > bond.slashable_remaining
        {
            return Err(LedgerError::Economic(
                "service bond is not slashable for this amount".into(),
            ));
        }
        let escrow_id = bond
            .escrow_coin_id
            .clone()
            .ok_or_else(|| LedgerError::Economic("bond has no slashable escrow".into()))?;
        let escrow = self
            .coins
            .get(&escrow_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(escrow_id.clone()))?;
        if escrow.state != CoinState::Reserved
            || escrow.owner != bond.owner
            || escrow.amount != bond.slashable_remaining
        {
            return Err(LedgerError::Economic(
                "persisted service bond escrow does not match the coin ledger".into(),
            ));
        }
        let subject = slash.subject_hash();
        self.verify_local_dual_quorum(&subject, &slash.validator_qc, &slash.notary_qc)?;
        let remaining = bond.slashable_remaining.checked_sub(slash.amount)?;
        let slashed_total = bond.slashed_amount.checked_add(slash.amount)?;
        let next_version = Self::checked_next_coin_version(escrow.version)?;

        self.advance()?;
        self.consume_coin(&escrow_id)?;
        let slashed_coin = self.make_coin(
            "rld:protocol:slashed-funds".into(),
            slash.amount,
            CoinState::Reserved,
            vec![escrow.object_id.clone()],
            Some(escrow.lineage_root.clone()),
            None,
            escrow.imported_from.clone(),
            next_version,
        )?;
        self.coins
            .insert(slashed_coin.object_id.clone(), slashed_coin.clone());
        let remaining_coin_id = if remaining.is_zero() {
            None
        } else {
            let remaining_coin = self.make_coin(
                bond.owner.clone(),
                remaining,
                CoinState::Reserved,
                vec![escrow.object_id],
                Some(escrow.lineage_root),
                None,
                escrow.imported_from,
                next_version,
            )?;
            let id = remaining_coin.object_id.clone();
            self.coins.insert(id.clone(), remaining_coin);
            Some(id)
        };
        self.economic_bond_slash_ids.insert(slash.slash_id);
        let stored = self
            .protocol_service_bonds
            .get_mut(&bond.bond_id)
            .expect("bond was checked");
        stored.escrow_coin_id = remaining_coin_id;
        stored.slashable_remaining = remaining;
        stored.slashed_amount = slashed_total;
        stored.slashed_coin_ids.push(slashed_coin.object_id);
        stored.status = if remaining.is_zero() {
            ProtocolServiceBondStatus::FullySlashed
        } else {
            ProtocolServiceBondStatus::PartiallySlashed
        };
        Ok(stored.clone())
    }

    pub fn unbond_protocol_service_bond(
        &mut self,
        bond_id: &str,
        authorization: SignedActionAuthorization,
    ) -> Result<ProtocolServiceBond, LedgerError> {
        let mut staged = self.clone();
        let bond = staged.apply_protocol_service_bond_unbond(bond_id, authorization)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(bond)
    }

    fn apply_protocol_service_bond_unbond(
        &mut self,
        bond_id: &str,
        authorization: SignedActionAuthorization,
    ) -> Result<ProtocolServiceBond, LedgerError> {
        self.ensure_economic_counter_headroom(1, 1)?;
        let bond = self
            .protocol_service_bonds
            .get(bond_id)
            .cloned()
            .ok_or_else(|| LedgerError::Economic("service bond was not found".into()))?;
        if !matches!(
            bond.status,
            ProtocolServiceBondStatus::Locked | ProtocolServiceBondStatus::PartiallySlashed
        ) || self.height < bond.unbond_after_height
            || bond.slashable_remaining.is_zero()
        {
            return Err(LedgerError::Economic(
                "service bond has not reached its delayed unbond height".into(),
            ));
        }
        let payload_hash = action_payload_hash(
            "UNBOND_PROTOCOL_SERVICE_BOND",
            &[
                bond_id.as_bytes(),
                &bond.slashable_remaining.0.to_be_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &authorization,
            &bond.owner,
            "UNBOND_PROTOCOL_SERVICE_BOND",
            &payload_hash,
        )?;
        self.verify_node_authorization(
            &authorization,
            &bond.provider_node_id,
            "UNBOND_PROTOCOL_SERVICE_BOND",
            &payload_hash,
        )?;
        let escrow_id = bond
            .escrow_coin_id
            .clone()
            .ok_or_else(|| LedgerError::Economic("bond has no unbondable escrow".into()))?;
        let escrow = self
            .coins
            .get(&escrow_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(escrow_id.clone()))?;
        if escrow.state != CoinState::Reserved
            || escrow.owner != bond.owner
            || escrow.amount != bond.slashable_remaining
        {
            return Err(LedgerError::Economic(
                "persisted service bond escrow does not match the coin ledger".into(),
            ));
        }
        let next_version = Self::checked_next_coin_version(escrow.version)?;

        self.consume_authorization(&authorization)?;
        self.advance()?;
        self.consume_coin(&escrow_id)?;
        let returned = self.make_coin(
            bond.owner.clone(),
            bond.slashable_remaining,
            CoinState::Spendable,
            vec![escrow.object_id],
            Some(escrow.lineage_root),
            None,
            escrow.imported_from,
            next_version,
        )?;
        self.coins.insert(returned.object_id.clone(), returned);
        let stored = self
            .protocol_service_bonds
            .get_mut(bond_id)
            .expect("bond was checked");
        stored.escrow_coin_id = None;
        stored.slashable_remaining = Amount::ZERO;
        stored.status = ProtocolServiceBondStatus::Unbonded;
        Ok(stored.clone())
    }

    pub fn release_protocol_reserve(
        &mut self,
        request: ProtocolReserveReleaseRequest,
    ) -> Result<ProtocolReserveReleaseRecord, LedgerError> {
        let mut staged = self.clone();
        let release = staged.apply_protocol_reserve_release(request)?;
        staged.assert_conservation()?;
        *self = staged;
        Ok(release)
    }

    fn apply_protocol_reserve_release(
        &mut self,
        request: ProtocolReserveReleaseRequest,
    ) -> Result<ProtocolReserveReleaseRecord, LedgerError> {
        self.ensure_economic_counter_headroom(1, 2)?;
        if request.release_id.trim().is_empty()
            || request.work_id.trim().is_empty()
            || request.work_id
                != ProtocolReserveReleaseRequest::derive_work_id(
                    &request.requester_subject_id,
                    &request.work_proof_hash,
                )
            || !is_canonical_sha256_hex(&request.work_proof_hash)
            || request.reward.is_zero()
            || !Self::is_sorted_unique_nonempty(&request.fee_receipt_ids)
            || request.price_attestation_ids.len() < 2
            || !Self::is_sorted_unique_nonempty(&request.price_attestation_ids)
        {
            return Err(LedgerError::Economic(
                "reserve release request is incomplete or non-canonical".into(),
            ));
        }
        let completion_subject = request.completion_subject_hash();
        if self
            .protocol_reserve_releases
            .contains_key(&request.release_id)
            || self.economic_consumed_work_ids.contains(&request.work_id)
            || self
                .economic_consumed_completion_qcs
                .contains(&completion_subject)
            || request
                .fee_receipt_ids
                .iter()
                .any(|id| self.economic_consumed_fee_receipts.contains(id))
        {
            return Err(LedgerError::Duplicate(request.release_id));
        }
        let lease = self
            .service_leases
            .get(&request.lease_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceLeaseNotFound(request.lease_id.clone()))?;
        let order = self
            .service_orders
            .get(&request.order_id)
            .cloned()
            .ok_or_else(|| LedgerError::ServiceOrderNotFound(request.order_id.clone()))?;
        let commitment = self
            .protocol_reserve_commitments
            .get(&request.order_id)
            .cloned()
            .filter(|commitment| commitment.settled_amount.is_none())
            .ok_or_else(|| LedgerError::Economic("protocol commitment is not active".into()))?;
        if lease.order_id != order.order_id
            || order.status != ServiceStatus::Leased
            || request.reward != lease.accepted_quote
            || request.reward > order.budget
            || request.reward > commitment.committed_amount
        {
            return Err(LedgerError::Economic(
                "release amount is not bound to the active order and lease".into(),
            ));
        }
        if commitment
            .matched_service_receipt_id
            .as_ref()
            .is_some_and(|id| request.fee_receipt_ids.binary_search(id).is_err())
        {
            return Err(LedgerError::Economic(
                "release omits the receipt that justified its reserve commitment".into(),
            ));
        }
        self.require_local_value_commitment(&order.order_id, commitment.committed_amount)?;

        let control = self
            .economic_control_attestations
            .get(&request.control_attestation_id)
            .cloned()
            .ok_or_else(|| LedgerError::Economic("control attestation was not found".into()))?;
        if control.zone_id != self.descriptor.zone_id
            || control.protocol_era != self.descriptor.protocol_era
            || control.crypto_era != self.descriptor.crypto_era
            || control.issued_height > self.height
            || control.valid_until_height <= self.height
        {
            return Err(LedgerError::Economic(
                "control attestation is stale or has the wrong era".into(),
            ));
        }
        let persisted_control_subject = control.subject_hash();
        crate::crypto::verify_bytes(
            &control.auditor_public_key,
            persisted_control_subject.as_bytes(),
            &control.auditor_signature,
        )
        .map_err(LedgerError::InvalidSignature)?;
        self.verify_local_dual_quorum(
            &persisted_control_subject,
            &control.validator_qc,
            &control.notary_qc,
        )?;
        let requester = Self::economic_member(&control, &request.requester_subject_id)?;
        let provider = Self::economic_member(&control, &lease.node_id)?;
        if requester.role != EconomicControlRole::Requester
            || provider.role != EconomicControlRole::ServiceProvider
            || requester.control_group_id == provider.control_group_id
        {
            return Err(LedgerError::Economic(
                "requester/provider ownership is missing or affiliated".into(),
            ));
        }
        let provider_payload =
            action_payload_hash("RELEASE_PROTOCOL_RESERVE", &[completion_subject.as_bytes()]);
        self.verify_node_authorization(
            &request.provider_authorization,
            &lease.node_id,
            "RELEASE_PROTOCOL_RESERVE",
            &provider_payload,
        )?;
        self.verify_local_dual_quorum(
            &completion_subject,
            &request.completion_validator_qc,
            &request.completion_notary_qc,
        )?;
        for signer in request
            .completion_validator_qc
            .attestations
            .iter()
            .map(|attestation| (&attestation.public_key, EconomicControlRole::Validator))
            .chain(
                request
                    .completion_notary_qc
                    .attestations
                    .iter()
                    .map(|attestation| (&attestation.public_key, EconomicControlRole::Notary)),
            )
        {
            if Self::economic_member(&control, signer.0)?.role != signer.1 {
                return Err(LedgerError::Economic(
                    "completion quorum signer has no matching persisted control role".into(),
                ));
            }
        }

        let mut attributable_fee = Amount::ZERO;
        let mut affiliated_recovery = Amount::ZERO;
        for receipt_id in &request.fee_receipt_ids {
            let receipt = self
                .service_receipts
                .get(receipt_id)
                .ok_or_else(|| LedgerError::Economic("fee receipt was not found".into()))?;
            let fee_order = self
                .service_orders
                .get(&receipt.order_id)
                .ok_or_else(|| LedgerError::ServiceOrderNotFound(receipt.order_id.clone()))?;
            let fee_lease = self
                .service_leases
                .get(&receipt.lease_id)
                .ok_or_else(|| LedgerError::ServiceLeaseNotFound(receipt.lease_id.clone()))?;
            if receipt.bootstrap
                || receipt.protocol_reserve_pool.is_some()
                || receipt.proof_hash != request.work_proof_hash
                || receipt.amount.is_zero()
                || fee_order.status != ServiceStatus::Completed
                || fee_order.buyer != request.requester_subject_id
                || fee_lease.order_id != fee_order.order_id
                || fee_lease.node_id != receipt.node_id
                || fee_lease.accepted_quote != receipt.amount
            {
                return Err(LedgerError::Economic(
                    "fee attribution is not a finalized user-funded part of this work".into(),
                ));
            }
            let earnings = self.node_earnings.get(&receipt.node_id).ok_or_else(|| {
                LedgerError::Economic("fee receipt has no persisted earnings record".into())
            })?;
            let role_key = format!("{:?}", receipt.role).to_uppercase();
            if !earnings.receipt_ids.contains(receipt_id)
                || earnings.total < receipt.amount
                || earnings
                    .by_role
                    .get(&role_key)
                    .is_none_or(|amount| *amount < receipt.amount)
            {
                return Err(LedgerError::Economic(
                    "fee receipt is not backed by actual node earnings".into(),
                ));
            }
            let recipient = Self::economic_member(&control, &receipt.node_id)?;
            let expected_role = Self::economic_role_for_service(&receipt.role);
            if recipient.role != expected_role {
                return Err(LedgerError::Economic(
                    "fee recipient has no matching persisted control role".into(),
                ));
            }
            attributable_fee = attributable_fee.checked_add(receipt.amount)?;
            if recipient.control_group_id == requester.control_group_id {
                affiliated_recovery = affiliated_recovery.checked_add(receipt.amount)?;
            }
        }
        let nonrecoverable_fee = attributable_fee.checked_sub(affiliated_recovery)?;
        if request.reward > nonrecoverable_fee {
            return Err(LedgerError::Economic(
                "reward exceeds same-work nonrecoverable user fees".into(),
            ));
        }

        let actor_groups = control
            .members
            .iter()
            .filter(|member| member.role != EconomicControlRole::PriceSource)
            .map(|member| member.control_group_id.clone())
            .chain(std::iter::once(control.auditor_control_group_id.clone()))
            .collect::<BTreeSet<_>>();
        let mut price_groups = BTreeSet::new();
        let mut independent_price_cap: Option<Amount> = None;
        for price_id in &request.price_attestation_ids {
            let price = self
                .economic_price_attestations
                .get(price_id)
                .ok_or_else(|| LedgerError::Economic("price attestation was not found".into()))?;
            if price.zone_id != self.descriptor.zone_id
                || price.work_id != request.work_id
                || price.control_attestation_id != request.control_attestation_id
                || price.issued_height > self.height
                || price.valid_until_height <= self.height
                || actor_groups.contains(&price.source_control_group_id)
            {
                return Err(LedgerError::Economic(
                    "price evidence is stale, unrelated or controlled by an economic actor".into(),
                ));
            }
            let source = Self::economic_member(&control, &price.source_public_key)?;
            if source.role != EconomicControlRole::PriceSource
                || source.control_group_id != price.source_control_group_id
            {
                return Err(LedgerError::Economic(
                    "price source ownership does not match persisted control evidence".into(),
                ));
            }
            crate::crypto::verify_bytes(
                &price.source_public_key,
                price.subject_hash().as_bytes(),
                &price.signature,
            )
            .map_err(LedgerError::InvalidSignature)?;
            price_groups.insert(price.source_control_group_id.clone());
            independent_price_cap = Some(match independent_price_cap {
                Some(cap) if cap <= price.amount => cap,
                _ => price.amount,
            });
        }
        if price_groups.len() < 2 {
            return Err(LedgerError::Economic(
                "at least two independent price-source UBO groups are required".into(),
            ));
        }
        let independent_price_cap = independent_price_cap.expect("two prices were checked");
        if request.reward > independent_price_cap {
            return Err(LedgerError::Economic(
                "reward exceeds the conservative independent price cap".into(),
            ));
        }

        let bond = self
            .protocol_service_bonds
            .get(&request.bond_id)
            .cloned()
            .ok_or_else(|| LedgerError::Economic("service bond was not found".into()))?;
        let bond_owner = Self::economic_member(&control, &bond.owner)?;
        let bond_escrow_id = bond
            .escrow_coin_id
            .as_ref()
            .ok_or_else(|| LedgerError::Economic("service bond has no escrow".into()))?;
        let bond_escrow = self
            .coins
            .get(bond_escrow_id)
            .ok_or_else(|| LedgerError::CoinNotFound(bond_escrow_id.clone()))?;
        if bond.order_id != order.order_id
            || bond.lease_id != lease.lease_id
            || bond.provider_node_id != lease.node_id
            || bond_owner.role != EconomicControlRole::ServiceProvider
            || bond_owner.control_group_id != provider.control_group_id
            || !matches!(
                bond.status,
                ProtocolServiceBondStatus::Locked | ProtocolServiceBondStatus::PartiallySlashed
            )
            || self.height >= bond.challenge_end_height
            || bond.unbond_after_height <= self.height
            || bond_escrow.state != CoinState::Reserved
            || bond_escrow.owner != bond.owner
            || bond_escrow.amount != bond.slashable_remaining
        {
            return Err(LedgerError::Economic(
                "release is not backed by the provider's live slashable bond".into(),
            ));
        }

        let policy = self
            .economic_release_policies
            .get(&request.release_policy_id)
            .cloned()
            .ok_or_else(|| LedgerError::Economic("release policy was not found".into()))?;
        if policy.zone_id != self.descriptor.zone_id
            || policy.protocol_era != self.descriptor.protocol_era
            || policy.crypto_era != self.descriptor.crypto_era
            || policy.reserve_pool != commitment.reserve_pool
            || self.height < policy.starts_at_height
            || self.height >= policy.ends_after_height
        {
            return Err(LedgerError::Economic(
                "release policy is inactive or targets another reserve pool".into(),
            ));
        }
        self.verify_local_dual_quorum(
            &policy.subject_hash(),
            &policy.validator_qc,
            &policy.notary_qc,
        )?;
        let required_bond =
            Self::checked_bps_ceil(request.reward, policy.minimum_bond_coverage_bps)?;
        if bond.locked_amount < required_bond || bond.slashable_remaining < required_bond {
            return Err(LedgerError::Economic(
                "provider bond is below the release policy coverage floor".into(),
            ));
        }
        let next_released = policy.released.checked_add(request.reward)?;
        if next_released > policy.era_release_cap {
            return Err(LedgerError::Economic(
                "release exceeds the checked per-Era reserve-pool cap".into(),
            ));
        }
        let pool_balance = self.protocol_reserve_pool_balance(commitment.reserve_pool);
        if request.reward > pool_balance || request.reward > self.reserve {
            return Err(LedgerError::Supply(
                "protocol reserve pool cannot fund this release".into(),
            ));
        }

        self.consume_authorization(&request.provider_authorization)?;
        self.advance()?;
        *self.protocol_reserve_pool_balance_mut(commitment.reserve_pool) =
            pool_balance.checked_sub(request.reward)?;
        self.reserve = self.reserve.checked_sub(request.reward)?;
        let lineage_root = hash_parts(&[
            self.descriptor.currency_genesis_root.as_bytes(),
            commitment.reserve_pool.wire_name().as_bytes(),
            order.order_id.as_bytes(),
            request.work_id.as_bytes(),
        ]);
        let reward_coin = self.make_coin(
            lease.node_id.clone(),
            request.reward,
            CoinState::Spendable,
            Vec::new(),
            Some(lineage_root),
            None,
            None,
            1,
        )?;
        self.coins
            .insert(reward_coin.object_id.clone(), reward_coin);
        let receipt = ServiceReceipt {
            receipt_id: self.next_id("service-receipt")?,
            order_id: order.order_id.clone(),
            lease_id: lease.lease_id.clone(),
            node_id: lease.node_id.clone(),
            role: order.role.clone(),
            amount: request.reward,
            proof_hash: request.work_proof_hash.clone(),
            completed_height: self.height,
            bootstrap: false,
            protocol_reserve_pool: Some(commitment.reserve_pool),
        };
        self.record_earnings(
            &lease.node_id,
            &order.role,
            request.reward,
            &receipt.receipt_id,
        )?;
        self.service_receipts
            .insert(receipt.receipt_id.clone(), receipt.clone());
        self.service_orders
            .get_mut(&order.order_id)
            .expect("order was checked")
            .status = ServiceStatus::Completed;
        self.protocol_reserve_commitments
            .get_mut(&order.order_id)
            .expect("commitment was checked")
            .settled_amount = Some(request.reward);
        self.economic_release_policies
            .get_mut(&policy.policy_id)
            .expect("policy was checked")
            .released = next_released;
        self.economic_consumed_work_ids
            .insert(request.work_id.clone());
        self.economic_consumed_completion_qcs
            .insert(completion_subject.clone());
        self.economic_consumed_fee_receipts
            .extend(request.fee_receipt_ids.iter().cloned());
        let record = ProtocolReserveReleaseRecord {
            release_id: request.release_id.clone(),
            order_id: order.order_id,
            lease_id: lease.lease_id,
            receipt_id: receipt.receipt_id,
            requester_subject_id: request.requester_subject_id,
            work_id: request.work_id,
            work_proof_hash: request.work_proof_hash,
            completion_subject_hash: completion_subject,
            completion_validator_qc: request.completion_validator_qc,
            completion_notary_qc: request.completion_notary_qc,
            fee_receipt_ids: request.fee_receipt_ids,
            control_attestation_id: request.control_attestation_id,
            price_attestation_ids: request.price_attestation_ids,
            bond_id: request.bond_id,
            bond_locked_amount: bond.locked_amount,
            bond_slashable_amount: bond.slashable_remaining,
            bond_slashed_amount: bond.slashed_amount,
            bond_challenge_end_height: bond.challenge_end_height,
            bond_unbond_after_height: bond.unbond_after_height,
            bond_slash_conditions_hash: bond.slash_conditions_hash,
            release_policy_id: request.release_policy_id,
            era_id: policy.era_id,
            era_release_cap: policy.era_release_cap,
            era_released_before: policy.released,
            pool_balance_before: pool_balance,
            minimum_bond_coverage_bps: policy.minimum_bond_coverage_bps,
            reserve_pool: commitment.reserve_pool,
            attributable_fee,
            affiliated_recovery,
            nonrecoverable_fee,
            independent_price_cap,
            reward: request.reward,
            released_height: self.height,
        };
        self.protocol_reserve_releases
            .insert(record.release_id.clone(), record.clone());
        Ok(record)
    }

    pub fn set_zone_trust_policy(
        &mut self,
        zone_id: String,
        policy: ZoneTrustPolicy,
    ) -> Result<(), LedgerError> {
        self.ensure_counter_headroom(1, 0)?;
        if policy == ZoneTrustPolicy::Quarantined {
            self.quarantined_zones.insert(zone_id.clone());
        } else {
            self.quarantined_zones.remove(&zone_id);
        }
        self.zone_trust_policies.insert(zone_id, policy);
        self.advance()?;
        self.create_checkpoint()?;
        Ok(())
    }

    pub fn trust_zone_checkpoint(
        &mut self,
        zone_id: String,
        checkpoint_hash: String,
    ) -> Result<(), LedgerError> {
        if zone_id.trim().is_empty() || checkpoint_hash.trim().is_empty() {
            return Err(LedgerError::Invalid(
                "Zone id and checkpoint hash are required".into(),
            ));
        }
        self.ensure_counter_headroom(1, 0)?;
        self.trusted_zone_checkpoints
            .entry(zone_id)
            .or_default()
            .insert(checkpoint_hash);
        self.advance()?;
        self.create_checkpoint()?;
        Ok(())
    }

    pub fn create_gateway_bond(
        &mut self,
        request: CreateGatewayBondRequest,
    ) -> Result<GatewayBond, LedgerError> {
        if request.source_zone.trim().is_empty() || request.gateway_public_key.trim().is_empty() {
            return Err(LedgerError::Invalid(
                "source Zone and gateway public key are required".into(),
            ));
        }
        let payload_hash = action_payload_hash(
            "CREATE_GATEWAY_BOND",
            &[
                request.source_zone.as_bytes(),
                request.owner.as_bytes(),
                request.gateway_public_key.as_bytes(),
                request.coin_id.as_bytes(),
                &request.amount.0.to_be_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &request.authorization,
            &request.owner,
            "CREATE_GATEWAY_BOND",
            &payload_hash,
        )?;
        let input = self
            .coins
            .get(&request.coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(request.coin_id.clone()))?;
        if input.state != CoinState::Spendable || input.owner != request.owner {
            return Err(LedgerError::OwnerMismatch);
        }
        if request.amount.is_zero() || request.amount > input.amount {
            return Err(LedgerError::Invalid("invalid gateway bond amount".into()));
        }
        let change = input.amount.checked_sub(request.amount)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 2 + u64::from(!change.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;

        self.consume_authorization(&request.authorization)?;
        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let escrow = self.make_coin(
            request.owner.clone(),
            request.amount,
            CoinState::Reserved,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins.insert(escrow.object_id.clone(), escrow.clone());
        if !change.is_zero() {
            let change_coin = self.make_coin(
                request.owner.clone(),
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                input.imported_from,
                next_version,
            )?;
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let bond = GatewayBond {
            bond_id: self.next_id("gateway-bond")?,
            source_zone: request.source_zone,
            owner: request.owner,
            gateway_public_key: request.gateway_public_key,
            amount: request.amount,
            escrow_coin_id: escrow.object_id,
            status: GatewayBondStatus::Active,
            created_height: self.height,
        };
        self.gateway_bonds
            .insert(bond.bond_id.clone(), bond.clone());
        self.assert_conservation()?;
        Ok(bond)
    }

    pub fn create_traveler_capsule(
        &mut self,
        intent: UniversalPaymentIntent,
        transport: TransportClass,
    ) -> Result<TravelerCarryCapsule, LedgerError> {
        let mut staged = self.clone();
        let capsule = staged.apply_create_traveler_capsule(intent, transport)?;
        *self = staged;
        Ok(capsule)
    }

    fn apply_create_traveler_capsule(
        &mut self,
        intent: UniversalPaymentIntent,
        transport: TransportClass,
    ) -> Result<TravelerCarryCapsule, LedgerError> {
        let owner = intent.recipient.clone();
        let transit = self.export_payment(intent, transport)?;
        let capsule_id = self.next_id("traveler-capsule")?;
        let capsule = TravelerCarryCapsule {
            capsule_id,
            owner,
            issued_height: self.height,
            transit,
        };
        self.traveler_capsules
            .insert(capsule.capsule_id.clone(), capsule.clone());
        Ok(capsule)
    }

    pub fn import_traveler_capsule(
        &mut self,
        capsule: TravelerCarryCapsule,
    ) -> Result<DestinationImportReceipt, LedgerError> {
        if capsule.owner != capsule.transit.recipient {
            return Err(LedgerError::Invalid(
                "traveler capsule owner does not match recipient".into(),
            ));
        }
        self.import_capsule(capsule.transit)
    }

    pub fn open_voyage_escrow(
        &mut self,
        payer: String,
        coin_id: String,
        transit_id: String,
        budget: Amount,
        max_reward_per_hop: Amount,
        authorization: SignedActionAuthorization,
    ) -> Result<AdaptiveVoyageEscrow, LedgerError> {
        let payload_hash = action_payload_hash(
            "OPEN_VOYAGE_ESCROW",
            &[
                payer.as_bytes(),
                coin_id.as_bytes(),
                transit_id.as_bytes(),
                &budget.0.to_be_bytes(),
                &max_reward_per_hop.0.to_be_bytes(),
            ],
        );
        self.verify_owner_authorization(
            &authorization,
            &payer,
            "OPEN_VOYAGE_ESCROW",
            &payload_hash,
        )?;
        let transit = self
            .transits
            .get(&transit_id)
            .ok_or_else(|| LedgerError::TransitNotFound(transit_id.clone()))?;
        let destination_zone = transit.destination_zone.clone();
        let input = self
            .coins
            .get(&coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.clone()))?;
        if input.state != CoinState::Spendable || input.owner != payer {
            return Err(LedgerError::OwnerMismatch);
        }
        if budget.is_zero()
            || max_reward_per_hop.is_zero()
            || budget > input.amount
            || max_reward_per_hop > budget
        {
            return Err(LedgerError::Invalid("invalid voyage escrow budget".into()));
        }
        let next_value_total = self.next_value_risk_total(ValueRiskPath::LocalPayment, budget)?;
        let change = input.amount.checked_sub(budget)?;
        let next_version = Self::checked_next_coin_version(input.version)?;
        let sequence_steps = 2 + u64::from(!change.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;

        self.consume_authorization(&authorization)?;
        self.advance()?;
        self.consume_coin(&input.object_id)?;
        let escrow_coin = self.make_coin(
            payer.clone(),
            budget,
            CoinState::Reserved,
            vec![input.object_id.clone()],
            Some(input.lineage_root.clone()),
            None,
            input.imported_from.clone(),
            next_version,
        )?;
        self.coins
            .insert(escrow_coin.object_id.clone(), escrow_coin.clone());
        if !change.is_zero() {
            let change_coin = self.make_coin(
                payer.clone(),
                change,
                CoinState::Spendable,
                vec![input.object_id],
                Some(input.lineage_root),
                None,
                input.imported_from,
                next_version,
            )?;
            self.coins
                .insert(change_coin.object_id.clone(), change_coin);
        }
        let voyage = AdaptiveVoyageEscrow {
            voyage_id: self.next_id("voyage")?,
            transit_id,
            payer,
            destination_zone,
            original_budget: budget,
            remaining_budget: budget,
            max_reward_per_hop,
            escrow_coin_id: Some(escrow_coin.object_id),
            settled_proof_hashes: Vec::new(),
            status: VoyageStatus::Open,
            created_height: self.height,
        };
        self.voyage_escrows
            .insert(voyage.voyage_id.clone(), voyage.clone());
        self.record_value_risk_commitment(
            ValueRiskPath::LocalPayment,
            voyage.voyage_id.clone(),
            voyage.original_budget,
            next_value_total,
        );
        self.assert_conservation()?;
        Ok(voyage)
    }

    pub fn settle_voyage_hop(
        &mut self,
        voyage_id: &str,
        node_id: String,
        amount: Amount,
        downstream_receipt_hash: String,
        authorization: SignedActionAuthorization,
    ) -> Result<VoyageServiceReceipt, LedgerError> {
        let payload_hash = action_payload_hash(
            "SETTLE_VOYAGE_HOP",
            &[
                voyage_id.as_bytes(),
                node_id.as_bytes(),
                &amount.0.to_be_bytes(),
                downstream_receipt_hash.as_bytes(),
            ],
        );
        self.verify_node_authorization(
            &authorization,
            &node_id,
            "SETTLE_VOYAGE_HOP",
            &payload_hash,
        )?;
        let voyage = self
            .voyage_escrows
            .get(voyage_id)
            .cloned()
            .ok_or_else(|| LedgerError::VoyageNotFound(voyage_id.into()))?;
        if voyage.status != VoyageStatus::Open
            || node_id == voyage.payer
            || amount.is_zero()
            || amount > voyage.max_reward_per_hop
            || amount > voyage.remaining_budget
            || downstream_receipt_hash.trim().is_empty()
            || voyage
                .settled_proof_hashes
                .contains(&downstream_receipt_hash)
        {
            return Err(LedgerError::ServiceState);
        }
        let escrow_coin_id = voyage.escrow_coin_id.ok_or(LedgerError::ServiceState)?;
        let escrow_coin = self
            .coins
            .get(&escrow_coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(escrow_coin_id.clone()))?;
        if escrow_coin.state != CoinState::Reserved || escrow_coin.amount != voyage.remaining_budget
        {
            return Err(LedgerError::ServiceState);
        }
        self.require_local_value_commitment(&voyage.voyage_id, voyage.original_budget)?;
        let remaining = voyage.remaining_budget.checked_sub(amount)?;
        let next_version = Self::checked_next_coin_version(escrow_coin.version)?;
        let sequence_steps = 2 + u64::from(!remaining.is_zero());
        self.ensure_counter_headroom(1, sequence_steps)?;

        self.consume_authorization(&authorization)?;
        self.advance()?;
        self.consume_coin(&escrow_coin_id)?;
        let reward = self.make_coin(
            node_id.clone(),
            amount,
            CoinState::Spendable,
            vec![escrow_coin.object_id.clone()],
            Some(escrow_coin.lineage_root.clone()),
            None,
            escrow_coin.imported_from.clone(),
            next_version,
        )?;
        self.coins.insert(reward.object_id.clone(), reward);
        let next_escrow_coin_id = if remaining.is_zero() {
            None
        } else {
            let next = self.make_coin(
                voyage.payer.clone(),
                remaining,
                CoinState::Reserved,
                vec![escrow_coin.object_id],
                Some(escrow_coin.lineage_root),
                None,
                escrow_coin.imported_from,
                next_version,
            )?;
            let id = next.object_id.clone();
            self.coins.insert(id.clone(), next);
            Some(id)
        };
        let receipt = VoyageServiceReceipt {
            receipt_id: self.next_id("voyage-receipt")?,
            voyage_id: voyage_id.into(),
            transit_id: voyage.transit_id,
            node_id: node_id.clone(),
            amount,
            downstream_receipt_hash: downstream_receipt_hash.clone(),
            completed_height: self.height,
        };
        self.voyage_receipts
            .insert(receipt.receipt_id.clone(), receipt.clone());
        let record = self
            .voyage_escrows
            .get_mut(voyage_id)
            .expect("voyage was checked");
        record.remaining_budget = remaining;
        record.escrow_coin_id = next_escrow_coin_id;
        record.settled_proof_hashes.push(downstream_receipt_hash);
        if remaining.is_zero() {
            record.status = VoyageStatus::Completed;
        }
        self.record_earnings(&node_id, &ServiceRole::Relay, amount, &receipt.receipt_id)?;
        self.assert_conservation()?;
        Ok(receipt)
    }

    pub fn activate_testnet_era(
        &mut self,
        new_suite: CryptoSuiteDescriptor,
    ) -> Result<EraContinuityCertificate, LedgerError> {
        if !self.descriptor.testnet {
            return Err(LedgerError::TestnetOnly);
        }
        if !self.descriptor.validator_keys.is_empty() || !self.descriptor.notary_keys.is_empty() {
            return Err(LedgerError::EraTransition(
                "simulated era activation is disabled for configured signer sets; submit a signed certificate"
                    .into(),
            ));
        }
        let previous_certificate_hash = self
            .era_certificates
            .last()
            .map(|certificate| certificate.certificate_hash.clone())
            .unwrap_or_else(|| self.era_continuity_accumulator.clone());
        let activation_checkpoint = self
            .latest_checkpoint()
            .map(|checkpoint| checkpoint.checkpoint_hash.clone())
            .ok_or_else(|| LedgerError::EraTransition("activation checkpoint missing".into()))?;
        let new_protocol_era =
            self.descriptor.protocol_era.checked_add(1).ok_or_else(|| {
                LedgerError::EraTransition("protocol era counter overflow".into())
            })?;
        let new_crypto_era = self
            .descriptor
            .crypto_era
            .checked_add(1)
            .ok_or_else(|| LedgerError::EraTransition("crypto era counter overflow".into()))?;
        let irreversible_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("ledger height counter overflow".into()))?;
        let mut certificate = EraContinuityCertificate {
            zone_id: self.descriptor.zone_id.clone(),
            previous_protocol_era: self.descriptor.protocol_era,
            new_protocol_era,
            previous_crypto_era: self.descriptor.crypto_era,
            new_crypto_era,
            previous_certificate_hash,
            activation_checkpoint,
            irreversible_height,
            new_suite,
            previous_validator_keys: self.descriptor.validator_keys.clone(),
            previous_notary_keys: self.descriptor.notary_keys.clone(),
            new_validator_keys: self.descriptor.validator_keys.clone(),
            new_notary_keys: self.descriptor.notary_keys.clone(),
            old_crypto_qc: simulated_qc(),
            new_crypto_qc: simulated_qc(),
            notary_qc: simulated_qc(),
            certificate_hash: String::new(),
        };
        let subject = certificate.subject_hash();
        certificate.certificate_hash.clone_from(&subject);
        certificate.old_crypto_qc.subject_hash.clone_from(&subject);
        certificate.new_crypto_qc.subject_hash.clone_from(&subject);
        certificate.notary_qc.subject_hash = subject;
        self.apply_era_transition(certificate.clone())?;
        Ok(certificate)
    }

    pub fn apply_era_transition(
        &mut self,
        certificate: EraContinuityCertificate,
    ) -> Result<ContinuityCheckpoint, LedgerError> {
        let subject = certificate.subject_hash();
        let expected_protocol_era =
            self.descriptor.protocol_era.checked_add(1).ok_or_else(|| {
                LedgerError::EraTransition("protocol era counter overflow".into())
            })?;
        let expected_crypto_era = self
            .descriptor
            .crypto_era
            .checked_add(1)
            .ok_or_else(|| LedgerError::EraTransition("crypto era counter overflow".into()))?;
        let expected_height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("ledger height counter overflow".into()))?;
        if certificate.zone_id != self.descriptor.zone_id
            || certificate.previous_protocol_era != self.descriptor.protocol_era
            || certificate.previous_crypto_era != self.descriptor.crypto_era
            || certificate.new_protocol_era != expected_protocol_era
            || certificate.new_crypto_era != expected_crypto_era
            || certificate.previous_validator_keys != self.descriptor.validator_keys
            || certificate.previous_notary_keys != self.descriptor.notary_keys
            || certificate.certificate_hash != subject
            || certificate.old_crypto_qc.subject_hash != subject
            || certificate.new_crypto_qc.subject_hash != subject
            || certificate.notary_qc.subject_hash != subject
            || certificate.irreversible_height != expected_height
            || certificate.new_suite.suite_id.trim().is_empty()
        {
            return Err(LedgerError::EraTransition(
                "era certificate binding mismatch".into(),
            ));
        }
        let latest = self
            .latest_checkpoint()
            .map(|checkpoint| checkpoint.checkpoint_hash.as_str())
            .unwrap_or_default();
        if certificate.activation_checkpoint != latest {
            return Err(LedgerError::EraTransition(
                "activation checkpoint mismatch".into(),
            ));
        }
        let simulated = certificate.old_crypto_qc.testnet_simulated
            && certificate.new_crypto_qc.testnet_simulated
            && certificate.notary_qc.testnet_simulated;
        let simulation_allowed = self.descriptor.testnet
            && certificate.previous_validator_keys.is_empty()
            && certificate.previous_notary_keys.is_empty()
            && certificate.new_validator_keys.is_empty()
            && certificate.new_notary_keys.is_empty();
        if simulated && !simulation_allowed {
            return Err(LedgerError::InvalidQuorum(
                "simulated era quorum is forbidden for a configured signer set".into(),
            ));
        }
        if !simulated {
            certificate
                .old_crypto_qc
                .verify(&certificate.previous_validator_keys)
                .map_err(LedgerError::InvalidQuorum)?;
            certificate
                .new_crypto_qc
                .verify(&certificate.new_validator_keys)
                .map_err(LedgerError::InvalidQuorum)?;
            certificate
                .notary_qc
                .verify(&certificate.previous_notary_keys)
                .map_err(LedgerError::InvalidQuorum)?;
        }
        if self
            .stake_resource_accounting
            .as_ref()
            .is_some_and(StakeStateResourceAccountingV1::has_accounted_value)
        {
            return Err(LedgerError::EraTransition(
                "stake resource accounting carries value and no cross-era migration exists".into(),
            ));
        }
        self.ensure_counter_headroom(1, 0)?;
        let mut staged = self.clone();
        staged.advance()?;
        // R6.19 has no authenticated cross-era resource-accounting migration.
        // A value-empty policy plane can be retired safely; immutable governance
        // history remains available for replay and audit under its original era.
        staged.pending_stake_resource_policy = None;
        staged.stake_resource_accounting = None;
        staged.descriptor.protocol_era = certificate.new_protocol_era;
        staged.descriptor.crypto_era = certificate.new_crypto_era;
        staged.descriptor.validator_keys = certificate.new_validator_keys.clone();
        staged.descriptor.notary_keys = certificate.new_notary_keys.clone();
        staged.era_continuity_accumulator = hash_parts(&[
            staged.era_continuity_accumulator.as_bytes(),
            certificate.certificate_hash.as_bytes(),
        ]);
        staged.era_certificates.push(certificate);
        let checkpoint = staged.create_checkpoint()?;
        *self = staged;
        Ok(checkpoint)
    }

    pub fn supply_buckets(&self) -> Result<SupplyBuckets, LedgerError> {
        let payment_fee_pools = self
            .epoch_fee_pools
            .values()
            .try_fold(Amount::ZERO, |total, pool| {
                total.checked_add(pool.collected)
            })?;
        let stake_resource_pool =
            self.stake_resource_accounting
                .as_ref()
                .map_or(Ok(Amount::ZERO), |accounting| {
                    accounting
                        .maintenance_pool()
                        .total_charged_fees
                        .checked_add(accounting.maintenance_pool().total_forfeited_bonds)
                })?;
        let fee_pools = payment_fee_pools.checked_add(stake_resource_pool)?;
        let mut buckets = SupplyBuckets {
            reserve: self.reserve,
            fee_pools,
            imported_total: self.imported_total,
            finalized_export_total: self.finalized_export_total,
            ..SupplyBuckets::default()
        };
        for coin in self.coins.values() {
            let target = match coin.state {
                CoinState::Spendable => &mut buckets.spendable,
                CoinState::Reserved => &mut buckets.reserved,
                CoinState::InTransit => &mut buckets.in_transit,
                CoinState::Returning => &mut buckets.returning,
                CoinState::Quarantined => &mut buckets.quarantined,
                CoinState::Consumed => continue,
            };
            *target = target.checked_add(coin.amount)?;
        }
        Ok(buckets)
    }

    pub fn supply_certificate(&self) -> Result<SupplyConservationCertificate, LedgerError> {
        let buckets = self.supply_buckets()?;
        let position = buckets
            .conservation_position()
            .map_err(LedgerError::Supply)?;
        let reserve_pool_total = self.reserve_pools.total().map_err(LedgerError::Supply)?;
        let mut leaves = Vec::new();
        for coin in self
            .coins
            .values()
            .filter(|coin| coin.state.carries_supply())
        {
            leaves.extend_from_slice(coin.object_id.as_bytes());
            leaves.extend_from_slice(&coin.amount.0.to_be_bytes());
            leaves.extend_from_slice(format!("{:?}", coin.state).as_bytes());
        }
        leaves.extend_from_slice(&self.reserve.0.to_be_bytes());
        leaves.extend_from_slice(&self.reserve_pools.startup_services.0.to_be_bytes());
        leaves.extend_from_slice(&self.reserve_pools.continuity_services.0.to_be_bytes());
        leaves.extend_from_slice(&self.reserve_pools.demand_matching.0.to_be_bytes());
        for (pricing_epoch, pool) in &self.epoch_fee_pools {
            leaves.extend_from_slice(&pricing_epoch.to_be_bytes());
            leaves.extend_from_slice(&pool.collected.0.to_be_bytes());
            leaves.extend_from_slice(&pool.charged_payments.to_be_bytes());
        }
        if let Some(accounting) = &self.stake_resource_accounting {
            let pool = accounting.maintenance_pool();
            leaves.extend_from_slice(b"RLD-STAKE-RESOURCE-POOL-V2");
            leaves.extend_from_slice(pool.pool_commitment.as_bytes());
            leaves.extend_from_slice(&pool.total_charged_fees.0.to_be_bytes());
            leaves.extend_from_slice(&pool.total_forfeited_bonds.0.to_be_bytes());
            leaves.extend_from_slice(&pool.total_live_bonds.0.to_be_bytes());
            leaves.extend_from_slice(&pool.total_refunded_bonds.0.to_be_bytes());
        }
        Ok(SupplyConservationCertificate {
            zone_id: self.descriptor.zone_id.clone(),
            height: self.height,
            merkle_sum_root: hash_bytes(&leaves),
            buckets,
            reserve_pools: self.reserve_pools.clone(),
            conservation_position: position,
            anchor_supply: self.anchor_supply,
            valid: position == self.anchor_supply && reserve_pool_total == self.reserve,
        })
    }

    pub fn assert_conservation(&self) -> Result<(), LedgerError> {
        self.validate_consensus_stake_escrows()?;
        self.validate_consensus_stake_slashes()?;
        self.validate_stake_position_liability_horizons()?;
        self.validate_stake_resource_policy_state()?;
        let reserve_pool_total = self.reserve_pools.total().map_err(LedgerError::Supply)?;
        if reserve_pool_total != self.reserve {
            return Err(LedgerError::Supply(format!(
                "protocol reserve pools {} do not equal reserve {}",
                reserve_pool_total, self.reserve
            )));
        }
        for pool in [
            ProtocolReservePoolKind::StartupServices,
            ProtocolReservePoolKind::ContinuityServices,
            ProtocolReservePoolKind::DemandMatching,
        ] {
            self.available_protocol_reserve(&pool)?;
        }
        let certificate = self.supply_certificate()?;
        if certificate.valid {
            Ok(())
        } else {
            Err(LedgerError::Supply(format!(
                "position {} does not equal anchor {}",
                certificate.conservation_position, certificate.anchor_supply
            )))
        }
    }

    pub fn create_checkpoint(&mut self) -> Result<ContinuityCheckpoint, LedgerError> {
        let state_root = self.state_root()?;
        let supply = self.supply_certificate()?;
        let previous_checkpoint = self
            .checkpoints
            .last()
            .map(|checkpoint| checkpoint.checkpoint_hash.clone());
        let checkpoint_hash = hash_parts(&[
            self.descriptor.zone_id.as_bytes(),
            &self.height.to_be_bytes(),
            state_root.as_bytes(),
            supply.merkle_sum_root.as_bytes(),
            previous_checkpoint
                .as_deref()
                .unwrap_or_default()
                .as_bytes(),
        ]);
        let checkpoint = ContinuityCheckpoint {
            zone_id: self.descriptor.zone_id.clone(),
            height: self.height,
            state_root,
            supply,
            protocol_era: self.descriptor.protocol_era,
            crypto_era: self.descriptor.crypto_era,
            previous_checkpoint,
            checkpoint_hash,
        };
        self.checkpoints.push(checkpoint.clone());
        Ok(checkpoint)
    }

    pub fn latest_checkpoint(&self) -> Option<&ContinuityCheckpoint> {
        self.checkpoints.last()
    }

    pub fn audit_proof_bundle(&self) -> Result<AuditProofBundle, LedgerError> {
        let mut snapshot = self.clone();
        let final_checkpoint = snapshot.create_checkpoint()?;
        let mut bundle = AuditProofBundle {
            zone_descriptor: snapshot.descriptor.clone(),
            currency_genesis_root: snapshot.descriptor.currency_genesis_root.clone(),
            generated_height: snapshot.height,
            checkpoints: snapshot.checkpoints.clone(),
            era_certificates: snapshot.era_certificates.clone(),
            coin_history: snapshot.coins.values().cloned().collect(),
            payments: snapshot.payments.values().cloned().collect(),
            transits: snapshot.transits.values().cloned().collect(),
            import_receipts: snapshot.import_receipts.values().cloned().collect(),
            rejection_proofs: snapshot.rejection_proofs.values().cloned().collect(),
            recipient_receipts: snapshot.recipient_receipts.values().cloned().collect(),
            liquidity_offers: snapshot.liquidity_offers.values().cloned().collect(),
            route_quotes: snapshot.route_quotes.values().cloned().collect(),
            epoch_fee_pools: snapshot.epoch_fee_pools.values().cloned().collect(),
            service_orders: snapshot.service_orders.values().cloned().collect(),
            service_leases: snapshot.service_leases.values().cloned().collect(),
            protocol_reserve_commitments: snapshot
                .protocol_reserve_commitments
                .values()
                .cloned()
                .collect(),
            economic_control_attestations: snapshot
                .economic_control_attestations
                .values()
                .cloned()
                .collect(),
            economic_price_attestations: snapshot
                .economic_price_attestations
                .values()
                .cloned()
                .collect(),
            economic_release_policies: snapshot
                .economic_release_policies
                .values()
                .cloned()
                .collect(),
            protocol_service_bonds: snapshot.protocol_service_bonds.values().cloned().collect(),
            protocol_reserve_releases: snapshot
                .protocol_reserve_releases
                .values()
                .cloned()
                .collect(),
            consensus_commits: snapshot.consensus_commits.values().cloned().collect(),
            m0_network_birth: snapshot.m0_network_birth.clone(),
            m0_network_birth_v3: snapshot.m0_network_birth_v3.clone(),
            m0_active_protocol: snapshot.m0_active_protocol.clone(),
            m0_pending_upgrade: snapshot.m0_pending_upgrade.clone(),
            admission_state: snapshot.admission_state.clone(),
            consensus_stake_authority: snapshot.consensus_stake_authority.clone(),
            consensus_stake_escrows: snapshot.consensus_stake_escrows.values().cloned().collect(),
            consensus_stake_unbonds: snapshot.consensus_stake_unbonds.values().cloned().collect(),
            consensus_stake_slashes: snapshot.consensus_stake_slashes.values().cloned().collect(),
            derived_stake_epochs: snapshot.derived_stake_epochs.values().cloned().collect(),
            stake_position_liability_horizons: snapshot.stake_position_liability_horizons.clone(),
            stake_position_liability_horizon_history: snapshot
                .stake_position_liability_horizon_history
                .clone(),
            stake_liability_horizon_activation_epoch: snapshot
                .stake_liability_horizon_activation_epoch,
            stake_resource_policy_proposals: snapshot
                .stake_resource_policy_proposals
                .values()
                .cloned()
                .collect(),
            stake_resource_policy_activations: snapshot
                .stake_resource_policy_activations
                .values()
                .cloned()
                .collect(),
            pending_stake_resource_policy: snapshot.pending_stake_resource_policy.clone(),
            stake_resource_accounting: snapshot.stake_resource_accounting.clone(),
            authorization_nullifiers: snapshot.authorization_nullifiers.clone(),
            gateway_bonds: snapshot.gateway_bonds.values().cloned().collect(),
            service_receipts: snapshot.service_receipts.values().cloned().collect(),
            voyage_receipts: snapshot.voyage_receipts.values().cloned().collect(),
            final_state_root: final_checkpoint.state_root,
            commitment_hash: String::new(),
        };
        bundle.commitment_hash = bundle
            .compute_commitment()
            .map_err(LedgerError::InvalidOperationalProof)?;
        bundle
            .verify_structure()
            .map_err(LedgerError::InvalidOperationalProof)?;
        Ok(bundle)
    }

    pub fn state_root(&self) -> Result<String, LedgerError> {
        let root_before_admission = self.state_root_before_admission()?;
        let base = match (self.m0_admission_genesis()?, &self.admission_state) {
            (None, None) => Ok(root_before_admission),
            (Some(_), None) => Err(LedgerError::Invalid(
                "M0 network-birth binding has no required admission trust state".into(),
            )),
            (None, Some(_)) => Err(LedgerError::Invalid(
                "ledger admission state cannot exist without an M0 network-birth binding".into(),
            )),
            (Some(admission_genesis), Some(admission_state)) => {
                admission_state
                    .validate_for_descriptor(&self.descriptor)
                    .map_err(|error| LedgerError::Invalid(error.to_string()))?;
                if admission_genesis != &admission_state.genesis {
                    return Err(LedgerError::Invalid(
                        "ledger admission state differs from the signed M0 network-birth trust root"
                            .into(),
                    ));
                }
                let extension_bytes = serde_json::to_vec(&(
                    "RLD-LEDGER-PERMISSIONLESS-ADMISSION-EXTENSION-V1",
                    admission_state,
                ))
                .map_err(|error| LedgerError::Invalid(error.to_string()))?;
                Ok(hash_parts(&[
                    b"RLD-LEDGER-STATE-ROOT-PERMISSIONLESS-ADMISSION-EXTENSION-V1",
                    root_before_admission.as_bytes(),
                    &extension_bytes,
                ]))
            }
        }?;
        if let Some(pending) = &self.m0_pending_upgrade {
            Ok(hash_parts(&[
                b"RLD-LEDGER-STATE-ROOT-PENDING-UPGRADE-V1",
                base.as_bytes(),
                &pending.canonical_bytes().map_err(LedgerError::Invalid)?,
            ]))
        } else {
            Ok(base)
        }
    }

    pub(crate) fn state_root_before_admission(&self) -> Result<String, LedgerError> {
        let base_bytes = serde_json::to_vec(&(
            (
                &self.descriptor,
                self.height,
                self.anchor_supply,
                self.reserve,
                &self.reserve_pools,
                self.imported_total,
                self.finalized_export_total,
                &self.value_risk_policy,
                &self.consensus_stake_authority,
                &self.consensus_stake_escrows,
                &self.consensus_stake_unbonds,
                &self.consensus_stake_slashes,
                &self.consensus_stake_evidence_nullifiers,
                &self.derived_stake_epochs,
                &self.epoch_fee_pools,
                self.sequence,
            ),
            (
                (
                    &self.coins,
                    &self.payments,
                    &self.payment_requests,
                    &self.consumed_payment_requests,
                    &self.recipient_receipts,
                    &self.liquidity_offers,
                    &self.route_quotes,
                    &self.spendability_certificates,
                ),
                (
                    &self.transits,
                    &self.transit_coin_ids,
                    &self.import_receipts,
                    &self.transit_nullifiers,
                    &self.rejected_transit_nullifiers,
                    &self.rejection_proofs,
                    &self.source_object_nullifiers,
                    &self.authorization_nullifiers,
                ),
                (
                    &self.zone_trust_policies,
                    &self.quarantined_zones,
                    &self.trusted_zone_checkpoints,
                    &self.gateway_bonds,
                    &self.zone_advertisements,
                    &self.traveler_capsules,
                ),
                (
                    &self.service_orders,
                    &self.service_leases,
                    &self.protocol_reserve_commitments,
                    (
                        &self.economic_control_attestations,
                        &self.economic_price_attestations,
                        &self.economic_release_policies,
                        &self.protocol_service_bonds,
                        &self.protocol_reserve_releases,
                        &self.economic_consumed_work_ids,
                        &self.economic_consumed_fee_receipts,
                        &self.economic_consumed_completion_qcs,
                        &self.economic_bond_slash_ids,
                    ),
                    &self.matched_service_receipts,
                    &self.service_receipts,
                    &self.node_earnings,
                    &self.voyage_escrows,
                    &self.voyage_receipts,
                    &self.bootstrap_claims,
                ),
                (&self.era_continuity_accumulator, &self.causal_firewall),
            ),
        ))
        .map_err(|error| LedgerError::Invalid(error.to_string()))?;
        let base_root = hash_bytes(&base_bytes);
        let stake_root = if self.stake_resource_policy_proposals.is_empty()
            && self.stake_resource_policy_activations.is_empty()
            && self.pending_stake_resource_policy.is_none()
            && self.stake_resource_accounting.is_none()
            && self.stake_position_liability_horizons.is_empty()
            && self.stake_position_liability_horizon_history.is_empty()
            && self.stake_liability_horizon_activation_epoch.is_none()
        {
            base_root
        } else if self.stake_position_liability_horizons.is_empty()
            && self.stake_position_liability_horizon_history.is_empty()
            && self.stake_liability_horizon_activation_epoch.is_none()
        {
            let extension_bytes = serde_json::to_vec(&(
                "RLD-LEDGER-STAKE-RESOURCE-EXTENSION-V1",
                &self.stake_resource_policy_proposals,
                &self.stake_resource_policy_activations,
                &self.pending_stake_resource_policy,
                &self.stake_resource_accounting,
            ))
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
            hash_parts(&[
                b"RLD-LEDGER-STATE-ROOT-STAKE-RESOURCE-EXTENSION-V1",
                base_root.as_bytes(),
                &extension_bytes,
            ])
        } else {
            let extension_bytes = serde_json::to_vec(&(
                "RLD-LEDGER-STAKE-RESOURCE-EXTENSION-V2",
                &self.stake_resource_policy_proposals,
                &self.stake_resource_policy_activations,
                &self.pending_stake_resource_policy,
                &self.stake_resource_accounting,
                &self.stake_position_liability_horizons,
                &self.stake_position_liability_horizon_history,
                &self.stake_liability_horizon_activation_epoch,
            ))
            .map_err(|error| LedgerError::Invalid(error.to_string()))?;
            hash_parts(&[
                b"RLD-LEDGER-STATE-ROOT-STAKE-RESOURCE-EXTENSION-V2",
                base_root.as_bytes(),
                &extension_bytes,
            ])
        };
        self.m0_admission_genesis()?;
        if let (Some(birth), Some(active)) = (&self.m0_network_birth_v3, &self.m0_active_protocol) {
            Ok(hash_parts(&[
                b"RLD-LEDGER-STATE-ROOT-M0-NETWORK-BIRTH-EXTENSION-V3",
                stake_root.as_bytes(),
                &birth.canonical_bytes().map_err(LedgerError::Invalid)?,
                &active.canonical_bytes().map_err(LedgerError::Invalid)?,
            ]))
        } else if let Some(network_birth) = &self.m0_network_birth {
            let extension_bytes =
                serde_json::to_vec(&("RLD-LEDGER-M0-NETWORK-BIRTH-EXTENSION-V2", network_birth))
                    .map_err(|error| LedgerError::Invalid(error.to_string()))?;
            Ok(hash_parts(&[
                b"RLD-LEDGER-STATE-ROOT-M0-NETWORK-BIRTH-EXTENSION-V2",
                stake_root.as_bytes(),
                &extension_bytes,
            ]))
        } else {
            Ok(stake_root)
        }
    }

    fn verify_source_acceptance(
        &self,
        capsule: &TransitCapsule,
        subject: &str,
        policy: &ZoneTrustPolicy,
    ) -> Result<(), LedgerError> {
        if capsule.validator_qc.subject_hash != subject {
            return Err(LedgerError::InvalidQuorum(
                "validator certificate subject hash mismatch".into(),
            ));
        }
        self.verify_source_quorum(
            &capsule.validator_qc,
            &capsule.source_descriptor.validator_keys,
            capsule.source_descriptor.testnet,
            "validator",
        )?;

        match policy {
            ZoneTrustPolicy::DualQc => {
                if capsule.notary_qc.subject_hash != subject {
                    return Err(LedgerError::InvalidQuorum(
                        "notary certificate subject hash mismatch".into(),
                    ));
                }
                if capsule
                    .source_descriptor
                    .validator_keys
                    .iter()
                    .any(|key| capsule.source_descriptor.notary_keys.contains(key))
                {
                    return Err(LedgerError::InvalidQuorum(
                        "validator and independent notary sets overlap".into(),
                    ));
                }
                self.verify_source_quorum(
                    &capsule.notary_qc,
                    &capsule.source_descriptor.notary_keys,
                    capsule.source_descriptor.testnet,
                    "notary",
                )?;
            }
            ZoneTrustPolicy::LightClient => {
                let trusted = self
                    .trusted_zone_checkpoints
                    .get(&capsule.source_zone)
                    .is_some_and(|checkpoints| checkpoints.contains(&capsule.source_checkpoint));
                if !trusted {
                    return Err(LedgerError::InvalidOperationalProof(
                        "source checkpoint is not anchored by the destination light client".into(),
                    ));
                }
            }
            ZoneTrustPolicy::BondedGateway => {
                let endorsement = capsule.gateway_endorsement.as_ref().ok_or_else(|| {
                    LedgerError::InvalidQuorum(
                        "bonded-gateway policy requires a gateway endorsement".into(),
                    )
                })?;
                endorsement
                    .verify(capsule)
                    .map_err(LedgerError::InvalidSignature)?;
                let bond = self
                    .gateway_bonds
                    .get(&endorsement.bond_id)
                    .ok_or_else(|| {
                        LedgerError::InvalidQuorum("gateway bond is not registered locally".into())
                    })?;
                let escrow = self.coins.get(&bond.escrow_coin_id).ok_or_else(|| {
                    LedgerError::InvalidQuorum("gateway bond escrow coin is missing".into())
                })?;
                if bond.status != GatewayBondStatus::Active
                    || bond.source_zone != capsule.source_zone
                    || bond.gateway_public_key != endorsement.gateway_public_key
                    || bond.amount.is_zero()
                    || escrow.state != CoinState::Reserved
                    || escrow.owner != bond.owner
                    || escrow.amount != bond.amount
                {
                    return Err(LedgerError::InvalidQuorum(
                        "gateway endorsement is not backed by an active local RLD bond".into(),
                    ));
                }
            }
            ZoneTrustPolicy::ObserveOnly | ZoneTrustPolicy::Quarantined => {
                return Err(LedgerError::SourceZoneQuarantined(
                    capsule.source_zone.clone(),
                ));
            }
        }
        Ok(())
    }

    fn verify_source_quorum(
        &self,
        certificate: &QuorumCertificate,
        allowed_keys: &[String],
        source_is_testnet: bool,
        role: &str,
    ) -> Result<(), LedgerError> {
        if certificate.testnet_simulated {
            if self.descriptor.testnet && source_is_testnet && allowed_keys.is_empty() {
                return Ok(());
            }
            return Err(LedgerError::InvalidQuorum(format!(
                "simulated {role} quorum is forbidden for this signer set"
            )));
        }
        certificate
            .verify(allowed_keys)
            .map_err(LedgerError::InvalidQuorum)
    }

    fn verify_local_dual_quorum(
        &self,
        subject: &str,
        validator_qc: &QuorumCertificate,
        notary_qc: &QuorumCertificate,
    ) -> Result<(), LedgerError> {
        if validator_qc.subject_hash != subject || notary_qc.subject_hash != subject {
            return Err(LedgerError::InvalidQuorum("subject hash mismatch".into()));
        }
        let simulated = validator_qc.testnet_simulated && notary_qc.testnet_simulated;
        if simulated {
            if self.descriptor.testnet
                && self.descriptor.validator_keys.is_empty()
                && self.descriptor.notary_keys.is_empty()
            {
                return Ok(());
            }
            return Err(LedgerError::InvalidQuorum(
                "simulated dual quorum is forbidden for this Zone".into(),
            ));
        }
        if validator_qc.testnet_simulated || notary_qc.testnet_simulated {
            return Err(LedgerError::InvalidQuorum(
                "validator and notary quorum modes must match".into(),
            ));
        }
        validator_qc
            .verify(&self.descriptor.validator_keys)
            .map_err(LedgerError::InvalidQuorum)?;
        notary_qc
            .verify(&self.descriptor.notary_keys)
            .map_err(LedgerError::InvalidQuorum)
    }

    fn verify_owner_authorization(
        &self,
        authorization: &SignedActionAuthorization,
        owner: &str,
        action: &str,
        payload_hash: &str,
    ) -> Result<(), LedgerError> {
        if self
            .authorization_nullifiers
            .contains(&authorization.authorization_id)
        {
            return Err(LedgerError::Duplicate(
                authorization.authorization_id.clone(),
            ));
        }
        authorization
            .verify_scope(
                &self.descriptor.zone_id,
                &self.descriptor.currency_genesis_root,
                self.descriptor.protocol_era,
                self.descriptor.crypto_era,
                action,
                payload_hash,
            )
            .map_err(LedgerError::InvalidSignature)?;
        if authorization.signer_address() != owner {
            return Err(LedgerError::OwnerMismatch);
        }
        Ok(())
    }

    fn verify_node_authorization(
        &self,
        authorization: &SignedActionAuthorization,
        node_id: &str,
        action: &str,
        payload_hash: &str,
    ) -> Result<(), LedgerError> {
        if self
            .authorization_nullifiers
            .contains(&authorization.authorization_id)
        {
            return Err(LedgerError::Duplicate(
                authorization.authorization_id.clone(),
            ));
        }
        authorization
            .verify_scope(
                &self.descriptor.zone_id,
                &self.descriptor.currency_genesis_root,
                self.descriptor.protocol_era,
                self.descriptor.crypto_era,
                action,
                payload_hash,
            )
            .map_err(LedgerError::InvalidSignature)?;
        let canonical_node_id = format!("rld-node:{}", authorization.signer_public_key);
        if node_id != authorization.signer_public_key && node_id != canonical_node_id {
            return Err(LedgerError::OwnerMismatch);
        }
        Ok(())
    }

    fn consume_authorization(
        &mut self,
        authorization: &SignedActionAuthorization,
    ) -> Result<(), LedgerError> {
        if !self
            .authorization_nullifiers
            .insert(authorization.authorization_id.clone())
        {
            return Err(LedgerError::Duplicate(
                authorization.authorization_id.clone(),
            ));
        }
        Ok(())
    }

    fn verify_era_certificate(&self, capsule: &TransitCapsule) -> Result<(), LedgerError> {
        let Some(certificate) = &capsule.era_certificate else {
            let genesis_era_hash = hash_parts(&[
                b"RLD-GENESIS-ERA",
                capsule.source_zone.as_bytes(),
                &capsule.source_descriptor.protocol_era.to_be_bytes(),
                &capsule.source_descriptor.crypto_era.to_be_bytes(),
            ]);
            if capsule.source_descriptor.protocol_era != 1
                || capsule.source_descriptor.crypto_era != 1
                || capsule.operational_proof.era_certificate_hash != genesis_era_hash
            {
                return Err(LedgerError::EraTransition(
                    "missing non-genesis era certificate".into(),
                ));
            }
            return Ok(());
        };

        let subject = certificate.subject_hash();
        if certificate.zone_id != capsule.source_zone
            || certificate.new_protocol_era != capsule.source_descriptor.protocol_era
            || certificate.new_crypto_era != capsule.source_descriptor.crypto_era
            || certificate.new_validator_keys != capsule.source_descriptor.validator_keys
            || certificate.new_notary_keys != capsule.source_descriptor.notary_keys
            || certificate.certificate_hash != subject
            || capsule.operational_proof.era_certificate_hash != subject
            || certificate.old_crypto_qc.subject_hash != subject
            || certificate.new_crypto_qc.subject_hash != subject
            || certificate.notary_qc.subject_hash != subject
        {
            return Err(LedgerError::EraTransition(
                "era certificate does not bind the source descriptor".into(),
            ));
        }
        let simulated = certificate.old_crypto_qc.testnet_simulated
            && certificate.new_crypto_qc.testnet_simulated
            && certificate.notary_qc.testnet_simulated;
        let simulation_allowed = self.descriptor.testnet
            && capsule.source_descriptor.testnet
            && certificate.previous_validator_keys.is_empty()
            && certificate.previous_notary_keys.is_empty()
            && certificate.new_validator_keys.is_empty()
            && certificate.new_notary_keys.is_empty();
        if simulated && simulation_allowed {
            return Ok(());
        }
        if simulated {
            return Err(LedgerError::InvalidQuorum(
                "simulated era quorum is forbidden for a configured signer set".into(),
            ));
        }
        certificate
            .old_crypto_qc
            .verify(&certificate.previous_validator_keys)
            .map_err(LedgerError::InvalidQuorum)?;
        certificate
            .new_crypto_qc
            .verify(&certificate.new_validator_keys)
            .map_err(LedgerError::InvalidQuorum)?;
        certificate
            .notary_qc
            .verify(&certificate.previous_notary_keys)
            .map_err(LedgerError::InvalidQuorum)?;
        Ok(())
    }

    fn validate_intent(
        &self,
        intent: &UniversalPaymentIntent,
        require_local_destination: bool,
    ) -> Result<(), LedgerError> {
        intent.verify().map_err(LedgerError::InvalidSignature)?;
        if intent.currency_genesis_root != self.descriptor.currency_genesis_root {
            return Err(LedgerError::Invalid(
                "currency genesis root mismatch".into(),
            ));
        }
        if intent.protocol_era != self.descriptor.protocol_era {
            return Err(LedgerError::Invalid("protocol era mismatch".into()));
        }
        if intent.crypto_era != self.descriptor.crypto_era {
            return Err(LedgerError::Invalid("crypto era mismatch".into()));
        }
        if intent.pricing_epoch != LOCAL_PAYMENT_PRICING_EPOCH {
            return Err(LedgerError::Invalid("pricing epoch mismatch".into()));
        }
        if intent.source_zone != self.descriptor.zone_id {
            return Err(LedgerError::Invalid("source Zone mismatch".into()));
        }
        if require_local_destination && intent.destination_zone != self.descriptor.zone_id {
            return Err(LedgerError::Invalid("destination is not local".into()));
        }
        if require_local_destination && intent.route_quote_id.is_some() {
            return Err(LedgerError::Invalid(
                "route quotes apply only to cross-Zone payments".into(),
            ));
        }
        if !require_local_destination && intent.destination_zone == self.descriptor.zone_id {
            return Err(LedgerError::Invalid(
                "use local payment inside one Zone".into(),
            ));
        }
        match (&intent.payment_request_id, &intent.payment_request) {
            (None, None) => {}
            (Some(request_id), Some(request)) => {
                if request_id != &request.request_id {
                    return Err(LedgerError::Invalid(
                        "payment request identifier mismatch".into(),
                    ));
                }
                request.verify().map_err(LedgerError::InvalidSignature)?;
                if request.currency_genesis_root != self.descriptor.currency_genesis_root {
                    return Err(LedgerError::Invalid(
                        "payment request currency genesis root mismatch".into(),
                    ));
                }
                if request.destination_zone != intent.destination_zone
                    || request.recipient != intent.recipient
                    || request.amount != intent.amount
                {
                    return Err(LedgerError::Invalid(
                        "payment intent does not match payment request".into(),
                    ));
                }
                if require_local_destination {
                    self.validate_payment_request_context(request)?;
                    if request.expires_at_height <= self.height {
                        return Err(LedgerError::Invalid("payment request has expired".into()));
                    }
                }
                if self.consumed_payment_requests.contains(request_id) {
                    return Err(LedgerError::Duplicate(request_id.clone()));
                }
                if let Some(registered) = self.payment_requests.get(request_id) {
                    if registered.commitment_hash() != request.commitment_hash() {
                        return Err(LedgerError::Invalid(
                            "registered payment request commitment mismatch".into(),
                        ));
                    }
                }
            }
            _ => {
                return Err(LedgerError::Invalid(
                    "payment request id and signed request must be supplied together".into(),
                ));
            }
        }
        Ok(())
    }

    fn validate_payment_request_context(
        &self,
        request: &PaymentRequest,
    ) -> Result<(), LedgerError> {
        if request.currency_genesis_root != self.descriptor.currency_genesis_root
            || request.protocol_era != self.descriptor.protocol_era
            || request.crypto_era != self.descriptor.crypto_era
        {
            return Err(LedgerError::Invalid(
                "payment request network or era context mismatch".into(),
            ));
        }
        Ok(())
    }

    fn consume_payment_request(
        &mut self,
        intent: &UniversalPaymentIntent,
    ) -> Result<(), LedgerError> {
        if let Some(request_id) = &intent.payment_request_id {
            if !self.consumed_payment_requests.insert(request_id.clone()) {
                return Err(LedgerError::Duplicate(request_id.clone()));
            }
        }
        Ok(())
    }

    fn spendable_owned_coin(
        &self,
        coin_id: &str,
        sender_public_key: &str,
    ) -> Result<CoinObject, LedgerError> {
        let coin = self
            .coins
            .get(coin_id)
            .cloned()
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.into()))?;
        if coin.state != CoinState::Spendable {
            return Err(LedgerError::CoinNotSpendable);
        }
        let expected = format!("rld:{}:{sender_public_key}", self.descriptor.zone_id);
        if coin.owner != expected {
            return Err(LedgerError::OwnerMismatch);
        }
        Ok(coin)
    }

    fn consume_coin(&mut self, coin_id: &str) -> Result<(), LedgerError> {
        if self.consensus_stake_escrows.contains_key(coin_id) {
            return Err(LedgerError::CoinNotSpendable);
        }
        let coin = self
            .coins
            .get_mut(coin_id)
            .ok_or_else(|| LedgerError::CoinNotFound(coin_id.into()))?;
        if coin.state == CoinState::Consumed {
            return Err(LedgerError::CoinNotSpendable);
        }
        coin.state = CoinState::Consumed;
        Ok(())
    }

    fn ensure_economic_counter_headroom(
        &self,
        height_steps: u64,
        sequence_steps: u64,
    ) -> Result<(), LedgerError> {
        self.ensure_counter_headroom(height_steps, sequence_steps)
            .map_err(|error| LedgerError::Economic(error.to_string()))
    }

    fn ensure_upgrade_height_boundary(&self, steps: u64) -> Result<(), LedgerError> {
        if let Some(pending) = &self.m0_pending_upgrade {
            self.m0_admission_genesis()?;
            if u128::from(self.height) + u128::from(steps) >= pending.schedule.activation_height {
                return Err(LedgerError::Invalid(
                    "scheduled activation required; ordinary height advance is forbidden".into(),
                ));
            }
        }
        Ok(())
    }

    /// Read-only successor evaluator. This does not authenticate a migration,
    /// finalize scheduling, persist state or grant any signing permission.
    pub fn preview_upgrade_schedule(
        &self,
        schedule: &crate::genesis::upgrade_wire::ScheduleUpgradeV1,
    ) -> Result<Self, LedgerError> {
        if self.value_risk_policy.current_cap != crate::ValueCap::ValueCap0
            || self.value_risk_policy.ever_enabled
            || self.value_risk_policy.pending_update.is_some()
        {
            return Err(LedgerError::Invalid(
                "bootstrap upgrade preview requires unchanged VALUE_CAP_0".into(),
            ));
        }
        let pending =
            crate::genesis::upgrade_pending::PendingUpgradeV1::from_parent(self, schedule)
                .map_err(LedgerError::Invalid)?;
        self.ensure_counter_headroom(1, 0)?;
        let mut candidate = self.clone();
        candidate.height += 1;
        candidate.m0_pending_upgrade = Some(pending);
        candidate.state_root()?;
        Ok(candidate)
    }

    fn ensure_counter_headroom(
        &self,
        height_steps: u64,
        sequence_steps: u64,
    ) -> Result<(), LedgerError> {
        self.ensure_upgrade_height_boundary(height_steps)?;
        self.height
            .checked_add(height_steps)
            .ok_or_else(|| LedgerError::Invalid("ledger height counter overflow".into()))?;
        self.sequence.checked_add(sequence_steps).ok_or_else(|| {
            LedgerError::Invalid("ledger object sequence counter overflow".into())
        })?;
        Ok(())
    }

    fn checked_next_coin_version(version: u64) -> Result<u64, LedgerError> {
        version
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("coin version counter overflow".into()))
    }

    fn is_sorted_unique_nonempty(values: &[String]) -> bool {
        !values.is_empty()
            && values.iter().all(|value| !value.trim().is_empty())
            && values.windows(2).all(|pair| pair[0] < pair[1])
    }

    fn economic_member<'a>(
        attestation: &'a EconomicControlAttestation,
        subject_id: &str,
    ) -> Result<&'a crate::EconomicControlMember, LedgerError> {
        attestation
            .members
            .binary_search_by(|member| member.subject_id.as_str().cmp(subject_id))
            .ok()
            .and_then(|index| attestation.members.get(index))
            .ok_or_else(|| {
                LedgerError::Economic(format!(
                    "subject {subject_id} has no persisted UBO control mapping"
                ))
            })
    }

    fn economic_role_for_service(role: &ServiceRole) -> EconomicControlRole {
        match role {
            ServiceRole::Validator => EconomicControlRole::Validator,
            ServiceRole::Notary => EconomicControlRole::Notary,
            ServiceRole::Relay | ServiceRole::Gateway | ServiceRole::FtlGateway => {
                EconomicControlRole::Relay
            }
            ServiceRole::Liquidity => EconomicControlRole::LiquidityProvider,
            ServiceRole::Storage
            | ServiceRole::Archive
            | ServiceRole::ContinuityCustodian
            | ServiceRole::Observer => EconomicControlRole::ServiceProvider,
        }
    }

    fn checked_bps_ceil(value: Amount, bps: u32) -> Result<Amount, LedgerError> {
        let divisor = 10_000u128;
        let multiplier = u128::from(bps);
        let whole = value
            .0
            .checked_div(divisor)
            .and_then(|quotient| quotient.checked_mul(multiplier))
            .ok_or_else(|| LedgerError::Economic("bond coverage calculation overflow".into()))?;
        let remainder_product = (value.0 % divisor)
            .checked_mul(multiplier)
            .ok_or_else(|| LedgerError::Economic("bond coverage calculation overflow".into()))?;
        let rounded_remainder = remainder_product
            .checked_add(divisor - 1)
            .and_then(|rounded| rounded.checked_div(divisor))
            .ok_or_else(|| LedgerError::Economic("bond coverage calculation overflow".into()))?;
        whole
            .checked_add(rounded_remainder)
            .map(Amount::from_runlai)
            .ok_or_else(|| LedgerError::Economic("bond coverage calculation overflow".into()))
    }

    fn protocol_reserve_pool_balance(&self, pool: ProtocolReservePoolKind) -> Amount {
        match pool {
            ProtocolReservePoolKind::StartupServices => self.reserve_pools.startup_services,
            ProtocolReservePoolKind::ContinuityServices => self.reserve_pools.continuity_services,
            ProtocolReservePoolKind::DemandMatching => self.reserve_pools.demand_matching,
        }
    }

    fn protocol_reserve_pool_balance_mut(&mut self, pool: ProtocolReservePoolKind) -> &mut Amount {
        match pool {
            ProtocolReservePoolKind::StartupServices => &mut self.reserve_pools.startup_services,
            ProtocolReservePoolKind::ContinuityServices => {
                &mut self.reserve_pools.continuity_services
            }
            ProtocolReservePoolKind::DemandMatching => &mut self.reserve_pools.demand_matching,
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn make_coin(
        &mut self,
        owner: String,
        amount: Amount,
        state: CoinState,
        parent_ids: Vec<String>,
        lineage_root: Option<String>,
        transit_id: Option<String>,
        imported_from: Option<String>,
        version: u64,
    ) -> Result<CoinObject, LedgerError> {
        let object_id = self.next_id("coin")?;
        let (origin_zone, origin_genesis_root) = parent_ids
            .iter()
            .find_map(|parent_id| self.coins.get(parent_id))
            .map(|parent| {
                (
                    parent.origin_zone.clone(),
                    parent.origin_genesis_root.clone(),
                )
            })
            .unwrap_or_else(|| {
                (
                    self.descriptor.zone_id.clone(),
                    self.descriptor.currency_genesis_root.clone(),
                )
            });
        let lineage_root = lineage_root.unwrap_or_else(|| {
            hash_parts(&[
                self.descriptor.genesis_root.as_bytes(),
                object_id.as_bytes(),
                &amount.0.to_be_bytes(),
            ])
        });
        Ok(CoinObject {
            object_id,
            lineage_root,
            parent_ids,
            owner,
            zone_id: self.descriptor.zone_id.clone(),
            amount,
            state,
            version,
            created_height: self.height,
            transit_id,
            imported_from,
            origin_zone,
            origin_genesis_root,
        })
    }

    fn record_earnings(
        &mut self,
        node_id: &str,
        role: &ServiceRole,
        amount: Amount,
        receipt_id: &str,
    ) -> Result<(), LedgerError> {
        let earnings = self
            .node_earnings
            .entry(node_id.into())
            .or_insert_with(|| NodeEarnings {
                node_id: node_id.into(),
                ..NodeEarnings::default()
            });
        earnings.total = earnings.total.checked_add(amount)?;
        let role_key = format!("{role:?}").to_uppercase();
        let role_total = earnings.by_role.entry(role_key).or_default();
        *role_total = role_total.checked_add(amount)?;
        earnings.receipt_ids.push(receipt_id.into());
        Ok(())
    }

    fn advance(&mut self) -> Result<(), LedgerError> {
        self.ensure_upgrade_height_boundary(1)?;
        self.height = self
            .height
            .checked_add(1)
            .ok_or_else(|| LedgerError::Invalid("ledger height counter overflow".into()))?;
        Ok(())
    }

    fn next_id(&mut self, kind: &str) -> Result<String, LedgerError> {
        self.sequence = self.sequence.checked_add(1).ok_or_else(|| {
            LedgerError::Invalid("ledger object sequence counter overflow".into())
        })?;
        Ok(format!(
            "{kind}-{}",
            &hash_parts(&[
                self.descriptor.zone_id.as_bytes(),
                kind.as_bytes(),
                &self.height.to_be_bytes(),
                &self.sequence.to_be_bytes(),
            ])[..32]
        ))
    }
}

fn protocol_reserve_pools(anchor_supply: Amount) -> Result<ProtocolReservePools, LedgerError> {
    let startup_services = Amount::from_runlai(anchor_supply.0 / 100);
    let continuity_services = Amount::from_runlai(
        startup_services
            .0
            .checked_mul(9)
            .ok_or_else(|| LedgerError::Supply("continuity pool overflow".into()))?,
    );
    let demand_matching = anchor_supply
        .checked_sub(startup_services)?
        .checked_sub(continuity_services)?;
    Ok(ProtocolReservePools {
        startup_services,
        continuity_services,
        demand_matching,
    })
}

fn simulated_qc() -> QuorumCertificate {
    QuorumCertificate {
        subject_hash: String::new(),
        threshold: 0,
        attestations: Vec::new(),
        testnet_simulated: true,
    }
}

fn outbound_qc(keys: &[String]) -> Result<QuorumCertificate, LedgerError> {
    if keys.is_empty() {
        return Ok(simulated_qc());
    }
    let threshold = required_quorum(keys.len())
        .map_err(LedgerError::InvalidQuorum)?
        .try_into()
        .map_err(|_| LedgerError::InvalidQuorum("quorum set exceeds u16".into()))?;
    Ok(QuorumCertificate {
        subject_hash: String::new(),
        threshold,
        attestations: Vec::new(),
        testnet_simulated: false,
    })
}

fn transport_code(transport: &TransportClass) -> &'static str {
    match transport {
        TransportClass::SublightDtn => "SUBLIGHT_DTN",
        TransportClass::CausalFtl => "CAUSAL_FTL",
        TransportClass::CausalWormhole => "CAUSAL_WORMHOLE",
        TransportClass::ChronologyUnsafe => "CHRONOLOGY_UNSAFE",
    }
}

pub fn currency_genesis_root() -> String {
    hash_parts(&[
        b"Rldcoin-v5-currency-genesis",
        &crate::TOTAL_SUPPLY_RUNLAI.to_be_bytes(),
        &crate::RUNLAI_PER_RLD.to_be_bytes(),
    ])
}

#[cfg(test)]
mod tests {
    use crate::{
        generate_identity, sign_bytes, EconomicControlMember, ServiceRole, TOTAL_SUPPLY_RUNLAI,
    };

    use super::*;

    fn signed_intent(
        identity: &crate::Identity,
        zone: &str,
        destination: &str,
        recipient: &str,
        coin_id: &str,
        amount: Amount,
    ) -> UniversalPaymentIntent {
        let mut intent = UniversalPaymentIntent {
            payment_id: format!("payment-{coin_id}"),
            source_zone: zone.into(),
            destination_zone: destination.into(),
            currency_genesis_root: currency_genesis_root(),
            protocol_era: 1,
            crypto_era: 1,
            pricing_epoch: LOCAL_PAYMENT_PRICING_EPOCH,
            sender_public_key: identity.public_key.clone(),
            recipient: recipient.into(),
            coin_id: coin_id.into(),
            amount,
            max_fee: Amount::from_runlai(LOCAL_PAYMENT_MAX_FEE_RUNLAI),
            nonce: 1,
            payment_request_id: None,
            payment_request: None,
            route_quote_id: None,
            signature: String::new(),
        };
        intent.signature = sign_bytes(&identity.secret_key, &intent.signing_bytes()).unwrap();
        intent
    }

    fn signed_authorization(
        identity: &crate::Identity,
        zone: &str,
        action: &str,
        payload_hash: String,
        nonce: u64,
    ) -> SignedActionAuthorization {
        let mut authorization = SignedActionAuthorization {
            authorization_id: format!("authorization-{action}-{nonce}"),
            zone_id: zone.into(),
            currency_genesis_root: currency_genesis_root(),
            protocol_era: 1,
            crypto_era: 1,
            signer_public_key: identity.public_key.clone(),
            action: action.into(),
            payload_hash,
            nonce,
            signature: String::new(),
        };
        authorization.signature =
            sign_bytes(&identity.secret_key, &authorization.signing_bytes()).unwrap();
        authorization
    }

    fn signed_qc(
        subject_hash: &str,
        members: &[crate::Identity],
        signer_count: usize,
    ) -> QuorumCertificate {
        QuorumCertificate {
            subject_hash: subject_hash.into(),
            threshold: required_quorum(members.len()).unwrap().try_into().unwrap(),
            attestations: members
                .iter()
                .take(signer_count)
                .map(|identity| crate::SignedAttestation {
                    public_key: identity.public_key.clone(),
                    signature: sign_bytes(&identity.secret_key, subject_hash.as_bytes()).unwrap(),
                })
                .collect(),
            testnet_simulated: false,
        }
    }

    fn stake_resource_policy(
        sequence: u64,
        previous_policy_commitment: String,
        activation_delay_blocks: u64,
    ) -> StakeStateResourcePolicyV1 {
        StakeStateResourcePolicyV1 {
            policy_version: 1,
            sequence,
            previous_policy_commitment,
            activation_delay_blocks,
            base_candidate_fee: Amount(100),
            base_position_fee: Amount(200),
            base_epoch_fee: Amount(300),
            base_unbond_fee: Amount(400),
            base_slash_evidence_fee: Amount(500),
            fee_per_wire_byte: Amount(2),
            fee_per_signature_verification: Amount(10),
            fee_per_state_read: Amount(3),
            fee_per_state_write: Amount(5),
            bond_per_persistent_byte: Amount(20),
            minimum_candidate_bond: Amount(2_000),
            minimum_position_bond: Amount(4_000),
            minimum_lease_blocks: 10,
            maximum_lease_blocks: 1_000,
            expiry_grace_blocks: 20,
            terminal_retention_blocks: 30,
            maximum_active_candidates: 2,
            maximum_candidates_per_owner: 1,
            maximum_active_positions: 4,
            maximum_positions_per_owner: 2,
            maximum_pending_unbonds: 2,
            maximum_pending_unbonds_per_owner: 1,
            maximum_slash_record_bytes: 2_000,
            maximum_total_stake_state_bytes: 10_000,
            maximum_stake_state_bytes_per_block: 2_000,
            maximum_stake_signature_checks_per_block: 20,
            maximum_stake_state_reads_per_block: 50,
            maximum_stake_state_writes_per_block: 20,
        }
    }

    fn resource_policy_qc(subject: &str, members: &[crate::Identity]) -> QuorumCertificate {
        if members.is_empty() {
            let mut qc = simulated_qc();
            qc.subject_hash = subject.into();
            qc
        } else {
            signed_qc(subject, members, required_quorum(members.len()).unwrap())
        }
    }

    fn resource_policy_proposal(
        ledger: &Ledger,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
        proposal_id: &str,
        policy: StakeStateResourcePolicyV1,
        activate_after_height: u64,
        expires_at_height: u64,
    ) -> ProposeStakeStateResourcePolicyV1 {
        let (current_sequence, current_commitment) =
            ledger.current_stake_resource_policy_identity();
        let proposed_policy_commitment =
            stake_state_resource_policy_commitment_v1(&policy).unwrap();
        let mut proposal = ProposeStakeStateResourcePolicyV1 {
            proposal_id: proposal_id.into(),
            network_domain: ledger.descriptor.network_domain.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            activate_after_height,
            expires_at_height,
            expected_current_policy_sequence: current_sequence,
            expected_current_policy_commitment: current_commitment,
            proposed_policy: policy,
            proposed_policy_commitment,
            subject_hash: String::new(),
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        proposal.subject_hash = proposal.compute_subject_hash();
        proposal.validator_qc = resource_policy_qc(&proposal.subject_hash, validators);
        proposal.notary_qc = resource_policy_qc(&proposal.subject_hash, notaries);
        proposal
    }

    fn resource_policy_activation(
        ledger: &Ledger,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
        activation_id: &str,
    ) -> ActivateStakeStateResourcePolicyV1 {
        let pending = ledger.pending_stake_resource_policy.as_ref().unwrap();
        let (current_sequence, current_commitment) =
            ledger.current_stake_resource_policy_identity();
        let mut activation = ActivateStakeStateResourcePolicyV1 {
            activation_id: activation_id.into(),
            network_domain: ledger.descriptor.network_domain.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: pending.expires_at_height,
            proposal_id: pending.proposal_id.clone(),
            expected_pending_policy_commitment: pending.proposed_policy_commitment.clone(),
            expected_current_policy_sequence: current_sequence,
            expected_current_policy_commitment: current_commitment,
            subject_hash: String::new(),
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        activation.subject_hash = activation.compute_subject_hash();
        activation.validator_qc = resource_policy_qc(&activation.subject_hash, validators);
        activation.notary_qc = resource_policy_qc(&activation.subject_hash, notaries);
        activation
    }

    fn resource_bound_registration_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        Vec<crate::Identity>,
        crate::Identity,
        crate::Identity,
        crate::Identity,
        RegisterConsensusValidatorRequestV2,
    ) {
        let (mut ledger, validators, owner, candidate_identity, legacy) =
            consensus_validator_registration_fixture();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        ledger.descriptor.notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let sponsor = generate_identity();
        let sponsor_address = sponsor.address(&ledger.descriptor.zone_id);
        let funded = Amount(1_000_000);
        ledger.reserve = ledger.reserve.checked_sub(funded).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(funded)
            .unwrap();
        let funding_coin = CoinObject {
            object_id: "stake-resource-candidate-funding-0001".into(),
            lineage_root: hash_parts(&[b"RLD-TEST-STAKE-RESOURCE-FUNDING-LINEAGE"]),
            parent_ids: Vec::new(),
            owner: sponsor_address.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            amount: funded,
            state: CoinState::Spendable,
            version: 1,
            created_height: ledger.height,
            transit_id: None,
            imported_from: None,
            origin_zone: ledger.descriptor.zone_id.clone(),
            origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
        };
        ledger
            .coins
            .insert(funding_coin.object_id.clone(), funding_coin.clone());

        let mut policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        policy.maximum_total_stake_state_bytes = 1_000_000;
        policy.maximum_stake_state_bytes_per_block = 100_000;
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "candidate-resource-policy-proposal-1",
            policy,
            ledger.height + 1,
            ledger.height + 20,
        );
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "candidate-resource-policy-activation-1",
        );
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();
        ledger.assert_conservation().unwrap();

        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        let context =
            ledger.stake_context_at(u128::from(ledger.height), ledger.state_root().unwrap());
        let mut candidate = ValidatorCandidateRecord {
            validator_id: legacy.validator_id,
            owner: owner.address(&ledger.descriptor.zone_id),
            public_key: candidate_identity.public_key.clone(),
            key_era: ledger.descriptor.crypto_era,
            registered_height: u128::from(ledger.height + 1),
            exit_height: None,
            proof_of_possession: String::new(),
        };
        candidate.proof_of_possession = sign_bytes(
            &candidate_identity.secret_key,
            &crate::validator_candidate_pop_message_v1(&context, &candidate),
        )
        .unwrap();
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let mut request = RegisterConsensusValidatorRequestV2 {
            request_id: "stake-resource-register-request-0001".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            validator_id: candidate.validator_id,
            owner: candidate.owner,
            public_key: candidate.public_key,
            key_era: candidate.key_era,
            proof_of_possession: candidate.proof_of_possession,
            resource_envelope: crate::StakeStateResourceEnvelopeV1 {
                resource_policy_sequence: accounting.active_policy().sequence,
                resource_policy_commitment: accounting.active_policy_commitment().into(),
                sponsor: sponsor_address,
                funding_coin_id: funding_coin.object_id,
                max_resource_fee: funded,
                max_state_bond: funded,
                lease_end_height: ledger.height + 100,
                resource_subject_hash: "00".repeat(32),
                authorization: signed_authorization(
                    &sponsor,
                    &ledger.descriptor.zone_id,
                    crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
                    "00".repeat(32),
                    9_100,
                ),
            },
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                REGISTER_CONSENSUS_VALIDATOR_ACTION_V2,
                "00".repeat(32),
                9_101,
            ),
        };
        let wire_bytes = ConsensusCommand::RegisterConsensusValidatorV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire_bytes.len().try_into().unwrap(),
            persistent_bytes: register_consensus_validator_persistent_bytes_v2(&request).unwrap(),
            signature_checks: REGISTER_CONSENSUS_VALIDATOR_SIGNATURE_CHECKS_V2,
            state_reads: REGISTER_CONSENSUS_VALIDATOR_STATE_READS_V2,
            state_writes: REGISTER_CONSENSUS_VALIDATOR_STATE_WRITES_V2,
        };
        let admission_request = StakeStateResourceAdmissionRequestV1 {
            resource_key: format!("CANDIDATE/{}", request.validator_id),
            resource_kind: StakeStateResourceKindV1::Candidate,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let subject =
            stake_state_resource_subject_hash_v1(accounting.context(), &admission_request);
        request.resource_envelope.resource_subject_hash = subject.clone();
        request.resource_envelope.authorization = signed_authorization(
            &sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            subject,
            9_100,
        );
        request.authorization = signed_authorization(
            &owner,
            &ledger.descriptor.zone_id,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V2,
            request.payload_hash(),
            9_101,
        );
        assert_eq!(
            ConsensusCommand::RegisterConsensusValidatorV2(Box::new(request.clone()))
                .wire_v1_command_bytes(&ledger.descriptor.network_domain)
                .unwrap()
                .len(),
            usize::try_from(usage.wire_bytes).unwrap()
        );
        (
            ledger,
            validators,
            notaries,
            owner,
            candidate_identity,
            sponsor,
            request,
        )
    }

    fn resign_resource_bound_registration(
        ledger: &Ledger,
        owner: &crate::Identity,
        sponsor: &crate::Identity,
        request: &mut RegisterConsensusValidatorRequestV2,
        sponsor_nonce: u64,
        owner_nonce: u64,
    ) {
        request.resource_envelope.resource_subject_hash = "00".repeat(32);
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            "00".repeat(32),
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V2,
            "00".repeat(32),
            owner_nonce,
        );
        let wire = ConsensusCommand::RegisterConsensusValidatorV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire.len().try_into().unwrap(),
            persistent_bytes: register_consensus_validator_persistent_bytes_v2(request).unwrap(),
            signature_checks: REGISTER_CONSENSUS_VALIDATOR_SIGNATURE_CHECKS_V2,
            state_reads: REGISTER_CONSENSUS_VALIDATOR_STATE_READS_V2,
            state_writes: REGISTER_CONSENSUS_VALIDATOR_STATE_WRITES_V2,
        };
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let admission = StakeStateResourceAdmissionRequestV1 {
            resource_key: format!("CANDIDATE/{}", request.validator_id),
            resource_kind: StakeStateResourceKindV1::Candidate,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let subject = stake_state_resource_subject_hash_v1(accounting.context(), &admission);
        request.resource_envelope.resource_subject_hash = subject.clone();
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            subject,
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V2,
            request.payload_hash(),
            owner_nonce,
        );
    }

    fn resource_bond_renewal_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        RenewStakeStateResourceBondRequestV1,
    ) {
        let (mut ledger, validators, _notaries, _owner, _candidate, sponsor, registration) =
            resource_bound_registration_fixture();
        let registration_commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::RegisterConsensusValidatorV2(Box::new(registration.clone())),
        );
        let outcome = ledger.apply_consensus_commit(registration_commit).unwrap();
        let ConsensusOutcome::StakeCandidateResourceRegistration(outcome) = outcome else {
            panic!("candidate registration returned the wrong outcome");
        };
        let funded = Amount(1_000_000);
        ledger.reserve = ledger.reserve.checked_sub(funded).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(funded)
            .unwrap();
        let sponsor_address = sponsor.address(&ledger.descriptor.zone_id);
        let funding_coin = CoinObject {
            object_id: "stake-resource-renewal-funding-0001".into(),
            lineage_root: hash_parts(&[b"RLD-TEST-STAKE-RESOURCE-RENEWAL-LINEAGE"]),
            parent_ids: Vec::new(),
            owner: sponsor_address.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            amount: funded,
            state: CoinState::Spendable,
            version: 1,
            created_height: ledger.height,
            transit_id: None,
            imported_from: None,
            origin_zone: ledger.descriptor.zone_id.clone(),
            origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
        };
        ledger
            .coins
            .insert(funding_coin.object_id.clone(), funding_coin.clone());
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let original = &accounting.bonds()[&outcome.resource_key];
        let mut request = RenewStakeStateResourceBondRequestV1 {
            renewal_id: "stake-resource-renewal-0001".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            resource_key: original.resource_key.clone(),
            resource_kind: original.resource_kind,
            resource_owner: original.resource_owner.clone(),
            expected_bond_id: original.bond_id.clone(),
            expected_initial_bond_record_hash: original.initial_record_hash(),
            expected_previous_renewal_hash: crate::stake_resource_accounting::ZERO_SHA256.into(),
            expected_current_lease_end_height: original.lease_end_height,
            new_lease_end_height: original.lease_end_height + 100,
            resource_policy_sequence: accounting.active_policy().sequence,
            resource_policy_commitment: accounting.active_policy_commitment().into(),
            sponsor: sponsor_address,
            funding_coin_id: funding_coin.object_id,
            max_resource_fee: funded,
            max_additional_bond: funded,
            authorization: signed_authorization(
                &sponsor,
                &ledger.descriptor.zone_id,
                crate::RENEW_STAKE_STATE_RESOURCE_BOND_ACTION_V1,
                "00".repeat(32),
                10_100,
            ),
        };
        request.authorization = signed_authorization(
            &sponsor,
            &ledger.descriptor.zone_id,
            crate::RENEW_STAKE_STATE_RESOURCE_BOND_ACTION_V1,
            request.payload_hash(),
            10_100,
        );
        ledger.assert_conservation().unwrap();
        (ledger, validators, sponsor, request)
    }

    fn resign_resource_bond_renewal(
        ledger: &Ledger,
        sponsor: &crate::Identity,
        request: &mut RenewStakeStateResourceBondRequestV1,
        nonce: u64,
    ) {
        request.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::RENEW_STAKE_STATE_RESOURCE_BOND_ACTION_V1,
            request.payload_hash(),
            nonce,
        );
    }

    fn certified_command(
        ledger: &Ledger,
        validators: &[crate::Identity],
        command: ConsensusCommand,
    ) -> ConsensusCommit {
        let leader = consensus_leader(ledger, validators);
        let proposal = consensus_proposal(ledger, leader, command);
        ConsensusCommit {
            votes: validators
                .iter()
                .take(required_quorum(validators.len()).unwrap())
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
            proposal,
        }
    }

    fn seed_mainnet_coin(ledger: &mut Ledger, owner: String, amount: Amount) -> CoinObject {
        assert!(!ledger.descriptor.testnet);
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(amount)
            .unwrap();
        ledger.reserve = ledger.reserve.checked_sub(amount).unwrap();
        ledger.advance().unwrap();
        let coin = ledger
            .make_coin(
                owner,
                amount,
                CoinState::Spendable,
                Vec::new(),
                None,
                None,
                None,
                1,
            )
            .unwrap();
        ledger.coins.insert(coin.object_id.clone(), coin.clone());
        ledger.assert_conservation().unwrap();
        coin
    }

    fn signed_value_risk_update(
        ledger: &Ledger,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
        to_cap: ValueCap,
        limits: crate::ValueRiskLimits,
        activate_after_height: u64,
        nonce: u64,
    ) -> ValueRiskPolicyUpdate {
        let (safety_case_hash, safety_case_valid_until_height) = if to_cap == ValueCap::ValueCap0 {
            (String::new(), 0)
        } else {
            (
                hash_parts(&[b"RLD-TEST-SAFETY-CASE", &nonce.to_be_bytes()]),
                activate_after_height + 500,
            )
        };
        let mut update = ValueRiskPolicyUpdate {
            update_id: format!("value-risk-update-{nonce}"),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            policy_version: CURRENT_VALUE_RISK_POLICY_VERSION,
            previous_policy_sequence: ledger.value_risk_policy.policy_sequence,
            from_cap: ledger.value_risk_policy.current_cap,
            to_cap,
            limits,
            safety_case_hash,
            safety_case_valid_until_height,
            proposed_height: ledger.height,
            activate_after_height,
            expires_at_height: activate_after_height + 1_000,
            nonce,
            subject_hash: String::new(),
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        update.subject_hash = update.compute_subject_hash();
        update.validator_qc = signed_qc(
            &update.subject_hash,
            validators,
            required_quorum(validators.len()).unwrap(),
        );
        update.notary_qc = signed_qc(
            &update.subject_hash,
            notaries,
            required_quorum(notaries.len()).unwrap(),
        );
        update
    }

    fn m0_ledger_for_admission_gate(
        display_name: &str,
    ) -> (Ledger, Vec<crate::Identity>, Vec<crate::Identity>) {
        let founder = generate_identity();
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let target = crate::AdmissionWork::from_hex(&format!("7f{}", "ff".repeat(31)))
            .expect("valid fixed admission target");
        let manifest = crate::SignedM0GenesisManifest::create(
            display_name,
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            "founder-admission-censorship-gate",
            crate::AdmissionLogConfigV1 {
                minimum_target: target,
                maximum_target: target,
                genesis_target: target,
                confirmation_work_floor: crate::AdmissionWork([32, 0, 0, 0]),
                contribution_epoch_mapping: crate::ContributionEpochMappingV1 {
                    ledger_height_origin: 0,
                    contribution_epoch_origin: 0,
                    ledger_blocks_per_contribution_epoch: 2,
                },
            },
            crate::AdmissionHash32::from_hex(&hash_bytes(b"admission-censorship-gate-benchmark"))
                .expect("valid benchmark digest"),
            &founder,
        )
        .unwrap();
        let mut ledger = Ledger::genesis_zone(
            &manifest.declaration.descriptor.display_name,
            manifest
                .declaration
                .descriptor
                .genesis_validator_keys
                .clone(),
            manifest.declaration.descriptor.genesis_notary_keys.clone(),
            false,
        )
        .unwrap();
        ledger
            .bind_m0_network_birth(manifest.declaration.network_birth_state())
            .unwrap();
        manifest.validate_ledger_identity(&ledger).unwrap();
        (ledger, validators, notaries)
    }

    fn stall_m0_admission_guard(ledger: &mut Ledger, fixture_label: &[u8]) {
        let entry_id = crate::AdmissionHash32::from_hex(&hash_bytes(
            &[b"admission-censorship-entry".as_slice(), fixture_label].concat(),
        ))
        .unwrap();
        let locator_commitment = crate::AdmissionHash32::from_hex(&hash_bytes(
            &[b"admission-censorship-locator".as_slice(), fixture_label].concat(),
        ))
        .unwrap();
        let proof_id = crate::AdmissionHash32::from_hex(&hash_bytes(
            &[b"admission-censorship-proof".as_slice(), fixture_label].concat(),
        ))
        .unwrap();
        let header_id = crate::AdmissionHash32::from_hex(&hash_bytes(
            &[b"admission-censorship-header".as_slice(), fixture_label].concat(),
        ))
        .unwrap();
        let observed_ledger_height = u128::from(ledger.height);
        let committing_ledger_height = u128::from(ledger.height.checked_add(1).unwrap());
        let (
            context,
            confirmation_work_floor,
            contribution_epoch_mapping,
            prior_committed_header,
            checkpoint_count,
            accumulator,
        ) = {
            let admission = ledger.admission_state.as_ref().unwrap();
            (
                admission.genesis.context.clone(),
                admission.genesis.config.confirmation_work_floor,
                admission.genesis.config.contribution_epoch_mapping.clone(),
                admission.committed_header,
                admission.checkpoint_count,
                admission.checkpoint_accumulator,
            )
        };
        let observed_ledger_epoch = contribution_epoch_mapping
            .epoch_at_height(observed_ledger_height)
            .unwrap();
        let committed_ledger_epoch = contribution_epoch_mapping
            .epoch_at_height(committing_ledger_height)
            .unwrap();
        let checkpoint = crate::AdmissionCheckpointV1 {
            context,
            admission_era: 0,
            header_id,
            log_height: 1,
            cumulative_work: crate::AdmissionWork([1, 0, 0, 0]),
            confirmations: crate::MIN_ADMISSION_CONFIRMATIONS as u16,
            descendant_work: confirmation_work_floor,
            entries_root: crate::admission_entry_root([entry_id]).unwrap(),
            availability_root: crate::admission_availability_root(&[
                crate::AdmissionAvailableEntryV1 {
                    entry_id,
                    locator_commitment,
                    declared_bytes: 1,
                },
            ])
            .unwrap(),
            observed_ledger_epoch,
            committed_ledger_epoch,
        };
        let transition = crate::VerifiedAdmissionCheckpointTransitionV1 {
            prior_committed_header,
            entry_ids: vec![entry_id],
            observed_ledger_height,
            committing_ledger_height,
            next_checkpoint_accumulator: crate::admission_checkpoint_accumulator_successor(
                accumulator,
                checkpoint_count,
                checkpoint.checkpoint_id(),
                proof_id,
            )
            .unwrap(),
            checkpoint,
            proof_id,
        };
        let proposal_context = ledger
            .test_authenticated_admission_checkpoint_proposal(&transition)
            .unwrap();
        ledger
            .execute_authenticated_admission_checkpoint_transition(&proposal_context, &transition)
            .unwrap();
        let current_asset_root =
            crate::AdmissionHash32::from_hex(&ledger.state_root_before_admission().unwrap())
                .unwrap();
        ledger
            .admission_state
            .as_mut()
            .unwrap()
            .censorship_guard
            .advance_epoch(committed_ledger_epoch + 3, current_asset_root)
            .unwrap();
        assert_eq!(
            ledger
                .admission_state
                .as_ref()
                .unwrap()
                .censorship_guard
                .status(),
            crate::AdmissionCensorshipStatusV1::CensorshipStalled
        );
    }

    #[test]
    fn formal_tag28_proposal_is_bound_but_pure_dispatch_remains_fail_closed() {
        let (ledger, validators, _) =
            m0_ledger_for_admission_gate("M0 authenticated tag-28 proposal gate");
        let admission = ledger.admission_state.as_ref().unwrap();
        let proof = AdmissionCheckpointProofV1 {
            context: admission.genesis.context.clone(),
            prior_committed_header: admission.committed_header,
            prior_checkpoint_accumulator: admission.checkpoint_accumulator,
            batch_segment: Vec::new(),
            confirmation_segment: Vec::new(),
        };
        let leader = consensus_leader(&ledger, &validators);
        let command = ConsensusCommand::CommitAdmissionCheckpoint(Box::new(proof.clone()));
        let proposal_plan = ledger.plan_admission_checkpoint_proposal(&proof).unwrap();
        assert_eq!(proposal_plan.parent_height(), ledger.height);
        assert_eq!(
            proposal_plan.parent_state_root(),
            ledger.state_root().unwrap()
        );
        assert_eq!(proposal_plan.expected_height(), ledger.height + 1);
        assert_eq!(
            proposal_plan.command_hash(),
            command
                .wire_v1_command_hash(&ledger.descriptor.network_domain)
                .unwrap()
        );
        let mut proposal = ConsensusProposal {
            proposal_id: "tag28-authentication-control".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            parent_height: ledger.height,
            parent_state_root: ledger.state_root().unwrap(),
            round: 0,
            proposer_public_key: leader.public_key.clone(),
            command_hash: command
                .wire_v1_command_hash(&ledger.descriptor.network_domain)
                .unwrap(),
            command,
            expected_height: ledger.height + 1,
            expected_state_root: hash_bytes(b"tag28-externally-derived-successor"),
            signature: String::new(),
        };
        proposal.signature = sign_bytes(
            &leader.secret_key,
            &proposal
                .wire_v1_signing_bytes(&ledger.descriptor.network_domain)
                .unwrap(),
        )
        .unwrap();
        let before = serde_json::to_vec(&ledger).unwrap();
        let authenticated = ledger
            .authenticate_admission_checkpoint_proposal(&proposal, &proof)
            .unwrap();
        assert_eq!(authenticated.command_hash(), proposal.command_hash);
        assert_eq!(authenticated.proof_id(), proof.proof_id().unwrap());
        assert_eq!(authenticated.proof_id(), proposal_plan.proof_id());
        assert_eq!(
            authenticated.committing_ledger_height(),
            proposal_plan.committing_ledger_height()
        );
        let mut dispatch = ledger.clone();
        assert!(matches!(
            dispatch.execute_consensus_command(proposal.command.clone()),
            Err(LedgerError::Invalid(message)) if message.contains("node-local history")
        ));
        assert_eq!(serde_json::to_vec(&dispatch).unwrap(), before);

        let mut other_proof = proof.clone();
        other_proof.prior_checkpoint_accumulator =
            AdmissionHash32::from_hex(&hash_bytes(b"different-accumulator")).unwrap();
        assert!(matches!(
            ledger.authenticate_admission_checkpoint_proposal(&proposal, &other_proof),
            Err(LedgerError::InvalidQuorum(message)) if message.contains("decoded proposal command")
        ));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), before);
    }

    fn resign_value_risk_update(
        update: &mut ValueRiskPolicyUpdate,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
    ) {
        update.subject_hash = update.compute_subject_hash();
        update.validator_qc = signed_qc(
            &update.subject_hash,
            validators,
            required_quorum(validators.len()).unwrap(),
        );
        update.notary_qc = signed_qc(
            &update.subject_hash,
            notaries,
            required_quorum(notaries.len()).unwrap(),
        );
    }

    fn activate_mainnet_value_policy(
        ledger: &mut Ledger,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
        limits: crate::ValueRiskLimits,
        nonce: u64,
    ) {
        let activate_after_height = ledger.height + MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS;
        let update = signed_value_risk_update(
            ledger,
            validators,
            notaries,
            ValueCap::ValueCap1,
            limits,
            activate_after_height,
            nonce,
        );
        ledger.submit_value_risk_policy_update(update).unwrap();
        while ledger.height < activate_after_height {
            ledger.advance().unwrap();
        }
        ledger.activate_pending_value_risk_policy().unwrap();
    }

    fn mainnet_capsule_for_test(
        source: &mut Ledger,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
        sender: &crate::Identity,
        destination_zone: &str,
        recipient: &str,
        amount: Amount,
    ) -> TransitCapsule {
        let source_zone = source.descriptor.zone_id.clone();
        let coin = seed_mainnet_coin(
            source,
            sender.address(&source_zone),
            Amount::from_rld_whole(10).unwrap(),
        );
        // The reference node deliberately cannot originate mainnet capsules
        // without an external BFT driver. This test-only switch exercises the
        // destination's fully signed import path without weakening production.
        source.descriptor.testnet = true;
        let intent = signed_intent(
            sender,
            &source_zone,
            destination_zone,
            recipient,
            &coin.object_id,
            amount,
        );
        let mut capsule = source
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        source.descriptor.testnet = false;
        capsule.source_descriptor.testnet = false;
        let subject = capsule.subject_hash();
        capsule.validator_qc = signed_qc(
            &subject,
            validators,
            required_quorum(validators.len()).unwrap(),
        );
        capsule.notary_qc = signed_qc(&subject, notaries, required_quorum(notaries.len()).unwrap());
        capsule
    }

    fn spendability_request(
        provider: &crate::Identity,
        zone_id: &str,
        coin_id: &str,
        payment_id: &str,
        amount: Amount,
        nonce: u64,
    ) -> SpendabilityCertificateRequest {
        let liquidity_provider = provider.address(zone_id);
        let recipient = format!("rld:{zone_id}:recipient-{nonce}");
        let settlement_claim_transit_id = format!("settlement-claim-{nonce}");
        let payload_hash = action_payload_hash(
            "ISSUE_DSC",
            &[
                payment_id.as_bytes(),
                coin_id.as_bytes(),
                liquidity_provider.as_bytes(),
                recipient.as_bytes(),
                &amount.0.to_be_bytes(),
                settlement_claim_transit_id.as_bytes(),
            ],
        );
        SpendabilityCertificateRequest {
            payment_id: payment_id.into(),
            provider_coin_id: coin_id.into(),
            liquidity_provider,
            recipient,
            amount,
            settlement_claim_transit_id,
            authorization: signed_authorization(
                provider,
                zone_id,
                "ISSUE_DSC",
                payload_hash,
                nonce,
            ),
        }
    }

    fn consensus_proposal(
        ledger: &Ledger,
        proposer: &crate::Identity,
        command: ConsensusCommand,
    ) -> ConsensusProposal {
        let parent_state_root = ledger.state_root().unwrap();
        let command_hash = command.command_hash();
        let mut staged = ledger.clone();
        staged.execute_consensus_command(command.clone()).unwrap();
        let mut proposal = ConsensusProposal {
            proposal_id: format!("proposal-{}", &command_hash[..24]),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            parent_height: ledger.height,
            parent_state_root,
            round: 0,
            proposer_public_key: proposer.public_key.clone(),
            command,
            command_hash,
            expected_height: staged.height,
            expected_state_root: staged.state_root().unwrap(),
            signature: String::new(),
        };
        proposal.signature = sign_bytes(&proposer.secret_key, &proposal.signing_bytes()).unwrap();
        proposal
    }

    fn consensus_leader<'a>(
        ledger: &Ledger,
        validators: &'a [crate::Identity],
    ) -> &'a crate::Identity {
        let leader = crate::deterministic_round_zero_leader(
            &ledger.descriptor.validator_keys,
            ledger.height,
        )
        .unwrap();
        validators
            .iter()
            .find(|validator| validator.public_key == leader)
            .expect("deterministic leader belongs to the test validator set")
    }

    fn consensus_vote(
        proposal: &ConsensusProposal,
        validator: &crate::Identity,
    ) -> crate::ConsensusVote {
        let mut vote = crate::ConsensusVote {
            proposal_id: proposal.proposal_id.clone(),
            proposal_hash: proposal.proposal_hash(),
            zone_id: proposal.zone_id.clone(),
            currency_genesis_root: proposal.currency_genesis_root.clone(),
            protocol_era: proposal.protocol_era,
            crypto_era: proposal.crypto_era,
            parent_height: proposal.parent_height,
            parent_state_root: proposal.parent_state_root.clone(),
            round: proposal.round,
            expected_state_root: proposal.expected_state_root.clone(),
            voter_public_key: validator.public_key.clone(),
            signature: String::new(),
        };
        vote.signature = sign_bytes(&validator.secret_key, &vote.signing_bytes()).unwrap();
        vote
    }

    fn stake_authority_governance_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        Vec<crate::Identity>,
        Vec<crate::Identity>,
        StakeAuthorityGovernanceUpdateV1,
    ) {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let mut ledger = Ledger::genesis_zone(
            "Stake authority command",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            true,
        )
        .unwrap();
        let candidate_identities = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();

        let seeded_stake = Amount::from_runlai(40);
        ledger.reserve = ledger.reserve.checked_sub(seeded_stake).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(seeded_stake)
            .unwrap();

        for index in 0..4 {
            let escrow_coin_id = format!("stake-escrow-{index:04}");
            let source_coin_id = format!("stake-source-{index:04}");
            let owner = format!("stake-owner-{index:04}");
            let lineage_root = format!("stake-lineage-{index:04}");
            ledger.coins.insert(
                source_coin_id.clone(),
                CoinObject {
                    object_id: source_coin_id.clone(),
                    lineage_root: lineage_root.clone(),
                    parent_ids: Vec::new(),
                    owner: owner.clone(),
                    zone_id: ledger.descriptor.zone_id.clone(),
                    amount: Amount::from_runlai(10),
                    state: CoinState::Consumed,
                    version: 0,
                    created_height: 0,
                    transit_id: None,
                    imported_from: None,
                    origin_zone: ledger.descriptor.zone_id.clone(),
                    origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
                },
            );
            ledger.coins.insert(
                escrow_coin_id.clone(),
                CoinObject {
                    object_id: escrow_coin_id.clone(),
                    lineage_root,
                    parent_ids: vec![source_coin_id.clone()],
                    owner: owner.clone(),
                    zone_id: ledger.descriptor.zone_id.clone(),
                    amount: Amount::from_runlai(10),
                    state: CoinState::Reserved,
                    version: 1,
                    created_height: 0,
                    transit_id: None,
                    imported_from: None,
                    origin_zone: ledger.descriptor.zone_id.clone(),
                    origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
                },
            );
            let position = ConsensusStakePosition {
                position_id: format!("stake-position-{index:04}"),
                kind: ConsensusStakePositionKind::SelfBond {
                    validator_id: format!("stake-validator-{index:04}"),
                },
                owner,
                source_coin_id,
                escrow_coin_id,
                amount: Amount::from_runlai(10),
                locked_height: 0,
                committed_through_height: 100,
                slash_terms: None,
            };
            ledger
                .consensus_stake_escrows
                .insert(position.escrow_coin_id.clone(), position);
        }
        ledger.assert_conservation().unwrap();

        let source_root = ledger.state_root().unwrap();
        let context = ledger.stake_context_at(u128::from(ledger.height), source_root.clone());
        let candidates = candidate_identities
            .iter()
            .enumerate()
            .map(|(index, identity)| {
                let mut internal = crate::ValidatorCandidateRecord {
                    validator_id: format!("stake-validator-{index:04}"),
                    owner: format!("stake-owner-{index:04}"),
                    public_key: identity.public_key.clone(),
                    key_era: ledger.descriptor.crypto_era,
                    registered_height: 0,
                    exit_height: None,
                    proof_of_possession: String::new(),
                };
                internal.proof_of_possession = sign_bytes(
                    &identity.secret_key,
                    &crate::validator_candidate_pop_message_v1(&context, &internal),
                )
                .unwrap();
                crate::StakeAuthorityCandidateCommandV1 {
                    validator_id: internal.validator_id,
                    owner: internal.owner,
                    public_key: internal.public_key,
                    key_era: internal.key_era,
                    registered_height: 0,
                    exit_height: None,
                    proof_of_possession: internal.proof_of_possession,
                }
            })
            .collect::<Vec<_>>();
        let positions = (0..4)
            .map(|index| crate::StakeAuthorityPositionCommandV1 {
                position_id: format!("stake-position-{index:04}"),
                position_type: crate::StakePositionTypeV1::SelfBond,
                validator_id: format!("stake-validator-{index:04}"),
                owner: format!("stake-owner-{index:04}"),
                source_coin_id: format!("stake-source-{index:04}"),
                escrow_coin_id: format!("stake-escrow-{index:04}"),
                amount: Amount::from_runlai(10),
                locked_height: 0,
                committed_through_height: 100,
            })
            .collect();
        let ubo_validators = (0..4)
            .map(|index| crate::StakeUboControlEntryV1 {
                validator_id: format!("stake-validator-{index:04}"),
                record: crate::StakeUboControlRecordCommandV1 {
                    control_group: format!("stake-control-{index:04}"),
                    valid_from_height: 0,
                    challenge_ends_height: 0,
                    valid_through_height: 100,
                    evidence_hash: hash_parts(&[
                        b"RLD-TEST-STAKE-UBO-EVIDENCE",
                        &(index as u64).to_be_bytes(),
                    ]),
                },
            })
            .collect();
        let genesis_anchor = ledger_stake_authority_genesis_anchor_v1(&context);
        let mut request = StakeAuthorityGovernanceUpdateV1 {
            update_id: "stake-authority-governance-1".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 10,
            authority_version: crate::STAKE_AUTHORITY_STATE_VERSION_V1,
            sequence: 1,
            expected_previous_commitment: genesis_anchor,
            policy: crate::StakeAuthorityPolicyCommandV1 {
                policy_version: 1,
                minimum_self_bond: Amount::from_runlai(10),
                minimum_delegation: Amount::from_runlai(1),
                candidate_maturity_blocks: 1,
                stake_maturity_blocks: 1,
                evidence_window_blocks: 1,
                activation_delay_blocks: 2,
                epoch_length_blocks: 10,
                maximum_validators: 4,
            },
            candidates,
            positions,
            ubo_map_version: 1,
            ubo_sequence: 1,
            ubo_predecessor_commitment: hash_parts(&[b"RLD-TEST-UBO-GENESIS"]),
            ubo_verifier_set_commitment: hash_parts(&[b"RLD-TEST-UBO-VERIFIERS"]),
            ubo_evidence_root: hash_parts(&[b"RLD-TEST-UBO-ROOT"]),
            ubo_validators,
            prospective_authority_commitment: "00".repeat(32),
            subject_hash: "00".repeat(32),
            validator_qc: signed_qc("00", &validators, 3),
            notary_qc: signed_qc("00", &notaries, 3),
        };
        let prospective = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(ledger.height + 1),
            None,
            request.to_ledger_update().unwrap(),
            &ledger.coins,
        )
        .unwrap();
        request.prospective_authority_commitment = prospective.commitment;
        request.subject_hash = request.compute_subject_hash();
        request.validator_qc = signed_qc(&request.subject_hash, &validators, 3);
        request.notary_qc = signed_qc(&request.subject_hash, &notaries, 3);
        (ledger, validators, notaries, candidate_identities, request)
    }

    fn consensus_stake_lock_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        LockConsensusStakeRequestV1,
    ) {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let owner = generate_identity();
        let candidate_identity = generate_identity();
        let mut ledger = Ledger::genesis_zone(
            "Atomic stake lock",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            true,
        )
        .unwrap();
        let owner_address = owner.address(&ledger.descriptor.zone_id);
        let funded = Amount::from_runlai(50);
        ledger.reserve = ledger.reserve.checked_sub(funded).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(funded)
            .unwrap();
        let source_coin = CoinObject {
            object_id: "stake-lock-source-0000".into(),
            lineage_root: hash_parts(&[b"RLD-TEST-STAKE-LOCK-LINEAGE-0000"]),
            parent_ids: Vec::new(),
            owner: owner_address.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            amount: funded,
            state: CoinState::Spendable,
            version: 1,
            created_height: ledger.height,
            transit_id: None,
            imported_from: None,
            origin_zone: ledger.descriptor.zone_id.clone(),
            origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
        };
        ledger
            .coins
            .insert(source_coin.object_id.clone(), source_coin.clone());
        ledger.assert_conservation().unwrap();

        let context =
            ledger.stake_context_at(u128::from(ledger.height), ledger.state_root().unwrap());
        let mut candidate = crate::ValidatorCandidateRecord {
            validator_id: "stake-lock-validator-0000".into(),
            owner: owner_address.clone(),
            public_key: candidate_identity.public_key.clone(),
            key_era: ledger.descriptor.crypto_era,
            registered_height: 0,
            exit_height: None,
            proof_of_possession: String::new(),
        };
        candidate.proof_of_possession = sign_bytes(
            &candidate_identity.secret_key,
            &crate::validator_candidate_pop_message_v1(&context, &candidate),
        )
        .unwrap();
        let mut governance = StakeAuthorityGovernanceUpdateV1 {
            update_id: "stake-lock-authority-1".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            authority_version: crate::STAKE_AUTHORITY_STATE_VERSION_V1,
            sequence: 1,
            expected_previous_commitment: ledger_stake_authority_genesis_anchor_v1(&context),
            policy: crate::StakeAuthorityPolicyCommandV1 {
                policy_version: 1,
                minimum_self_bond: Amount::from_runlai(10),
                minimum_delegation: Amount::from_runlai(1),
                candidate_maturity_blocks: 1,
                stake_maturity_blocks: 1,
                evidence_window_blocks: 2,
                activation_delay_blocks: 2,
                epoch_length_blocks: 10,
                maximum_validators: 4,
            },
            candidates: vec![crate::StakeAuthorityCandidateCommandV1 {
                validator_id: candidate.validator_id,
                owner: candidate.owner,
                public_key: candidate.public_key,
                key_era: candidate.key_era,
                registered_height: 0,
                exit_height: None,
                proof_of_possession: candidate.proof_of_possession,
            }],
            positions: Vec::new(),
            ubo_map_version: 1,
            ubo_sequence: 1,
            ubo_predecessor_commitment: hash_parts(&[b"RLD-TEST-STAKE-LOCK-UBO-GENESIS"]),
            ubo_verifier_set_commitment: hash_parts(&[b"RLD-TEST-STAKE-LOCK-UBO-VERIFIERS"]),
            ubo_evidence_root: hash_parts(&[b"RLD-TEST-STAKE-LOCK-UBO-EVIDENCE"]),
            ubo_validators: vec![
                crate::StakeUboControlEntryV1 {
                    validator_id: "stake-lock-validator-0000".into(),
                    record: crate::StakeUboControlRecordCommandV1 {
                        control_group: "stake-lock-control-0000".into(),
                        valid_from_height: 0,
                        challenge_ends_height: 0,
                        valid_through_height: 1_000,
                        evidence_hash: hash_parts(&[b"RLD-TEST-STAKE-LOCK-UBO-RECORD"]),
                    },
                },
                crate::StakeUboControlEntryV1 {
                    validator_id: "stake-register-validator-0001".into(),
                    record: crate::StakeUboControlRecordCommandV1 {
                        control_group: "stake-register-control-0001".into(),
                        valid_from_height: 0,
                        challenge_ends_height: 0,
                        valid_through_height: 1_000,
                        evidence_hash: hash_parts(&[b"RLD-TEST-STAKE-REGISTER-UBO-RECORD"]),
                    },
                },
            ],
            prospective_authority_commitment: "00".repeat(32),
            subject_hash: "00".repeat(32),
            validator_qc: signed_qc("00", &validators, 3),
            notary_qc: signed_qc("00", &notaries, 3),
        };
        let prospective = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(ledger.height + 1),
            None,
            governance.to_ledger_update().unwrap(),
            &ledger.coins,
        )
        .unwrap();
        governance.prospective_authority_commitment = prospective.commitment;
        governance.subject_hash = governance.compute_subject_hash();
        governance.validator_qc = signed_qc(&governance.subject_hash, &validators, 3);
        governance.notary_qc = signed_qc(&governance.subject_hash, &notaries, 3);
        ledger.submit_stake_authority_update(governance).unwrap();
        let authority = ledger.consensus_stake_authority.clone().unwrap();

        let mut request = LockConsensusStakeRequestV1 {
            position_id: "stake-lock-position-0000".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            position_type: StakePositionTypeV1::SelfBond,
            validator_id: "stake-lock-validator-0000".into(),
            owner: owner_address,
            source_coin_id: source_coin.object_id,
            amount: Amount::from_runlai(10),
            committed_through_height: 100,
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                LOCK_CONSENSUS_STAKE_ACTION_V1,
                String::new(),
                700,
            ),
        };
        request.authorization = signed_authorization(
            &owner,
            &ledger.descriptor.zone_id,
            LOCK_CONSENSUS_STAKE_ACTION_V1,
            request.payload_hash(),
            700,
        );
        (ledger, validators, owner, request)
    }

    fn v2_lock_request_from_v1(
        ledger: &Ledger,
        owner: &crate::Identity,
        request: LockConsensusStakeRequestV1,
        nonce: u64,
    ) -> LockConsensusStakeRequestV2 {
        let position_kind = match request.position_type {
            StakePositionTypeV1::SelfBond => ConsensusStakePositionKind::SelfBond {
                validator_id: request.validator_id.clone(),
            },
            StakePositionTypeV1::Delegation => ConsensusStakePositionKind::Delegation {
                validator_id: request.validator_id.clone(),
            },
        };
        let slash_terms_payload = consensus_stake_slash_terms_payload_hash_v2(
            &request.position_id,
            &position_kind,
            &request.owner,
            &request.source_coin_id,
            request.amount,
            u128::from(request.committed_through_height),
            &ConsensusStakeSlashPolicyV2::protocol_v2(),
        );
        let slash_terms_authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            ACCEPT_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
            slash_terms_payload,
            nonce,
        );
        let mut v2 = LockConsensusStakeRequestV2 {
            position_id: request.position_id,
            zone_id: request.zone_id,
            currency_genesis_root: request.currency_genesis_root,
            protocol_era: request.protocol_era,
            crypto_era: request.crypto_era,
            proposed_height: request.proposed_height,
            expires_at_height: request.expires_at_height,
            expected_authority_sequence: request.expected_authority_sequence,
            expected_authority_commitment: request.expected_authority_commitment,
            position_type: request.position_type,
            validator_id: request.validator_id,
            owner: request.owner,
            source_coin_id: request.source_coin_id,
            amount: request.amount,
            committed_through_height: request.committed_through_height,
            slash_terms_authorization,
            authorization: signed_authorization(
                owner,
                &ledger.descriptor.zone_id,
                LOCK_CONSENSUS_STAKE_ACTION_V2,
                String::new(),
                nonce + 1,
            ),
        };
        v2.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            LOCK_CONSENSUS_STAKE_ACTION_V2,
            v2.payload_hash(),
            nonce + 1,
        );
        v2
    }

    fn resource_bound_stake_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        crate::Identity,
        LockConsensusStakeRequestV3,
    ) {
        let (mut ledger, validators, owner, mut v1) = consensus_stake_lock_fixture();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        ledger.descriptor.notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let sponsor = generate_identity();
        let sponsor_address = sponsor.address(&ledger.descriptor.zone_id);
        let funded = Amount(1_000_000);
        ledger.reserve = ledger.reserve.checked_sub(funded).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(funded)
            .unwrap();
        let funding_coin = CoinObject {
            object_id: "stake-resource-position-funding-0001".into(),
            lineage_root: hash_parts(&[b"RLD-TEST-STAKE-POSITION-RESOURCE-LINEAGE"]),
            parent_ids: Vec::new(),
            owner: sponsor_address.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            amount: funded,
            state: CoinState::Spendable,
            version: 1,
            created_height: ledger.height,
            transit_id: None,
            imported_from: None,
            origin_zone: ledger.descriptor.zone_id.clone(),
            origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
        };
        ledger
            .coins
            .insert(funding_coin.object_id.clone(), funding_coin.clone());
        let mut policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        policy.maximum_total_stake_state_bytes = 1_000_000;
        policy.maximum_stake_state_bytes_per_block = 100_000;
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "position-resource-policy-proposal-1",
            policy,
            ledger.height + 1,
            ledger.height + 20,
        );
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "position-resource-policy-activation-1",
        );
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        v1.proposed_height = ledger.height;
        v1.expires_at_height = ledger.height + 20;
        v1.expected_authority_sequence = authority.sequence;
        v1.expected_authority_commitment = authority.commitment.clone();
        let v2 = v2_lock_request_from_v1(&ledger, &owner, v1, 9_400);
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let mut request = LockConsensusStakeRequestV3 {
            position_id: v2.position_id,
            zone_id: v2.zone_id,
            currency_genesis_root: v2.currency_genesis_root,
            protocol_era: v2.protocol_era,
            crypto_era: v2.crypto_era,
            proposed_height: v2.proposed_height,
            expires_at_height: v2.expires_at_height,
            expected_authority_sequence: v2.expected_authority_sequence,
            expected_authority_commitment: v2.expected_authority_commitment,
            position_type: v2.position_type,
            validator_id: v2.validator_id,
            owner: v2.owner,
            source_coin_id: v2.source_coin_id,
            amount: v2.amount,
            committed_through_height: v2.committed_through_height,
            slash_terms_authorization: v2.slash_terms_authorization,
            resource_envelope: crate::StakeStateResourceEnvelopeV1 {
                resource_policy_sequence: accounting.active_policy().sequence,
                resource_policy_commitment: accounting.active_policy_commitment().into(),
                sponsor: sponsor_address,
                funding_coin_id: funding_coin.object_id,
                max_resource_fee: funded,
                max_state_bond: funded,
                lease_end_height: v2.committed_through_height
                    + accounting.active_policy().terminal_retention_blocks,
                resource_subject_hash: "00".repeat(32),
                authorization: signed_authorization(
                    &sponsor,
                    &ledger.descriptor.zone_id,
                    crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
                    "00".repeat(32),
                    9_402,
                ),
            },
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                LOCK_CONSENSUS_STAKE_ACTION_V3,
                "00".repeat(32),
                9_401,
            ),
        };
        resign_resource_bound_stake(&ledger, &owner, &sponsor, &mut request, 9_402, 9_401);
        (ledger, validators, owner, sponsor, request)
    }

    fn resign_resource_bound_stake(
        ledger: &Ledger,
        owner: &crate::Identity,
        sponsor: &crate::Identity,
        request: &mut LockConsensusStakeRequestV3,
        sponsor_nonce: u64,
        owner_nonce: u64,
    ) {
        request.resource_envelope.resource_subject_hash = "00".repeat(32);
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            "00".repeat(32),
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            LOCK_CONSENSUS_STAKE_ACTION_V3,
            "00".repeat(32),
            owner_nonce,
        );
        let wire = ConsensusCommand::LockConsensusStakeV3(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire.len().try_into().unwrap(),
            persistent_bytes: lock_consensus_stake_persistent_bytes_v3(request).unwrap(),
            signature_checks: LOCK_CONSENSUS_STAKE_SIGNATURE_CHECKS_V3,
            state_reads: LOCK_CONSENSUS_STAKE_STATE_READS_V3,
            state_writes: LOCK_CONSENSUS_STAKE_STATE_WRITES_V3,
        };
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let admission = StakeStateResourceAdmissionRequestV1 {
            resource_key: format!("POSITION/{}", request.position_id),
            resource_kind: StakeStateResourceKindV1::Position,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let subject = stake_state_resource_subject_hash_v1(accounting.context(), &admission);
        request.resource_envelope.resource_subject_hash = subject.clone();
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            subject,
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            LOCK_CONSENSUS_STAKE_ACTION_V3,
            request.payload_hash(),
            owner_nonce,
        );
        assert_eq!(
            ConsensusCommand::LockConsensusStakeV3(Box::new(request.clone()))
                .wire_v1_command_bytes(&ledger.descriptor.network_domain)
                .unwrap()
                .len(),
            usize::try_from(usage.wire_bytes).unwrap()
        );
    }

    fn resource_position_migration_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        crate::Identity,
        MigrateConsensusStakeResourceRequestV1,
    ) {
        let (mut ledger, validators, owner, v1) = consensus_stake_lock_fixture();
        let v2 = v2_lock_request_from_v1(&ledger, &owner, v1, 9_500);
        let position = ledger.lock_consensus_stake_v2(v2).unwrap();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        ledger.descriptor.notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let sponsor = generate_identity();
        let sponsor_address = sponsor.address(&ledger.descriptor.zone_id);
        let funded = Amount(1_000_000);
        ledger.reserve = ledger.reserve.checked_sub(funded).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(funded)
            .unwrap();
        let funding_coin = CoinObject {
            object_id: "stake-resource-migration-funding-0001".into(),
            lineage_root: hash_parts(&[b"RLD-TEST-STAKE-RESOURCE-MIGRATION-LINEAGE"]),
            parent_ids: Vec::new(),
            owner: sponsor_address.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            amount: funded,
            state: CoinState::Spendable,
            version: 1,
            created_height: ledger.height,
            transit_id: None,
            imported_from: None,
            origin_zone: ledger.descriptor.zone_id.clone(),
            origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
        };
        ledger
            .coins
            .insert(funding_coin.object_id.clone(), funding_coin.clone());
        let mut policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        policy.maximum_total_stake_state_bytes = 1_000_000;
        policy.maximum_stake_state_bytes_per_block = 100_000;
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "migration-resource-policy-proposal-1",
            policy,
            ledger.height + 1,
            ledger.height + 20,
        );
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "migration-resource-policy-activation-1",
        );
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let mut request = MigrateConsensusStakeResourceRequestV1 {
            request_id: "stake-resource-migration-request-0001".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            position_id: position.position_id.clone(),
            escrow_coin_id: position.escrow_coin_id.clone(),
            owner: position.owner.clone(),
            expected_position_commitment: position.resource_commitment_v1(),
            resource_envelope: crate::StakeStateResourceEnvelopeV1 {
                resource_policy_sequence: accounting.active_policy().sequence,
                resource_policy_commitment: accounting.active_policy_commitment().into(),
                sponsor: sponsor_address,
                funding_coin_id: funding_coin.object_id,
                max_resource_fee: funded,
                max_state_bond: funded,
                lease_end_height: u64::try_from(position.committed_through_height).unwrap()
                    + accounting.active_policy().terminal_retention_blocks,
                resource_subject_hash: "00".repeat(32),
                authorization: signed_authorization(
                    &sponsor,
                    &ledger.descriptor.zone_id,
                    crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
                    "00".repeat(32),
                    9_502,
                ),
            },
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                MIGRATE_CONSENSUS_STAKE_RESOURCE_ACTION_V1,
                "00".repeat(32),
                9_501,
            ),
        };
        resign_resource_migration(
            &ledger,
            &owner,
            &sponsor,
            &position,
            &mut request,
            9_502,
            9_501,
        );
        (ledger, validators, owner, sponsor, request)
    }

    fn resign_resource_migration(
        ledger: &Ledger,
        owner: &crate::Identity,
        sponsor: &crate::Identity,
        position: &ConsensusStakePosition,
        request: &mut MigrateConsensusStakeResourceRequestV1,
        sponsor_nonce: u64,
        owner_nonce: u64,
    ) {
        request.resource_envelope.resource_subject_hash = "00".repeat(32);
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            "00".repeat(32),
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            MIGRATE_CONSENSUS_STAKE_RESOURCE_ACTION_V1,
            "00".repeat(32),
            owner_nonce,
        );
        let wire = ConsensusCommand::MigrateConsensusStakeResource(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire.len().try_into().unwrap(),
            persistent_bytes: migrate_consensus_stake_resource_persistent_bytes_v1(
                request, position,
            )
            .unwrap(),
            signature_checks: MIGRATE_CONSENSUS_STAKE_RESOURCE_SIGNATURE_CHECKS_V1,
            state_reads: MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_READS_V1,
            state_writes: MIGRATE_CONSENSUS_STAKE_RESOURCE_STATE_WRITES_V1,
        };
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let admission = StakeStateResourceAdmissionRequestV1 {
            resource_key: format!("POSITION/{}", request.position_id),
            resource_kind: StakeStateResourceKindV1::Position,
            resource_owner: request.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let subject = stake_state_resource_subject_hash_v1(accounting.context(), &admission);
        request.resource_envelope.resource_subject_hash = subject.clone();
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            subject,
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            MIGRATE_CONSENSUS_STAKE_RESOURCE_ACTION_V1,
            request.payload_hash(),
            owner_nonce,
        );
        assert_eq!(
            ConsensusCommand::MigrateConsensusStakeResource(Box::new(request.clone()))
                .wire_v1_command_bytes(&ledger.descriptor.network_domain)
                .unwrap()
                .len(),
            usize::try_from(usage.wire_bytes).unwrap()
        );
    }

    fn seed_stake_resource_test_coin(
        ledger: &mut Ledger,
        object_id: &str,
        owner: String,
        amount: Amount,
    ) -> CoinObject {
        ledger.reserve = ledger.reserve.checked_sub(amount).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(amount)
            .unwrap();
        let coin = CoinObject {
            object_id: object_id.into(),
            lineage_root: hash_parts(&[
                b"RLD-TEST-STAKE-RESOURCE-COIN-LINEAGE",
                object_id.as_bytes(),
            ]),
            parent_ids: Vec::new(),
            owner,
            zone_id: ledger.descriptor.zone_id.clone(),
            amount,
            state: CoinState::Spendable,
            version: 1,
            created_height: ledger.height,
            transit_id: None,
            imported_from: None,
            origin_zone: ledger.descriptor.zone_id.clone(),
            origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
        };
        ledger.coins.insert(coin.object_id.clone(), coin.clone());
        coin
    }

    fn resign_candidate_resource_migration(
        ledger: &Ledger,
        owner: &crate::Identity,
        sponsor: &crate::Identity,
        candidate: &ValidatorCandidateRecord,
        request: &mut MigrateConsensusCandidateResourceRequestV1,
        sponsor_nonce: u64,
        owner_nonce: u64,
    ) {
        request.resource_envelope.resource_subject_hash = "00".repeat(32);
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            "00".repeat(32),
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_ACTION_V1,
            "00".repeat(32),
            owner_nonce,
        );
        let wire = ConsensusCommand::MigrateConsensusCandidateResource(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire.len().try_into().unwrap(),
            persistent_bytes: migrate_consensus_candidate_resource_persistent_bytes_v1(
                request, candidate,
            )
            .unwrap(),
            signature_checks: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_SIGNATURE_CHECKS_V1,
            state_reads: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_READS_V1,
            state_writes: MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_STATE_WRITES_V1,
        };
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let admission = StakeStateResourceAdmissionRequestV1 {
            resource_key: format!("CANDIDATE/{}", candidate.validator_id),
            resource_kind: StakeStateResourceKindV1::Candidate,
            resource_owner: candidate.owner.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: request.expected_authority_commitment.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let subject = stake_state_resource_subject_hash_v1(accounting.context(), &admission);
        request.resource_envelope.resource_subject_hash = subject.clone();
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            subject,
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_ACTION_V1,
            request.payload_hash(),
            owner_nonce,
        );
        assert_eq!(
            ConsensusCommand::MigrateConsensusCandidateResource(Box::new(request.clone()))
                .wire_v1_command_bytes(&ledger.descriptor.network_domain)
                .unwrap()
                .len(),
            usize::try_from(usage.wire_bytes).unwrap()
        );
    }

    fn resource_candidate_migration_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        crate::Identity,
        MigrateConsensusCandidateResourceRequestV1,
    ) {
        let (mut ledger, validators, owner, _stake_request) = consensus_stake_lock_fixture();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        ledger.descriptor.notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let sponsor = generate_identity();
        let funded = Amount(1_000_000);
        let sponsor_address = sponsor.address(&ledger.descriptor.zone_id);
        let funding = seed_stake_resource_test_coin(
            &mut ledger,
            "candidate-resource-migration-funding-0001",
            sponsor_address.clone(),
            funded,
        );
        let mut policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        policy.maximum_total_stake_state_bytes = 1_000_000;
        policy.maximum_stake_state_bytes_per_block = 100_000;
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "candidate-migration-policy-proposal",
            policy,
            ledger.height + 1,
            ledger.height + 20,
        );
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "candidate-migration-policy-activation",
        );
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        let candidate = authority.candidates[0].clone();
        assert_eq!(candidate.owner, owner.address(&ledger.descriptor.zone_id));
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let mut request = MigrateConsensusCandidateResourceRequestV1 {
            request_id: "candidate-resource-migration-request-0001".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            validator_id: candidate.validator_id.clone(),
            owner: candidate.owner.clone(),
            public_key: candidate.public_key.clone(),
            key_era: candidate.key_era,
            registered_height: u64::try_from(candidate.registered_height).unwrap(),
            exit_height: candidate
                .exit_height
                .map(|height| u64::try_from(height).unwrap()),
            proof_of_possession: candidate.proof_of_possession.clone(),
            expected_candidate_commitment: candidate.resource_commitment_v1(),
            resource_envelope: crate::StakeStateResourceEnvelopeV1 {
                resource_policy_sequence: accounting.active_policy().sequence,
                resource_policy_commitment: accounting.active_policy_commitment().into(),
                sponsor: sponsor_address,
                funding_coin_id: funding.object_id,
                max_resource_fee: funded,
                max_state_bond: funded,
                lease_end_height: ledger.height + 500,
                resource_subject_hash: "00".repeat(32),
                authorization: signed_authorization(
                    &sponsor,
                    &ledger.descriptor.zone_id,
                    crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
                    "00".repeat(32),
                    9_800,
                ),
            },
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_ACTION_V1,
                "00".repeat(32),
                9_801,
            ),
        };
        resign_candidate_resource_migration(
            &ledger,
            &owner,
            &sponsor,
            &candidate,
            &mut request,
            9_800,
            9_801,
        );
        (ledger, validators, owner, sponsor, request)
    }

    fn resign_epoch_resource_derivation(
        ledger: &Ledger,
        payer: &crate::Identity,
        sponsor: &crate::Identity,
        epoch: &LedgerDerivedStakeEpochV1,
        request: &mut DeriveNextStakeEpochRequestV2,
        sponsor_nonce: u64,
        payer_nonce: u64,
    ) {
        request.resource_envelope.resource_subject_hash = "00".repeat(32);
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            "00".repeat(32),
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            payer,
            &ledger.descriptor.zone_id,
            DERIVE_NEXT_STAKE_EPOCH_ACTION_V2,
            "00".repeat(32),
            payer_nonce,
        );
        let wire = ConsensusCommand::DeriveNextStakeEpochV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap();
        let (next_horizons, next_horizon_history) = ledger
            .preview_stake_liability_horizon_update(epoch)
            .unwrap();
        let horizon_usage = stake_liability_horizon_usage_delta_v1(
            &ledger.stake_position_liability_horizons,
            &ledger.stake_position_liability_horizon_history,
            &next_horizons,
            &next_horizon_history,
        )
        .unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire.len().try_into().unwrap(),
            persistent_bytes: derive_next_stake_epoch_persistent_bytes_v2(
                request,
                epoch,
                horizon_usage,
            )
            .unwrap(),
            signature_checks: DERIVE_NEXT_STAKE_EPOCH_SIGNATURE_CHECKS_V2,
            state_reads: derive_next_stake_epoch_state_reads_v2(epoch, horizon_usage).unwrap(),
            state_writes: derive_next_stake_epoch_state_writes_v2(horizon_usage).unwrap(),
        };
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let admission = StakeStateResourceAdmissionRequestV1 {
            resource_key: format!("EPOCH/{}", epoch.descriptor.consensus_epoch),
            resource_kind: StakeStateResourceKindV1::Epoch,
            resource_owner: request.payer.clone(),
            outer_operation_hash: request.resource_operation_hash(),
            expected_parent_commitment: epoch.previous_record_hash.clone(),
            usage,
            envelope: request.resource_envelope.clone(),
        };
        let subject = stake_state_resource_subject_hash_v1(accounting.context(), &admission);
        request.resource_envelope.resource_subject_hash = subject.clone();
        request.resource_envelope.authorization = signed_authorization(
            sponsor,
            &ledger.descriptor.zone_id,
            crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
            subject,
            sponsor_nonce,
        );
        request.authorization = signed_authorization(
            payer,
            &ledger.descriptor.zone_id,
            DERIVE_NEXT_STAKE_EPOCH_ACTION_V2,
            request.payload_hash(),
            payer_nonce,
        );
        assert_eq!(
            ConsensusCommand::DeriveNextStakeEpochV2(Box::new(request.clone()))
                .wire_v1_command_bytes(&ledger.descriptor.network_domain)
                .unwrap()
                .len(),
            usize::try_from(usage.wire_bytes).unwrap()
        );
    }

    fn resource_bound_epoch_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        crate::Identity,
        DeriveNextStakeEpochRequestV2,
        LedgerDerivedStakeEpochV1,
    ) {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let owners = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let candidate_keys = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let sponsor = generate_identity();
        let payer = generate_identity();
        let mut ledger = Ledger::genesis_zone(
            "Resource-bound Epoch",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            true,
        )
        .unwrap();
        let source_root = ledger.state_root().unwrap();
        let context = ledger.stake_context_at(u128::from(ledger.height), source_root.clone());
        let candidates = candidate_keys
            .iter()
            .enumerate()
            .map(|(index, identity)| {
                let mut candidate = ValidatorCandidateRecord {
                    validator_id: format!("epoch-validator-{index:04}"),
                    owner: owners[index].address(&ledger.descriptor.zone_id),
                    public_key: identity.public_key.clone(),
                    key_era: ledger.descriptor.crypto_era,
                    registered_height: 0,
                    exit_height: None,
                    proof_of_possession: String::new(),
                };
                candidate.proof_of_possession = sign_bytes(
                    &identity.secret_key,
                    &crate::validator_candidate_pop_message_v1(&context, &candidate),
                )
                .unwrap();
                candidate
            })
            .collect::<Vec<_>>();
        let candidate_commands = candidates
            .iter()
            .map(|candidate| crate::StakeAuthorityCandidateCommandV1 {
                validator_id: candidate.validator_id.clone(),
                owner: candidate.owner.clone(),
                public_key: candidate.public_key.clone(),
                key_era: candidate.key_era,
                registered_height: u64::try_from(candidate.registered_height).unwrap(),
                exit_height: None,
                proof_of_possession: candidate.proof_of_possession.clone(),
            })
            .collect::<Vec<_>>();
        let ubo_validators = candidates
            .iter()
            .enumerate()
            .map(|(index, candidate)| crate::StakeUboControlEntryV1 {
                validator_id: candidate.validator_id.clone(),
                record: crate::StakeUboControlRecordCommandV1 {
                    control_group: format!("epoch-control-{index:04}"),
                    valid_from_height: 0,
                    challenge_ends_height: 0,
                    valid_through_height: 2_000,
                    evidence_hash: hash_parts(&[
                        b"RLD-TEST-EPOCH-UBO-EVIDENCE",
                        &(index as u64).to_be_bytes(),
                    ]),
                },
            })
            .collect::<Vec<_>>();
        let mut governance = StakeAuthorityGovernanceUpdateV1 {
            update_id: "resource-epoch-authority-1".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            authority_version: crate::STAKE_AUTHORITY_STATE_VERSION_V1,
            sequence: 1,
            expected_previous_commitment: ledger_stake_authority_genesis_anchor_v1(&context),
            policy: crate::StakeAuthorityPolicyCommandV1 {
                policy_version: crate::STAKE_EPOCH_DERIVATION_VERSION_V2,
                minimum_self_bond: Amount::from_runlai(10),
                minimum_delegation: Amount::from_runlai(1),
                candidate_maturity_blocks: 1,
                stake_maturity_blocks: 1,
                evidence_window_blocks: 2,
                activation_delay_blocks: 2,
                epoch_length_blocks: 10,
                maximum_validators: 4,
            },
            candidates: candidate_commands,
            positions: Vec::new(),
            ubo_map_version: 1,
            ubo_sequence: 1,
            ubo_predecessor_commitment: hash_parts(&[b"RLD-TEST-EPOCH-UBO-GENESIS"]),
            ubo_verifier_set_commitment: hash_parts(&[b"RLD-TEST-EPOCH-UBO-VERIFIERS"]),
            ubo_evidence_root: hash_parts(&[b"RLD-TEST-EPOCH-UBO-ROOT"]),
            ubo_validators,
            prospective_authority_commitment: "00".repeat(32),
            subject_hash: "00".repeat(32),
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        let prospective = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(ledger.height + 1),
            None,
            governance.to_ledger_update().unwrap(),
            &ledger.coins,
        )
        .unwrap();
        governance.prospective_authority_commitment = prospective.commitment;
        governance.subject_hash = governance.compute_subject_hash();
        governance.validator_qc = signed_qc(&governance.subject_hash, &validators, 3);
        governance.notary_qc = signed_qc(&governance.subject_hash, &notaries, 3);
        ledger.submit_stake_authority_update(governance).unwrap();

        let sponsor_address = sponsor.address(&ledger.descriptor.zone_id);
        let epoch_zone_id = ledger.descriptor.zone_id.clone();
        let resource_funding = (0..9)
            .map(|index| {
                seed_stake_resource_test_coin(
                    &mut ledger,
                    &format!("epoch-resource-funding-{index:04}"),
                    sponsor_address.clone(),
                    Amount(1_000_000),
                )
            })
            .collect::<Vec<_>>();
        let stake_sources = owners
            .iter()
            .enumerate()
            .map(|(index, owner)| {
                seed_stake_resource_test_coin(
                    &mut ledger,
                    &format!("epoch-stake-source-{index:04}"),
                    owner.address(&epoch_zone_id),
                    Amount::from_runlai(10),
                )
            })
            .collect::<Vec<_>>();
        ledger.assert_conservation().unwrap();

        let mut policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        policy.maximum_active_candidates = 8;
        policy.maximum_candidates_per_owner = 2;
        policy.maximum_active_positions = 8;
        policy.maximum_positions_per_owner = 2;
        policy.maximum_total_stake_state_bytes = 10_000_000;
        policy.maximum_stake_state_bytes_per_block = 1_000_000;
        policy.maximum_stake_signature_checks_per_block = 100;
        policy.maximum_stake_state_reads_per_block = 1_000;
        policy.maximum_stake_state_writes_per_block = 100;
        policy.maximum_lease_blocks = 5_000;
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "epoch-resource-policy-proposal",
            policy,
            ledger.height + 1,
            ledger.height + 100,
        );
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "epoch-resource-policy-activation",
        );
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();

        for index in 0..4 {
            let authority = ledger.consensus_stake_authority.as_ref().unwrap();
            let candidate = authority.candidates[index].clone();
            let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
            let mut request = MigrateConsensusCandidateResourceRequestV1 {
                request_id: format!("epoch-candidate-migration-{index:04}"),
                zone_id: ledger.descriptor.zone_id.clone(),
                currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
                protocol_era: ledger.descriptor.protocol_era,
                crypto_era: ledger.descriptor.crypto_era,
                proposed_height: ledger.height,
                expires_at_height: ledger.height + 100,
                expected_authority_sequence: authority.sequence,
                expected_authority_commitment: authority.commitment.clone(),
                validator_id: candidate.validator_id.clone(),
                owner: candidate.owner.clone(),
                public_key: candidate.public_key.clone(),
                key_era: candidate.key_era,
                registered_height: u64::try_from(candidate.registered_height).unwrap(),
                exit_height: None,
                proof_of_possession: candidate.proof_of_possession.clone(),
                expected_candidate_commitment: candidate.resource_commitment_v1(),
                resource_envelope: crate::StakeStateResourceEnvelopeV1 {
                    resource_policy_sequence: accounting.active_policy().sequence,
                    resource_policy_commitment: accounting.active_policy_commitment().into(),
                    sponsor: sponsor_address.clone(),
                    funding_coin_id: resource_funding[index].object_id.clone(),
                    max_resource_fee: Amount(1_000_000),
                    max_state_bond: Amount(1_000_000),
                    lease_end_height: 2_030,
                    resource_subject_hash: "00".repeat(32),
                    authorization: signed_authorization(
                        &sponsor,
                        &ledger.descriptor.zone_id,
                        crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
                        "00".repeat(32),
                        10_000 + index as u64 * 10,
                    ),
                },
                authorization: signed_authorization(
                    &owners[index],
                    &ledger.descriptor.zone_id,
                    MIGRATE_CONSENSUS_CANDIDATE_RESOURCE_ACTION_V1,
                    "00".repeat(32),
                    10_001 + index as u64 * 10,
                ),
            };
            resign_candidate_resource_migration(
                &ledger,
                &owners[index],
                &sponsor,
                &candidate,
                &mut request,
                10_000 + index as u64 * 10,
                10_001 + index as u64 * 10,
            );
            ledger
                .migrate_consensus_candidate_resource(request)
                .unwrap();
        }

        for index in 0..4 {
            let authority = ledger.consensus_stake_authority.as_ref().unwrap();
            let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
            let mut request = LockConsensusStakeRequestV3 {
                position_id: format!("epoch-position-{index:04}"),
                zone_id: ledger.descriptor.zone_id.clone(),
                currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
                protocol_era: ledger.descriptor.protocol_era,
                crypto_era: ledger.descriptor.crypto_era,
                proposed_height: ledger.height,
                expires_at_height: ledger.height + 100,
                expected_authority_sequence: authority.sequence,
                expected_authority_commitment: authority.commitment.clone(),
                position_type: StakePositionTypeV1::SelfBond,
                validator_id: candidates[index].validator_id.clone(),
                owner: candidates[index].owner.clone(),
                source_coin_id: stake_sources[index].object_id.clone(),
                amount: Amount::from_runlai(10),
                committed_through_height: 2_000,
                slash_terms_authorization: signed_authorization(
                    &owners[index],
                    &ledger.descriptor.zone_id,
                    ACCEPT_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
                    "00".repeat(32),
                    11_000 + index as u64 * 10,
                ),
                resource_envelope: crate::StakeStateResourceEnvelopeV1 {
                    resource_policy_sequence: accounting.active_policy().sequence,
                    resource_policy_commitment: accounting.active_policy_commitment().into(),
                    sponsor: sponsor_address.clone(),
                    funding_coin_id: resource_funding[4 + index].object_id.clone(),
                    max_resource_fee: Amount(1_000_000),
                    max_state_bond: Amount(1_000_000),
                    lease_end_height: 2_030,
                    resource_subject_hash: "00".repeat(32),
                    authorization: signed_authorization(
                        &sponsor,
                        &ledger.descriptor.zone_id,
                        crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
                        "00".repeat(32),
                        11_002 + index as u64 * 10,
                    ),
                },
                authorization: signed_authorization(
                    &owners[index],
                    &ledger.descriptor.zone_id,
                    LOCK_CONSENSUS_STAKE_ACTION_V3,
                    "00".repeat(32),
                    11_001 + index as u64 * 10,
                ),
            };
            request.slash_terms_authorization = signed_authorization(
                &owners[index],
                &ledger.descriptor.zone_id,
                ACCEPT_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
                request.slash_terms_payload_hash(),
                11_000 + index as u64 * 10,
            );
            resign_resource_bound_stake(
                &ledger,
                &owners[index],
                &sponsor,
                &mut request,
                11_002 + index as u64 * 10,
                11_001 + index as u64 * 10,
            );
            ledger.lock_consensus_stake_v3(request).unwrap();
        }
        // The final self-bond must cross the policy's one-block maturity
        // boundary before it can contribute to the deterministic snapshot.
        ledger.advance().unwrap();
        let mut preview_ledger = ledger.clone();
        let preview = preview_ledger.derive_and_store_next_stake_epoch().unwrap();
        assert_eq!(
            preview.derivation_version,
            crate::STAKE_EPOCH_DERIVATION_VERSION_V2
        );
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let mut request = DeriveNextStakeEpochRequestV2 {
            request_id: "resource-bound-epoch-request-1".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 100,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            expected_consensus_epoch: preview.descriptor.consensus_epoch,
            expected_snapshot_height: ledger.height,
            expected_snapshot_state_root: ledger.state_root().unwrap(),
            expected_derived_record_hash: preview.record_hash.clone(),
            payer: payer.address(&ledger.descriptor.zone_id),
            resource_envelope: crate::StakeStateResourceEnvelopeV1 {
                resource_policy_sequence: accounting.active_policy().sequence,
                resource_policy_commitment: accounting.active_policy_commitment().into(),
                sponsor: sponsor_address,
                funding_coin_id: resource_funding[8].object_id.clone(),
                max_resource_fee: Amount(1_000_000),
                max_state_bond: Amount(1_000_000),
                lease_end_height: 2_030,
                resource_subject_hash: "00".repeat(32),
                authorization: signed_authorization(
                    &sponsor,
                    &ledger.descriptor.zone_id,
                    crate::FUND_STAKE_STATE_RESOURCE_ACTION_V1,
                    "00".repeat(32),
                    12_000,
                ),
            },
            authorization: signed_authorization(
                &payer,
                &ledger.descriptor.zone_id,
                DERIVE_NEXT_STAKE_EPOCH_ACTION_V2,
                "00".repeat(32),
                12_001,
            ),
        };
        resign_epoch_resource_derivation(
            &ledger,
            &payer,
            &sponsor,
            &preview,
            &mut request,
            12_000,
            12_001,
        );
        (ledger, validators, payer, sponsor, request, preview)
    }

    fn slash_terms_migration_request(
        ledger: &Ledger,
        owner: &crate::Identity,
        position: &ConsensusStakePosition,
        nonce: u64,
    ) -> MigrateConsensusStakeSlashTermsV2 {
        let slash_terms_authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            ACCEPT_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
            position.slash_terms_payload_hash_v2(),
            nonce,
        );
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        let mut request = MigrateConsensusStakeSlashTermsV2 {
            request_id: format!("migrate-stake-slash-terms-{nonce}"),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            position_id: position.position_id.clone(),
            escrow_coin_id: position.escrow_coin_id.clone(),
            owner: position.owner.clone(),
            slash_terms_authorization,
            authorization: signed_authorization(
                owner,
                &ledger.descriptor.zone_id,
                MIGRATE_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
                String::new(),
                nonce + 1,
            ),
        };
        request.authorization = signed_authorization(
            owner,
            &ledger.descriptor.zone_id,
            MIGRATE_CONSENSUS_STAKE_SLASH_TERMS_ACTION_V2,
            request.payload_hash(position),
            nonce + 1,
        );
        request
    }

    fn consensus_stake_slash_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        Vec<crate::Identity>,
        Vec<crate::Identity>,
        LedgerDerivedStakeEpochV1,
    ) {
        consensus_stake_slash_fixture_with_shared_validator(false)
    }

    fn consensus_stake_slash_fixture_with_shared_validator(
        shared_validator_liabilities: bool,
    ) -> (
        Ledger,
        Vec<crate::Identity>,
        Vec<crate::Identity>,
        Vec<crate::Identity>,
        LedgerDerivedStakeEpochV1,
    ) {
        let (mut ledger, validators, notaries, candidate_identities, mut governance) =
            stake_authority_governance_fixture();
        if shared_validator_liabilities {
            let amount = Amount::from_runlai(1);
            ledger.reserve = ledger.reserve.checked_sub(amount).unwrap();
            ledger.reserve_pools.demand_matching = ledger
                .reserve_pools
                .demand_matching
                .checked_sub(amount)
                .unwrap();
            let source_coin_id = "stake-source-0004".to_string();
            let escrow_coin_id = "stake-escrow-0004".to_string();
            let owner = "stake-owner-0004".to_string();
            let lineage_root = "stake-lineage-0004".to_string();
            ledger.coins.insert(
                source_coin_id.clone(),
                CoinObject {
                    object_id: source_coin_id.clone(),
                    lineage_root: lineage_root.clone(),
                    parent_ids: Vec::new(),
                    owner: owner.clone(),
                    zone_id: ledger.descriptor.zone_id.clone(),
                    amount,
                    state: CoinState::Consumed,
                    version: 0,
                    created_height: 0,
                    transit_id: None,
                    imported_from: None,
                    origin_zone: ledger.descriptor.zone_id.clone(),
                    origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
                },
            );
            ledger.coins.insert(
                escrow_coin_id.clone(),
                CoinObject {
                    object_id: escrow_coin_id.clone(),
                    lineage_root,
                    parent_ids: vec![source_coin_id.clone()],
                    owner: owner.clone(),
                    zone_id: ledger.descriptor.zone_id.clone(),
                    amount,
                    state: CoinState::Reserved,
                    version: 1,
                    created_height: 0,
                    transit_id: None,
                    imported_from: None,
                    origin_zone: ledger.descriptor.zone_id.clone(),
                    origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
                },
            );
            let position = ConsensusStakePosition {
                position_id: "stake-position-0004".into(),
                kind: ConsensusStakePositionKind::Delegation {
                    validator_id: "stake-validator-0000".into(),
                },
                owner: owner.clone(),
                source_coin_id: source_coin_id.clone(),
                escrow_coin_id: escrow_coin_id.clone(),
                amount,
                locked_height: 0,
                committed_through_height: 100,
                slash_terms: None,
            };
            ledger
                .consensus_stake_escrows
                .insert(escrow_coin_id.clone(), position);
            governance
                .positions
                .push(crate::StakeAuthorityPositionCommandV1 {
                    position_id: "stake-position-0004".into(),
                    position_type: StakePositionTypeV1::Delegation,
                    validator_id: "stake-validator-0000".into(),
                    owner,
                    source_coin_id,
                    escrow_coin_id,
                    amount,
                    locked_height: 0,
                    committed_through_height: 100,
                });
        }
        ledger.assert_conservation().unwrap();

        let owners = (0..governance.positions.len())
            .map(|_| generate_identity())
            .collect::<Vec<_>>();
        for (candidate, owner) in governance.candidates.iter_mut().zip(owners.iter()) {
            candidate.owner = owner.address(&ledger.descriptor.zone_id);
        }
        for (index, position) in governance.positions.iter_mut().enumerate() {
            let owner = owners[index].address(&ledger.descriptor.zone_id);
            position.owner.clone_from(&owner);
            let source_id = position.source_coin_id.clone();
            let escrow_id = position.escrow_coin_id.clone();
            ledger
                .coins
                .get_mut(&source_id)
                .unwrap()
                .owner
                .clone_from(&owner);
            ledger
                .coins
                .get_mut(&escrow_id)
                .unwrap()
                .owner
                .clone_from(&owner);
            ledger
                .consensus_stake_escrows
                .get_mut(&escrow_id)
                .unwrap()
                .owner
                .clone_from(&owner);
        }
        governance.policy.policy_version = 2;
        let context =
            ledger.stake_context_at(u128::from(ledger.height), ledger.state_root().unwrap());
        for (candidate, identity) in governance
            .candidates
            .iter_mut()
            .zip(candidate_identities.iter())
        {
            let internal = ValidatorCandidateRecord {
                validator_id: candidate.validator_id.clone(),
                owner: candidate.owner.clone(),
                public_key: candidate.public_key.clone(),
                key_era: candidate.key_era,
                registered_height: u128::from(candidate.registered_height),
                exit_height: candidate.exit_height.map(u128::from),
                proof_of_possession: String::new(),
            };
            candidate.proof_of_possession = sign_bytes(
                &identity.secret_key,
                &crate::validator_candidate_pop_message_v1(&context, &internal),
            )
            .unwrap();
        }
        let prospective = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(ledger.height + 1),
            None,
            governance.to_ledger_update().unwrap(),
            &ledger.coins,
        )
        .unwrap();
        governance.prospective_authority_commitment = prospective.commitment;
        governance.subject_hash = governance.compute_subject_hash();
        governance.validator_qc = signed_qc(&governance.subject_hash, &validators, 3);
        governance.notary_qc = signed_qc(&governance.subject_hash, &notaries, 3);
        ledger.submit_stake_authority_update(governance).unwrap();

        for (index, owner) in owners.iter().enumerate() {
            let position = ledger
                .consensus_stake_escrows
                .values()
                .find(|position| position.position_id == format!("stake-position-{index:04}"))
                .cloned()
                .unwrap();
            let request = slash_terms_migration_request(
                &ledger,
                owner,
                &position,
                1_000 + (index as u64) * 2,
            );
            ledger.migrate_consensus_stake_slash_terms(request).unwrap();
        }
        let record = ledger.derive_and_store_next_stake_epoch().unwrap();
        while u128::from(ledger.height) < record.descriptor.activation_height {
            ledger.advance().unwrap();
        }
        (ledger, validators, owners, candidate_identities, record)
    }

    fn signed_stake_vote_statement(
        record: &LedgerDerivedStakeEpochV1,
        validator: &crate::Identity,
        proposal_id: &str,
        proposal_hash: String,
        expected_state_root: String,
    ) -> crate::SignedConsensusVoteStatementV1 {
        let mut statement = crate::SignedConsensusVoteStatementV1 {
            proposal_id: proposal_id.into(),
            proposal_hash,
            zone_id: record.descriptor.zone_id.clone(),
            currency_genesis_root: record.descriptor.currency_genesis_root.clone(),
            protocol_era: record.descriptor.protocol_era,
            crypto_era: record.descriptor.crypto_era,
            parent_height: u64::try_from(record.descriptor.activation_height - 1).unwrap(),
            parent_state_root: hash_parts(&[b"RLD-TEST-SLASH-PARENT"]),
            round: 0,
            expected_state_root,
            voter_public_key: validator.public_key.clone(),
            signature: String::new(),
        };
        statement.signature = sign_bytes(
            &validator.secret_key,
            &statement
                .signing_bytes(&record.descriptor.network_domain)
                .unwrap(),
        )
        .unwrap();
        statement
    }

    fn double_sign_evidence(
        record: &LedgerDerivedStakeEpochV1,
        validator: &crate::Identity,
    ) -> crate::ConsensusStakeSlashEvidenceV1 {
        let first = signed_stake_vote_statement(
            record,
            validator,
            "slash-proposal-a",
            hash_parts(&[b"RLD-TEST-SLASH-PROPOSAL-A"]),
            hash_parts(&[b"RLD-TEST-SLASH-ROOT-A"]),
        );
        let second = signed_stake_vote_statement(
            record,
            validator,
            "slash-proposal-b",
            hash_parts(&[b"RLD-TEST-SLASH-PROPOSAL-B"]),
            hash_parts(&[b"RLD-TEST-SLASH-ROOT-B"]),
        );
        let (first, second) = if first
            .signed_commitment(&record.descriptor.network_domain)
            .unwrap()
            < second
                .signed_commitment(&record.descriptor.network_domain)
                .unwrap()
        {
            (first, second)
        } else {
            (second, first)
        };
        crate::ConsensusStakeSlashEvidenceV1 {
            kind: crate::ConsensusStakeSlashEvidenceKindV1::DoubleSign,
            first_vote: Some(first),
            second_vote: Some(second),
            first_checkpoint: None,
            second_checkpoint: None,
            proposal: None,
            invalid_vote: None,
        }
    }

    fn consensus_stake_slash_request(
        ledger: &Ledger,
        record: &LedgerDerivedStakeEpochV1,
        position_index: usize,
        validator: &crate::Identity,
        expected_unbond_request_commitment: Option<String>,
    ) -> SlashConsensusStakeV1 {
        let liability = &record.stake_liabilities[position_index];
        let evidence = double_sign_evidence(record, validator);
        let evidence_hash = evidence
            .evidence_hash(&record.descriptor.network_domain)
            .unwrap();
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        SlashConsensusStakeV1 {
            slash_id: format!("consensus-stake-slash-{position_index}"),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            consensus_epoch: record.descriptor.consensus_epoch,
            derived_epoch_record_hash: record.record_hash.clone(),
            position_id: liability.position.position_id.clone(),
            escrow_coin_id: liability.position.escrow_coin_id.clone(),
            expected_position_amount: liability.position.amount,
            liability_commitment: liability.liability_commitment.clone(),
            expected_unbond_request_commitment,
            evidence_hash,
            evidence,
        }
    }

    fn consensus_stake_unbond_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        RequestConsensusStakeUnbondV1,
        ConsensusCommit,
    ) {
        let (mut ledger, validators, owner, lock_request) = consensus_stake_lock_fixture();
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::LockConsensusStake(Box::new(lock_request)),
        );
        let lock_commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };
        let ConsensusOutcome::ConsensusStake(position) =
            ledger.apply_consensus_commit(lock_commit.clone()).unwrap()
        else {
            panic!("stake lock fixture returned the wrong outcome");
        };
        let authority = ledger.consensus_stake_authority.clone().unwrap();
        let owner_address = owner.address(&ledger.descriptor.zone_id);
        let mut request = RequestConsensusStakeUnbondV1 {
            request_id: "stake-unbond-request-0000".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: 200,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment,
            position_id: position.position_id,
            escrow_coin_id: position.escrow_coin_id,
            owner: owner_address.clone(),
            beneficiary: owner_address,
            requested_withdraw_after_height: 100,
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
                String::new(),
                900,
            ),
        };
        request.authorization = signed_authorization(
            &owner,
            &ledger.descriptor.zone_id,
            REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
            request.payload_hash(),
            900,
        );
        (ledger, validators, owner, request, lock_commit)
    }

    fn consensus_validator_registration_fixture() -> (
        Ledger,
        Vec<crate::Identity>,
        crate::Identity,
        crate::Identity,
        RegisterConsensusValidatorRequestV1,
    ) {
        let (ledger, validators, _stake_owner, _stake_request) = consensus_stake_lock_fixture();
        let owner = generate_identity();
        let candidate_identity = generate_identity();
        let authority = ledger.consensus_stake_authority.clone().unwrap();
        let context =
            ledger.stake_context_at(u128::from(ledger.height), ledger.state_root().unwrap());
        let mut candidate = ValidatorCandidateRecord {
            validator_id: "stake-register-validator-0001".into(),
            owner: owner.address(&ledger.descriptor.zone_id),
            public_key: candidate_identity.public_key.clone(),
            key_era: ledger.descriptor.crypto_era,
            registered_height: u128::from(ledger.height + 1),
            exit_height: None,
            proof_of_possession: String::new(),
        };
        candidate.proof_of_possession = sign_bytes(
            &candidate_identity.secret_key,
            &crate::validator_candidate_pop_message_v1(&context, &candidate),
        )
        .unwrap();
        let mut request = RegisterConsensusValidatorRequestV1 {
            request_id: "stake-register-request-0001".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment,
            validator_id: candidate.validator_id,
            owner: candidate.owner,
            public_key: candidate.public_key,
            key_era: candidate.key_era,
            proof_of_possession: candidate.proof_of_possession,
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                REGISTER_CONSENSUS_VALIDATOR_ACTION_V1,
                String::new(),
                800,
            ),
        };
        request.authorization = signed_authorization(
            &owner,
            &ledger.descriptor.zone_id,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V1,
            request.payload_hash(),
            800,
        );
        (ledger, validators, owner, candidate_identity, request)
    }

    fn simulated_protocol_order_request(
        ledger: &Ledger,
        request_id: &str,
        reserve_pool: ProtocolReservePoolKind,
        role: ServiceRole,
        budget: Amount,
        description: &str,
        matched_service_receipt_id: Option<String>,
    ) -> ProtocolServiceOrderRequest {
        let mut request = ProtocolServiceOrderRequest {
            request_id: request_id.into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            reserve_pool,
            role,
            budget,
            description: description.into(),
            matched_service_receipt_id,
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            nonce: 1,
            subject_hash: String::new(),
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        let subject = request.compute_subject_hash();
        request.subject_hash.clone_from(&subject);
        request.validator_qc.subject_hash.clone_from(&subject);
        request.notary_qc.subject_hash = subject;
        request
    }

    fn discovery_advertisement(
        descriptor: ZoneDescriptor,
        sequence: u64,
        validators: Option<&[crate::Identity]>,
    ) -> ZoneAdvertisement {
        let mut advertisement = ZoneAdvertisement {
            descriptor,
            sequence,
            endpoints: vec!["http://127.0.0.1:7845".into()],
            neighboring_zone_ids: Vec::new(),
            transports: vec![TransportClass::SublightDtn],
            subject_hash: String::new(),
            validator_qc: simulated_qc(),
        };
        let subject = advertisement.compute_subject_hash();
        advertisement.subject_hash.clone_from(&subject);
        advertisement.validator_qc = validators
            .map(|members| signed_qc(&subject, members, required_quorum(members.len()).unwrap()))
            .unwrap_or_else(|| {
                let mut qc = simulated_qc();
                qc.subject_hash.clone_from(&subject);
                qc
            });
        advertisement
    }

    #[test]
    fn service_reward_and_local_payment_preserve_supply() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let pools_before = ledger.reserve_pools.clone();
        let zone = ledger.descriptor.zone_id.clone();
        let alice_address = alice.address(&zone);
        let reward = Amount::from_rld_whole(100).unwrap();
        let (coin, receipt) = ledger
            .bootstrap_service_reward(
                "alice-node".into(),
                alice_address,
                ServiceRole::Observer,
                "proof".into(),
                reward,
            )
            .unwrap();
        assert_eq!(
            ledger.reserve_pools.startup_services,
            pools_before.startup_services.checked_sub(reward).unwrap()
        );
        assert_eq!(
            ledger.reserve_pools.continuity_services,
            pools_before.continuity_services
        );
        assert_eq!(
            ledger.reserve_pools.demand_matching,
            pools_before.demand_matching
        );
        assert_eq!(
            ledger.service_orders[&receipt.order_id].status,
            ServiceStatus::Completed
        );
        assert_eq!(
            ledger.service_leases[&receipt.lease_id].accepted_quote,
            reward
        );
        let intent = signed_intent(
            &alice,
            &zone,
            &zone,
            &bob.address(&zone),
            &coin.object_id,
            Amount::from_rld_whole(7).unwrap(),
        );
        let mut underfunded = intent.clone();
        underfunded.max_fee = Amount::ZERO;
        underfunded.signature =
            sign_bytes(&alice.secret_key, &underfunded.signing_bytes()).unwrap();
        assert!(matches!(
            ledger.local_payment(underfunded),
            Err(LedgerError::Invalid(message)) if message.contains("max_fee")
        ));

        let record = ledger.local_payment(intent).unwrap();
        assert!(!record.charged_fee.is_zero());
        assert!(record.charged_fee <= Amount::from_runlai(LOCAL_PAYMENT_MAX_FEE_RUNLAI));
        assert_eq!(record.pricing_epoch, LOCAL_PAYMENT_PRICING_EPOCH);
        assert_eq!(record.output_coin_ids.len(), 2);
        assert_eq!(
            ledger.epoch_fee_pools[&LOCAL_PAYMENT_PRICING_EPOCH].collected,
            record.charged_fee
        );
        assert_eq!(
            ledger.balance(&bob.address(&zone)).unwrap(),
            Amount::from_rld_whole(7).unwrap()
        );
        assert_eq!(
            ledger.supply_buckets().unwrap().active_total().unwrap().0,
            TOTAL_SUPPLY_RUNLAI
        );
        assert_eq!(
            ledger.supply_buckets().unwrap().fee_pools,
            record.charged_fee
        );
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn payment_intent_rejects_foreign_network_era_and_price_contexts() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth-context", vec![], vec![], true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "context-node".into(),
                alice.address(&zone),
                ServiceRole::Observer,
                "context-proof".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &zone,
            &zone,
            &bob.address(&zone),
            &coin.object_id,
            Amount::from_rld_whole(1).unwrap(),
        );

        for (mut forged, expected) in [
            (
                {
                    let mut candidate = intent.clone();
                    candidate.currency_genesis_root = "foreign-currency-root".into();
                    candidate
                },
                "currency genesis root mismatch",
            ),
            (
                {
                    let mut candidate = intent.clone();
                    candidate.protocol_era += 1;
                    candidate
                },
                "protocol era mismatch",
            ),
            (
                {
                    let mut candidate = intent.clone();
                    candidate.crypto_era += 1;
                    candidate
                },
                "crypto era mismatch",
            ),
            (
                {
                    let mut candidate = intent.clone();
                    candidate.pricing_epoch += 1;
                    candidate
                },
                "pricing epoch mismatch",
            ),
        ] {
            forged.signature = sign_bytes(&alice.secret_key, &forged.signing_bytes()).unwrap();
            assert!(matches!(
                ledger.local_payment(forged),
                Err(LedgerError::Invalid(message)) if message == expected
            ));
        }

        assert_eq!(ledger.coins[&coin.object_id].state, CoinState::Spendable);
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn genesis_reserve_is_consensus_split_one_nine_ninety() {
        let ledger = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let one_percent = Amount::from_runlai(TOTAL_SUPPLY_RUNLAI / 100);
        assert_eq!(ledger.reserve_pools.startup_services, one_percent);
        assert_eq!(
            ledger.reserve_pools.continuity_services,
            Amount::from_runlai(one_percent.0 * 9)
        );
        assert_eq!(
            ledger.reserve_pools.demand_matching,
            Amount::from_runlai(one_percent.0 * 90)
        );
        assert_eq!(ledger.reserve_pools.total().unwrap(), ledger.reserve);

        let empty = Ledger::empty_zone("Mars", vec![], vec![], true).unwrap();
        assert_eq!(empty.reserve_pools, ProtocolReservePools::default());
        assert_eq!(empty.reserve_pools.total().unwrap(), empty.reserve);
    }

    #[test]
    fn height_overflow_rejects_transition_without_any_ledger_mutation() {
        let mut ledger = Ledger::genesis_zone("Height overflow", vec![], vec![], true).unwrap();
        ledger.height = u64::MAX;
        let before = serde_json::to_vec(&ledger).unwrap();
        let before_root = ledger.state_root().unwrap();

        let error = ledger
            .set_zone_trust_policy("zone-at-overflow".into(), ZoneTrustPolicy::Quarantined)
            .unwrap_err();

        assert!(matches!(
            error,
            LedgerError::Invalid(message) if message.contains("height counter overflow")
        ));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), before);
        assert_eq!(ledger.state_root().unwrap(), before_root);
    }

    #[test]
    fn sequence_overflow_rejects_new_object_without_any_ledger_mutation() {
        let mut ledger = Ledger::genesis_zone("Sequence overflow", vec![], vec![], true).unwrap();
        ledger.sequence = u64::MAX;
        let before = serde_json::to_vec(&ledger).unwrap();
        let before_root = ledger.state_root().unwrap();

        let error = ledger
            .bootstrap_service_reward(
                "sequence-overflow-node".into(),
                "rld:sequence-overflow-owner".into(),
                ServiceRole::Observer,
                "sequence-overflow-proof".into(),
                Amount::from_rld_whole(1).unwrap(),
            )
            .unwrap_err();

        assert!(matches!(
            error,
            LedgerError::Invalid(message) if message.contains("sequence counter overflow")
        ));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), before);
        assert_eq!(ledger.state_root().unwrap(), before_root);
    }

    #[test]
    fn reserve_pool_tampering_breaks_supply_conservation() {
        let mut ledger = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(Amount::from_runlai(1))
            .unwrap();
        assert!(matches!(
            ledger.assert_conservation(),
            Err(LedgerError::Supply(message))
                if message.contains("protocol reserve pools")
        ));
        assert!(!ledger.supply_certificate().unwrap().valid);
    }

    #[test]
    fn legacy_snapshot_migrates_reserve_pools_and_bootstrap_records() {
        let alice = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let (_, receipt) = ledger
            .bootstrap_service_reward(
                "alice-node".into(),
                alice.address(&zone),
                ServiceRole::Observer,
                "proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let old_height = ledger.height;
        let old_checkpoint_count = ledger.checkpoints.len();
        let mut snapshot = serde_json::to_value(&ledger).unwrap();
        let object = snapshot.as_object_mut().unwrap();
        object.remove("reserve_pools");
        object.insert("service_orders".into(), serde_json::json!({}));
        object.insert("service_leases".into(), serde_json::json!({}));

        let mut migrated: Ledger = serde_json::from_value(snapshot).unwrap();
        migrated.ensure_reserve_pools().unwrap();
        assert_eq!(migrated.reserve_pools.total().unwrap(), migrated.reserve);
        assert!(migrated.service_orders.contains_key(&receipt.order_id));
        assert!(migrated.service_leases.contains_key(&receipt.lease_id));
        assert_eq!(migrated.height, old_height + 1);
        assert_eq!(migrated.checkpoints.len(), old_checkpoint_count + 1);
        migrated.assert_conservation().unwrap();
    }

    #[test]
    fn signed_zone_discovery_rejects_stale_and_forged_advertisements() {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let source =
            Ledger::empty_zone("Discovery-source", validator_keys, Vec::new(), true).unwrap();
        let mut observer = Ledger::empty_zone("Discovery-observer", vec![], vec![], true).unwrap();
        let advertisement =
            discovery_advertisement(source.descriptor.clone(), 1, Some(&validators));
        let root_before_advertisement = observer.state_root().unwrap();
        observer
            .register_zone_advertisement(advertisement.clone())
            .unwrap();
        assert_ne!(observer.state_root().unwrap(), root_before_advertisement);
        let mut sequence_tamper = observer.clone();
        sequence_tamper.sequence += 1;
        assert_ne!(
            sequence_tamper.state_root().unwrap(),
            observer.state_root().unwrap()
        );
        assert!(matches!(
            observer.register_zone_advertisement(advertisement.clone()),
            Err(LedgerError::Duplicate(_))
        ));

        let mut forged = advertisement;
        forged.sequence = 2;
        forged.descriptor.validator_keys = vec![generate_identity().public_key];
        let subject = forged.compute_subject_hash();
        forged.subject_hash.clone_from(&subject);
        forged.validator_qc = QuorumCertificate {
            subject_hash: subject.clone(),
            threshold: 1,
            attestations: vec![crate::SignedAttestation {
                public_key: forged.descriptor.validator_keys[0].clone(),
                signature: String::new(),
            }],
            testnet_simulated: false,
        };
        assert!(observer.register_zone_advertisement(forged).is_err());
    }

    #[test]
    fn signed_payment_request_is_single_use_and_recipient_can_confirm() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth-request", vec![], vec![], true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "alice-request-node".into(),
                alice.address(&zone),
                ServiceRole::Observer,
                "request-flow".into(),
                Amount::from_rld_whole(20).unwrap(),
            )
            .unwrap();
        let mut request = PaymentRequest {
            request_id: "request-bob-coffee".into(),
            recipient: bob.address(&zone),
            recipient_public_key: bob.public_key.clone(),
            destination_zone: zone.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            amount: Amount::from_rld_whole(3).unwrap(),
            memo: "coffee".into(),
            expires_at_height: ledger.height + 100,
            nonce: 9,
            signature: String::new(),
        };
        request.signature = sign_bytes(&bob.secret_key, &request.signing_bytes()).unwrap();
        let mut foreign_request = request.clone();
        foreign_request.currency_genesis_root = "foreign-currency-root".into();
        foreign_request.signature =
            sign_bytes(&bob.secret_key, &foreign_request.signing_bytes()).unwrap();
        assert!(matches!(
            ledger.register_payment_request(foreign_request),
            Err(LedgerError::Invalid(message))
                if message.contains("network or era context mismatch")
        ));
        ledger.register_payment_request(request.clone()).unwrap();

        let mut intent = signed_intent(
            &alice,
            &zone,
            &zone,
            &bob.address(&zone),
            &coin.object_id,
            request.amount,
        );
        intent.payment_id = "payment-request-bob-coffee".into();
        intent.payment_request_id = Some(request.request_id.clone());
        intent.payment_request = Some(request.clone());
        intent.signature = sign_bytes(&alice.secret_key, &intent.signing_bytes()).unwrap();
        let payment = ledger.local_payment(intent).unwrap();

        let change_coin = ledger
            .coins_for_owner(&alice.address(&zone))
            .into_iter()
            .find(|candidate| candidate.state == CoinState::Spendable)
            .unwrap();
        let mut replay = signed_intent(
            &alice,
            &zone,
            &zone,
            &bob.address(&zone),
            &change_coin.object_id,
            request.amount,
        );
        replay.payment_request_id = Some(request.request_id.clone());
        replay.payment_request = Some(request);
        replay.signature = sign_bytes(&alice.secret_key, &replay.signing_bytes()).unwrap();
        assert!(matches!(
            ledger.local_payment(replay),
            Err(LedgerError::Duplicate(_))
        ));

        let mut receipt = RecipientReceipt {
            receipt_id: "recipient-receipt-coffee".into(),
            payment_id: payment.intent.payment_id.clone(),
            settlement_reference: payment.intent.payment_id.clone(),
            destination_zone: zone.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            recipient: bob.address(&zone),
            recipient_public_key: bob.public_key.clone(),
            amount: payment.intent.amount,
            observed_destination_height: ledger.height,
            nonce: 10,
            signature: String::new(),
        };
        receipt.signature = sign_bytes(&bob.secret_key, &receipt.signing_bytes()).unwrap();
        let mut stale_receipt = receipt.clone();
        stale_receipt.crypto_era += 1;
        stale_receipt.signature =
            sign_bytes(&bob.secret_key, &stale_receipt.signing_bytes()).unwrap();
        assert!(matches!(
            ledger.accept_recipient_receipt(stale_receipt),
            Err(LedgerError::Invalid(message))
                if message.contains("network or era context mismatch")
        ));
        ledger.accept_recipient_receipt(receipt).unwrap();
        assert!(ledger
            .recipient_receipts
            .contains_key("payment-request-bob-coffee"));
    }

    #[test]
    fn cross_zone_payment_request_is_qc_bound_and_destination_validated() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-request-cross", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars-request-cross", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "cross-request-node".into(),
                alice.address(&earth_id),
                ServiceRole::Relay,
                "cross-request-proof".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let mut request = PaymentRequest {
            request_id: "request-mars-cross".into(),
            recipient: bob.address(&mars_id),
            recipient_public_key: bob.public_key.clone(),
            destination_zone: mars_id.clone(),
            currency_genesis_root: mars.descriptor.currency_genesis_root.clone(),
            protocol_era: mars.descriptor.protocol_era,
            crypto_era: mars.descriptor.crypto_era + 1,
            amount: Amount::from_rld_whole(2).unwrap(),
            memo: "destination-era-check".into(),
            expires_at_height: mars.height + 100,
            nonce: 11,
            signature: String::new(),
        };
        request.signature = sign_bytes(&bob.secret_key, &request.signing_bytes()).unwrap();
        let mut intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            request.amount,
        );
        intent.payment_request_id = Some(request.request_id.clone());
        intent.payment_request = Some(request.clone());
        intent.signature = sign_bytes(&alice.secret_key, &intent.signing_bytes()).unwrap();

        let capsule = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        assert_eq!(capsule.payment_request.as_ref(), Some(&request));
        assert!(matches!(
            mars.import_capsule(capsule),
            Err(LedgerError::Invalid(message))
                if message.contains("network or era context mismatch")
        ));
        assert!(!mars.consumed_payment_requests.contains(&request.request_id));
        mars.assert_conservation().unwrap();
    }

    #[test]
    fn audit_bundle_carries_full_history_and_detects_tampering() {
        let alice = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth-audit", vec![], vec![], true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        ledger
            .bootstrap_service_reward(
                "archive-audit-node".into(),
                alice.address(&zone),
                ServiceRole::Archive,
                "restore-checkpoint".into(),
                Amount::from_rld_whole(5).unwrap(),
            )
            .unwrap();
        let bundle = ledger.audit_proof_bundle().unwrap();
        bundle.verify_structure().unwrap();
        assert!(!bundle.coin_history.is_empty());
        assert!(!bundle.service_receipts.is_empty());

        let mut tampered = bundle;
        tampered.coin_history[0].amount = Amount::from_rld_whole(6).unwrap();
        assert!(tampered.verify_structure().is_err());
    }

    #[test]
    fn cross_zone_import_is_exactly_once() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-node".into(),
                alice.address(&earth_id),
                ServiceRole::Relay,
                "proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(10).unwrap(),
        );
        let capsule = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        let receipt = mars.import_capsule(capsule.clone()).unwrap();
        assert!(matches!(
            mars.import_capsule(capsule),
            Err(LedgerError::TransitAlreadyImported)
        ));
        earth.finalize_export(&receipt).unwrap();
        earth.assert_conservation().unwrap();
        mars.assert_conservation().unwrap();
        let global_active = earth
            .supply_buckets()
            .unwrap()
            .active_total()
            .unwrap()
            .checked_add(mars.supply_buckets().unwrap().active_total().unwrap())
            .unwrap();
        assert_eq!(global_active, Amount::TOTAL_SUPPLY);
    }

    #[test]
    fn destination_recomputes_source_reserve_pool_conservation() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-pool-proof", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars-pool-proof", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "pool-proof-node".into(),
                alice.address(&earth_id),
                ServiceRole::Relay,
                "pool-proof-work".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(1).unwrap(),
        );
        let mut capsule = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        capsule.source_supply.reserve_pools.demand_matching = capsule
            .source_supply
            .reserve_pools
            .demand_matching
            .checked_add(Amount::from_runlai(1))
            .unwrap();
        capsule.operational_proof.supply_certificate_hash = hash_bytes(
            &serde_json::to_vec(&capsule.source_supply).expect("serializable supply certificate"),
        );
        let subject = capsule.subject_hash();
        capsule.validator_qc.subject_hash.clone_from(&subject);
        capsule.notary_qc.subject_hash = subject;
        assert!(matches!(
            mars.import_capsule(capsule),
            Err(LedgerError::InvalidOperationalProof(message))
                if message.contains("source supply certificate")
        ));
    }

    #[test]
    fn configured_zone_requires_real_dual_quorum() {
        let alice = generate_identity();
        let bob = generate_identity();
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let mut earth =
            Ledger::genesis_zone("Earth-real-qc", validator_keys, notary_keys, true).unwrap();
        let mut mars = Ledger::empty_zone("Mars-real-qc", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-validator-client".into(),
                alice.address(&earth_id),
                ServiceRole::Validator,
                "real-dual-qc-export".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(2).unwrap(),
        );
        let pending = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        assert!(matches!(
            mars.import_capsule(pending.clone()),
            Err(LedgerError::InvalidQuorum(_))
        ));
        let subject = pending.subject_hash();
        let insufficient = signed_qc(&subject, &validators, 2);
        assert!(matches!(
            earth.certify_transit(
                &pending.transit_id,
                insufficient,
                signed_qc(&subject, &notaries, 3)
            ),
            Err(LedgerError::InvalidQuorum(_))
        ));
        let certified = earth
            .certify_transit(
                &pending.transit_id,
                signed_qc(&subject, &validators, 3),
                signed_qc(&subject, &notaries, 3),
            )
            .unwrap();
        mars.import_capsule(certified).unwrap();
        assert_eq!(
            mars.balance(&bob.address(&mars_id)).unwrap(),
            Amount::from_rld_whole(2).unwrap()
        );
    }

    #[test]
    fn destination_rejection_is_the_only_path_to_return_an_open_transit() {
        let alice = generate_identity();
        let bob = generate_identity();
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let mut earth = Ledger::genesis_zone("Earth-return", vec![], vec![], true).unwrap();
        let mut mars =
            Ledger::empty_zone("Mars-return", validator_keys, notary_keys, true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let alice_address = alice.address(&earth_id);
        let (coin, _) = earth
            .bootstrap_service_reward(
                "return-test-node".into(),
                alice_address.clone(),
                ServiceRole::Observer,
                "return-test-work".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(2).unwrap(),
        );
        let capsule = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();

        assert!(earth.finalize_return(&capsule.transit_id).is_err());
        let pending = mars
            .create_destination_rejection(
                capsule.clone(),
                DestinationRejectionReason::RecipientDeclined,
            )
            .unwrap();
        assert!(!mars
            .rejected_transit_nullifiers
            .contains(&capsule.transit_id));
        assert!(matches!(
            earth.begin_return_from_rejection(pending.clone()),
            Err(LedgerError::InvalidQuorum(_))
        ));
        let subject = pending.subject_hash();
        let certified = mars
            .certify_destination_rejection(
                &pending.rejection_id,
                signed_qc(&subject, &validators, 3),
                signed_qc(&subject, &notaries, 3),
            )
            .unwrap();
        assert!(mars
            .rejected_transit_nullifiers
            .contains(&capsule.transit_id));
        assert!(mars.import_capsule(capsule.clone()).is_err());

        let mut version_overflow = earth.clone();
        let transit_coin_id = version_overflow.transit_coin_ids[&capsule.transit_id].clone();
        version_overflow
            .coins
            .get_mut(&transit_coin_id)
            .unwrap()
            .version = u64::MAX;
        let before = serde_json::to_vec(&version_overflow).unwrap();
        let before_height = version_overflow.height;
        let before_coin = version_overflow.coins[&transit_coin_id].clone();
        let before_payment = version_overflow.payments[&capsule.payment_id].clone();
        let before_proofs = version_overflow.rejection_proofs.clone();
        assert!(matches!(
            version_overflow.begin_return_from_rejection(certified.clone()),
            Err(LedgerError::Invalid(message)) if message.contains("coin version counter overflow")
        ));
        assert_eq!(serde_json::to_vec(&version_overflow).unwrap(), before);
        assert_eq!(version_overflow.height, before_height);
        assert_eq!(version_overflow.coins[&transit_coin_id], before_coin);
        assert_eq!(
            version_overflow.payments[&capsule.payment_id],
            before_payment
        );
        assert_eq!(version_overflow.rejection_proofs, before_proofs);

        let returning = earth.begin_return_from_rejection(certified).unwrap();
        assert_eq!(returning.status, PaymentStatus::Returning);
        assert!(earth.balance(&alice_address).unwrap() < Amount::from_rld_whole(10).unwrap());
        let returned = earth.finalize_return(&capsule.transit_id).unwrap();
        assert_eq!(returned.status, PaymentStatus::Returned);
        assert_eq!(
            earth.balance(&alice_address).unwrap(),
            Amount::from_rld_whole(10).unwrap()
        );
        assert!(matches!(
            earth.begin_return_from_rejection(pending),
            Err(LedgerError::Duplicate(_)) | Err(LedgerError::InvalidQuorum(_))
        ));
        earth.assert_conservation().unwrap();
        mars.assert_conservation().unwrap();
    }

    #[test]
    fn import_rejects_tampered_self_certifying_zone_descriptor() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-identity", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars-identity", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "identity-node".into(),
                alice.address(&earth_id),
                ServiceRole::Observer,
                "identity-proof".into(),
                Amount::from_rld_whole(2).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(1).unwrap(),
        );
        let mut capsule = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        capsule.source_descriptor.display_name = "Forged Earth".into();
        assert!(matches!(
            mars.import_capsule(capsule),
            Err(LedgerError::InvalidOperationalProof(_))
        ));
    }

    #[test]
    fn v2_zone_identity_binds_currency_network_and_hash_suite() {
        let testnet = Ledger::empty_zone("Identity-domain", vec![], vec![], true).unwrap();
        let mainnet = Ledger::empty_zone("Identity-domain", vec![], vec![], false).unwrap();

        assert_eq!(
            testnet.descriptor.identity_version,
            CURRENT_ZONE_IDENTITY_VERSION
        );
        assert_eq!(
            testnet.descriptor.identity_hash_suite,
            ZONE_IDENTITY_HASH_SUITE
        );
        assert_eq!(testnet.descriptor.network_domain, RLDCOIN_TESTNET_DOMAIN);
        assert_eq!(mainnet.descriptor.network_domain, RLDCOIN_MAINNET_DOMAIN);
        assert_ne!(testnet.descriptor.zone_id, mainnet.descriptor.zone_id);
        testnet.descriptor.validate_identity().unwrap();
        mainnet.descriptor.validate_identity().unwrap();

        let mut forged_currency = testnet.descriptor.clone();
        forged_currency.currency_genesis_root = "foreign-currency-root".into();
        assert!(forged_currency.validate_identity().is_err());

        let mut forged_domain = testnet.descriptor.clone();
        forged_domain.network_domain = RLDCOIN_MAINNET_DOMAIN.into();
        assert!(forged_domain.validate_identity().is_err());

        let mut forged_suite = testnet.descriptor.clone();
        forged_suite.identity_hash_suite = "UNSUPPORTED-HASH".into();
        assert!(forged_suite.validate_identity().is_err());

        let mut forged_network_kind = testnet.descriptor.clone();
        forged_network_kind.testnet = false;
        assert!(forged_network_kind.validate_identity().is_err());
    }

    #[test]
    fn configured_zone_requires_signed_era_transition() {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let mut ledger = Ledger::genesis_zone(
            "Earth-era-qc",
            validator_keys.clone(),
            notary_keys.clone(),
            true,
        )
        .unwrap();
        let suite = CryptoSuiteDescriptor {
            suite_id: "era-2-suite".into(),
            signature_algorithm: "ED25519".into(),
            hash_algorithm: "SHA-256".into(),
            encoding: "RLD-CANONICAL-V1".into(),
        };
        assert!(matches!(
            ledger.activate_testnet_era(suite.clone()),
            Err(LedgerError::EraTransition(_))
        ));

        let mut certificate = EraContinuityCertificate {
            zone_id: ledger.descriptor.zone_id.clone(),
            previous_protocol_era: 1,
            new_protocol_era: 2,
            previous_crypto_era: 1,
            new_crypto_era: 2,
            previous_certificate_hash: ledger.era_continuity_accumulator.clone(),
            activation_checkpoint: ledger.latest_checkpoint().unwrap().checkpoint_hash.clone(),
            irreversible_height: ledger.height + 1,
            new_suite: suite,
            previous_validator_keys: validator_keys.clone(),
            previous_notary_keys: notary_keys.clone(),
            new_validator_keys: validator_keys,
            new_notary_keys: notary_keys,
            old_crypto_qc: simulated_qc(),
            new_crypto_qc: simulated_qc(),
            notary_qc: simulated_qc(),
            certificate_hash: String::new(),
        };
        let subject = certificate.subject_hash();
        certificate.certificate_hash.clone_from(&subject);
        certificate.old_crypto_qc = signed_qc(&subject, &validators, 3);
        certificate.new_crypto_qc = signed_qc(&subject, &validators, 3);
        certificate.notary_qc = signed_qc(&subject, &notaries, 3);
        ledger.apply_era_transition(certificate).unwrap();
        assert_eq!(ledger.descriptor.protocol_era, 2);
        assert_eq!(ledger.descriptor.crypto_era, 2);
    }

    #[test]
    fn signed_route_quote_failover_stays_inside_the_preauthorized_budget() {
        let alice = generate_identity();
        let bob = generate_identity();
        let route_node = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-route", vec![], vec![], true).unwrap();
        let mars = Ledger::empty_zone("Mars-route", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-route-client".into(),
                alice.address(&earth_id),
                ServiceRole::Relay,
                "route-payment".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let provider = route_node.address(&earth_id);
        let failed_hop = "zone-failed-relay".to_owned();
        let route = vec![earth_id.clone(), failed_hop.clone(), mars_id.clone()];
        let route_path = route.join("|");
        let base_fee = Amount::from_rld_whole(2).unwrap();
        let reroute_budget = Amount::from_rld_whole(1).unwrap();
        let expiry = earth.height + 100;
        let payload = action_payload_hash(
            "CREATE_ROUTE_QUOTE",
            &[
                provider.as_bytes(),
                mars_id.as_bytes(),
                route_path.as_bytes(),
                b"SUBLIGHT_DTN",
                &base_fee.0.to_be_bytes(),
                &reroute_budget.0.to_be_bytes(),
                &expiry.to_be_bytes(),
            ],
        );
        let quote = earth
            .create_route_quote(CreateRouteQuoteRequest {
                provider: provider.clone(),
                destination_zone: mars_id.clone(),
                route,
                transport: TransportClass::SublightDtn,
                base_fee,
                authorized_reroute_budget: reroute_budget,
                expires_at_height: expiry,
                authorization: signed_authorization(
                    &route_node,
                    &earth_id,
                    "CREATE_ROUTE_QUOTE",
                    payload,
                    30,
                ),
            })
            .unwrap();

        let replacement_route = vec![
            earth_id.clone(),
            "zone-backup-relay".into(),
            mars_id.clone(),
        ];
        let incremental_fee = Amount::from_rld_whole(1).unwrap();
        let reroute_payload = action_payload_hash(
            "REROUTE_ROUTE_QUOTE",
            &[
                quote.quote_id.as_bytes(),
                failed_hop.as_bytes(),
                replacement_route.join("|").as_bytes(),
                &incremental_fee.0.to_be_bytes(),
            ],
        );
        let rerouted = earth
            .reroute_route_quote(
                &quote.quote_id,
                RerouteRouteQuoteRequest {
                    failed_hop,
                    replacement_route,
                    incremental_fee,
                    authorization: signed_authorization(
                        &route_node,
                        &earth_id,
                        "REROUTE_ROUTE_QUOTE",
                        reroute_payload,
                        31,
                    ),
                },
            )
            .unwrap();
        assert_eq!(rerouted.consumed_reroute_fee, reroute_budget);

        let mut intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(10).unwrap(),
        );
        intent.route_quote_id = Some(quote.quote_id.clone());
        intent.max_fee = base_fee;
        intent.signature = sign_bytes(&alice.secret_key, &intent.signing_bytes()).unwrap();
        assert!(matches!(
            earth.export_payment(intent.clone(), TransportClass::SublightDtn),
            Err(LedgerError::Invalid(_))
        ));
        assert_eq!(
            earth.route_quotes[&quote.quote_id].status,
            RouteQuoteStatus::Open
        );

        intent.max_fee = base_fee.checked_add(reroute_budget).unwrap();
        intent.signature = sign_bytes(&alice.secret_key, &intent.signing_bytes()).unwrap();
        earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        assert_eq!(
            earth.balance(&provider).unwrap(),
            Amount::from_rld_whole(3).unwrap()
        );
        assert_eq!(
            earth.route_quotes[&quote.quote_id].status,
            RouteQuoteStatus::Locked
        );
        assert_eq!(
            earth.balance(&alice.address(&earth_id)).unwrap(),
            Amount::from_rld_whole(87).unwrap()
        );
    }

    #[test]
    fn liquidity_offer_makes_recipient_final_and_routes_claim_to_provider() {
        let alice = generate_identity();
        let bob = generate_identity();
        let provider = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-liquidity", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars-liquidity", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (genesis_coin, _) = earth
            .bootstrap_service_reward(
                "liquidity-seed-node".into(),
                alice.address(&earth_id),
                ServiceRole::Liquidity,
                "seed-destination-liquidity".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();

        let seed_intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &provider.address(&mars_id),
            &genesis_coin.object_id,
            Amount::from_rld_whole(20).unwrap(),
        );
        let seed_capsule = earth
            .export_payment(seed_intent, TransportClass::SublightDtn)
            .unwrap();
        let seed_receipt = mars.import_capsule(seed_capsule).unwrap();
        earth.finalize_export(&seed_receipt).unwrap();

        let provider_coin = mars
            .coins_for_owner(&provider.address(&mars_id))
            .into_iter()
            .find(|coin| coin.state == CoinState::Spendable)
            .unwrap();
        let offer_amount = Amount::from_rld_whole(20).unwrap();
        let minimum = Amount::from_rld_whole(1).unwrap();
        let maximum = Amount::from_rld_whole(10).unwrap();
        let expiry = mars.height + 100;
        let offer_payload = action_payload_hash(
            "CREATE_LIQUIDITY_OFFER",
            &[
                provider.address(&mars_id).as_bytes(),
                provider_coin.object_id.as_bytes(),
                &offer_amount.0.to_be_bytes(),
                &minimum.0.to_be_bytes(),
                &maximum.0.to_be_bytes(),
                &expiry.to_be_bytes(),
            ],
        );
        let offer = mars
            .create_liquidity_offer(CreateLiquidityOfferRequest {
                provider: provider.address(&mars_id),
                coin_id: provider_coin.object_id,
                amount: offer_amount,
                minimum,
                maximum,
                expires_at_height: expiry,
                authorization: signed_authorization(
                    &provider,
                    &mars_id,
                    "CREATE_LIQUIDITY_OFFER",
                    offer_payload,
                    40,
                ),
            })
            .unwrap();

        let alice_change = earth
            .coins_for_owner(&alice.address(&earth_id))
            .into_iter()
            .find(|coin| coin.state == CoinState::Spendable)
            .unwrap();
        let payment_intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &alice_change.object_id,
            Amount::from_rld_whole(5).unwrap(),
        );
        let payment_capsule = earth
            .export_payment(payment_intent, TransportClass::SublightDtn)
            .unwrap();
        let certificate = mars
            .take_liquidity_offer(TakeLiquidityOfferRequest {
                offer_id: offer.offer_id,
                settlement_claim: payment_capsule.clone(),
            })
            .unwrap();
        assert_eq!(
            mars.balance(&bob.address(&mars_id)).unwrap(),
            Amount::from_rld_whole(5).unwrap()
        );
        assert_eq!(certificate.recipient, bob.address(&mars_id));

        let receipt = mars.import_capsule(payment_capsule).unwrap();
        assert_eq!(
            mars.coins[&receipt.destination_coin_id].owner,
            provider.address(&mars_id)
        );
        assert_eq!(
            mars.balance(&provider.address(&mars_id)).unwrap(),
            Amount::from_rld_whole(5).unwrap()
        );
        assert_eq!(
            mars.balance(&bob.address(&mars_id)).unwrap(),
            Amount::from_rld_whole(5).unwrap()
        );
        earth.finalize_export(&receipt).unwrap();
        earth.assert_conservation().unwrap();
        mars.assert_conservation().unwrap();
    }

    #[test]
    fn funded_service_lease_pays_the_node() {
        let buyer = generate_identity();
        let archive_node = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let buyer_address = buyer.address(&zone);
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "buyer-node".into(),
                buyer_address.clone(),
                ServiceRole::Observer,
                "proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let budget = Amount::from_rld_whole(12).unwrap();
        let description = "hold checkpoint".to_owned();
        let create_payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                buyer_address.as_bytes(),
                coin.object_id.as_bytes(),
                b"ARCHIVE",
                &budget.0.to_be_bytes(),
                description.as_bytes(),
            ],
        );
        let order = ledger
            .create_service_order(
                buyer_address,
                coin.object_id,
                ServiceRole::Archive,
                budget,
                description,
                signed_authorization(&buyer, &zone, "CREATE_SERVICE_ORDER", create_payload, 1),
            )
            .unwrap();
        let quote = Amount::from_rld_whole(10).unwrap();
        let lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                order.order_id.as_bytes(),
                archive_node.public_key.as_bytes(),
                &quote.0.to_be_bytes(),
            ],
        );
        let lease = ledger
            .lease_service(
                &order.order_id,
                archive_node.public_key.clone(),
                quote,
                signed_authorization(&archive_node, &zone, "LEASE_SERVICE", lease_payload, 2),
            )
            .unwrap();
        let proof_hash = "proof-of-storage".to_owned();
        let complete_payload = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                lease.lease_id.as_bytes(),
                archive_node.public_key.as_bytes(),
                proof_hash.as_bytes(),
            ],
        );
        ledger
            .complete_service(
                &lease.lease_id,
                proof_hash,
                signed_authorization(
                    &archive_node,
                    &zone,
                    "COMPLETE_SERVICE",
                    complete_payload,
                    3,
                ),
            )
            .unwrap();
        assert_eq!(
            ledger.node_earnings[&archive_node.public_key].total,
            Amount::from_rld_whole(10).unwrap()
        );
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn continuity_pool_requires_dual_qc_for_order_and_completion() {
        let buyer = generate_identity();
        let archive_node = generate_identity();
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let mut ledger =
            Ledger::genesis_zone("Earth-protocol-work", validator_keys, notary_keys, true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let buyer_address = buyer.address(&zone);
        let (buyer_coin, _) = ledger
            .bootstrap_service_reward(
                "continuity-demand-buyer".into(),
                buyer_address.clone(),
                ServiceRole::Observer,
                "continuity-demand-bootstrap".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let user_budget = Amount::from_rld_whole(50).unwrap();
        let user_description = "user requests checkpoint recovery".to_owned();
        let user_order_payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                buyer_address.as_bytes(),
                buyer_coin.object_id.as_bytes(),
                b"ARCHIVE",
                &user_budget.0.to_be_bytes(),
                user_description.as_bytes(),
            ],
        );
        let user_order = ledger
            .create_service_order(
                buyer_address,
                buyer_coin.object_id,
                ServiceRole::Archive,
                user_budget,
                user_description,
                signed_authorization(
                    &buyer,
                    &zone,
                    "CREATE_SERVICE_ORDER",
                    user_order_payload,
                    55,
                ),
            )
            .unwrap();
        let user_lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                user_order.order_id.as_bytes(),
                archive_node.public_key.as_bytes(),
                &user_budget.0.to_be_bytes(),
            ],
        );
        let user_lease = ledger
            .lease_service(
                &user_order.order_id,
                archive_node.public_key.clone(),
                user_budget,
                signed_authorization(
                    &archive_node,
                    &zone,
                    "LEASE_SERVICE",
                    user_lease_payload,
                    56,
                ),
            )
            .unwrap();
        let proof_hash = "archive-recovery-challenge-proof".to_owned();
        let user_complete_payload = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                user_lease.lease_id.as_bytes(),
                archive_node.public_key.as_bytes(),
                proof_hash.as_bytes(),
            ],
        );
        let user_receipt = ledger
            .complete_service(
                &user_lease.lease_id,
                proof_hash.clone(),
                signed_authorization(
                    &archive_node,
                    &zone,
                    "COMPLETE_SERVICE",
                    user_complete_payload,
                    57,
                ),
            )
            .unwrap();
        let initial_reserve = ledger.reserve;
        let initial_continuity = ledger.reserve_pools.continuity_services;
        let budget = Amount::from_rld_whole(50).unwrap();
        let mut request = simulated_protocol_order_request(
            &ledger,
            "protocol-continuity-order-1",
            ProtocolReservePoolKind::ContinuityServices,
            ServiceRole::Archive,
            budget,
            "restore a continuity checkpoint",
            Some(user_receipt.receipt_id),
        );
        assert!(matches!(
            ledger.create_protocol_service_order(request.clone()),
            Err(LedgerError::InvalidQuorum(_))
        ));
        let order_subject = request.subject_hash.clone();
        request.validator_qc = signed_qc(&order_subject, &validators, 3);
        request.notary_qc = signed_qc(&order_subject, &notaries, 3);
        let order = ledger.create_protocol_service_order(request).unwrap();
        assert_eq!(
            ledger
                .available_protocol_reserve(&ProtocolReservePoolKind::ContinuityServices)
                .unwrap(),
            initial_continuity.checked_sub(budget).unwrap()
        );

        let quote = Amount::from_rld_whole(40).unwrap();
        let lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                order.order_id.as_bytes(),
                archive_node.public_key.as_bytes(),
                &quote.0.to_be_bytes(),
            ],
        );
        let lease = ledger
            .lease_service(
                &order.order_id,
                archive_node.public_key.clone(),
                quote,
                signed_authorization(&archive_node, &zone, "LEASE_SERVICE", lease_payload, 60),
            )
            .unwrap();
        let complete_payload = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                lease.lease_id.as_bytes(),
                archive_node.public_key.as_bytes(),
                proof_hash.as_bytes(),
            ],
        );
        let node_authorization = signed_authorization(
            &archive_node,
            &zone,
            "COMPLETE_SERVICE",
            complete_payload,
            61,
        );
        assert!(matches!(
            ledger.complete_service(
                &lease.lease_id,
                proof_hash.clone(),
                node_authorization.clone()
            ),
            Err(LedgerError::Invalid(_))
        ));
        let claim = ProtocolServiceCompletionClaim {
            zone_id: zone,
            order_id: order.order_id.clone(),
            lease_id: lease.lease_id.clone(),
            node_id: archive_node.public_key.clone(),
            role: ServiceRole::Archive,
            amount: quote,
            proof_hash: proof_hash.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
        };
        let completion_subject = claim.subject_hash();
        let receipt = ledger
            .complete_protocol_service(
                &lease.lease_id,
                proof_hash,
                node_authorization,
                signed_qc(&completion_subject, &validators, 3),
                signed_qc(&completion_subject, &notaries, 3),
            )
            .unwrap();
        assert_eq!(
            receipt.protocol_reserve_pool,
            Some(ProtocolReservePoolKind::ContinuityServices)
        );
        assert_eq!(
            ledger.reserve_pools.continuity_services,
            initial_continuity.checked_sub(quote).unwrap()
        );
        assert_eq!(ledger.reserve, initial_reserve.checked_sub(quote).unwrap());
        assert_eq!(
            ledger.balance(&archive_node.public_key).unwrap(),
            user_budget.checked_add(quote).unwrap()
        );
        assert_eq!(
            ledger.protocol_reserve_commitments[&order.order_id].settled_amount,
            Some(quote)
        );
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn demand_pool_matches_real_user_fees_once_and_pays_the_same_node() {
        let buyer = generate_identity();
        let storage_node = generate_identity();
        let impostor = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth-demand-match", vec![], vec![], true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let buyer_address = buyer.address(&zone);
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "buyer-bootstrap-node".into(),
                buyer_address.clone(),
                ServiceRole::Observer,
                "buyer-bootstrap-proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let user_budget = Amount::from_rld_whole(10).unwrap();
        let description = "store live user data".to_owned();
        let create_payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                buyer_address.as_bytes(),
                coin.object_id.as_bytes(),
                b"STORAGE",
                &user_budget.0.to_be_bytes(),
                description.as_bytes(),
            ],
        );
        let user_order = ledger
            .create_service_order(
                buyer_address,
                coin.object_id,
                ServiceRole::Storage,
                user_budget,
                description,
                signed_authorization(&buyer, &zone, "CREATE_SERVICE_ORDER", create_payload, 70),
            )
            .unwrap();
        let user_lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                user_order.order_id.as_bytes(),
                storage_node.public_key.as_bytes(),
                &user_budget.0.to_be_bytes(),
            ],
        );
        let user_lease = ledger
            .lease_service(
                &user_order.order_id,
                storage_node.public_key.clone(),
                user_budget,
                signed_authorization(
                    &storage_node,
                    &zone,
                    "LEASE_SERVICE",
                    user_lease_payload,
                    71,
                ),
            )
            .unwrap();
        let proof_hash = "random-data-holding-challenge".to_owned();
        let user_complete_payload = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                user_lease.lease_id.as_bytes(),
                storage_node.public_key.as_bytes(),
                proof_hash.as_bytes(),
            ],
        );
        let user_receipt = ledger
            .complete_service(
                &user_lease.lease_id,
                proof_hash.clone(),
                signed_authorization(
                    &storage_node,
                    &zone,
                    "COMPLETE_SERVICE",
                    user_complete_payload,
                    72,
                ),
            )
            .unwrap();

        let match_amount = Amount::from_rld_whole(5).unwrap();
        let request = simulated_protocol_order_request(
            &ledger,
            "protocol-demand-order-1",
            ProtocolReservePoolKind::DemandMatching,
            ServiceRole::Storage,
            match_amount,
            "match verified user storage demand",
            Some(user_receipt.receipt_id.clone()),
        );
        let match_order = ledger.create_protocol_service_order(request).unwrap();
        let duplicate = simulated_protocol_order_request(
            &ledger,
            "protocol-demand-order-2",
            ProtocolReservePoolKind::DemandMatching,
            ServiceRole::Storage,
            match_amount,
            "attempt duplicate demand match",
            Some(user_receipt.receipt_id.clone()),
        );
        assert!(matches!(
            ledger.create_protocol_service_order(duplicate),
            Err(LedgerError::Duplicate(_))
        ));

        let impostor_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                match_order.order_id.as_bytes(),
                impostor.public_key.as_bytes(),
                &match_amount.0.to_be_bytes(),
            ],
        );
        assert!(ledger
            .lease_service(
                &match_order.order_id,
                impostor.public_key.clone(),
                match_amount,
                signed_authorization(&impostor, &zone, "LEASE_SERVICE", impostor_payload, 73,),
            )
            .is_err());
        let match_lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                match_order.order_id.as_bytes(),
                storage_node.public_key.as_bytes(),
                &match_amount.0.to_be_bytes(),
            ],
        );
        let match_lease = ledger
            .lease_service(
                &match_order.order_id,
                storage_node.public_key.clone(),
                match_amount,
                signed_authorization(
                    &storage_node,
                    &zone,
                    "LEASE_SERVICE",
                    match_lease_payload,
                    74,
                ),
            )
            .unwrap();
        let match_complete_payload = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                match_lease.lease_id.as_bytes(),
                storage_node.public_key.as_bytes(),
                proof_hash.as_bytes(),
            ],
        );
        let claim = ProtocolServiceCompletionClaim {
            zone_id: zone.clone(),
            order_id: match_order.order_id,
            lease_id: match_lease.lease_id.clone(),
            node_id: storage_node.public_key.clone(),
            role: ServiceRole::Storage,
            amount: match_amount,
            proof_hash: proof_hash.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
        };
        let completion_subject = claim.subject_hash();
        let mut validator_qc = simulated_qc();
        validator_qc.subject_hash.clone_from(&completion_subject);
        let mut notary_qc = simulated_qc();
        notary_qc.subject_hash = completion_subject;
        let demand_before = ledger.reserve_pools.demand_matching;
        let receipt = ledger
            .complete_protocol_service(
                &match_lease.lease_id,
                proof_hash,
                signed_authorization(
                    &storage_node,
                    &zone,
                    "COMPLETE_SERVICE",
                    match_complete_payload,
                    75,
                ),
                validator_qc,
                notary_qc,
            )
            .unwrap();
        assert_eq!(
            receipt.protocol_reserve_pool,
            Some(ProtocolReservePoolKind::DemandMatching)
        );
        assert_eq!(
            ledger.reserve_pools.demand_matching,
            demand_before.checked_sub(match_amount).unwrap()
        );
        assert_eq!(
            ledger.node_earnings[&storage_node.public_key].total,
            user_budget.checked_add(match_amount).unwrap()
        );
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn signed_action_authorization_prevents_asset_theft() {
        let owner = generate_identity();
        let attacker = generate_identity();
        let mut ledger = Ledger::genesis_zone("Earth-auth", vec![], vec![], true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let owner_address = owner.address(&zone);
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "owner-node".into(),
                owner_address.clone(),
                ServiceRole::Observer,
                "owner-work".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let budget = Amount::from_rld_whole(2).unwrap();
        let description = "attempted theft".to_owned();
        let payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                owner_address.as_bytes(),
                coin.object_id.as_bytes(),
                b"ARCHIVE",
                &budget.0.to_be_bytes(),
                description.as_bytes(),
            ],
        );
        let mut wrong_context =
            signed_authorization(&owner, &zone, "CREATE_SERVICE_ORDER", payload.clone(), 19);
        wrong_context.crypto_era += 1;
        wrong_context.signature =
            sign_bytes(&owner.secret_key, &wrong_context.signing_bytes()).unwrap();
        let wrong_context_result = ledger.create_service_order(
            owner_address.clone(),
            coin.object_id.clone(),
            ServiceRole::Archive,
            budget,
            description.clone(),
            wrong_context,
        );
        assert!(matches!(
            wrong_context_result,
            Err(LedgerError::InvalidSignature(message))
                if message.contains("scope mismatch")
        ));
        let result = ledger.create_service_order(
            owner_address,
            coin.object_id.clone(),
            ServiceRole::Archive,
            budget,
            description,
            signed_authorization(&attacker, &zone, "CREATE_SERVICE_ORDER", payload, 20),
        );
        assert!(matches!(result, Err(LedgerError::OwnerMismatch)));
        assert_eq!(ledger.coins[&coin.object_id].state, CoinState::Spendable);
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn bounded_proof_survives_ten_thousand_era_migrations() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-era", vec![], vec![], true).unwrap();
        for index in 0..10_000 {
            earth
                .activate_testnet_era(CryptoSuiteDescriptor {
                    suite_id: format!("test-suite-{index}"),
                    signature_algorithm: "ED25519-TEST".into(),
                    hash_algorithm: "SHA-256-TEST".into(),
                    encoding: "RLD-CANONICAL-V1".into(),
                })
                .unwrap();
        }
        let earth_id = earth.descriptor.zone_id.clone();
        let mars = Ledger::empty_zone("Mars-era", vec![], vec![], true).unwrap();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "era-custodian".into(),
                alice.address(&earth_id),
                ServiceRole::ContinuityCustodian,
                "ten-thousand-era-migrations".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(1).unwrap(),
        );
        let mut intent = intent;
        intent.protocol_era = earth.descriptor.protocol_era;
        intent.crypto_era = earth.descriptor.crypto_era;
        intent.signature = sign_bytes(&alice.secret_key, &intent.signing_bytes()).unwrap();
        let capsule = earth
            .export_payment(intent, TransportClass::CausalFtl)
            .unwrap();
        assert_eq!(earth.descriptor.protocol_era, 10_001);
        assert!(
            capsule.operational_proof.encoded_len().unwrap() <= crate::MAX_OPERATIONAL_PROOF_BYTES
        );
        capsule.operational_proof.validate_bounds().unwrap();
    }

    #[test]
    fn conflicting_source_object_quarantines_its_zone() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-conflict", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars-conflict", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-conflict-node".into(),
                alice.address(&earth_id),
                ServiceRole::Notary,
                "source-proof".into(),
                Amount::from_rld_whole(20).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(5).unwrap(),
        );
        let capsule = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        let mut conflict = capsule.clone();
        conflict.transit_id = "malicious-alternate-transit".into();
        conflict.source_object.transit_id = Some(conflict.transit_id.clone());
        conflict.operational_proof.object_hash = hash_bytes(
            &serde_json::to_vec(&conflict.source_object).expect("source object must encode"),
        );
        conflict.operational_proof.transit_nullifier_commitment = hash_parts(&[
            b"RLD-TRANSIT-NULLIFIER-V1",
            conflict.source_zone.as_bytes(),
            conflict.transit_id.as_bytes(),
        ]);
        let subject = conflict.subject_hash();
        conflict.validator_qc.subject_hash.clone_from(&subject);
        conflict.notary_qc.subject_hash = subject;

        mars.import_capsule(capsule).unwrap();
        assert!(matches!(
            mars.import_capsule(conflict),
            Err(LedgerError::SourceZoneQuarantined(_))
        ));
        assert!(mars.quarantined_zones.contains(&earth_id));
    }

    #[test]
    fn traveler_capsule_and_voyage_escrow_pay_real_relay_work() {
        let alice = generate_identity();
        let bob = generate_identity();
        let relay_alpha = generate_identity();
        let relay_beta = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth-voyage", vec![], vec![], true).unwrap();
        let mut starship = Ledger::empty_zone("Starship-CVZ", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let ship_id = starship.descriptor.zone_id.clone();
        let alice_address = alice.address(&earth_id);
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-voyage-node".into(),
                alice_address.clone(),
                ServiceRole::Relay,
                "departure-service".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let traveler = earth
            .create_traveler_capsule(
                signed_intent(
                    &alice,
                    &earth_id,
                    &ship_id,
                    &bob.address(&ship_id),
                    &coin.object_id,
                    Amount::from_rld_whole(25).unwrap(),
                ),
                TransportClass::CausalWormhole,
            )
            .unwrap();
        let transit_id = traveler.transit.transit_id.clone();
        let budget_coin = earth
            .coins_for_owner(&alice_address)
            .into_iter()
            .find(|candidate| candidate.state == CoinState::Spendable)
            .unwrap();
        let voyage_budget = Amount::from_rld_whole(10).unwrap();
        let max_reward = Amount::from_rld_whole(3).unwrap();
        let open_payload = action_payload_hash(
            "OPEN_VOYAGE_ESCROW",
            &[
                alice_address.as_bytes(),
                budget_coin.object_id.as_bytes(),
                transit_id.as_bytes(),
                &voyage_budget.0.to_be_bytes(),
                &max_reward.0.to_be_bytes(),
            ],
        );
        let voyage = earth
            .open_voyage_escrow(
                alice_address,
                budget_coin.object_id,
                transit_id,
                voyage_budget,
                max_reward,
                signed_authorization(&alice, &earth_id, "OPEN_VOYAGE_ESCROW", open_payload, 10),
            )
            .unwrap();
        let alpha_amount = Amount::from_rld_whole(2).unwrap();
        let alpha_proof = "downstream-receipt-alpha".to_owned();
        let alpha_payload = action_payload_hash(
            "SETTLE_VOYAGE_HOP",
            &[
                voyage.voyage_id.as_bytes(),
                relay_alpha.public_key.as_bytes(),
                &alpha_amount.0.to_be_bytes(),
                alpha_proof.as_bytes(),
            ],
        );
        earth
            .settle_voyage_hop(
                &voyage.voyage_id,
                relay_alpha.public_key.clone(),
                alpha_amount,
                alpha_proof,
                signed_authorization(
                    &relay_alpha,
                    &earth_id,
                    "SETTLE_VOYAGE_HOP",
                    alpha_payload,
                    11,
                ),
            )
            .unwrap();
        let beta_amount = Amount::from_rld_whole(3).unwrap();
        let beta_proof = "downstream-receipt-beta".to_owned();
        let beta_payload = action_payload_hash(
            "SETTLE_VOYAGE_HOP",
            &[
                voyage.voyage_id.as_bytes(),
                relay_beta.public_key.as_bytes(),
                &beta_amount.0.to_be_bytes(),
                beta_proof.as_bytes(),
            ],
        );
        earth
            .settle_voyage_hop(
                &voyage.voyage_id,
                relay_beta.public_key.clone(),
                beta_amount,
                beta_proof,
                signed_authorization(
                    &relay_beta,
                    &earth_id,
                    "SETTLE_VOYAGE_HOP",
                    beta_payload,
                    12,
                ),
            )
            .unwrap();
        assert_eq!(
            earth.node_earnings[&relay_alpha.public_key].total,
            Amount::from_rld_whole(2).unwrap()
        );
        assert_eq!(
            earth.node_earnings[&relay_beta.public_key].total,
            Amount::from_rld_whole(3).unwrap()
        );
        let serialized = serde_json::to_vec(&traveler).unwrap();
        let starship_snapshot = serde_json::to_vec(&starship).unwrap();
        let checkpoint_before = starship
            .latest_checkpoint()
            .unwrap()
            .checkpoint_hash
            .clone();
        let simulated_elapsed_years = 1_000_000u64;
        assert_eq!(simulated_elapsed_years, 1_000_000);
        let after_deep_time: TravelerCarryCapsule = serde_json::from_slice(&serialized).unwrap();
        starship = serde_json::from_slice(&starship_snapshot).unwrap();
        assert_eq!(
            starship.latest_checkpoint().unwrap().checkpoint_hash,
            checkpoint_before
        );
        let receipt = starship.import_traveler_capsule(after_deep_time).unwrap();
        assert_eq!(receipt.amount, Amount::from_rld_whole(25).unwrap());
        earth.finalize_export(&receipt).unwrap();
        earth.assert_conservation().unwrap();
        starship.assert_conservation().unwrap();
        starship.audit_proof_bundle().unwrap();
    }

    #[test]
    fn amount_constant_is_exact() {
        assert_eq!(Amount::TOTAL_SUPPLY.0, TOTAL_SUPPLY_RUNLAI);
        assert_eq!(TOTAL_SUPPLY_RUNLAI, 10u128.pow(35));
        assert_eq!(crate::RUNLAI_PER_RLD, 10u128.pow(24));
    }

    #[test]
    fn persisted_schema_change_creates_one_new_audit_checkpoint() {
        let mut ledger = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let original_height = ledger.height;
        ledger
            .zone_trust_policies
            .insert("legacy-source".into(), ZoneTrustPolicy::ObserveOnly);
        assert!(ledger.ensure_current_checkpoint().unwrap());
        assert_eq!(ledger.height, original_height + 1);
        assert_eq!(
            ledger.latest_checkpoint().unwrap().state_root,
            ledger.state_root().unwrap()
        );
        assert!(!ledger.ensure_current_checkpoint().unwrap());
    }

    #[test]
    fn four_validator_commit_requires_three_votes_and_replicates_payment() {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|validator| validator.public_key.clone())
            .collect::<Vec<_>>();
        let alice = generate_identity();
        let bob = generate_identity();
        let mut ledger =
            Ledger::genesis_zone("Earth-4V", validator_keys, Vec::new(), true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "alice-observer".into(),
                alice.address(&zone),
                ServiceRole::Observer,
                "four-validator-bootstrap-proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &zone,
            &zone,
            &bob.address(&zone),
            &coin.object_id,
            Amount::from_rld_whole(25).unwrap(),
        );
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(&ledger, leader, ConsensusCommand::LocalPayment(intent));
        let mut foreign_context = proposal.clone();
        foreign_context.currency_genesis_root = "foreign-currency-root".into();
        foreign_context.signature =
            sign_bytes(&leader.secret_key, &foreign_context.signing_bytes()).unwrap();
        assert!(matches!(
            ledger.validate_consensus_proposal(&foreign_context),
            Err(LedgerError::InvalidQuorum(message))
                if message.contains("not authorized")
        ));
        let state_root_before_vote = ledger.state_root().unwrap();
        ledger.lock_consensus_vote(&proposal).unwrap();
        assert_eq!(ledger.state_root().unwrap(), state_root_before_vote);

        let insufficient = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..2]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };
        assert!(ledger.apply_consensus_commit(insufficient).is_err());

        let commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };
        let outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::LocalPayment(record) = &outcome else {
            panic!("local payment proposal returned the wrong consensus outcome");
        };
        assert_eq!(record.status, PaymentStatus::UniversallySettled);
        assert_eq!(
            ledger.balance(&bob.address(&zone)).unwrap(),
            Amount::from_rld_whole(25).unwrap()
        );
        assert!(ledger.consensus_commits.contains_key(&commit.commit_hash()));
        assert_eq!(
            ledger.apply_consensus_commit(commit).unwrap(),
            outcome,
            "commit replay must be idempotent"
        );
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn external_consensus_execution_capability_preserves_unrooted_metadata() {
        let validator = generate_identity();
        let validators = vec![validator];
        let mut prestate = Ledger::genesis_zone(
            "external-consensus-metadata",
            vec![validators[0].public_key.clone()],
            Vec::new(),
            true,
        )
        .unwrap();
        prestate.create_checkpoint().unwrap();
        let command = ConsensusCommand::NetworkHeartbeat(NetworkHeartbeatV1 {
            heartbeat_id: "external-consensus-metadata-heartbeat".into(),
            zone_id: prestate.descriptor.zone_id.clone(),
            currency_genesis_root: prestate.descriptor.currency_genesis_root.clone(),
            protocol_era: prestate.descriptor.protocol_era,
            crypto_era: prestate.descriptor.crypto_era,
            parent_height: prestate.height,
            note_hash: hash_bytes(b"external consensus metadata capability"),
        });
        let commit = certified_command(&prestate, &validators, command);
        prestate.lock_consensus_vote(&commit.proposal).unwrap();

        let mut canonical = prestate.clone();
        canonical.apply_consensus_commit(commit.clone()).unwrap();

        let authenticated = prestate
            .authenticate_consensus_commit_for_external_execution(&commit)
            .unwrap();
        let mut externally_executed = prestate.clone();
        externally_executed
            .execute_consensus_command(commit.proposal.command.clone())
            .unwrap();
        externally_executed
            .finalize_externally_executed_consensus_commit(authenticated)
            .unwrap();
        assert_eq!(
            serde_json::to_vec(&externally_executed).unwrap(),
            serde_json::to_vec(&canonical).unwrap()
        );

        let authenticated = prestate
            .authenticate_consensus_commit_for_external_execution(&commit)
            .unwrap();
        let mut tampered = prestate;
        tampered
            .execute_consensus_command(commit.proposal.command.clone())
            .unwrap();
        tampered.checkpoints.clear();
        let tampered_before = serde_json::to_vec(&tampered).unwrap();
        assert!(matches!(
            tampered.finalize_externally_executed_consensus_commit(authenticated),
            Err(LedgerError::InvalidQuorum(message))
                if message.contains("protected unrooted Ledger bookkeeping")
        ));
        assert_eq!(serde_json::to_vec(&tampered).unwrap(), tampered_before);
    }

    #[test]
    fn stake_authority_commands_are_dual_authorized_rooted_replayable_and_runtime_disabled() {
        let (mut ledger, validators, _notaries, _candidate_identities, request) =
            stake_authority_governance_fixture();
        let runtime_keys = ledger.descriptor.validator_keys.clone();

        let mut bad_subject = request.clone();
        bad_subject.subject_hash = hash_parts(&[b"RLD-BAD-STAKE-AUTHORITY-SUBJECT"]);
        let baseline = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.execute_consensus_command(ConsensusCommand::SubmitStakeAuthorityUpdate(
                Box::new(bad_subject)
            )),
            Err(LedgerError::Invalid(message)) if message.contains("subject commitment")
        ));
        assert_eq!(ledger.state_root().unwrap(), baseline);

        let mut overlapping = ledger.clone();
        overlapping.descriptor.notary_keys = overlapping.descriptor.validator_keys.clone();
        let overlap_root = overlapping.state_root().unwrap();
        assert!(matches!(
            overlapping.execute_consensus_command(
                ConsensusCommand::SubmitStakeAuthorityUpdate(Box::new(request.clone()))
            ),
            Err(LedgerError::InvalidQuorum(message)) if message.contains("overlap")
        ));
        assert_eq!(overlapping.state_root().unwrap(), overlap_root);

        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::SubmitStakeAuthorityUpdate(Box::new(request)),
        );
        let commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };

        let mut mismatched = ledger.clone();
        let mut wrong_proposal = proposal.clone();
        wrong_proposal.expected_state_root = hash_parts(&[b"RLD-WRONG-CERTIFIED-POST-ROOT"]);
        wrong_proposal.signature =
            sign_bytes(&leader.secret_key, &wrong_proposal.signing_bytes()).unwrap();
        let wrong_commit = ConsensusCommit {
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&wrong_proposal, validator))
                .collect(),
            proposal: wrong_proposal,
        };
        let mismatch_root = mismatched.state_root().unwrap();
        assert!(mismatched.apply_consensus_commit(wrong_commit).is_err());
        assert_eq!(mismatched.state_root().unwrap(), mismatch_root);

        let authority_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::StakeAuthority(authority) = &authority_outcome else {
            panic!("stake authority command returned the wrong outcome");
        };
        assert_eq!(authority.status, StakeAuthorityStateStatus::StagedOnly);
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);
        assert_eq!(ledger.consensus_stake_authority.as_ref(), Some(authority));

        let replay_root = ledger.state_root().unwrap();
        assert_eq!(
            ledger.apply_consensus_commit(commit.clone()).unwrap(),
            authority_outcome
        );
        assert_eq!(ledger.state_root().unwrap(), replay_root);

        let authority = ledger.consensus_stake_authority.clone().unwrap();
        let derive_request = DeriveNextStakeEpochRequestV1 {
            request_id: "derive-stake-epoch-1".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 10,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment,
            expected_consensus_epoch: 1,
            expected_snapshot_height: ledger.height,
            expected_snapshot_state_root: ledger.state_root().unwrap(),
        };
        let leader = consensus_leader(&ledger, &validators);
        let derive_proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::DeriveNextStakeEpoch(Box::new(derive_request)),
        );
        let derive_commit = ConsensusCommit {
            proposal: derive_proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&derive_proposal, validator))
                .collect(),
        };
        let derived_outcome = ledger
            .apply_consensus_commit(derive_commit.clone())
            .unwrap();
        let ConsensusOutcome::DerivedStakeEpoch(record) = &derived_outcome else {
            panic!("stake Epoch command returned the wrong outcome");
        };
        assert_eq!(record.status, crate::StakeEpochRecordStatus::DerivedOnly);
        assert_eq!(record.descriptor.consensus_epoch, 1);
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);

        let final_root = ledger.state_root().unwrap();
        assert_eq!(
            ledger.apply_consensus_commit(commit).unwrap(),
            authority_outcome,
            "an older authority commit must replay its exact historical result"
        );
        assert_eq!(
            ledger.apply_consensus_commit(derive_commit).unwrap(),
            derived_outcome
        );
        assert_eq!(ledger.state_root().unwrap(), final_root);
    }

    #[test]
    fn owner_and_candidate_key_authorize_registration_and_one_way_exit() {
        let (mut ledger, validators, owner, candidate_identity, request) =
            consensus_validator_registration_fixture();
        let runtime_keys = ledger.descriptor.validator_keys.clone();
        let prior_authority = ledger.consensus_stake_authority.clone().unwrap();
        let registration_authorization = request.authorization.authorization_id.clone();
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::RegisterConsensusValidator(Box::new(request.clone())),
        );
        let commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };
        let registration_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::StakeCandidate(registered) = &registration_outcome else {
            panic!("validator registration returned the wrong outcome");
        };
        assert_eq!(registered.validator_id, request.validator_id);
        assert_eq!(
            registered.registered_height,
            u128::from(proposal.expected_height)
        );
        assert_eq!(registered.exit_height, None);
        assert!(ledger
            .authorization_nullifiers
            .contains(&registration_authorization));
        let registered_authority = ledger.consensus_stake_authority.clone().unwrap();
        assert_eq!(registered_authority.sequence, prior_authority.sequence + 1);
        assert!(registered_authority.candidates.contains(registered));
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);

        let context =
            ledger.stake_context_at(u128::from(ledger.height), ledger.state_root().unwrap());
        let mut exited = registered.clone();
        exited.exit_height = Some(100);
        exited.proof_of_possession = sign_bytes(
            &candidate_identity.secret_key,
            &crate::validator_candidate_pop_message_v1(&context, &exited),
        )
        .unwrap();
        let authority = ledger.consensus_stake_authority.clone().unwrap();
        let mut exit_request = ExitConsensusValidatorRequestV1 {
            request_id: "stake-exit-request-0001".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment,
            validator_id: exited.validator_id.clone(),
            owner: exited.owner.clone(),
            public_key: exited.public_key.clone(),
            key_era: exited.key_era,
            registered_height: u64::try_from(exited.registered_height).unwrap(),
            exit_height: u64::try_from(exited.exit_height.unwrap()).unwrap(),
            proof_of_possession: exited.proof_of_possession.clone(),
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                EXIT_CONSENSUS_VALIDATOR_ACTION_V1,
                String::new(),
                801,
            ),
        };
        exit_request.authorization = signed_authorization(
            &owner,
            &ledger.descriptor.zone_id,
            EXIT_CONSENSUS_VALIDATOR_ACTION_V1,
            exit_request.payload_hash(),
            801,
        );
        let exit_authorization = exit_request.authorization.authorization_id.clone();
        let leader = consensus_leader(&ledger, &validators);
        let exit_proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::ExitConsensusValidator(Box::new(exit_request.clone())),
        );
        let exit_commit = ConsensusCommit {
            proposal: exit_proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&exit_proposal, validator))
                .collect(),
        };
        let exit_outcome = ledger.apply_consensus_commit(exit_commit.clone()).unwrap();
        assert_eq!(
            exit_outcome,
            ConsensusOutcome::StakeCandidate(exited.clone())
        );
        assert!(ledger
            .authorization_nullifiers
            .contains(&exit_authorization));
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);
        assert!(ledger
            .consensus_stake_authority
            .as_ref()
            .unwrap()
            .candidates
            .contains(&exited));
        ledger.assert_conservation().unwrap();

        let replay_root = ledger.state_root().unwrap();
        assert_eq!(
            ledger.apply_consensus_commit(commit).unwrap(),
            registration_outcome
        );
        assert_eq!(
            ledger.apply_consensus_commit(exit_commit).unwrap(),
            exit_outcome
        );
        assert_eq!(ledger.state_root().unwrap(), replay_root);
    }

    #[test]
    fn candidate_forgery_and_broad_lifecycle_rewrite_fail_atomically() {
        let (mut forged_ledger, _validators, _owner, _candidate_identity, mut forged) =
            consensus_validator_registration_fixture();
        let forged_root = forged_ledger.state_root().unwrap();
        let forged_authorization = forged.authorization.authorization_id.clone();
        forged.proof_of_possession = "00".repeat(64);
        assert!(matches!(
            forged_ledger.register_consensus_validator(forged),
            Err(LedgerError::InvalidSignature(_))
        ));
        assert_eq!(forged_ledger.state_root().unwrap(), forged_root);
        assert!(!forged_ledger
            .authorization_nullifiers
            .contains(&forged_authorization));

        let (mut bad_pop_ledger, _validators, bad_pop_owner, _candidate_identity, mut bad_pop) =
            consensus_validator_registration_fixture();
        bad_pop.proof_of_possession = "00".repeat(64);
        bad_pop.authorization = signed_authorization(
            &bad_pop_owner,
            &bad_pop_ledger.descriptor.zone_id,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V1,
            bad_pop.payload_hash(),
            802,
        );
        let bad_pop_authorization = bad_pop.authorization.authorization_id.clone();
        let bad_pop_root = bad_pop_ledger.state_root().unwrap();
        assert!(bad_pop_ledger
            .register_consensus_validator(bad_pop)
            .is_err());
        assert_eq!(bad_pop_ledger.state_root().unwrap(), bad_pop_root);
        assert!(!bad_pop_ledger
            .authorization_nullifiers
            .contains(&bad_pop_authorization));

        let (mut broad, validators, notaries, _candidate_identities, mut update) =
            stake_authority_governance_fixture();
        broad.submit_stake_authority_update(update.clone()).unwrap();
        let authority = broad.consensus_stake_authority.clone().unwrap();
        let bootstrap_view = update.clone();
        let extra = generate_identity();
        update.update_id = "stake-authority-broad-candidate-rewrite".into();
        update.proposed_height = broad.height;
        update.expires_at_height = broad.height + 10;
        update.sequence = authority.sequence + 1;
        update.expected_previous_commitment = authority.commitment;
        update.ubo_sequence = authority.ubo_control.sequence + 1;
        update.ubo_predecessor_commitment =
            ubo_control_commitment_v1(&authority.ubo_control).unwrap();
        update
            .candidates
            .push(crate::StakeAuthorityCandidateCommandV1 {
                validator_id: "zz-broad-injected-validator".into(),
                owner: "zz-broad-injected-owner".into(),
                public_key: extra.public_key,
                key_era: broad.descriptor.crypto_era,
                registered_height: broad.height,
                exit_height: None,
                proof_of_possession: "11".repeat(64),
            });
        update.prospective_authority_commitment = "00".repeat(32);
        update.subject_hash = update.compute_subject_hash();
        update.validator_qc = signed_qc(&update.subject_hash, &validators, 3);
        update.notary_qc = signed_qc(&update.subject_hash, &notaries, 3);
        let broad_root = broad.state_root().unwrap();
        assert!(matches!(
            broad.submit_stake_authority_update(update),
            Err(LedgerError::Invalid(message))
                if message.contains("bootstrap-only")
        ));
        assert_eq!(broad.state_root().unwrap(), broad_root);

        for (name, mut forbidden) in [
            ("policy", {
                let mut request = bootstrap_view.clone();
                request.policy.activation_delay_blocks += 1;
                request
            }),
            ("positions", {
                let mut request = bootstrap_view.clone();
                request.positions.pop();
                request
            }),
            ("ubo", {
                let mut request = bootstrap_view.clone();
                request.ubo_evidence_root = "77".repeat(32);
                request
            }),
        ] {
            forbidden.update_id = format!("forbidden-broad-{name}");
            forbidden.proposed_height = broad.height;
            forbidden.expires_at_height = broad.height + 10;
            let root = broad.state_root().unwrap();
            assert!(matches!(
                broad.submit_stake_authority_update(forbidden),
                Err(LedgerError::Invalid(message)) if message.contains("bootstrap-only")
            ));
            assert_eq!(broad.state_root().unwrap(), root);
        }
    }

    #[test]
    fn owner_authorized_consensus_stake_lock_is_atomic_supply_preserving_and_replayable() {
        let (mut ledger, validators, _owner, request) = consensus_stake_lock_fixture();
        let source_root = ledger.state_root().unwrap();
        let source_supply = ledger.supply_certificate().unwrap().conservation_position;
        let runtime_keys = ledger.descriptor.validator_keys.clone();
        let prior_authority = ledger.consensus_stake_authority.clone().unwrap();
        let authorization_id = request.authorization.authorization_id.clone();
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::LockConsensusStake(Box::new(request.clone())),
        );
        let commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };

        let outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::ConsensusStake(position) = &outcome else {
            panic!("stake lock command returned the wrong outcome");
        };
        assert_eq!(position.position_id, request.position_id);
        assert_eq!(position.source_coin_id, request.source_coin_id);
        assert_eq!(position.amount, request.amount);
        assert_eq!(
            ledger.coins[&position.source_coin_id].state,
            CoinState::Consumed
        );
        assert_eq!(
            ledger.coins[&position.escrow_coin_id].state,
            CoinState::Reserved
        );
        assert_eq!(
            ledger.consensus_stake_escrows.get(&position.escrow_coin_id),
            Some(position)
        );
        assert_eq!(
            ledger.balance(&request.owner).unwrap(),
            Amount::from_runlai(40)
        );
        let authority = ledger.consensus_stake_authority.clone().unwrap();
        assert_eq!(authority.sequence, prior_authority.sequence + 1);
        assert_eq!(authority.previous_commitment, prior_authority.commitment);
        assert_eq!(authority.source_state_root, source_root);
        assert_eq!(authority.positions, vec![position.clone()]);
        assert_eq!(
            authority.ubo_control.sequence,
            prior_authority.ubo_control.sequence + 1
        );
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);
        assert!(ledger.authorization_nullifiers.contains(&authorization_id));
        let mut attempted_spend = ledger.clone();
        let attempted_spend_root = attempted_spend.state_root().unwrap();
        assert!(matches!(
            attempted_spend.consume_coin(&position.escrow_coin_id),
            Err(LedgerError::CoinNotSpendable)
        ));
        assert_eq!(attempted_spend.state_root().unwrap(), attempted_spend_root);
        assert_eq!(
            ledger.supply_certificate().unwrap().conservation_position,
            source_supply
        );
        ledger.assert_conservation().unwrap();

        let replay_root = ledger.state_root().unwrap();
        assert_eq!(ledger.apply_consensus_commit(commit).unwrap(), outcome);
        assert_eq!(ledger.state_root().unwrap(), replay_root);
        let audit = ledger.audit_proof_bundle().unwrap();
        assert_eq!(audit.consensus_stake_escrows, vec![position.clone()]);
        assert_eq!(audit.consensus_stake_authority, Some(authority.clone()));
    }

    #[test]
    fn v2_stake_lock_requires_independent_owner_signed_slash_terms_and_replays_exactly() {
        let (mut ledger, validators, owner, legacy_request) = consensus_stake_lock_fixture();
        let request = v2_lock_request_from_v1(&ledger, &owner, legacy_request, 710);
        let slash_authorization_id = request.slash_terms_authorization.authorization_id.clone();
        let mutation_authorization_id = request.authorization.authorization_id.clone();
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::LockConsensusStakeV2(Box::new(request.clone())),
        );
        let commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };

        let outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::ConsensusStake(position) = &outcome else {
            panic!("v2 stake lock returned the wrong outcome");
        };
        let terms = position.slash_terms.as_ref().unwrap();
        assert_eq!(
            terms.slash_policy,
            ConsensusStakeSlashPolicyV2::protocol_v2()
        );
        assert_eq!(terms.owner_authorization, request.slash_terms_authorization);
        assert!(ledger
            .authorization_nullifiers
            .contains(&slash_authorization_id));
        assert!(ledger
            .authorization_nullifiers
            .contains(&mutation_authorization_id));
        assert_eq!(
            ledger.consensus_stake_authority.as_ref().unwrap().positions,
            vec![position.clone()]
        );
        ledger.assert_conservation().unwrap();
        let replay_root = ledger.state_root().unwrap();
        assert_eq!(ledger.apply_consensus_commit(commit).unwrap(), outcome);
        assert_eq!(ledger.state_root().unwrap(), replay_root);

        let (mut forged, _validators, owner, legacy_request) = consensus_stake_lock_fixture();
        let mut forged_request = v2_lock_request_from_v1(&forged, &owner, legacy_request, 720);
        forged_request.slash_terms_authorization.payload_hash = "99".repeat(32);
        forged_request.authorization = signed_authorization(
            &owner,
            &forged.descriptor.zone_id,
            LOCK_CONSENSUS_STAKE_ACTION_V2,
            forged_request.payload_hash(),
            721,
        );
        let forged_slash_id = forged_request
            .slash_terms_authorization
            .authorization_id
            .clone();
        let forged_mutation_id = forged_request.authorization.authorization_id.clone();
        let forged_root = forged.state_root().unwrap();
        assert!(matches!(
            forged.lock_consensus_stake_v2(forged_request),
            Err(LedgerError::InvalidSignature(_))
        ));
        assert_eq!(forged.state_root().unwrap(), forged_root);
        assert!(!forged.authorization_nullifiers.contains(&forged_slash_id));
        assert!(!forged
            .authorization_nullifiers
            .contains(&forged_mutation_id));

        let (mut policy_v2, _validators, owner, mut legacy_request) =
            consensus_stake_lock_fixture();
        let mut authority = policy_v2.consensus_stake_authority.clone().unwrap();
        authority.policy.policy_version = 2;
        authority.commitment =
            crate::ledger_stake_authority_state_commitment_v1(&authority).unwrap();
        legacy_request.expected_authority_commitment = authority.commitment.clone();
        policy_v2.consensus_stake_authority = Some(authority);
        legacy_request.authorization = signed_authorization(
            &owner,
            &policy_v2.descriptor.zone_id,
            LOCK_CONSENSUS_STAKE_ACTION_V1,
            legacy_request.payload_hash(),
            730,
        );
        let legacy_root = policy_v2.state_root().unwrap();
        assert!(matches!(
            policy_v2.lock_consensus_stake(legacy_request),
            Err(LedgerError::Invalid(message)) if message.contains("unslashable")
        ));
        assert_eq!(policy_v2.state_root().unwrap(), legacy_root);
    }

    #[test]
    fn legacy_stake_migration_adds_exact_terms_without_moving_coin_and_replays() {
        let (mut ledger, validators, owner, lock_request) = consensus_stake_lock_fixture();
        let position = ledger.lock_consensus_stake(lock_request).unwrap();
        let source_coin = ledger.coins[&position.source_coin_id].clone();
        let escrow_coin = ledger.coins[&position.escrow_coin_id].clone();
        let supply = ledger.supply_certificate().unwrap().conservation_position;
        let prior_authority = ledger.consensus_stake_authority.clone().unwrap();
        let request = slash_terms_migration_request(&ledger, &owner, &position, 740);

        let mut substituted = request.clone();
        substituted.escrow_coin_id = "substituted-escrow".into();
        let substitution_root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.migrate_consensus_stake_slash_terms(substituted),
            Err(LedgerError::Invalid(_))
        ));
        assert_eq!(ledger.state_root().unwrap(), substitution_root);

        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::MigrateConsensusStakeSlashTerms(Box::new(request.clone())),
        );
        let commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };
        let outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::ConsensusStake(migrated) = &outcome else {
            panic!("stake slash-terms migration returned the wrong outcome");
        };
        assert_eq!(migrated.position_id, position.position_id);
        assert_eq!(migrated.source_coin_id, position.source_coin_id);
        assert_eq!(migrated.escrow_coin_id, position.escrow_coin_id);
        assert_eq!(migrated.amount, position.amount);
        assert_eq!(ledger.coins[&migrated.source_coin_id], source_coin);
        assert_eq!(ledger.coins[&migrated.escrow_coin_id], escrow_coin);
        assert_eq!(
            migrated.slash_terms.as_ref().unwrap().owner_authorization,
            request.slash_terms_authorization
        );
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        assert_eq!(authority.sequence, prior_authority.sequence + 1);
        assert_eq!(
            authority.ubo_control.sequence,
            prior_authority.ubo_control.sequence + 1
        );
        assert_eq!(
            ledger.supply_certificate().unwrap().conservation_position,
            supply
        );
        ledger.assert_conservation().unwrap();
        let replay_root = ledger.state_root().unwrap();
        assert_eq!(ledger.apply_consensus_commit(commit).unwrap(), outcome);
        assert_eq!(ledger.state_root().unwrap(), replay_root);

        let (mut duplicate_auth, _validators, owner, lock_request) = consensus_stake_lock_fixture();
        let position = duplicate_auth.lock_consensus_stake(lock_request).unwrap();
        let mut duplicate_request =
            slash_terms_migration_request(&duplicate_auth, &owner, &position, 750);
        duplicate_request.authorization = duplicate_request.slash_terms_authorization.clone();
        let duplicate_root = duplicate_auth.state_root().unwrap();
        assert!(matches!(
            duplicate_auth.migrate_consensus_stake_slash_terms(duplicate_request),
            Err(LedgerError::Duplicate(_))
        ));
        assert_eq!(duplicate_auth.state_root().unwrap(), duplicate_root);
    }

    #[test]
    fn objective_double_sign_slash_is_exact_supply_preserving_and_replay_safe() {
        let (mut ledger, validators, _owners, candidate_identities, epoch) =
            consensus_stake_slash_fixture();
        let position = epoch.stake_liabilities[0].position.clone();
        let source_escrow = ledger.coins[&position.escrow_coin_id].clone();
        let prior_authority = ledger.consensus_stake_authority.clone().unwrap();
        let supply = ledger.supply_certificate().unwrap().conservation_position;
        let request =
            consensus_stake_slash_request(&ledger, &epoch, 0, &candidate_identities[0], None);
        let evidence_hash = request.evidence_hash.clone();
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::SlashConsensusStake(Box::new(request)),
        );
        let commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };

        let outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::ConsensusStakeSlash(record) = &outcome else {
            panic!("stake slash returned the wrong outcome");
        };
        assert_eq!(record.position, position);
        assert_eq!(record.source_escrow_coin_id, source_escrow.object_id);
        assert_eq!(record.slash_bps, 10_000);
        assert_eq!(record.slashed_amount, position.amount);
        assert_eq!(record.evidence_hash, evidence_hash);
        assert_eq!(record.record_hash, record.compute_record_hash());
        let evidence_nullifier =
            consensus_stake_slash_nullifier_v1(&record.evidence_hash, &record.liability_commitment);
        assert!(ledger
            .consensus_stake_evidence_nullifiers
            .contains(&evidence_nullifier));
        assert!(!ledger
            .consensus_stake_escrows
            .contains_key(&position.escrow_coin_id));
        assert_eq!(
            ledger.coins[&position.escrow_coin_id].state,
            CoinState::Consumed
        );
        let safety_coin = &ledger.coins[&record.safety_pool_coin_id];
        assert_eq!(safety_coin.owner, CONSENSUS_SLASH_SAFETY_POOL_V2);
        assert_eq!(safety_coin.state, CoinState::Reserved);
        assert_eq!(safety_coin.amount, position.amount);
        assert_eq!(
            safety_coin.parent_ids,
            vec![position.escrow_coin_id.clone()]
        );
        let authority = ledger.consensus_stake_authority.as_ref().unwrap();
        assert_eq!(authority.sequence, prior_authority.sequence + 1);
        assert_eq!(
            authority.ubo_control.sequence,
            prior_authority.ubo_control.sequence + 1
        );
        assert!(authority
            .positions
            .iter()
            .all(|candidate| candidate.position_id != position.position_id));
        assert_eq!(
            ledger.supply_certificate().unwrap().conservation_position,
            supply
        );
        ledger.assert_conservation().unwrap();

        let replay_root = ledger.state_root().unwrap();
        assert_eq!(ledger.apply_consensus_commit(commit).unwrap(), outcome);
        assert_eq!(ledger.state_root().unwrap(), replay_root);
    }

    #[test]
    fn one_objective_fault_slashes_each_independent_validator_liability_once() {
        let (mut ledger, _validators, _owners, candidate_identities, epoch) =
            consensus_stake_slash_fixture_with_shared_validator(true);
        let delegated_index = epoch
            .stake_liabilities
            .iter()
            .position(|liability| liability.position.position_id == "stake-position-0004")
            .unwrap();
        assert_eq!(
            epoch.stake_liabilities[0].validator_public_key,
            epoch.stake_liabilities[delegated_index].validator_public_key
        );

        let first_request =
            consensus_stake_slash_request(&ledger, &epoch, 0, &candidate_identities[0], None);
        let evidence_hash = first_request.evidence_hash.clone();
        let first_evidence = first_request.evidence.clone();
        let first = ledger.slash_consensus_stake(first_request).unwrap();
        assert_eq!(first.evidence, first_evidence);

        let second_request = consensus_stake_slash_request(
            &ledger,
            &epoch,
            delegated_index,
            &candidate_identities[0],
            None,
        );
        assert_eq!(second_request.evidence_hash, evidence_hash);
        let second = ledger.slash_consensus_stake(second_request).unwrap();
        assert_eq!(second.evidence_hash, evidence_hash);

        let first_nullifier =
            consensus_stake_slash_nullifier_v1(&first.evidence_hash, &first.liability_commitment);
        let second_nullifier =
            consensus_stake_slash_nullifier_v1(&second.evidence_hash, &second.liability_commitment);
        assert_ne!(first_nullifier, second_nullifier);
        assert_eq!(ledger.consensus_stake_evidence_nullifiers.len(), 2);
        assert!(ledger
            .consensus_stake_evidence_nullifiers
            .contains(&first_nullifier));
        assert!(ledger
            .consensus_stake_evidence_nullifiers
            .contains(&second_nullifier));
        assert!(!ledger
            .consensus_stake_escrows
            .contains_key(&epoch.stake_liabilities[0].position.escrow_coin_id));
        assert!(!ledger.consensus_stake_escrows.contains_key(
            &epoch.stake_liabilities[delegated_index]
                .position
                .escrow_coin_id
        ));
        ledger.assert_conservation().unwrap();

        let restored: Ledger =
            serde_json::from_slice(&serde_json::to_vec(&ledger).unwrap()).unwrap();
        restored.assert_conservation().unwrap();
        assert_eq!(
            restored.consensus_stake_slashes[&first.slash_id].evidence,
            first_evidence
        );
        let restored_audit = restored.audit_proof_bundle().unwrap();
        restored_audit.verify_structure().unwrap();
        assert_eq!(
            restored_audit
                .consensus_stake_slashes
                .iter()
                .find(|record| record.slash_id == first.slash_id)
                .unwrap()
                .evidence,
            first_evidence
        );

        let mut forged_archive = ledger.clone();
        forged_archive
            .consensus_stake_slashes
            .get_mut(&first.slash_id)
            .unwrap()
            .evidence
            .first_vote
            .as_mut()
            .unwrap()
            .signature = "00".repeat(64);
        assert!(matches!(
            forged_archive.assert_conservation(),
            Err(LedgerError::Invalid(message)) if message.contains("slash identity, evidence")
        ));

        let mut tampered_ledger = ledger.clone();
        let tampered_record = tampered_ledger
            .consensus_stake_slashes
            .get_mut(&first.slash_id)
            .unwrap();
        tampered_record.derived_epoch_record_hash = hash_parts(&[b"RLD-TAMPERED-SLASH-EPOCH"]);
        tampered_record.record_hash = tampered_record.compute_record_hash();
        assert!(matches!(
            tampered_ledger.assert_conservation(),
            Err(LedgerError::Invalid(message)) if message.contains("slash identity, evidence, liability")
        ));

        let mut tampered_audit = ledger.audit_proof_bundle().unwrap();
        let tampered_record = tampered_audit
            .consensus_stake_slashes
            .iter_mut()
            .find(|record| record.slash_id == first.slash_id)
            .unwrap();
        tampered_record.liability_commitment = hash_parts(&[b"RLD-TAMPERED-SLASH-LIABILITY"]);
        tampered_record.record_hash = tampered_record.compute_record_hash();
        assert!(matches!(
            tampered_audit.verify_structure(),
            Err(message) if message.contains("slash identity, evidence, liability")
        ));

        let replay_root = ledger.state_root().unwrap();
        let mut replay_request =
            consensus_stake_slash_request(&ledger, &epoch, 0, &candidate_identities[0], None);
        replay_request.slash_id = "consensus-stake-slash-replay-0000".into();
        let replay_error = ledger.slash_consensus_stake(replay_request).unwrap_err();
        assert!(
            matches!(&replay_error, LedgerError::Duplicate(_)),
            "unexpected replay error: {replay_error}"
        );
        assert_eq!(ledger.state_root().unwrap(), replay_root);
    }

    #[test]
    fn stake_slash_handles_pending_unbond_and_rejects_forged_evidence_atomically() {
        let (mut ledger, _validators, owners, candidate_identities, epoch) =
            consensus_stake_slash_fixture();
        let position_index = 1;
        let position = epoch.stake_liabilities[position_index].position.clone();
        let owner_address = owners[position_index].address(&ledger.descriptor.zone_id);
        let authority = ledger.consensus_stake_authority.clone().unwrap();
        let withdraw_after_height = u64::try_from(
            epoch.stake_liabilities[position_index]
                .evidence_deadline_height
                .max(position.committed_through_height)
                .max(u128::from(ledger.height + 1) + authority.policy.activation_delay_blocks),
        )
        .unwrap();
        let mut unbond = RequestConsensusStakeUnbondV1 {
            request_id: "slash-pending-unbond-0001".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment,
            position_id: position.position_id.clone(),
            escrow_coin_id: position.escrow_coin_id.clone(),
            owner: owner_address.clone(),
            beneficiary: owner_address,
            requested_withdraw_after_height: withdraw_after_height,
            authorization: signed_authorization(
                &owners[position_index],
                &ledger.descriptor.zone_id,
                REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
                String::new(),
                2_000,
            ),
        };
        unbond.authorization = signed_authorization(
            &owners[position_index],
            &ledger.descriptor.zone_id,
            REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
            unbond.payload_hash(),
            2_000,
        );
        let pending = ledger.request_consensus_stake_unbond(unbond).unwrap();
        assert_eq!(pending.status, ConsensusStakeUnbondStatusV1::Pending);

        let mut wrong_precondition = consensus_stake_slash_request(
            &ledger,
            &epoch,
            position_index,
            &candidate_identities[position_index],
            Some("00".repeat(32)),
        );
        wrong_precondition.slash_id = "slash-wrong-unbond-precondition".into();
        let root = ledger.state_root().unwrap();
        let wrong_error = ledger
            .slash_consensus_stake(wrong_precondition)
            .unwrap_err();
        assert!(
            matches!(&wrong_error, LedgerError::Invalid(message) if message.contains("pending-unbond precondition")),
            "unexpected slash precondition error: {wrong_error}"
        );
        assert_eq!(ledger.state_root().unwrap(), root);

        let mut forged = consensus_stake_slash_request(
            &ledger,
            &epoch,
            position_index,
            &candidate_identities[position_index],
            Some(pending.request_commitment.clone()),
        );
        forged.slash_id = "slash-forged-evidence".into();
        forged.evidence.first_vote.as_mut().unwrap().signature = "00".repeat(64);
        forged.evidence_hash = forged
            .evidence
            .evidence_hash(&epoch.descriptor.network_domain)
            .unwrap();
        let forged_nullifier =
            consensus_stake_slash_nullifier_v1(&forged.evidence_hash, &forged.liability_commitment);
        let root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.slash_consensus_stake(forged),
            Err(LedgerError::Invalid(message)) if message.contains("evidence rejected")
        ));
        assert_eq!(ledger.state_root().unwrap(), root);
        assert!(!ledger
            .consensus_stake_evidence_nullifiers
            .contains(&forged_nullifier));

        let valid = consensus_stake_slash_request(
            &ledger,
            &epoch,
            position_index,
            &candidate_identities[position_index],
            Some(pending.request_commitment.clone()),
        );
        let record = ledger.slash_consensus_stake(valid.clone()).unwrap();
        let tombstone = &ledger.consensus_stake_unbonds[&pending.request_id];
        assert_eq!(tombstone.status, ConsensusStakeUnbondStatusV1::FullySlashed);
        assert_eq!(
            tombstone.slash_id.as_deref(),
            Some(record.slash_id.as_str())
        );
        assert_eq!(tombstone.slashed_amount, position.amount);
        assert_eq!(tombstone.completed_height, Some(record.applied_height));
        assert!(tombstone.payout_coin_id.is_none());
        assert_eq!(
            record.unbond_request_commitment.as_deref(),
            Some(pending.request_commitment.as_str())
        );
        let evidence_nullifier =
            consensus_stake_slash_nullifier_v1(&record.evidence_hash, &record.liability_commitment);
        assert!(ledger
            .consensus_stake_evidence_nullifiers
            .contains(&evidence_nullifier));
        assert_eq!(
            ledger.coins[&position.escrow_coin_id].state,
            CoinState::Consumed
        );
        ledger.assert_conservation().unwrap();

        let replay_root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.slash_consensus_stake(valid),
            Err(LedgerError::Invalid(message)) if message.contains("height does not match")
        ));
        assert_eq!(ledger.state_root().unwrap(), replay_root);
    }

    #[test]
    fn all_objective_stake_evidence_types_bind_historical_key_context_and_window() {
        let (_ledger, _validators, _owners, candidate_identities, epoch) =
            consensus_stake_slash_fixture();
        let liability = &epoch.stake_liabilities[0];
        let position_id = liability.position.position_id.as_str();
        let liability_commitment = liability.liability_commitment.as_str();

        let double_sign = double_sign_evidence(&epoch, &candidate_identities[0]);
        let verified = crate::verify_consensus_stake_slash_evidence_v1(
            &epoch,
            position_id,
            liability_commitment,
            &double_sign,
        )
        .unwrap();
        assert_eq!(
            verified.kind,
            crate::ConsensusStakeSlashEvidenceKindV1::DoubleSign
        );
        assert_eq!(verified.slash_bps, 10_000);

        let mut noncanonical = double_sign.clone();
        std::mem::swap(&mut noncanonical.first_vote, &mut noncanonical.second_vote);
        assert!(matches!(
            crate::verify_consensus_stake_slash_evidence_v1(
                &epoch,
                position_id,
                liability_commitment,
                &noncanonical,
            ),
            Err(crate::ConsensusStakeEvidenceError::NonCanonicalPair)
        ));

        let mut malformed = double_sign.clone();
        malformed.proposal = Some(crate::SignedConsensusProposalStatementV1 {
            proposal_id: "inactive-field".into(),
            zone_id: epoch.descriptor.zone_id.clone(),
            currency_genesis_root: epoch.descriptor.currency_genesis_root.clone(),
            protocol_era: epoch.descriptor.protocol_era,
            crypto_era: epoch.descriptor.crypto_era,
            parent_height: 0,
            parent_state_root: String::new(),
            round: 0,
            proposer_public_key: candidate_identities[0].public_key.clone(),
            command_hash: String::new(),
            expected_height: 0,
            expected_state_root: String::new(),
            signature: String::new(),
        });
        assert!(matches!(
            crate::verify_consensus_stake_slash_evidence_v1(
                &epoch,
                position_id,
                liability_commitment,
                &malformed,
            ),
            Err(crate::ConsensusStakeEvidenceError::InvalidEvidenceShape)
        ));

        let mut forged = double_sign.clone();
        forged.first_vote.as_mut().unwrap().signature = "00".repeat(64);
        if forged
            .first_vote
            .as_ref()
            .unwrap()
            .signed_commitment(&epoch.descriptor.network_domain)
            .unwrap()
            > forged
                .second_vote
                .as_ref()
                .unwrap()
                .signed_commitment(&epoch.descriptor.network_domain)
                .unwrap()
        {
            std::mem::swap(&mut forged.first_vote, &mut forged.second_vote);
        }
        assert!(matches!(
            crate::verify_consensus_stake_slash_evidence_v1(
                &epoch,
                position_id,
                liability_commitment,
                &forged,
            ),
            Err(crate::ConsensusStakeEvidenceError::InvalidSignature(_))
        ));

        let wrong_key = double_sign_evidence(&epoch, &candidate_identities[1]);
        assert!(matches!(
            crate::verify_consensus_stake_slash_evidence_v1(
                &epoch,
                position_id,
                liability_commitment,
                &wrong_key,
            ),
            Err(crate::ConsensusStakeEvidenceError::HistoricalKeyMismatch)
        ));

        let mut outside = double_sign.clone();
        for vote in [
            outside.first_vote.as_mut().unwrap(),
            outside.second_vote.as_mut().unwrap(),
        ] {
            vote.parent_height = u64::try_from(liability.exit_height).unwrap();
            vote.signature = sign_bytes(
                &candidate_identities[0].secret_key,
                &vote
                    .signing_bytes(&epoch.descriptor.network_domain)
                    .unwrap(),
            )
            .unwrap();
        }
        if outside
            .first_vote
            .as_ref()
            .unwrap()
            .signed_commitment(&epoch.descriptor.network_domain)
            .unwrap()
            > outside
                .second_vote
                .as_ref()
                .unwrap()
                .signed_commitment(&epoch.descriptor.network_domain)
                .unwrap()
        {
            std::mem::swap(&mut outside.first_vote, &mut outside.second_vote);
        }
        assert!(matches!(
            crate::verify_consensus_stake_slash_evidence_v1(
                &epoch,
                position_id,
                liability_commitment,
                &outside,
            ),
            Err(crate::ConsensusStakeEvidenceError::OutsideLiabilityWindow)
        ));

        let checkpoint_height = liability.activation_height;
        let mut checkpoint_a = crate::SignedConsensusCheckpointStatementV1 {
            network_domain: epoch.descriptor.network_domain.clone(),
            zone_id: epoch.descriptor.zone_id.clone(),
            currency_genesis_root: epoch.descriptor.currency_genesis_root.clone(),
            protocol_era: epoch.descriptor.protocol_era,
            crypto_era: epoch.descriptor.crypto_era,
            consensus_protocol_version: epoch.descriptor.consensus_protocol_version,
            consensus_epoch: epoch.descriptor.consensus_epoch,
            checkpoint_height,
            previous_checkpoint_hash: hash_parts(&[b"RLD-TEST-PREVIOUS-CHECKPOINT"]),
            state_root: hash_parts(&[b"RLD-TEST-CHECKPOINT-A"]),
            validator_id: liability.position.validator_id().to_owned(),
            validator_public_key: liability.validator_public_key.clone(),
            validator_key_era: liability.validator_key_era,
            signature: String::new(),
        };
        checkpoint_a.signature = sign_bytes(
            &candidate_identities[0].secret_key,
            &checkpoint_a.signing_bytes().unwrap(),
        )
        .unwrap();
        let mut checkpoint_b = checkpoint_a.clone();
        checkpoint_b.state_root = hash_parts(&[b"RLD-TEST-CHECKPOINT-B"]);
        checkpoint_b.signature = sign_bytes(
            &candidate_identities[0].secret_key,
            &checkpoint_b.signing_bytes().unwrap(),
        )
        .unwrap();
        let (first_checkpoint, second_checkpoint) = if checkpoint_a.signed_commitment().unwrap()
            < checkpoint_b.signed_commitment().unwrap()
        {
            (checkpoint_a.clone(), checkpoint_b)
        } else {
            (checkpoint_b, checkpoint_a.clone())
        };
        let conflicting_checkpoint = crate::ConsensusStakeSlashEvidenceV1 {
            kind: crate::ConsensusStakeSlashEvidenceKindV1::ConflictingCheckpoint,
            first_vote: None,
            second_vote: None,
            first_checkpoint: Some(first_checkpoint),
            second_checkpoint: Some(second_checkpoint),
            proposal: None,
            invalid_vote: None,
        };
        let verified = crate::verify_consensus_stake_slash_evidence_v1(
            &epoch,
            position_id,
            liability_commitment,
            &conflicting_checkpoint,
        )
        .unwrap();
        assert_eq!(
            verified.kind,
            crate::ConsensusStakeSlashEvidenceKindV1::ConflictingCheckpoint
        );
        let mut same_checkpoint = conflicting_checkpoint.clone();
        same_checkpoint.second_checkpoint = same_checkpoint.first_checkpoint.clone();
        assert!(crate::verify_consensus_stake_slash_evidence_v1(
            &epoch,
            position_id,
            liability_commitment,
            &same_checkpoint,
        )
        .is_err());

        let parent_height = u64::try_from(liability.activation_height - 1).unwrap();
        let proposal_id = "invalid-state-commitment-proposal";
        let mut proposal = crate::SignedConsensusProposalStatementV1 {
            proposal_id: proposal_id.into(),
            zone_id: epoch.descriptor.zone_id.clone(),
            currency_genesis_root: epoch.descriptor.currency_genesis_root.clone(),
            protocol_era: epoch.descriptor.protocol_era,
            crypto_era: epoch.descriptor.crypto_era,
            parent_height,
            parent_state_root: hash_parts(&[b"RLD-TEST-SLASH-PARENT"]),
            round: 0,
            proposer_public_key: candidate_identities[1].public_key.clone(),
            command_hash: hash_parts(&[b"RLD-TEST-INVALID-STATE-COMMAND"]),
            expected_height: parent_height + 1,
            expected_state_root: hash_parts(&[b"RLD-TEST-PROPOSAL-STATE"]),
            signature: String::new(),
        };
        proposal.signature = sign_bytes(
            &candidate_identities[1].secret_key,
            &proposal
                .signing_bytes(&epoch.descriptor.network_domain)
                .unwrap(),
        )
        .unwrap();
        let proposal_hash = proposal
            .content_hash(&epoch.descriptor.network_domain)
            .unwrap();
        let invalid_vote = signed_stake_vote_statement(
            &epoch,
            &candidate_identities[0],
            proposal_id,
            proposal_hash,
            hash_parts(&[b"RLD-TEST-VOTE-INVALID-STATE"]),
        );
        let invalid_state = crate::ConsensusStakeSlashEvidenceV1 {
            kind: crate::ConsensusStakeSlashEvidenceKindV1::InvalidStateCommitment,
            first_vote: None,
            second_vote: None,
            first_checkpoint: None,
            second_checkpoint: None,
            proposal: Some(proposal),
            invalid_vote: Some(invalid_vote),
        };
        let verified = crate::verify_consensus_stake_slash_evidence_v1(
            &epoch,
            position_id,
            liability_commitment,
            &invalid_state,
        )
        .unwrap();
        assert_eq!(
            verified.kind,
            crate::ConsensusStakeSlashEvidenceKindV1::InvalidStateCommitment
        );
    }

    #[test]
    fn delayed_stake_unbond_is_certified_supply_preserving_and_exactly_replayable() {
        let (mut ledger, validators, _owner, request, lock_commit) =
            consensus_stake_unbond_fixture();
        let runtime_keys = ledger.descriptor.validator_keys.clone();
        let supply = ledger.supply_certificate().unwrap().conservation_position;
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::RequestConsensusStakeUnbond(Box::new(request.clone())),
        );
        let request_commit = ConsensusCommit {
            proposal: proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal, validator))
                .collect(),
        };
        let pending_outcome = ledger
            .apply_consensus_commit(request_commit.clone())
            .unwrap();
        let ConsensusOutcome::ConsensusStakeUnbond(pending) = &pending_outcome else {
            panic!("stake unbond request returned the wrong outcome");
        };
        assert_eq!(pending.status, ConsensusStakeUnbondStatusV1::Pending);
        assert_eq!(pending.owner, pending.beneficiary);
        assert_eq!(pending.withdraw_after_height, 100);
        assert!(ledger
            .consensus_stake_authority
            .as_ref()
            .unwrap()
            .positions
            .iter()
            .all(|position| position.position_id != pending.position.position_id));
        assert_eq!(
            ledger.coins[&pending.position.escrow_coin_id].state,
            CoinState::Reserved
        );
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);

        let early = CompleteConsensusStakeUnbondV1 {
            completion_id: "stake-unbond-completion-early".into(),
            request_id: pending.request_id.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: 200,
            expected_unbond_request_commitment: pending.request_commitment.clone(),
            beneficiary: pending.beneficiary.clone(),
        };
        let mut redirected = early.clone();
        redirected.completion_id = "stake-unbond-completion-redirected".into();
        redirected.beneficiary = "rld:redirected-beneficiary".into();
        let redirected_root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.complete_consensus_stake_unbond(redirected),
            Err(LedgerError::Invalid(message)) if message.contains("beneficiary")
        ));
        assert_eq!(ledger.state_root().unwrap(), redirected_root);
        let early_root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.complete_consensus_stake_unbond(early),
            Err(LedgerError::Invalid(message)) if message.contains("withdrawal height")
        ));
        assert_eq!(ledger.state_root().unwrap(), early_root);

        while ledger.height < pending.withdraw_after_height {
            ledger.advance().unwrap();
        }
        let completion = CompleteConsensusStakeUnbondV1 {
            completion_id: "stake-unbond-completion-0000".into(),
            request_id: pending.request_id.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 10,
            expected_unbond_request_commitment: pending.request_commitment.clone(),
            beneficiary: pending.beneficiary.clone(),
        };
        let leader = consensus_leader(&ledger, &validators);
        let completion_proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::CompleteConsensusStakeUnbond(Box::new(completion)),
        );
        let completion_commit = ConsensusCommit {
            proposal: completion_proposal.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&completion_proposal, validator))
                .collect(),
        };
        let crash_envelope = serde_json::to_vec(&completion_commit).unwrap();
        let recovered_commit: ConsensusCommit = serde_json::from_slice(&crash_envelope).unwrap();
        assert_eq!(recovered_commit, completion_commit);
        let completed_outcome = ledger
            .apply_consensus_commit(recovered_commit.clone())
            .unwrap();
        let ConsensusOutcome::ConsensusStakeUnbond(completed) = &completed_outcome else {
            panic!("stake unbond completion returned the wrong outcome");
        };
        assert_eq!(completed.status, ConsensusStakeUnbondStatusV1::Completed);
        assert_eq!(
            ledger.coins[&completed.position.escrow_coin_id].state,
            CoinState::Consumed
        );
        let payout = &ledger.coins[completed.payout_coin_id.as_ref().unwrap()];
        assert_eq!(payout.state, CoinState::Spendable);
        assert_eq!(payout.owner, completed.owner);
        assert_eq!(payout.amount, completed.position.amount);
        assert_eq!(
            payout.parent_ids.as_slice(),
            std::slice::from_ref(&completed.position.escrow_coin_id)
        );
        assert!(!ledger
            .consensus_stake_escrows
            .contains_key(&completed.position.escrow_coin_id));
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);
        assert_eq!(
            ledger.supply_certificate().unwrap().conservation_position,
            supply
        );
        ledger.assert_conservation().unwrap();

        let replay_root = ledger.state_root().unwrap();
        assert_eq!(
            ledger.apply_consensus_commit(lock_commit).unwrap(),
            ConsensusOutcome::ConsensusStake(completed.position.clone())
        );
        assert_eq!(
            ledger.apply_consensus_commit(request_commit).unwrap(),
            pending_outcome
        );
        assert_eq!(
            ledger
                .apply_consensus_commit(recovered_commit.clone())
                .unwrap(),
            completed_outcome
        );
        assert_eq!(ledger.state_root().unwrap(), replay_root);
        let mut duplicate_completion = match &recovered_commit.proposal.command {
            ConsensusCommand::CompleteConsensusStakeUnbond(request) => (**request).clone(),
            _ => unreachable!(),
        };
        duplicate_completion.proposed_height = ledger.height;
        duplicate_completion.expires_at_height = ledger.height + 10;
        assert!(matches!(
            ledger.complete_consensus_stake_unbond(duplicate_completion),
            Err(LedgerError::Duplicate(_))
        ));
        assert_eq!(ledger.state_root().unwrap(), replay_root);
        let audit = ledger.audit_proof_bundle().unwrap();
        assert_eq!(audit.consensus_stake_unbonds, vec![completed.clone()]);
    }

    #[test]
    fn stake_unbond_forgery_beneficiary_replay_and_overflow_fail_atomically() {
        let (mut forged, _validators, _owner, mut request, _lock_commit) =
            consensus_stake_unbond_fixture();
        let authorization_id = request.authorization.authorization_id.clone();
        request.beneficiary = "rld:forged-beneficiary".into();
        let root = forged.state_root().unwrap();
        assert!(matches!(
            forged.request_consensus_stake_unbond(request),
            Err(LedgerError::OwnerMismatch)
        ));
        assert_eq!(forged.state_root().unwrap(), root);
        assert!(!forged.authorization_nullifiers.contains(&authorization_id));

        let (mut wrong_owner, _validators, _owner, mut request, _lock_commit) =
            consensus_stake_unbond_fixture();
        let attacker = generate_identity();
        let attacker_address = attacker.address(&wrong_owner.descriptor.zone_id);
        request.owner.clone_from(&attacker_address);
        request.beneficiary = attacker_address;
        request.authorization = signed_authorization(
            &attacker,
            &wrong_owner.descriptor.zone_id,
            REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
            request.payload_hash(),
            901,
        );
        let attacker_authorization = request.authorization.authorization_id.clone();
        let root = wrong_owner.state_root().unwrap();
        assert!(matches!(
            wrong_owner.request_consensus_stake_unbond(request),
            Err(LedgerError::OwnerMismatch)
        ));
        assert_eq!(wrong_owner.state_root().unwrap(), root);
        assert!(!wrong_owner
            .authorization_nullifiers
            .contains(&attacker_authorization));

        let (mut duplicate, _validators, owner, request, _lock_commit) =
            consensus_stake_unbond_fixture();
        duplicate
            .request_consensus_stake_unbond(request.clone())
            .unwrap();
        let mut replay = request;
        replay.proposed_height = duplicate.height;
        replay.expected_authority_sequence = duplicate
            .consensus_stake_authority
            .as_ref()
            .unwrap()
            .sequence;
        replay.expected_authority_commitment = duplicate
            .consensus_stake_authority
            .as_ref()
            .unwrap()
            .commitment
            .clone();
        replay.authorization = signed_authorization(
            &owner,
            &duplicate.descriptor.zone_id,
            REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
            replay.payload_hash(),
            902,
        );
        let duplicate_root = duplicate.state_root().unwrap();
        assert!(matches!(
            duplicate.request_consensus_stake_unbond(replay),
            Err(LedgerError::Duplicate(_))
        ));
        assert_eq!(duplicate.state_root().unwrap(), duplicate_root);

        let (mut overflow, _validators, owner, mut request, _lock_commit) =
            consensus_stake_unbond_fixture();
        let mut authority = overflow.consensus_stake_authority.clone().unwrap();
        authority.policy.activation_delay_blocks = u128::MAX;
        authority.commitment =
            crate::ledger_stake_authority_state_commitment_v1(&authority).unwrap();
        request.expected_authority_sequence = authority.sequence;
        request.expected_authority_commitment = authority.commitment.clone();
        overflow.consensus_stake_authority = Some(authority);
        request.authorization = signed_authorization(
            &owner,
            &overflow.descriptor.zone_id,
            REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
            request.payload_hash(),
            903,
        );
        let overflow_authorization = request.authorization.authorization_id.clone();
        let overflow_root = overflow.state_root().unwrap();
        assert!(matches!(
            overflow.request_consensus_stake_unbond(request),
            Err(LedgerError::Invalid(message)) if message.contains("overflow")
        ));
        assert_eq!(overflow.state_root().unwrap(), overflow_root);
        assert!(!overflow
            .authorization_nullifiers
            .contains(&overflow_authorization));
    }

    #[test]
    fn stake_unbond_cannot_truncate_a_derived_epoch_commitment_or_evidence_window() {
        let (mut ledger, validators, notaries, candidate_identities, mut governance) =
            stake_authority_governance_fixture();
        let owner = generate_identity();
        let owner_address = owner.address(&ledger.descriptor.zone_id);
        let position_id = governance.positions[0].position_id.clone();
        let escrow_id = governance.positions[0].escrow_coin_id.clone();
        let source_id = governance.positions[0].source_coin_id.clone();
        for position in &mut governance.positions {
            position.committed_through_height = 14;
            ledger
                .consensus_stake_escrows
                .get_mut(&position.escrow_coin_id)
                .unwrap()
                .committed_through_height = 14;
        }
        governance.positions[0].owner.clone_from(&owner_address);
        ledger
            .consensus_stake_escrows
            .get_mut(&escrow_id)
            .unwrap()
            .owner
            .clone_from(&owner_address);
        ledger.coins.get_mut(&source_id).unwrap().owner = owner_address.clone();
        ledger.coins.get_mut(&escrow_id).unwrap().owner = owner_address.clone();
        governance.candidates[0].owner.clone_from(&owner_address);
        let context =
            ledger.stake_context_at(u128::from(ledger.height), ledger.state_root().unwrap());
        let mut candidate = ValidatorCandidateRecord {
            validator_id: governance.candidates[0].validator_id.clone(),
            owner: owner_address.clone(),
            public_key: governance.candidates[0].public_key.clone(),
            key_era: governance.candidates[0].key_era,
            registered_height: 0,
            exit_height: None,
            proof_of_possession: String::new(),
        };
        candidate.proof_of_possession = sign_bytes(
            &candidate_identities[0].secret_key,
            &crate::validator_candidate_pop_message_v1(&context, &candidate),
        )
        .unwrap();
        governance.candidates[0].proof_of_possession = candidate.proof_of_possession;
        let prospective = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(ledger.height + 1),
            None,
            governance.to_ledger_update().unwrap(),
            &ledger.coins,
        )
        .unwrap();
        governance.prospective_authority_commitment = prospective.commitment;
        governance.subject_hash = governance.compute_subject_hash();
        governance.validator_qc = signed_qc(&governance.subject_hash, &validators, 3);
        governance.notary_qc = signed_qc(&governance.subject_hash, &notaries, 3);
        ledger.submit_stake_authority_update(governance).unwrap();
        let authority = ledger.consensus_stake_authority.clone().unwrap();
        let derive_request = DeriveNextStakeEpochRequestV1 {
            request_id: "stake-unbond-protected-epoch".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 10,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment.clone(),
            expected_consensus_epoch: 1,
            expected_snapshot_height: ledger.height,
            expected_snapshot_state_root: ledger.state_root().unwrap(),
        };
        let epoch = ledger.derive_next_stake_epoch(derive_request).unwrap();
        assert_eq!(
            epoch.descriptor.exit_height + authority.policy.evidence_window_blocks,
            14
        );

        let mut request = RequestConsensusStakeUnbondV1 {
            request_id: "stake-unbond-too-early-for-epoch".into(),
            zone_id: ledger.descriptor.zone_id.clone(),
            currency_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            proposed_height: ledger.height,
            expires_at_height: ledger.height + 20,
            expected_authority_sequence: authority.sequence,
            expected_authority_commitment: authority.commitment,
            position_id,
            escrow_coin_id: escrow_id,
            owner: owner_address.clone(),
            beneficiary: owner_address,
            requested_withdraw_after_height: 13,
            authorization: signed_authorization(
                &owner,
                &ledger.descriptor.zone_id,
                REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
                String::new(),
                904,
            ),
        };
        request.authorization = signed_authorization(
            &owner,
            &ledger.descriptor.zone_id,
            REQUEST_CONSENSUS_STAKE_UNBOND_ACTION_V1,
            request.payload_hash(),
            904,
        );
        let authorization_id = request.authorization.authorization_id.clone();
        let root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.request_consensus_stake_unbond(request),
            Err(LedgerError::Invalid(message)) if message.contains("Epoch evidence window")
        ));
        assert_eq!(ledger.state_root().unwrap(), root);
        assert!(!ledger.authorization_nullifiers.contains(&authorization_id));
    }

    #[test]
    fn stake_lock_forgery_and_unregistered_governance_position_fail_atomically() {
        let (mut ledger, _validators, _owner, mut forged) = consensus_stake_lock_fixture();
        let baseline = ledger.state_root().unwrap();
        let authorization_id = forged.authorization.authorization_id.clone();
        forged.amount = Amount::from_runlai(11);
        assert!(matches!(
            ledger.lock_consensus_stake(forged),
            Err(LedgerError::InvalidSignature(_))
        ));
        assert_eq!(ledger.state_root().unwrap(), baseline);
        assert!(!ledger.authorization_nullifiers.contains(&authorization_id));

        let (mut delegated, _validators, owner, mut delegation) = consensus_stake_lock_fixture();
        delegation.position_id = "stake-delegation-position-0000".into();
        delegation.position_type = StakePositionTypeV1::Delegation;
        delegation.amount = Amount::from_runlai(1);
        delegation.authorization = signed_authorization(
            &owner,
            &delegated.descriptor.zone_id,
            LOCK_CONSENSUS_STAKE_ACTION_V1,
            delegation.payload_hash(),
            701,
        );
        let delegated_position = delegated.lock_consensus_stake(delegation).unwrap();
        assert!(matches!(
            delegated_position.kind,
            ConsensusStakePositionKind::Delegation { ref validator_id }
                if validator_id == "stake-lock-validator-0000"
        ));
        delegated.assert_conservation().unwrap();

        let (mut injected, validators, notaries, _candidate_identities, mut request) =
            stake_authority_governance_fixture();
        request.positions[0].position_id = "stake-position-0000-unregistered".into();
        let context =
            injected.stake_context_at(u128::from(injected.height), injected.state_root().unwrap());
        let prospective = build_ledger_stake_authority_state_v1(
            &context,
            u128::from(injected.height + 1),
            None,
            request.to_ledger_update().unwrap(),
            &injected.coins,
        )
        .unwrap();
        request.prospective_authority_commitment = prospective.commitment;
        request.subject_hash = request.compute_subject_hash();
        request.validator_qc = signed_qc(&request.subject_hash, &validators, 3);
        request.notary_qc = signed_qc(&request.subject_hash, &notaries, 3);
        let injected_root = injected.state_root().unwrap();
        assert!(matches!(
            injected.submit_stake_authority_update(request),
            Err(LedgerError::Invalid(message))
                if message.contains("no exact owner-authorized escrow registration")
        ));
        assert_eq!(injected.state_root().unwrap(), injected_root);
        assert!(injected.consensus_stake_authority.is_none());
    }

    #[test]
    fn round_zero_lock_blocks_overlapping_conflicting_quorums_without_mutation() {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|validator| validator.public_key.clone())
            .collect::<Vec<_>>();
        let alice = generate_identity();
        let bob = generate_identity();
        let carol = generate_identity();
        let mut ledger =
            Ledger::genesis_zone("overlapping-qc", validator_keys, Vec::new(), true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "overlapping-qc-work".into(),
                alice.address(&zone),
                ServiceRole::Observer,
                "overlapping-qc-proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let leader = consensus_leader(&ledger, &validators);
        let proposal_a = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::LocalPayment(signed_intent(
                &alice,
                &zone,
                &zone,
                &bob.address(&zone),
                &coin.object_id,
                Amount::from_rld_whole(25).unwrap(),
            )),
        );
        let proposal_b = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::LocalPayment(signed_intent(
                &alice,
                &zone,
                &zone,
                &carol.address(&zone),
                &coin.object_id,
                Amount::from_rld_whole(25).unwrap(),
            )),
        );
        assert_ne!(
            proposal_a.expected_state_root,
            proposal_b.expected_state_root
        );

        let commit_a = ConsensusCommit {
            proposal: proposal_a.clone(),
            votes: validators[..3]
                .iter()
                .map(|validator| consensus_vote(&proposal_a, validator))
                .collect(),
        };
        let commit_b = ConsensusCommit {
            proposal: proposal_b.clone(),
            votes: validators[1..]
                .iter()
                .map(|validator| consensus_vote(&proposal_b, validator))
                .collect(),
        };
        commit_a.verify(&ledger.descriptor.validator_keys).unwrap();
        commit_b.verify(&ledger.descriptor.validator_keys).unwrap();

        ledger.lock_consensus_vote(&proposal_a).unwrap();
        let before_conflict = serde_json::to_vec(&ledger).unwrap();
        let conflict = ledger.apply_consensus_commit(commit_b).unwrap_err();
        assert!(conflict.to_string().contains("durable vote lock"));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), before_conflict);

        let outcome = ledger.apply_consensus_commit(commit_a.clone()).unwrap();
        assert!(ledger.consensus_vote_locks.is_empty());
        let finalized = serde_json::to_vec(&ledger).unwrap();
        assert_eq!(ledger.apply_consensus_commit(commit_a).unwrap(), outcome);
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), finalized);
    }

    #[test]
    fn nonleader_and_cross_round_proposals_fail_before_vote_lock_changes() {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let validator_keys = validators
            .iter()
            .map(|validator| validator.public_key.clone())
            .collect::<Vec<_>>();
        let sender = generate_identity();
        let recipient = generate_identity();
        let mut ledger =
            Ledger::genesis_zone("round-zero-only", validator_keys, Vec::new(), true).unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let (coin, _) = ledger
            .bootstrap_service_reward(
                "round-zero-work".into(),
                sender.address(&zone),
                ServiceRole::Observer,
                "round-zero-proof".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let leader = consensus_leader(&ledger, &validators);
        let proposal = consensus_proposal(
            &ledger,
            leader,
            ConsensusCommand::LocalPayment(signed_intent(
                &sender,
                &zone,
                &zone,
                &recipient.address(&zone),
                &coin.object_id,
                Amount::from_rld_whole(1).unwrap(),
            )),
        );
        ledger.lock_consensus_vote(&proposal).unwrap();
        let locked = ledger.consensus_vote_locks.clone();

        let mut round_one = proposal.clone();
        round_one.round = 1;
        round_one.signature = sign_bytes(&leader.secret_key, &round_one.signing_bytes()).unwrap();
        assert!(ledger.lock_consensus_vote(&round_one).is_err());
        assert_eq!(ledger.consensus_vote_locks, locked);

        let nonleader = validators
            .iter()
            .find(|validator| validator.public_key != leader.public_key)
            .unwrap();
        let mut unauthorized = proposal;
        unauthorized.proposer_public_key = nonleader.public_key.clone();
        unauthorized.signature =
            sign_bytes(&nonleader.secret_key, &unauthorized.signing_bytes()).unwrap();
        assert!(ledger.lock_consensus_vote(&unauthorized).is_err());
        assert_eq!(ledger.consensus_vote_locks, locked);
    }

    #[test]
    fn legacy_vote_locks_consolidate_only_when_commitments_match() {
        let validator = generate_identity();
        let mut ledger = Ledger::genesis_zone(
            "legacy-lock-migration",
            vec![validator.public_key.clone()],
            Vec::new(),
            true,
        )
        .unwrap();
        let root = ledger.state_root().unwrap();
        ledger
            .consensus_vote_locks
            .insert(format!("{}:{root}:0", ledger.height), "proposal-a".into());
        ledger
            .consensus_vote_locks
            .insert(format!("{}:{root}:1", ledger.height), "proposal-a".into());
        assert!(ledger.migrate_consensus_vote_locks().unwrap());
        assert_eq!(ledger.consensus_vote_locks.len(), 1);
        assert!(ledger
            .consensus_vote_locks
            .contains_key(&format!("instance-v2:{}:{root}", ledger.height)));

        ledger
            .consensus_vote_locks
            .insert(format!("{}:{root}:2", ledger.height), "proposal-b".into());
        let before = ledger.consensus_vote_locks.clone();
        assert!(ledger.migrate_consensus_vote_locks().is_err());
        assert_eq!(ledger.consensus_vote_locks, before);
    }

    #[test]
    fn cross_zone_export_and_import_each_require_destination_local_consensus() {
        let source_validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let destination_validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone(
            "Earth-consensus",
            source_validators
                .iter()
                .map(|validator| validator.public_key.clone())
                .collect(),
            Vec::new(),
            true,
        )
        .unwrap();
        let mut mars = Ledger::empty_zone(
            "Mars-consensus",
            destination_validators
                .iter()
                .map(|validator| validator.public_key.clone())
                .collect(),
            Vec::new(),
            true,
        )
        .unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-cross-zone-consensus-work".into(),
                alice.address(&earth_id),
                ServiceRole::Observer,
                "cross-zone-consensus-work-proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(7).unwrap(),
        );
        let export_proposal = consensus_proposal(
            &earth,
            consensus_leader(&earth, &source_validators),
            ConsensusCommand::ExportPayment {
                intent,
                transport: TransportClass::SublightDtn,
            },
        );
        let export_commit = ConsensusCommit {
            proposal: export_proposal.clone(),
            votes: source_validators[..3]
                .iter()
                .map(|validator| consensus_vote(&export_proposal, validator))
                .collect(),
        };
        let ConsensusOutcome::ExportPayment(capsule) =
            earth.apply_consensus_commit(export_commit).unwrap()
        else {
            panic!("export consensus returned the wrong outcome");
        };
        let mut capsule = *capsule;
        capsule.validator_qc = signed_qc(&capsule.subject_hash(), &source_validators, 3);

        mars.set_zone_trust_policy(earth_id.clone(), ZoneTrustPolicy::LightClient)
            .unwrap();
        mars.trust_zone_checkpoint(earth_id, capsule.source_checkpoint.clone())
            .unwrap();
        let import_proposal = consensus_proposal(
            &mars,
            consensus_leader(&mars, &destination_validators),
            ConsensusCommand::ImportCapsule(Box::new(capsule)),
        );
        let import_commit = ConsensusCommit {
            proposal: import_proposal.clone(),
            votes: destination_validators[..3]
                .iter()
                .map(|validator| consensus_vote(&import_proposal, validator))
                .collect(),
        };
        let ConsensusOutcome::ImportCapsule(receipt) =
            mars.apply_consensus_commit(import_commit).unwrap()
        else {
            panic!("import consensus returned the wrong outcome");
        };
        assert_eq!(receipt.amount, Amount::from_rld_whole(7).unwrap());
        assert_eq!(
            mars.balance(&bob.address(&mars_id)).unwrap(),
            Amount::from_rld_whole(7).unwrap()
        );
        let finalize_proposal = consensus_proposal(
            &earth,
            consensus_leader(&earth, &source_validators),
            ConsensusCommand::FinalizeExport(receipt.clone()),
        );
        let finalize_commit = ConsensusCommit {
            proposal: finalize_proposal.clone(),
            votes: source_validators[..3]
                .iter()
                .map(|validator| consensus_vote(&finalize_proposal, validator))
                .collect(),
        };
        let ConsensusOutcome::FinalizeExport(finalized) =
            earth.apply_consensus_commit(finalize_commit).unwrap()
        else {
            panic!("finalize consensus returned the wrong outcome");
        };
        assert_eq!(finalized.status, PaymentStatus::UniversallySettled);
        earth.assert_conservation().unwrap();
        mars.assert_conservation().unwrap();
    }

    #[test]
    fn light_client_policy_requires_an_explicit_checkpoint_anchor() {
        let alice = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-light-client-work".into(),
                alice.address(&earth_id),
                ServiceRole::Observer,
                "light-client-work-proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();
        let intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(10).unwrap(),
        );
        let capsule = earth
            .export_payment(intent, TransportClass::SublightDtn)
            .unwrap();
        mars.set_zone_trust_policy(earth_id.clone(), ZoneTrustPolicy::LightClient)
            .unwrap();
        assert!(mars.import_capsule(capsule.clone()).is_err());
        mars.trust_zone_checkpoint(earth_id, capsule.source_checkpoint.clone())
            .unwrap();
        let receipt = mars.import_capsule(capsule).unwrap();
        assert_eq!(receipt.amount, Amount::from_rld_whole(10).unwrap());
        mars.assert_conservation().unwrap();
    }

    #[test]
    fn bonded_gateway_policy_requires_a_signed_coin_backed_local_bond() {
        let alice = generate_identity();
        let gateway = generate_identity();
        let bob = generate_identity();
        let mut earth = Ledger::genesis_zone("Earth", vec![], vec![], true).unwrap();
        let mut mars = Ledger::empty_zone("Mars", vec![], vec![], true).unwrap();
        let earth_id = earth.descriptor.zone_id.clone();
        let mars_id = mars.descriptor.zone_id.clone();
        let (coin, _) = earth
            .bootstrap_service_reward(
                "alice-bonded-gateway-work".into(),
                alice.address(&earth_id),
                ServiceRole::Observer,
                "bonded-gateway-work-proof".into(),
                Amount::from_rld_whole(100).unwrap(),
            )
            .unwrap();

        let seed_intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &gateway.address(&mars_id),
            &coin.object_id,
            Amount::from_rld_whole(20).unwrap(),
        );
        let seed_capsule = earth
            .export_payment(seed_intent, TransportClass::SublightDtn)
            .unwrap();
        let seed_receipt = mars.import_capsule(seed_capsule).unwrap();
        let bond_amount = Amount::from_rld_whole(10).unwrap();
        let owner = gateway.address(&mars_id);
        let bond_payload = action_payload_hash(
            "CREATE_GATEWAY_BOND",
            &[
                earth_id.as_bytes(),
                owner.as_bytes(),
                gateway.public_key.as_bytes(),
                seed_receipt.destination_coin_id.as_bytes(),
                &bond_amount.0.to_be_bytes(),
            ],
        );
        let bond = mars
            .create_gateway_bond(CreateGatewayBondRequest {
                source_zone: earth_id.clone(),
                owner,
                gateway_public_key: gateway.public_key.clone(),
                coin_id: seed_receipt.destination_coin_id,
                amount: bond_amount,
                authorization: signed_authorization(
                    &gateway,
                    &mars_id,
                    "CREATE_GATEWAY_BOND",
                    bond_payload,
                    901,
                ),
            })
            .unwrap();
        mars.set_zone_trust_policy(earth_id.clone(), ZoneTrustPolicy::BondedGateway)
            .unwrap();

        let alice_change = earth
            .coins_for_owner(&alice.address(&earth_id))
            .into_iter()
            .find(|candidate| candidate.state == CoinState::Spendable)
            .unwrap();
        let payment_intent = signed_intent(
            &alice,
            &earth_id,
            &mars_id,
            &bob.address(&mars_id),
            &alice_change.object_id,
            Amount::from_rld_whole(5).unwrap(),
        );
        let mut capsule = earth
            .export_payment(payment_intent, TransportClass::SublightDtn)
            .unwrap();
        assert!(mars.import_capsule(capsule.clone()).is_err());
        let mut endorsement = crate::GatewayEndorsement {
            bond_id: bond.bond_id.clone(),
            source_zone: earth_id,
            gateway_public_key: gateway.public_key.clone(),
            capsule_subject_hash: capsule.subject_hash(),
            signature: String::new(),
        };
        endorsement.signature =
            sign_bytes(&gateway.secret_key, &endorsement.signing_bytes()).unwrap();
        capsule.gateway_endorsement = Some(endorsement);
        let receipt = mars.import_capsule(capsule).unwrap();
        assert_eq!(receipt.amount, Amount::from_rld_whole(5).unwrap());
        assert_eq!(
            mars.coins[&mars.gateway_bonds[&bond.bond_id].escrow_coin_id].state,
            CoinState::Reserved
        );
        mars.assert_conservation().unwrap();
    }

    #[test]
    fn mainnet_value_cap_zero_rejects_every_guarded_spendable_path_without_mutation() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let validator_keys = validators
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let alice = generate_identity();
        let mut mainnet =
            Ledger::genesis_zone("Mainnet cap zero", validator_keys, notary_keys, false).unwrap();
        let zone_id = mainnet.descriptor.zone_id.clone();
        let coin = seed_mainnet_coin(
            &mut mainnet,
            alice.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let baseline = mainnet.state_root().unwrap();

        let local = signed_intent(
            &alice,
            &zone_id,
            &zone_id,
            &format!("rld:{zone_id}:bob"),
            &coin.object_id,
            Amount::from_rld_whole(1).unwrap(),
        );
        assert!(matches!(
            mainnet.local_payment(local),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(mainnet.state_root().unwrap(), baseline);

        let export = signed_intent(
            &alice,
            &zone_id,
            "zone-remote",
            "rld:zone-remote:bob",
            &coin.object_id,
            Amount::from_rld_whole(1).unwrap(),
        );
        assert!(matches!(
            mainnet.export_payment(export, TransportClass::SublightDtn),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(mainnet.state_root().unwrap(), baseline);

        let request = spendability_request(
            &alice,
            &zone_id,
            &coin.object_id,
            "mainnet-cap-zero-dsc",
            Amount::from_rld_whole(1).unwrap(),
            1,
        );
        assert!(matches!(
            mainnet.issue_spendability_certificate(request),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(mainnet.state_root().unwrap(), baseline);

        let source_owner = generate_identity();
        let recipient = generate_identity();
        let mut testnet_source = Ledger::genesis_zone("Test source", vec![], vec![], true).unwrap();
        let source_zone = testnet_source.descriptor.zone_id.clone();
        let (source_coin, _) = testnet_source
            .bootstrap_service_reward(
                "cap-zero-source-work".into(),
                source_owner.address(&source_zone),
                ServiceRole::Observer,
                "cap-zero-source-proof".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let capsule = testnet_source
            .export_payment(
                signed_intent(
                    &source_owner,
                    &source_zone,
                    &zone_id,
                    &recipient.address(&zone_id),
                    &source_coin.object_id,
                    Amount::from_rld_whole(1).unwrap(),
                ),
                TransportClass::SublightDtn,
            )
            .unwrap();
        assert!(matches!(
            mainnet.import_capsule(capsule),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(mainnet.state_root().unwrap(), baseline);
        assert_eq!(mainnet.value_risk_policy, ValueRiskPolicy::default());
    }

    #[test]
    fn signed_delayed_value_cap_activation_enforces_limits_and_safe_downshift() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let alice = generate_identity();
        let mut ledger = Ledger::genesis_zone(
            "Mainnet staged policy",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let zone_id = ledger.descriptor.zone_id.clone();
        let coin = seed_mainnet_coin(
            &mut ledger,
            alice.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let limits = crate::ValueRiskLimits {
            max_single_transfer: Amount::from_rld_whole(2).unwrap(),
            max_local_value_total: Amount::from_rld_whole(3).unwrap(),
            max_cross_zone_exposure: Amount::from_rld_whole(4).unwrap(),
            max_dsc_exposure: Amount::from_rld_whole(3).unwrap(),
        };
        let activate_after = ledger.height + MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS;
        let valid_update = signed_value_risk_update(
            &ledger,
            &validators,
            &notaries,
            ValueCap::ValueCap1,
            limits.clone(),
            activate_after,
            10,
        );

        let mut simulated = valid_update.clone();
        simulated.validator_qc = simulated_qc();
        simulated.notary_qc = simulated_qc();
        simulated.validator_qc.subject_hash = simulated.subject_hash.clone();
        simulated.notary_qc.subject_hash = simulated.subject_hash.clone();
        let before_forgery = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.submit_value_risk_policy_update(simulated),
            Err(LedgerError::InvalidQuorum(_))
        ));
        assert_eq!(ledger.state_root().unwrap(), before_forgery);

        ledger
            .submit_value_risk_policy_update(valid_update)
            .unwrap();
        assert_eq!(ledger.value_risk_policy.current_cap, ValueCap::ValueCap0);
        assert!(ledger.value_risk_policy.pending_update.is_some());
        assert!(matches!(
            ledger.activate_pending_value_risk_policy(),
            Err(LedgerError::ValueRisk(_))
        ));
        let pre_activation_intent = signed_intent(
            &alice,
            &zone_id,
            &zone_id,
            &format!("rld:{zone_id}:before-delay"),
            &coin.object_id,
            Amount::from_rld_whole(1).unwrap(),
        );
        assert!(matches!(
            ledger.local_payment(pre_activation_intent),
            Err(LedgerError::ValueRisk(_))
        ));

        while ledger.height < activate_after {
            ledger.advance().unwrap();
        }
        ledger.activate_pending_value_risk_policy().unwrap();
        assert_eq!(ledger.value_risk_policy.current_cap, ValueCap::ValueCap1);
        assert!(ledger.value_risk_policy.ever_enabled);

        let recipient = format!("rld:{zone_id}:recipient");
        let paid = ledger
            .local_payment(signed_intent(
                &alice,
                &zone_id,
                &zone_id,
                &recipient,
                &coin.object_id,
                Amount::from_rld_whole(2).unwrap(),
            ))
            .unwrap();
        assert_eq!(
            ledger.value_risk_policy.exposure.local_value_total,
            Amount::from_rld_whole(2).unwrap()
        );
        let change = ledger
            .coins_for_owner(&alice.address(&zone_id))
            .into_iter()
            .find(|candidate| candidate.state == CoinState::Spendable)
            .unwrap();
        let before_limit_reject = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.local_payment(signed_intent(
                &alice,
                &zone_id,
                &zone_id,
                &format!("rld:{zone_id}:over-total"),
                &change.object_id,
                Amount::from_rld_whole(2).unwrap(),
            )),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(ledger.state_root().unwrap(), before_limit_reject);

        let downshift = signed_value_risk_update(
            &ledger,
            &validators,
            &notaries,
            ValueCap::ValueCap0,
            crate::ValueRiskLimits::default(),
            ledger.height,
            11,
        );
        ledger.submit_value_risk_policy_update(downshift).unwrap();
        assert_eq!(ledger.value_risk_policy.current_cap, ValueCap::ValueCap0);
        assert!(ledger.value_risk_policy.pending_update.is_none());
        assert!(ledger.value_risk_policy.ever_enabled);
        assert_eq!(
            ledger.coins[&paid.output_coin_ids[0]].state,
            CoinState::Spendable
        );
        assert!(ledger.payments.contains_key(&paid.intent.payment_id));
        assert_eq!(
            ledger.value_risk_policy.exposure.local_value_total,
            Amount::from_rld_whole(2).unwrap()
        );
        assert!(matches!(
            ledger.local_payment(signed_intent(
                &alice,
                &zone_id,
                &zone_id,
                &format!("rld:{zone_id}:after-downshift"),
                &change.object_id,
                Amount::from_rld_whole(1).unwrap(),
            )),
            Err(LedgerError::ValueRisk(_))
        ));
    }

    #[test]
    fn censorship_stalled_blocks_value_risk_increase_submission_and_activation_atomically() {
        let limits = crate::ValueRiskLimits {
            max_single_transfer: Amount::from_rld_whole(1).unwrap(),
            max_local_value_total: Amount::from_rld_whole(2).unwrap(),
            max_cross_zone_exposure: Amount::from_rld_whole(1).unwrap(),
            max_dsc_exposure: Amount::from_rld_whole(1).unwrap(),
        };

        let (mut submission, validators, notaries) =
            m0_ledger_for_admission_gate("M0 censorship submission gate");
        assert!(submission.admission_may_sign_consensus().unwrap());
        assert!(submission
            .admission_may_accept_value_eligible_finality()
            .unwrap());
        assert!(submission.admission_may_raise_value_cap().unwrap());
        stall_m0_admission_guard(&mut submission, b"submission");
        assert!(!submission.admission_may_sign_consensus().unwrap());
        assert!(!submission
            .admission_may_accept_value_eligible_finality()
            .unwrap());
        assert!(!submission.admission_may_raise_value_cap().unwrap());

        let activate_after = submission.height + MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS;
        let update = signed_value_risk_update(
            &submission,
            &validators,
            &notaries,
            ValueCap::ValueCap1,
            limits.clone(),
            activate_after,
            60,
        );
        let before_submission = submission.state_root().unwrap();
        assert!(matches!(
            submission.submit_value_risk_policy_update(update),
            Err(LedgerError::ValueRisk(message)) if message.contains("CENSORSHIP_STALLED")
        ));
        assert_eq!(submission.state_root().unwrap(), before_submission);
        assert!(submission.value_risk_policy.pending_update.is_none());

        let (mut activation, validators, notaries) =
            m0_ledger_for_admission_gate("M0 censorship activation gate");
        let activate_after = activation.height + MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS;
        let update = signed_value_risk_update(
            &activation,
            &validators,
            &notaries,
            ValueCap::ValueCap1,
            limits,
            activate_after,
            61,
        );
        activation.submit_value_risk_policy_update(update).unwrap();
        stall_m0_admission_guard(&mut activation, b"activation");
        while activation.height < activate_after {
            activation.advance().unwrap();
        }
        let pending_before = activation.value_risk_policy.pending_update.clone();
        let before_activation = activation.state_root().unwrap();
        assert!(matches!(
            activation.activate_pending_value_risk_policy(),
            Err(LedgerError::ValueRisk(message)) if message.contains("CENSORSHIP_STALLED")
        ));
        assert_eq!(activation.state_root().unwrap(), before_activation);
        assert_eq!(
            activation.value_risk_policy.current_cap,
            ValueCap::ValueCap0
        );
        assert_eq!(activation.value_risk_policy.pending_update, pending_before);
    }

    #[test]
    fn mainnet_dsc_and_cross_zone_exposure_limits_are_consensus_state() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let provider = generate_identity();
        let mut destination = Ledger::genesis_zone(
            "Mainnet destination",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let destination_zone = destination.descriptor.zone_id.clone();
        let provider_coin = seed_mainnet_coin(
            &mut destination,
            provider.address(&destination_zone),
            Amount::from_rld_whole(10).unwrap(),
        );
        let limits = crate::ValueRiskLimits {
            max_single_transfer: Amount::from_rld_whole(2).unwrap(),
            max_local_value_total: Amount::from_rld_whole(4).unwrap(),
            max_cross_zone_exposure: Amount::from_rld_whole(3).unwrap(),
            max_dsc_exposure: Amount::from_rld_whole(3).unwrap(),
        };
        activate_mainnet_value_policy(&mut destination, &validators, &notaries, limits, 20);

        let before_oversized = destination.state_root().unwrap();
        assert!(matches!(
            destination.issue_spendability_certificate(spendability_request(
                &provider,
                &destination_zone,
                &provider_coin.object_id,
                "oversized-dsc",
                Amount::from_rld_whole(3).unwrap(),
                21,
            )),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(destination.state_root().unwrap(), before_oversized);

        destination
            .issue_spendability_certificate(spendability_request(
                &provider,
                &destination_zone,
                &provider_coin.object_id,
                "first-dsc",
                Amount::from_rld_whole(2).unwrap(),
                22,
            ))
            .unwrap();
        assert_eq!(
            destination.value_risk_policy.exposure.dsc_exposure,
            Amount::from_rld_whole(2).unwrap()
        );
        let second_provider_coin = seed_mainnet_coin(
            &mut destination,
            provider.address(&destination_zone),
            Amount::from_rld_whole(10).unwrap(),
        );
        let before_dsc_total = destination.state_root().unwrap();
        assert!(matches!(
            destination.issue_spendability_certificate(spendability_request(
                &provider,
                &destination_zone,
                &second_provider_coin.object_id,
                "second-dsc",
                Amount::from_rld_whole(2).unwrap(),
                23,
            )),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(destination.state_root().unwrap(), before_dsc_total);

        let source_validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let source_notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let sender = generate_identity();
        let recipient = generate_identity();
        let mut source = Ledger::genesis_zone(
            "Mainnet source",
            source_validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            source_notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let capsule = mainnet_capsule_for_test(
            &mut source,
            &source_validators,
            &source_notaries,
            &sender,
            &destination_zone,
            &recipient.address(&destination_zone),
            Amount::from_rld_whole(2).unwrap(),
        );
        destination.import_capsule(capsule).unwrap();
        assert_eq!(
            destination.value_risk_policy.exposure.cross_zone_exposure,
            Amount::from_rld_whole(2).unwrap()
        );
        let second_capsule = mainnet_capsule_for_test(
            &mut source,
            &source_validators,
            &source_notaries,
            &sender,
            &destination_zone,
            &recipient.address(&destination_zone),
            Amount::from_rld_whole(2).unwrap(),
        );
        let before_cross_total = destination.state_root().unwrap();
        assert!(matches!(
            destination.import_capsule(second_capsule),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(destination.state_root().unwrap(), before_cross_total);

        let test_sender = generate_identity();
        let mut test_source = Ledger::genesis_zone("Wrong network", vec![], vec![], true).unwrap();
        let test_zone = test_source.descriptor.zone_id.clone();
        let (test_coin, _) = test_source
            .bootstrap_service_reward(
                "wrong-network-work".into(),
                test_sender.address(&test_zone),
                ServiceRole::Observer,
                "wrong-network-proof".into(),
                Amount::from_rld_whole(10).unwrap(),
            )
            .unwrap();
        let wrong_network_capsule = test_source
            .export_payment(
                signed_intent(
                    &test_sender,
                    &test_zone,
                    &destination_zone,
                    &recipient.address(&destination_zone),
                    &test_coin.object_id,
                    Amount::from_rld_whole(1).unwrap(),
                ),
                TransportClass::SublightDtn,
            )
            .unwrap();
        assert!(matches!(
            destination.import_capsule(wrong_network_capsule),
            Err(LedgerError::InvalidOperationalProof(message))
                if message.contains("cross-network")
        ));
    }

    #[test]
    fn value_cap_can_enable_only_local_payments_and_keeps_other_paths_closed() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let alice = generate_identity();
        let mut ledger = Ledger::genesis_zone(
            "Local-only canary",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let zone_id = ledger.descriptor.zone_id.clone();
        let coin = seed_mainnet_coin(
            &mut ledger,
            alice.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        activate_mainnet_value_policy(
            &mut ledger,
            &validators,
            &notaries,
            crate::ValueRiskLimits {
                max_single_transfer: Amount::from_rld_whole(1).unwrap(),
                max_local_value_total: Amount::from_rld_whole(2).unwrap(),
                max_cross_zone_exposure: Amount::ZERO,
                max_dsc_exposure: Amount::ZERO,
            },
            30,
        );

        ledger
            .local_payment(signed_intent(
                &alice,
                &zone_id,
                &zone_id,
                &format!("rld:{zone_id}:local-canary-recipient"),
                &coin.object_id,
                Amount::from_rld_whole(1).unwrap(),
            ))
            .unwrap();
        let change = ledger
            .coins_for_owner(&alice.address(&zone_id))
            .into_iter()
            .find(|candidate| candidate.state == CoinState::Spendable)
            .unwrap();
        let before_closed_paths = ledger.state_root().unwrap();
        let export_error = ledger
            .export_payment(
                signed_intent(
                    &alice,
                    &zone_id,
                    "zone-disabled-cross-path",
                    "rld:zone-disabled-cross-path:recipient",
                    &change.object_id,
                    Amount::from_rld_whole(1).unwrap(),
                ),
                TransportClass::SublightDtn,
            )
            .unwrap_err();
        assert!(matches!(
            export_error,
            LedgerError::ValueRisk(message) if message.contains("disables the cross-Zone")
        ));
        assert_eq!(ledger.state_root().unwrap(), before_closed_paths);

        let dsc_error = ledger
            .issue_spendability_certificate(spendability_request(
                &alice,
                &zone_id,
                &change.object_id,
                "disabled-dsc-path",
                Amount::from_rld_whole(1).unwrap(),
                31,
            ))
            .unwrap_err();
        assert!(matches!(
            dsc_error,
            LedgerError::ValueRisk(message)
                if message.contains("disables the destination-spendability")
        ));
        assert_eq!(ledger.state_root().unwrap(), before_closed_paths);
    }

    #[test]
    fn value_policy_rejects_noncanonical_safety_hash_and_sequence_overflow_atomically() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let mut ledger = Ledger::genesis_zone(
            "Policy boundary checks",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let limits = crate::ValueRiskLimits {
            max_single_transfer: Amount::from_rld_whole(1).unwrap(),
            max_local_value_total: Amount::from_rld_whole(1).unwrap(),
            max_cross_zone_exposure: Amount::ZERO,
            max_dsc_exposure: Amount::ZERO,
        };
        let activate_after = ledger.height + MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS;
        let mut forged = signed_value_risk_update(
            &ledger,
            &validators,
            &notaries,
            ValueCap::ValueCap1,
            limits,
            activate_after,
            40,
        );
        forged.safety_case_hash = "A".repeat(64);
        resign_value_risk_update(&mut forged, &validators, &notaries);
        let before_forged_hash = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.submit_value_risk_policy_update(forged),
            Err(LedgerError::ValueRisk(message)) if message.contains("lowercase SHA-256")
        ));
        assert_eq!(ledger.state_root().unwrap(), before_forged_hash);

        ledger.value_risk_policy.policy_sequence = u64::MAX;
        let overflow = signed_value_risk_update(
            &ledger,
            &validators,
            &notaries,
            ValueCap::ValueCap0,
            crate::ValueRiskLimits::default(),
            ledger.height,
            41,
        );
        let before_overflow = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.submit_value_risk_policy_update(overflow),
            Err(LedgerError::ValueRisk(message)) if message.contains("sequence overflow")
        ));
        assert_eq!(ledger.state_root().unwrap(), before_overflow);
    }

    #[test]
    fn safety_case_expiry_blocks_late_activation_and_running_value_but_not_downshift() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let validator_keys = validators
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect::<Vec<_>>();
        let limits = crate::ValueRiskLimits {
            max_single_transfer: Amount::from_rld_whole(1).unwrap(),
            max_local_value_total: Amount::from_rld_whole(3).unwrap(),
            max_cross_zone_exposure: Amount::ZERO,
            max_dsc_exposure: Amount::ZERO,
        };

        let mut late = Ledger::genesis_zone(
            "Expired before activation",
            validator_keys.clone(),
            notary_keys.clone(),
            false,
        )
        .unwrap();
        let activate_after = late.height + MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS;
        let mut late_update = signed_value_risk_update(
            &late,
            &validators,
            &notaries,
            ValueCap::ValueCap1,
            limits.clone(),
            activate_after,
            50,
        );
        late_update.safety_case_valid_until_height = activate_after + 2;
        resign_value_risk_update(&mut late_update, &validators, &notaries);
        late.submit_value_risk_policy_update(late_update).unwrap();
        while late.height < activate_after + 2 {
            late.advance().unwrap();
        }
        let before_late_activation = late.state_root().unwrap();
        assert!(matches!(
            late.activate_pending_value_risk_policy(),
            Err(LedgerError::ValueRisk(message)) if message.contains("expires before")
        ));
        assert_eq!(late.state_root().unwrap(), before_late_activation);
        assert_eq!(late.value_risk_policy.current_cap, ValueCap::ValueCap0);

        let alice = generate_identity();
        let mut active = Ledger::genesis_zone(
            "Runtime evidence expiry",
            validator_keys,
            notary_keys,
            false,
        )
        .unwrap();
        let zone_id = active.descriptor.zone_id.clone();
        let coin = seed_mainnet_coin(
            &mut active,
            alice.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let active_after = active.height + MIN_VALUE_CAP_UPGRADE_DELAY_BLOCKS;
        let mut active_update = signed_value_risk_update(
            &active,
            &validators,
            &notaries,
            ValueCap::ValueCap1,
            limits,
            active_after,
            51,
        );
        active_update.safety_case_valid_until_height = active_after + 5;
        resign_value_risk_update(&mut active_update, &validators, &notaries);
        active
            .submit_value_risk_policy_update(active_update)
            .unwrap();
        while active.height < active_after {
            active.advance().unwrap();
        }
        active.activate_pending_value_risk_policy().unwrap();
        let paid = active
            .local_payment(signed_intent(
                &alice,
                &zone_id,
                &zone_id,
                &format!("rld:{zone_id}:before-evidence-expiry"),
                &coin.object_id,
                Amount::from_rld_whole(1).unwrap(),
            ))
            .unwrap();
        let change = active
            .coins_for_owner(&alice.address(&zone_id))
            .into_iter()
            .find(|candidate| candidate.state == CoinState::Spendable)
            .unwrap();
        while active.height < active.value_risk_policy.safety_case_valid_until_height {
            active.advance().unwrap();
        }
        let before_expired_payment = active.state_root().unwrap();
        assert!(matches!(
            active.local_payment(signed_intent(
                &alice,
                &zone_id,
                &zone_id,
                &format!("rld:{zone_id}:after-evidence-expiry"),
                &change.object_id,
                Amount::from_rld_whole(1).unwrap(),
            )),
            Err(LedgerError::ValueRisk(message)) if message.contains("expired")
        ));
        assert_eq!(active.state_root().unwrap(), before_expired_payment);

        let downshift = signed_value_risk_update(
            &active,
            &validators,
            &notaries,
            ValueCap::ValueCap0,
            crate::ValueRiskLimits::default(),
            active.height,
            52,
        );
        active.submit_value_risk_policy_update(downshift).unwrap();
        assert_eq!(active.value_risk_policy.current_cap, ValueCap::ValueCap0);
        assert_eq!(
            active.coins[&paid.output_coin_ids[0]].state,
            CoinState::Spendable
        );
    }

    #[test]
    fn cap_zero_rejects_new_service_and_voyage_commitments_before_any_mutation() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let payer = generate_identity();
        let mut ledger = Ledger::genesis_zone(
            "Commitment cap zero",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let zone_id = ledger.descriptor.zone_id.clone();
        let transit = mainnet_capsule_for_test(
            &mut ledger,
            &validators,
            &notaries,
            &payer,
            "zone-voyage-destination",
            "rld:zone-voyage-destination:recipient",
            Amount::from_rld_whole(1).unwrap(),
        );
        let service_coin = seed_mainnet_coin(
            &mut ledger,
            payer.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let voyage_coin = seed_mainnet_coin(
            &mut ledger,
            payer.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let service_budget = Amount::from_rld_whole(2).unwrap();
        let service_description = "cap-zero service";
        let service_payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                payer.address(&zone_id).as_bytes(),
                service_coin.object_id.as_bytes(),
                b"STORAGE",
                &service_budget.0.to_be_bytes(),
                service_description.as_bytes(),
            ],
        );
        let service_authorization = signed_authorization(
            &payer,
            &zone_id,
            "CREATE_SERVICE_ORDER",
            service_payload,
            60,
        );
        let voyage_budget = Amount::from_rld_whole(2).unwrap();
        let hop_limit = Amount::from_rld_whole(1).unwrap();
        let voyage_payload = action_payload_hash(
            "OPEN_VOYAGE_ESCROW",
            &[
                payer.address(&zone_id).as_bytes(),
                voyage_coin.object_id.as_bytes(),
                transit.transit_id.as_bytes(),
                &voyage_budget.0.to_be_bytes(),
                &hop_limit.0.to_be_bytes(),
            ],
        );
        let voyage_authorization =
            signed_authorization(&payer, &zone_id, "OPEN_VOYAGE_ESCROW", voyage_payload, 61);
        let baseline = ledger.state_root().unwrap();

        assert!(matches!(
            ledger.create_service_order(
                payer.address(&zone_id),
                service_coin.object_id.clone(),
                ServiceRole::Storage,
                service_budget,
                service_description.into(),
                service_authorization.clone(),
            ),
            Err(LedgerError::ValueRisk(_))
        ));
        assert!(!ledger
            .authorization_nullifiers
            .contains(&service_authorization.authorization_id));
        assert_eq!(
            ledger.coins[&service_coin.object_id].state,
            CoinState::Spendable
        );
        assert_eq!(ledger.state_root().unwrap(), baseline);

        assert!(matches!(
            ledger.open_voyage_escrow(
                payer.address(&zone_id),
                voyage_coin.object_id.clone(),
                transit.transit_id,
                voyage_budget,
                hop_limit,
                voyage_authorization.clone(),
            ),
            Err(LedgerError::ValueRisk(_))
        ));
        assert!(!ledger
            .authorization_nullifiers
            .contains(&voyage_authorization.authorization_id));
        assert_eq!(
            ledger.coins[&voyage_coin.object_id].state,
            CoinState::Spendable
        );
        assert_eq!(ledger.state_root().unwrap(), baseline);
    }

    #[test]
    fn commitments_count_once_reject_overflow_and_close_after_expiry_and_downshift() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let payer = generate_identity();
        let service_node = generate_identity();
        let mut ledger = Ledger::genesis_zone(
            "Commitment closeout",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let zone_id = ledger.descriptor.zone_id.clone();
        let transit = mainnet_capsule_for_test(
            &mut ledger,
            &validators,
            &notaries,
            &payer,
            "zone-closeout-destination",
            "rld:zone-closeout-destination:recipient",
            Amount::from_rld_whole(1).unwrap(),
        );
        let service_coin = seed_mainnet_coin(
            &mut ledger,
            payer.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let voyage_coin = seed_mainnet_coin(
            &mut ledger,
            payer.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        activate_mainnet_value_policy(
            &mut ledger,
            &validators,
            &notaries,
            crate::ValueRiskLimits {
                max_single_transfer: Amount::from_rld_whole(2).unwrap(),
                max_local_value_total: Amount::from_rld_whole(4).unwrap(),
                max_cross_zone_exposure: Amount::ZERO,
                max_dsc_exposure: Amount::ZERO,
            },
            70,
        );

        let service_budget = Amount::from_rld_whole(2).unwrap();
        let description = "prepaid closeout service";
        let service_payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                payer.address(&zone_id).as_bytes(),
                service_coin.object_id.as_bytes(),
                b"STORAGE",
                &service_budget.0.to_be_bytes(),
                description.as_bytes(),
            ],
        );
        let order = ledger
            .create_service_order(
                payer.address(&zone_id),
                service_coin.object_id,
                ServiceRole::Storage,
                service_budget,
                description.into(),
                signed_authorization(
                    &payer,
                    &zone_id,
                    "CREATE_SERVICE_ORDER",
                    service_payload,
                    71,
                ),
            )
            .unwrap();
        assert_eq!(
            ledger.value_risk_policy.exposure.local_value_total,
            Amount::from_rld_whole(2).unwrap()
        );

        let voyage_budget = Amount::from_rld_whole(2).unwrap();
        let hop_limit = Amount::from_rld_whole(1).unwrap();
        let voyage_payload = action_payload_hash(
            "OPEN_VOYAGE_ESCROW",
            &[
                payer.address(&zone_id).as_bytes(),
                voyage_coin.object_id.as_bytes(),
                transit.transit_id.as_bytes(),
                &voyage_budget.0.to_be_bytes(),
                &hop_limit.0.to_be_bytes(),
            ],
        );
        let voyage = ledger
            .open_voyage_escrow(
                payer.address(&zone_id),
                voyage_coin.object_id,
                transit.transit_id.clone(),
                voyage_budget,
                hop_limit,
                signed_authorization(&payer, &zone_id, "OPEN_VOYAGE_ESCROW", voyage_payload, 72),
            )
            .unwrap();
        let committed_total = Amount::from_rld_whole(4).unwrap();
        assert_eq!(
            ledger.value_risk_policy.exposure.local_value_total,
            committed_total
        );

        let extra_service_coin = seed_mainnet_coin(
            &mut ledger,
            payer.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let extra_voyage_coin = seed_mainnet_coin(
            &mut ledger,
            payer.address(&zone_id),
            Amount::from_rld_whole(10).unwrap(),
        );
        let extra_budget = Amount::from_rld_whole(1).unwrap();
        let extra_service_payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                payer.address(&zone_id).as_bytes(),
                extra_service_coin.object_id.as_bytes(),
                b"OBSERVER",
                &extra_budget.0.to_be_bytes(),
                b"over-limit service",
            ],
        );
        let extra_service_authorization = signed_authorization(
            &payer,
            &zone_id,
            "CREATE_SERVICE_ORDER",
            extra_service_payload,
            73,
        );
        let before_over_limit = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.create_service_order(
                payer.address(&zone_id),
                extra_service_coin.object_id.clone(),
                ServiceRole::Observer,
                extra_budget,
                "over-limit service".into(),
                extra_service_authorization.clone(),
            ),
            Err(LedgerError::ValueRisk(_))
        ));
        assert!(!ledger
            .authorization_nullifiers
            .contains(&extra_service_authorization.authorization_id));
        assert_eq!(ledger.state_root().unwrap(), before_over_limit);

        let extra_voyage_payload = action_payload_hash(
            "OPEN_VOYAGE_ESCROW",
            &[
                payer.address(&zone_id).as_bytes(),
                extra_voyage_coin.object_id.as_bytes(),
                transit.transit_id.as_bytes(),
                &extra_budget.0.to_be_bytes(),
                &extra_budget.0.to_be_bytes(),
            ],
        );
        let extra_voyage_authorization = signed_authorization(
            &payer,
            &zone_id,
            "OPEN_VOYAGE_ESCROW",
            extra_voyage_payload,
            74,
        );
        assert!(matches!(
            ledger.open_voyage_escrow(
                payer.address(&zone_id),
                extra_voyage_coin.object_id,
                transit.transit_id,
                extra_budget,
                extra_budget,
                extra_voyage_authorization.clone(),
            ),
            Err(LedgerError::ValueRisk(_))
        ));
        assert!(!ledger
            .authorization_nullifiers
            .contains(&extra_voyage_authorization.authorization_id));
        assert_eq!(ledger.state_root().unwrap(), before_over_limit);

        while ledger.height < ledger.value_risk_policy.safety_case_valid_until_height {
            ledger.advance().unwrap();
        }
        let hop_proof = "expired-policy-hop-proof";
        let hop_payload = action_payload_hash(
            "SETTLE_VOYAGE_HOP",
            &[
                voyage.voyage_id.as_bytes(),
                service_node.public_key.as_bytes(),
                &hop_limit.0.to_be_bytes(),
                hop_proof.as_bytes(),
            ],
        );
        ledger
            .settle_voyage_hop(
                &voyage.voyage_id,
                service_node.public_key.clone(),
                hop_limit,
                hop_proof.into(),
                signed_authorization(
                    &service_node,
                    &zone_id,
                    "SETTLE_VOYAGE_HOP",
                    hop_payload,
                    75,
                ),
            )
            .unwrap();
        assert_eq!(
            ledger.value_risk_policy.exposure.local_value_total,
            committed_total
        );

        let downshift = signed_value_risk_update(
            &ledger,
            &validators,
            &notaries,
            ValueCap::ValueCap0,
            crate::ValueRiskLimits::default(),
            ledger.height,
            76,
        );
        ledger.submit_value_risk_policy_update(downshift).unwrap();
        let quote = service_budget;
        let lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                order.order_id.as_bytes(),
                service_node.public_key.as_bytes(),
                &quote.0.to_be_bytes(),
            ],
        );
        let lease = ledger
            .lease_service(
                &order.order_id,
                service_node.public_key.clone(),
                quote,
                signed_authorization(&service_node, &zone_id, "LEASE_SERVICE", lease_payload, 77),
            )
            .unwrap();
        let completion_proof = "cap-zero-service-closeout";
        let completion_payload = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                lease.lease_id.as_bytes(),
                service_node.public_key.as_bytes(),
                completion_proof.as_bytes(),
            ],
        );
        ledger
            .complete_service(
                &lease.lease_id,
                completion_proof.into(),
                signed_authorization(
                    &service_node,
                    &zone_id,
                    "COMPLETE_SERVICE",
                    completion_payload,
                    78,
                ),
            )
            .unwrap();
        assert_eq!(ledger.value_risk_policy.current_cap, ValueCap::ValueCap0);
        assert_eq!(
            ledger.value_risk_policy.exposure.local_value_total,
            committed_total
        );
        assert_eq!(
            ledger.balance(&service_node.public_key).unwrap(),
            Amount::from_rld_whole(3).unwrap()
        );
    }

    #[test]
    fn liquidity_offer_reserves_dsc_risk_once_and_settles_after_cap_zero() {
        let validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let provider = generate_identity();
        let recipient = generate_identity();
        let mut destination = Ledger::genesis_zone(
            "Precommitted liquidity",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let destination_zone = destination.descriptor.zone_id.clone();
        let provider_coin = seed_mainnet_coin(
            &mut destination,
            provider.address(&destination_zone),
            Amount::from_rld_whole(10).unwrap(),
        );
        activate_mainnet_value_policy(
            &mut destination,
            &validators,
            &notaries,
            crate::ValueRiskLimits {
                max_single_transfer: Amount::from_rld_whole(2).unwrap(),
                max_local_value_total: Amount::ZERO,
                max_cross_zone_exposure: Amount::ZERO,
                max_dsc_exposure: Amount::from_rld_whole(2).unwrap(),
            },
            80,
        );
        let offer_amount = Amount::from_rld_whole(2).unwrap();
        let take_amount = Amount::from_rld_whole(1).unwrap();
        let expires_at_height = destination.height + 10_000;
        let provider_address = provider.address(&destination_zone);
        let offer_payload = action_payload_hash(
            "CREATE_LIQUIDITY_OFFER",
            &[
                provider_address.as_bytes(),
                provider_coin.object_id.as_bytes(),
                &offer_amount.0.to_be_bytes(),
                &take_amount.0.to_be_bytes(),
                &take_amount.0.to_be_bytes(),
                &expires_at_height.to_be_bytes(),
            ],
        );
        let offer = destination
            .create_liquidity_offer(CreateLiquidityOfferRequest {
                provider: provider_address.clone(),
                coin_id: provider_coin.object_id,
                amount: offer_amount,
                minimum: take_amount,
                maximum: take_amount,
                expires_at_height,
                authorization: signed_authorization(
                    &provider,
                    &destination_zone,
                    "CREATE_LIQUIDITY_OFFER",
                    offer_payload,
                    81,
                ),
            })
            .unwrap();
        assert_eq!(
            destination.value_risk_policy.exposure.dsc_exposure,
            offer_amount
        );

        let source_validators: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let source_notaries: Vec<_> = (0..4).map(|_| generate_identity()).collect();
        let sender = generate_identity();
        let mut source = Ledger::genesis_zone(
            "Liquidity settlement source",
            source_validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            source_notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            false,
        )
        .unwrap();
        let capsule = mainnet_capsule_for_test(
            &mut source,
            &source_validators,
            &source_notaries,
            &sender,
            &destination_zone,
            &recipient.address(&destination_zone),
            take_amount,
        );
        let downshift = signed_value_risk_update(
            &destination,
            &validators,
            &notaries,
            ValueCap::ValueCap0,
            crate::ValueRiskLimits::default(),
            destination.height,
            82,
        );
        destination
            .submit_value_risk_policy_update(downshift)
            .unwrap();

        let mut unmarked = destination.clone();
        unmarked
            .value_risk_policy
            .exposure
            .dsc_commitment_amounts
            .remove(&offer.offer_id);
        let unmarked_root = unmarked.state_root().unwrap();
        assert!(matches!(
            unmarked.take_liquidity_offer(TakeLiquidityOfferRequest {
                offer_id: offer.offer_id.clone(),
                settlement_claim: capsule.clone(),
            }),
            Err(LedgerError::ValueRisk(message)) if message.contains("prepaid DSC commitment")
        ));
        assert_eq!(unmarked.state_root().unwrap(), unmarked_root);

        let certificate = destination
            .take_liquidity_offer(TakeLiquidityOfferRequest {
                offer_id: offer.offer_id,
                settlement_claim: capsule.clone(),
            })
            .unwrap();
        assert_eq!(
            destination.value_risk_policy.exposure.dsc_exposure,
            offer_amount
        );
        assert_eq!(
            destination.coins[&certificate.local_coin_id].state,
            CoinState::Spendable
        );
        destination.import_capsule(capsule).unwrap();
        assert_eq!(
            destination.value_risk_policy.exposure.dsc_exposure,
            take_amount
        );
        assert_eq!(
            destination.value_risk_policy.exposure.cross_zone_exposure,
            take_amount
        );
        assert_eq!(
            destination.balance(&provider_address).unwrap(),
            Amount::from_rld_whole(9).unwrap()
        );
    }

    struct EconomicReleaseFixture {
        ledger: Ledger,
        request: ProtocolReserveReleaseRequest,
        provider: crate::Identity,
        auditor: crate::Identity,
        validators: Vec<crate::Identity>,
        notaries: Vec<crate::Identity>,
        user_receipt_id: String,
    }

    fn economic_release_fixture() -> EconomicReleaseFixture {
        let buyer = generate_identity();
        let provider = generate_identity();
        let auditor = generate_identity();
        let relay = generate_identity();
        let liquidity = generate_identity();
        let price_a = generate_identity();
        let price_b = generate_identity();
        let price_a_alias = generate_identity();
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let mut ledger = Ledger::genesis_zone(
            "Economic release test Zone",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            true,
        )
        .unwrap();
        let zone = ledger.descriptor.zone_id.clone();
        let buyer_address = buyer.address(&zone);
        let provider_address = provider.address(&zone);
        let user_fee = Amount::from_rld_whole(100).unwrap();
        let reward = Amount::from_rld_whole(50).unwrap();
        let (buyer_coin, _) = ledger
            .bootstrap_service_reward(
                "economic-buyer-bootstrap".into(),
                buyer_address.clone(),
                ServiceRole::Observer,
                hash_parts(&[b"economic-buyer-bootstrap-proof"]),
                user_fee,
            )
            .unwrap();
        let (bond_coin, _) = ledger
            .bootstrap_service_reward(
                "economic-provider-bond-bootstrap".into(),
                provider_address.clone(),
                ServiceRole::Observer,
                hash_parts(&[b"economic-provider-bootstrap-proof"]),
                user_fee,
            )
            .unwrap();

        let description = "user-funded economic work".to_owned();
        let create_payload = action_payload_hash(
            "CREATE_SERVICE_ORDER",
            &[
                buyer_address.as_bytes(),
                buyer_coin.object_id.as_bytes(),
                b"OBSERVER",
                &user_fee.0.to_be_bytes(),
                description.as_bytes(),
            ],
        );
        let user_order = ledger
            .create_service_order(
                buyer_address.clone(),
                buyer_coin.object_id,
                ServiceRole::Observer,
                user_fee,
                description,
                signed_authorization(&buyer, &zone, "CREATE_SERVICE_ORDER", create_payload, 1_001),
            )
            .unwrap();
        let lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                user_order.order_id.as_bytes(),
                provider.public_key.as_bytes(),
                &user_fee.0.to_be_bytes(),
            ],
        );
        let user_lease = ledger
            .lease_service(
                &user_order.order_id,
                provider.public_key.clone(),
                user_fee,
                signed_authorization(&provider, &zone, "LEASE_SERVICE", lease_payload, 1_002),
            )
            .unwrap();
        let work_proof_hash = hash_parts(&[b"economic-finalized-work-proof"]);
        let work_id =
            ProtocolReserveReleaseRequest::derive_work_id(&buyer_address, &work_proof_hash);
        let complete_payload = action_payload_hash(
            "COMPLETE_SERVICE",
            &[
                user_lease.lease_id.as_bytes(),
                provider.public_key.as_bytes(),
                work_proof_hash.as_bytes(),
            ],
        );
        let user_receipt = ledger
            .complete_service(
                &user_lease.lease_id,
                work_proof_hash.clone(),
                signed_authorization(
                    &provider,
                    &zone,
                    "COMPLETE_SERVICE",
                    complete_payload,
                    1_003,
                ),
            )
            .unwrap();

        let mut protocol_order_request = simulated_protocol_order_request(
            &ledger,
            "economic-protocol-order",
            ProtocolReservePoolKind::DemandMatching,
            ServiceRole::Observer,
            reward,
            "protocol match for finalized user work",
            Some(user_receipt.receipt_id.clone()),
        );
        protocol_order_request.validator_qc = signed_qc(
            &protocol_order_request.subject_hash,
            &validators,
            required_quorum(validators.len()).unwrap(),
        );
        protocol_order_request.notary_qc = signed_qc(
            &protocol_order_request.subject_hash,
            &notaries,
            required_quorum(notaries.len()).unwrap(),
        );
        let protocol_order = ledger
            .create_protocol_service_order(protocol_order_request)
            .unwrap();
        let protocol_lease_payload = action_payload_hash(
            "LEASE_SERVICE",
            &[
                protocol_order.order_id.as_bytes(),
                provider.public_key.as_bytes(),
                &reward.0.to_be_bytes(),
            ],
        );
        let protocol_lease = ledger
            .lease_service(
                &protocol_order.order_id,
                provider.public_key.clone(),
                reward,
                signed_authorization(
                    &provider,
                    &zone,
                    "LEASE_SERVICE",
                    protocol_lease_payload,
                    1_004,
                ),
            )
            .unwrap();

        let mut members = vec![
            EconomicControlMember {
                subject_id: buyer_address.clone(),
                control_group_id: "ubo-requester".into(),
                role: EconomicControlRole::Requester,
                validator_vote_bps: 0,
            },
            EconomicControlMember {
                subject_id: provider.public_key.clone(),
                control_group_id: "ubo-provider".into(),
                role: EconomicControlRole::ServiceProvider,
                validator_vote_bps: 0,
            },
            EconomicControlMember {
                subject_id: provider_address.clone(),
                control_group_id: "ubo-provider".into(),
                role: EconomicControlRole::ServiceProvider,
                validator_vote_bps: 0,
            },
            EconomicControlMember {
                subject_id: relay.public_key,
                control_group_id: "ubo-relay".into(),
                role: EconomicControlRole::Relay,
                validator_vote_bps: 0,
            },
            EconomicControlMember {
                subject_id: liquidity.public_key,
                control_group_id: "ubo-liquidity".into(),
                role: EconomicControlRole::LiquidityProvider,
                validator_vote_bps: 0,
            },
            EconomicControlMember {
                subject_id: price_a.public_key.clone(),
                control_group_id: "ubo-price-a".into(),
                role: EconomicControlRole::PriceSource,
                validator_vote_bps: 0,
            },
            EconomicControlMember {
                subject_id: price_b.public_key.clone(),
                control_group_id: "ubo-price-b".into(),
                role: EconomicControlRole::PriceSource,
                validator_vote_bps: 0,
            },
            EconomicControlMember {
                subject_id: price_a_alias.public_key.clone(),
                control_group_id: "ubo-price-a".into(),
                role: EconomicControlRole::PriceSource,
                validator_vote_bps: 0,
            },
        ];
        members.extend(validators.iter().enumerate().map(|(index, identity)| {
            EconomicControlMember {
                subject_id: identity.public_key.clone(),
                control_group_id: format!("ubo-validator-{index}"),
                role: EconomicControlRole::Validator,
                validator_vote_bps: 2_500,
            }
        }));
        members.extend(notaries.iter().enumerate().map(|(index, identity)| {
            EconomicControlMember {
                subject_id: identity.public_key.clone(),
                control_group_id: format!("ubo-notary-{index}"),
                role: EconomicControlRole::Notary,
                validator_vote_bps: 0,
            }
        }));
        members.sort_by(|left, right| left.subject_id.cmp(&right.subject_id));
        let mut control = EconomicControlAttestation {
            attestation_id: "economic-control-1".into(),
            zone_id: zone.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            issued_height: ledger.height,
            valid_until_height: ledger.height + 1_000,
            evidence_hash: hash_parts(&[b"independent-ownership-audit"]),
            auditor_public_key: auditor.public_key.clone(),
            auditor_control_group_id: "ubo-independent-auditor".into(),
            members,
            auditor_signature: String::new(),
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        let control_subject = control.subject_hash();
        control.auditor_signature =
            sign_bytes(&auditor.secret_key, control_subject.as_bytes()).unwrap();
        control.validator_qc = signed_qc(
            &control_subject,
            &validators,
            required_quorum(validators.len()).unwrap(),
        );
        control.notary_qc = signed_qc(
            &control_subject,
            &notaries,
            required_quorum(notaries.len()).unwrap(),
        );
        ledger
            .execute_production_command(ProductionCommand::EconomicControlAttestation(control))
            .unwrap();

        for (id, source, group) in [
            ("price-a", &price_a, "ubo-price-a"),
            ("price-b", &price_b, "ubo-price-b"),
            ("price-c-same-ubo-as-a", &price_a_alias, "ubo-price-a"),
        ] {
            let mut price = EconomicPriceAttestation {
                attestation_id: id.into(),
                zone_id: zone.clone(),
                work_id: work_id.clone(),
                control_attestation_id: "economic-control-1".into(),
                source_public_key: source.public_key.clone(),
                source_control_group_id: group.into(),
                amount: reward,
                issued_height: ledger.height,
                valid_until_height: ledger.height + 500,
                evidence_hash: hash_parts(&[b"independent-price-evidence", id.as_bytes()]),
                signature: String::new(),
            };
            price.signature =
                sign_bytes(&source.secret_key, price.subject_hash().as_bytes()).unwrap();
            ledger
                .execute_production_command(ProductionCommand::EconomicPriceAttestation(price))
                .unwrap();
        }

        let mut policy = EconomicReleasePolicy {
            policy_id: "economic-policy-demand-era-1".into(),
            zone_id: zone.clone(),
            protocol_era: ledger.descriptor.protocol_era,
            crypto_era: ledger.descriptor.crypto_era,
            era_id: "economic-era-1".into(),
            reserve_pool: ProtocolReservePoolKind::DemandMatching,
            era_release_cap: user_fee,
            released: Amount::ZERO,
            starts_at_height: 0,
            ends_after_height: ledger.height + 500,
            minimum_bond_coverage_bps: MIN_PROTOCOL_SERVICE_BOND_COVERAGE_BPS,
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        let policy_subject = policy.subject_hash();
        policy.validator_qc = signed_qc(
            &policy_subject,
            &validators,
            required_quorum(validators.len()).unwrap(),
        );
        policy.notary_qc = signed_qc(
            &policy_subject,
            &notaries,
            required_quorum(notaries.len()).unwrap(),
        );
        ledger
            .execute_production_command(ProductionCommand::EconomicReleasePolicy(policy))
            .unwrap();

        let challenge_end_height = ledger.height + 200;
        let unbond_after_height = challenge_end_height + 100;
        let slash_conditions_hash = hash_parts(&[b"economic-service-bond-conditions"]);
        let bond_payload = action_payload_hash(
            "LOCK_PROTOCOL_SERVICE_BOND",
            &[
                b"economic-bond-1",
                protocol_order.order_id.as_bytes(),
                protocol_lease.lease_id.as_bytes(),
                bond_coin.object_id.as_bytes(),
                &user_fee.0.to_be_bytes(),
                &challenge_end_height.to_be_bytes(),
                &unbond_after_height.to_be_bytes(),
                slash_conditions_hash.as_bytes(),
            ],
        );
        ledger
            .execute_production_command(ProductionCommand::ProtocolServiceBondLock(
                ProtocolServiceBondLockRequest {
                    bond_id: "economic-bond-1".into(),
                    order_id: protocol_order.order_id.clone(),
                    lease_id: protocol_lease.lease_id.clone(),
                    owner: provider_address,
                    coin_id: bond_coin.object_id,
                    amount: user_fee,
                    challenge_end_height,
                    unbond_after_height,
                    slash_conditions_hash,
                    authorization: signed_authorization(
                        &provider,
                        &zone,
                        "LOCK_PROTOCOL_SERVICE_BOND",
                        bond_payload,
                        1_005,
                    ),
                },
            ))
            .unwrap();

        let mut request = ProtocolReserveReleaseRequest {
            release_id: "economic-release-1".into(),
            order_id: protocol_order.order_id,
            lease_id: protocol_lease.lease_id,
            requester_subject_id: buyer_address,
            work_id,
            work_proof_hash,
            fee_receipt_ids: vec![user_receipt.receipt_id.clone()],
            control_attestation_id: "economic-control-1".into(),
            price_attestation_ids: vec!["price-a".into(), "price-b".into()],
            bond_id: "economic-bond-1".into(),
            release_policy_id: "economic-policy-demand-era-1".into(),
            reward,
            provider_authorization: signed_authorization(
                &provider,
                &zone,
                "PLACEHOLDER",
                hash_parts(&[b"placeholder"]),
                1_006,
            ),
            completion_validator_qc: simulated_qc(),
            completion_notary_qc: simulated_qc(),
        };
        let completion_subject = request.completion_subject_hash();
        request.provider_authorization = signed_authorization(
            &provider,
            &zone,
            "RELEASE_PROTOCOL_RESERVE",
            action_payload_hash("RELEASE_PROTOCOL_RESERVE", &[completion_subject.as_bytes()]),
            1_006,
        );
        request.completion_validator_qc = signed_qc(
            &completion_subject,
            &validators,
            required_quorum(validators.len()).unwrap(),
        );
        request.completion_notary_qc = signed_qc(
            &completion_subject,
            &notaries,
            required_quorum(notaries.len()).unwrap(),
        );

        EconomicReleaseFixture {
            ledger,
            request,
            provider,
            auditor,
            validators,
            notaries,
            user_receipt_id: user_receipt.receipt_id,
        }
    }

    fn resign_control(
        control: &mut EconomicControlAttestation,
        auditor: &crate::Identity,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
    ) {
        let subject = control.subject_hash();
        control.auditor_signature = sign_bytes(&auditor.secret_key, subject.as_bytes()).unwrap();
        control.validator_qc = signed_qc(
            &subject,
            validators,
            required_quorum(validators.len()).unwrap(),
        );
        control.notary_qc = signed_qc(&subject, notaries, required_quorum(notaries.len()).unwrap());
    }

    #[test]
    fn economic_release_is_persistent_atomic_and_replay_safe() {
        let mut fixture = economic_release_fixture();
        let reserve_before = fixture.ledger.reserve;
        let pool_before = fixture.ledger.reserve_pools.demand_matching;
        let record: ProtocolReserveReleaseRecord = serde_json::from_value(
            fixture
                .ledger
                .execute_production_command(ProductionCommand::ProtocolReserveRelease(Box::new(
                    fixture.request.clone(),
                )))
                .unwrap(),
        )
        .unwrap();
        assert_eq!(
            record.attributable_fee,
            Amount::from_rld_whole(100).unwrap()
        );
        assert_eq!(record.affiliated_recovery, Amount::ZERO);
        assert_eq!(
            record.nonrecoverable_fee,
            Amount::from_rld_whole(100).unwrap()
        );
        assert_eq!(record.reward, Amount::from_rld_whole(50).unwrap());
        assert_eq!(
            fixture.ledger.reserve,
            reserve_before.checked_sub(record.reward).unwrap()
        );
        assert_eq!(
            fixture.ledger.reserve_pools.demand_matching,
            pool_before.checked_sub(record.reward).unwrap()
        );
        assert_eq!(
            fixture.ledger.economic_release_policies["economic-policy-demand-era-1"].released,
            record.reward
        );
        assert!(fixture
            .ledger
            .economic_consumed_fee_receipts
            .contains(&fixture.user_receipt_id));
        fixture.ledger.audit_proof_bundle().unwrap();

        let encoded = serde_json::to_vec(&fixture.ledger).unwrap();
        let mut restarted: Ledger = serde_json::from_slice(&encoded).unwrap();
        let root_before_replay = restarted.state_root().unwrap();
        let height_before_replay = restarted.height;
        assert!(matches!(
            restarted.release_protocol_reserve(fixture.request.clone()),
            Err(LedgerError::Duplicate(_))
        ));
        assert_eq!(restarted.state_root().unwrap(), root_before_replay);
        assert_eq!(restarted.height, height_before_replay);

        let mut cross_pool = fixture.request;
        cross_pool.release_id = "economic-release-cross-pool".into();
        cross_pool.release_policy_id = "pretend-other-pool".into();
        let root_before_cross_pool = restarted.state_root().unwrap();
        assert!(matches!(
            restarted.release_protocol_reserve(cross_pool),
            Err(LedgerError::Duplicate(_))
        ));
        assert_eq!(restarted.state_root().unwrap(), root_before_cross_pool);
    }

    #[test]
    fn economic_release_rejects_split_control_stale_or_same_source_prices_and_fake_fees() {
        let fixture = economic_release_fixture();

        let mut split_ledger = fixture.ledger.clone();
        let mut split = split_ledger.economic_control_attestations["economic-control-1"].clone();
        split.attestation_id = "economic-control-split-ubo".into();
        let validator_subjects = split_ledger.descriptor.validator_keys.clone();
        for member in &mut split.members {
            if validator_subjects
                .iter()
                .take(2)
                .any(|key| key == &member.subject_id)
            {
                member.control_group_id = "ubo-hidden-validator-combine".into();
            }
        }
        resign_control(
            &mut split,
            &fixture.auditor,
            &fixture.validators,
            &fixture.notaries,
        );
        let split_root = split_ledger.state_root().unwrap();
        assert!(matches!(
            split_ledger.register_economic_control_attestation(split),
            Err(LedgerError::Economic(message)) if message.contains("UBO control group")
        ));
        assert_eq!(split_ledger.state_root().unwrap(), split_root);

        let mut same_source = fixture.ledger.clone();
        let mut same_source_request = fixture.request.clone();
        same_source_request.price_attestation_ids =
            vec!["price-a".into(), "price-c-same-ubo-as-a".into()];
        resign_release_request(
            &mut same_source_request,
            &fixture.provider,
            &fixture.validators,
            &fixture.notaries,
            &same_source.descriptor.zone_id,
            2_001,
        );
        let same_source_root = same_source.state_root().unwrap();
        assert!(matches!(
            same_source.release_protocol_reserve(same_source_request),
            Err(LedgerError::Economic(message)) if message.contains("independent price-source")
        ));
        assert_eq!(same_source.state_root().unwrap(), same_source_root);

        let mut stale = fixture.ledger.clone();
        stale
            .economic_price_attestations
            .get_mut("price-a")
            .unwrap()
            .valid_until_height = stale.height;
        let stale_root = stale.state_root().unwrap();
        assert!(matches!(
            stale.release_protocol_reserve(fixture.request.clone()),
            Err(LedgerError::Economic(message)) if message.contains("stale")
        ));
        assert_eq!(stale.state_root().unwrap(), stale_root);

        let mut fake_fee = fixture.ledger;
        let mut fake_request = fixture.request;
        fake_request
            .fee_receipt_ids
            .push("zz-fake-fee-receipt".into());
        resign_release_request(
            &mut fake_request,
            &fixture.provider,
            &fixture.validators,
            &fixture.notaries,
            &fake_fee.descriptor.zone_id,
            2_002,
        );
        let fake_root = fake_fee.state_root().unwrap();
        assert!(matches!(
            fake_fee.release_protocol_reserve(fake_request),
            Err(LedgerError::Economic(message)) if message.contains("fee receipt was not found")
        ));
        assert_eq!(fake_fee.state_root().unwrap(), fake_root);
    }

    fn resign_release_request(
        request: &mut ProtocolReserveReleaseRequest,
        provider: &crate::Identity,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
        zone: &str,
        nonce: u64,
    ) {
        let subject = request.completion_subject_hash();
        request.provider_authorization = signed_authorization(
            provider,
            zone,
            "RELEASE_PROTOCOL_RESERVE",
            action_payload_hash("RELEASE_PROTOCOL_RESERVE", &[subject.as_bytes()]),
            nonce,
        );
        request.completion_validator_qc = signed_qc(
            &subject,
            validators,
            required_quorum(validators.len()).unwrap(),
        );
        request.completion_notary_qc =
            signed_qc(&subject, notaries, required_quorum(notaries.len()).unwrap());
    }

    fn resign_economic_policy(
        policy: &mut EconomicReleasePolicy,
        validators: &[crate::Identity],
        notaries: &[crate::Identity],
    ) {
        let subject = policy.subject_hash();
        policy.validator_qc = signed_qc(
            &subject,
            validators,
            required_quorum(validators.len()).unwrap(),
        );
        policy.notary_qc = signed_qc(&subject, notaries, required_quorum(notaries.len()).unwrap());
    }

    #[test]
    fn economic_release_excludes_bond_from_fee_cap_and_checks_era_arithmetic() {
        let fixture = economic_release_fixture();
        let bond = &fixture.ledger.protocol_service_bonds["economic-bond-1"];
        assert_eq!(bond.locked_amount, Amount::from_rld_whole(100).unwrap());
        assert_eq!(
            fixture.ledger.service_receipts[&fixture.user_receipt_id].amount,
            Amount::from_rld_whole(100).unwrap()
        );

        let mut bond_only = fixture.ledger.clone();
        let mut bond_only_request = fixture.request.clone();
        bond_only_request.fee_receipt_ids.clear();
        resign_release_request(
            &mut bond_only_request,
            &fixture.provider,
            &fixture.validators,
            &fixture.notaries,
            &bond_only.descriptor.zone_id,
            2_500,
        );
        let bond_only_root = bond_only.state_root().unwrap();
        assert!(matches!(
            bond_only.release_protocol_reserve(bond_only_request),
            Err(LedgerError::Economic(message)) if message.contains("incomplete")
        ));
        assert_eq!(bond_only.state_root().unwrap(), bond_only_root);

        let mut era_cap = fixture.ledger.clone();
        let era_policy = era_cap
            .economic_release_policies
            .get_mut("economic-policy-demand-era-1")
            .unwrap();
        era_policy.era_release_cap = Amount::from_rld_whole(49).unwrap();
        resign_economic_policy(era_policy, &fixture.validators, &fixture.notaries);
        let era_root = era_cap.state_root().unwrap();
        assert!(matches!(
            era_cap.release_protocol_reserve(fixture.request.clone()),
            Err(LedgerError::Economic(message)) if message.contains("per-Era")
        ));
        assert_eq!(era_cap.state_root().unwrap(), era_root);

        let mut overflow = fixture.ledger.clone();
        let overflow_policy = overflow
            .economic_release_policies
            .get_mut("economic-policy-demand-era-1")
            .unwrap();
        overflow_policy.released = Amount::from_runlai(u128::MAX);
        overflow_policy.era_release_cap = Amount::from_runlai(u128::MAX);
        resign_economic_policy(overflow_policy, &fixture.validators, &fixture.notaries);
        let overflow_root = overflow.state_root().unwrap();
        assert!(matches!(
            overflow.release_protocol_reserve(fixture.request.clone()),
            Err(LedgerError::Amount(AmountError::Overflow))
        ));
        assert_eq!(overflow.state_root().unwrap(), overflow_root);

        let mut counter_overflow = fixture.ledger;
        counter_overflow.sequence = u64::MAX;
        let counter_root = counter_overflow.state_root().unwrap();
        assert!(matches!(
            counter_overflow.release_protocol_reserve(fixture.request),
            Err(LedgerError::Economic(message)) if message.contains("sequence")
        ));
        assert_eq!(counter_overflow.state_root().unwrap(), counter_root);
    }

    #[test]
    fn protocol_service_bond_is_slashable_and_delayed_before_unbond() {
        let fixture = economic_release_fixture();
        let mut ledger = fixture.ledger;
        let slash_amount = Amount::from_rld_whole(10).unwrap();
        let mut slash = ProtocolServiceBondSlash {
            slash_id: "economic-slash-1".into(),
            bond_id: "economic-bond-1".into(),
            amount: slash_amount,
            evidence_hash: hash_parts(&[b"service-failure-evidence"]),
            validator_qc: simulated_qc(),
            notary_qc: simulated_qc(),
        };
        let subject = slash.subject_hash();
        slash.validator_qc = signed_qc(
            &subject,
            &fixture.validators,
            required_quorum(fixture.validators.len()).unwrap(),
        );
        slash.notary_qc = signed_qc(
            &subject,
            &fixture.notaries,
            required_quorum(fixture.notaries.len()).unwrap(),
        );
        let bond: ProtocolServiceBond = serde_json::from_value(
            ledger
                .execute_production_command(ProductionCommand::ProtocolServiceBondSlash(
                    slash.clone(),
                ))
                .unwrap(),
        )
        .unwrap();
        assert_eq!(bond.slashed_amount, slash_amount);
        assert_eq!(
            bond.slashable_remaining,
            Amount::from_rld_whole(90).unwrap()
        );
        assert_eq!(bond.status, ProtocolServiceBondStatus::PartiallySlashed);
        let replay_root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.slash_protocol_service_bond(slash),
            Err(LedgerError::Duplicate(_))
        ));
        assert_eq!(ledger.state_root().unwrap(), replay_root);
        assert!(matches!(
            ledger.release_protocol_reserve(fixture.request),
            Err(LedgerError::Economic(message)) if message.contains("coverage floor")
        ));

        let unbond_height = ledger.protocol_service_bonds["economic-bond-1"].unbond_after_height;
        ledger.height = unbond_height;
        let remaining = ledger.protocol_service_bonds["economic-bond-1"].slashable_remaining;
        let payload = action_payload_hash(
            "UNBOND_PROTOCOL_SERVICE_BOND",
            &[b"economic-bond-1", &remaining.0.to_be_bytes()],
        );
        let zone = ledger.descriptor.zone_id.clone();
        let bond: ProtocolServiceBond = serde_json::from_value(
            ledger
                .execute_production_command(ProductionCommand::ProtocolServiceBondUnbond {
                    bond_id: "economic-bond-1".into(),
                    authorization: signed_authorization(
                        &fixture.provider,
                        &zone,
                        "UNBOND_PROTOCOL_SERVICE_BOND",
                        payload,
                        3_001,
                    ),
                })
                .unwrap(),
        )
        .unwrap();
        assert_eq!(bond.status, ProtocolServiceBondStatus::Unbonded);
        assert!(bond.escrow_coin_id.is_none());
        assert!(bond.slashable_remaining.is_zero());
        ledger.assert_conservation().unwrap();
    }

    #[test]
    fn legacy_protocol_completion_is_fail_closed_on_mainnet() {
        let provider = generate_identity();
        let mut ledger =
            Ledger::genesis_zone("Mainnet legacy release gate", vec![], vec![], false).unwrap();
        let root = ledger.state_root().unwrap();
        let authorization = signed_authorization(
            &provider,
            &ledger.descriptor.zone_id,
            "COMPLETE_SERVICE",
            hash_parts(&[b"legacy-mainnet-completion"]),
            9_001,
        );
        assert!(matches!(
            ledger.complete_protocol_service(
                "missing-lease",
                hash_parts(&[b"legacy-mainnet-work"]),
                authorization,
                simulated_qc(),
                simulated_qc(),
            ),
            Err(LedgerError::Invalid(message)) if message.contains("EconomicReleaseEvidence")
        ));
        assert_eq!(ledger.state_root().unwrap(), root);
    }

    #[test]
    fn empty_resource_extension_preserves_pre_r617_state_roots() {
        let ledger =
            Ledger::genesis_zone("Resource root compatibility", vec![], vec![], true).unwrap();
        let expected = ledger.state_root().unwrap();
        let mut legacy: serde_json::Value = serde_json::to_value(&ledger).unwrap();
        let object = legacy.as_object_mut().unwrap();
        object.remove("stake_resource_policy_proposals");
        object.remove("stake_resource_policy_activations");
        object.remove("pending_stake_resource_policy");
        object.remove("stake_resource_accounting");
        let restored: Ledger = serde_json::from_value(legacy).unwrap();
        assert_eq!(restored.state_root().unwrap(), expected);
        restored.assert_conservation().unwrap();
    }

    #[test]
    fn resource_policy_governance_is_delayed_rooted_auditable_and_replayable() {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let mut ledger = Ledger::genesis_zone(
            "Resource policy governance",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            true,
        )
        .unwrap();
        let runtime_validator_keys = ledger.descriptor.validator_keys.clone();
        let legacy_root = ledger.state_root().unwrap();
        let policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 2);
        let request = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "resource-policy-proposal-1",
            policy.clone(),
            2,
            10,
        );
        let proposal_commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::ProposeStakeStateResourcePolicy(Box::new(request.clone())),
        );
        assert_eq!(
            ledger
                .apply_consensus_commit(proposal_commit.clone())
                .unwrap(),
            ConsensusOutcome::StakeStateResourcePolicyProposal(Box::new(request.clone()))
        );
        assert_ne!(ledger.state_root().unwrap(), legacy_root);
        assert_eq!(ledger.descriptor.validator_keys, runtime_validator_keys);
        assert_eq!(
            ledger
                .apply_consensus_commit(proposal_commit.clone())
                .unwrap(),
            ConsensusOutcome::StakeStateResourcePolicyProposal(Box::new(request.clone()))
        );

        let early = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "resource-policy-activation-early",
        );
        let before_early = serde_json::to_vec(&ledger).unwrap();
        assert!(matches!(
            ledger.activate_stake_state_resource_policy(early),
            Err(LedgerError::StakeResource(message)) if message.contains("delayed pending")
        ));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), before_early);

        ledger.advance().unwrap();
        assert_eq!(ledger.height, 2);
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "resource-policy-activation-1",
        );
        let activation_commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::ActivateStakeStateResourcePolicy(Box::new(activation.clone())),
        );
        assert_eq!(
            ledger
                .apply_consensus_commit(activation_commit.clone())
                .unwrap(),
            ConsensusOutcome::StakeStateResourcePolicy(policy.clone())
        );
        assert_eq!(
            ledger.apply_consensus_commit(proposal_commit).unwrap(),
            ConsensusOutcome::StakeStateResourcePolicyProposal(Box::new(request))
        );
        assert_eq!(
            ledger.apply_consensus_commit(activation_commit).unwrap(),
            ConsensusOutcome::StakeStateResourcePolicy(policy)
        );
        assert!(ledger.pending_stake_resource_policy.is_none());
        assert_eq!(ledger.stake_resource_policy_proposals.len(), 1);
        assert_eq!(ledger.stake_resource_policy_activations.len(), 1);
        assert_eq!(ledger.descriptor.validator_keys, runtime_validator_keys);

        let first_commitment = ledger
            .stake_resource_accounting
            .as_ref()
            .unwrap()
            .active_policy_commitment()
            .to_owned();
        let successor = stake_resource_policy(2, first_commitment, 2);
        let successor_proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "resource-policy-proposal-2",
            successor.clone(),
            5,
            20,
        );
        ledger
            .propose_stake_state_resource_policy(successor_proposal)
            .unwrap();
        ledger.advance().unwrap();
        let successor_activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "resource-policy-activation-2",
        );
        ledger
            .activate_stake_state_resource_policy(successor_activation)
            .unwrap();
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        assert_eq!(accounting.active_policy(), &successor);
        assert_eq!(accounting.maintenance_pool().policy_buckets.len(), 2);
        assert!(!accounting.has_accounted_value());
        assert!(ledger.supply_certificate().unwrap().valid);
        assert!(ledger.supply_buckets().unwrap().fee_pools.is_zero());

        let encoded = serde_json::to_vec(&ledger).unwrap();
        let restored: Ledger = serde_json::from_slice(&encoded).unwrap();
        assert_eq!(restored.state_root().unwrap(), ledger.state_root().unwrap());
        restored.assert_conservation().unwrap();
        let bundle = ledger.audit_proof_bundle().unwrap();
        bundle.verify_structure().unwrap();
        assert_eq!(bundle.stake_resource_policy_proposals.len(), 2);
        assert_eq!(bundle.stake_resource_policy_activations.len(), 2);
    }

    #[test]
    fn resource_policy_forgery_quorum_and_value_cap_fail_atomically() {
        let validators = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        let ledger = Ledger::genesis_zone(
            "Resource policy rejection",
            validators
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            notaries
                .iter()
                .map(|identity| identity.public_key.clone())
                .collect(),
            true,
        )
        .unwrap();
        let policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 2);

        let mut forged = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "resource-policy-forged",
            policy.clone(),
            2,
            10,
        );
        forged.expected_current_policy_commitment = "11".repeat(32);
        forged.proposed_policy.previous_policy_commitment = "11".repeat(32);
        forged.proposed_policy_commitment =
            stake_state_resource_policy_commitment_v1(&forged.proposed_policy).unwrap();
        forged.subject_hash = forged.compute_subject_hash();
        forged.validator_qc = resource_policy_qc(&forged.subject_hash, &validators);
        forged.notary_qc = resource_policy_qc(&forged.subject_hash, &notaries);
        let mut forged_ledger = ledger.clone();
        let before = serde_json::to_vec(&forged_ledger).unwrap();
        assert!(forged_ledger
            .propose_stake_state_resource_policy(forged)
            .is_err());
        assert_eq!(serde_json::to_vec(&forged_ledger).unwrap(), before);

        let mut insufficient = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "resource-policy-insufficient",
            policy.clone(),
            2,
            10,
        );
        insufficient.notary_qc = signed_qc(&insufficient.subject_hash, &notaries, 2);
        let mut insufficient_ledger = ledger.clone();
        let before = serde_json::to_vec(&insufficient_ledger).unwrap();
        assert!(insufficient_ledger
            .propose_stake_state_resource_policy(insufficient)
            .is_err());
        assert_eq!(serde_json::to_vec(&insufficient_ledger).unwrap(), before);

        let mut value_enabled = ledger;
        value_enabled.value_risk_policy.current_cap = ValueCap::ValueCap1;
        let blocked = resource_policy_proposal(
            &value_enabled,
            &validators,
            &notaries,
            "resource-policy-value-cap",
            policy,
            2,
            10,
        );
        let before = serde_json::to_vec(&value_enabled).unwrap();
        assert!(matches!(
            value_enabled.propose_stake_state_resource_policy(blocked),
            Err(LedgerError::ValueRisk(_))
        ));
        assert_eq!(serde_json::to_vec(&value_enabled).unwrap(), before);
    }

    #[test]
    fn resource_bound_candidate_registration_is_atomic_metered_and_replayable() {
        let (mut ledger, validators, _notaries, _owner, _candidate, _sponsor, request) =
            resource_bound_registration_fixture();
        let runtime_keys = ledger.descriptor.validator_keys.clone();
        let funding = ledger.coins[&request.resource_envelope.funding_coin_id].clone();
        let wire_bytes = ConsensusCommand::RegisterConsensusValidatorV2(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap()
            .len();
        let persistent_bytes = register_consensus_validator_persistent_bytes_v2(&request).unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire_bytes.try_into().unwrap(),
            persistent_bytes,
            signature_checks: REGISTER_CONSENSUS_VALIDATOR_SIGNATURE_CHECKS_V2,
            state_reads: REGISTER_CONSENSUS_VALIDATOR_STATE_READS_V2,
            state_writes: REGISTER_CONSENSUS_VALIDATOR_STATE_WRITES_V2,
        };
        let expected_quote = ledger
            .stake_resource_accounting
            .as_ref()
            .unwrap()
            .quote(StakeStateResourceKindV1::Candidate, usage)
            .unwrap();
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::RegisterConsensusValidatorV2(Box::new(request.clone())),
        );
        let expected_height = commit.proposal.expected_height;
        let consensus_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::StakeCandidateResourceRegistration(outcome) = &consensus_outcome
        else {
            panic!("resource-bound registration returned the wrong outcome");
        };
        assert_eq!(outcome.candidate.validator_id, request.validator_id);
        assert_eq!(
            outcome.candidate.registered_height,
            u128::from(expected_height)
        );
        assert_eq!((outcome.charged_fee, outcome.locked_bond), expected_quote);
        assert_eq!(
            outcome.resource_key,
            format!("CANDIDATE/{}", request.validator_id)
        );
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);
        assert_eq!(ledger.coins[&funding.object_id].state, CoinState::Consumed);
        let bond_coin = &ledger.coins[&outcome.bond_coin_id];
        assert_eq!(bond_coin.state, CoinState::Reserved);
        assert_eq!(bond_coin.amount, outcome.locked_bond);
        assert_eq!(
            bond_coin.parent_ids,
            std::slice::from_ref(&funding.object_id)
        );
        let change = ledger
            .coins
            .values()
            .find(|coin| {
                coin.parent_ids == [funding.object_id.clone()]
                    && coin.object_id != outcome.bond_coin_id
            })
            .unwrap();
        assert_eq!(change.state, CoinState::Spendable);
        assert_eq!(
            change.amount,
            funding
                .amount
                .checked_sub(outcome.charged_fee)
                .unwrap()
                .checked_sub(outcome.locked_bond)
                .unwrap()
        );
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        let record = &accounting.bonds()[&outcome.resource_key];
        assert_eq!(
            record.initial_record_hash(),
            outcome.initial_bond_record_hash
        );
        assert_eq!(record.charged_wire_bytes, usage.wire_bytes);
        assert_eq!(record.charged_persistent_bytes, persistent_bytes);
        assert_eq!(record.charged_signature_checks, 3);
        assert_eq!(record.charged_state_reads, 8);
        assert_eq!(record.charged_state_writes, 10);
        assert_eq!(accounting.total_persistent_bytes(), persistent_bytes);
        assert_eq!(accounting.block_meter().height, expected_height);
        assert_eq!(
            accounting.maintenance_pool().total_charged_fees,
            outcome.charged_fee
        );
        assert_eq!(
            accounting.maintenance_pool().total_live_bonds,
            outcome.locked_bond
        );
        assert!(accounting.has_accounted_value());
        assert!(ledger
            .authorization_nullifiers
            .contains(&request.authorization.authorization_id));
        assert!(ledger
            .authorization_nullifiers
            .contains(&request.resource_envelope.authorization.authorization_id));
        assert!(ledger.supply_certificate().unwrap().valid);
        ledger.assert_conservation().unwrap();
        ledger
            .audit_proof_bundle()
            .unwrap()
            .verify_structure()
            .unwrap();

        let encoded = serde_json::to_vec(&ledger).unwrap();
        let mut restored: Ledger = serde_json::from_slice(&encoded).unwrap();
        assert_eq!(restored.state_root().unwrap(), ledger.state_root().unwrap());
        let replay_root = restored.state_root().unwrap();
        assert_eq!(
            restored.apply_consensus_commit(commit).unwrap(),
            consensus_outcome
        );
        assert_eq!(restored.state_root().unwrap(), replay_root);
    }

    #[test]
    fn resource_bound_candidate_rejects_forgery_reuse_and_sponsor_limits_atomically() {
        let (ledger, _validators, _notaries, owner, _candidate, sponsor, request) =
            resource_bound_registration_fixture();

        let mut wrong_subject_ledger = ledger.clone();
        let mut wrong_subject = request.clone();
        wrong_subject.resource_envelope.resource_subject_hash = "55".repeat(32);
        wrong_subject.authorization = signed_authorization(
            &owner,
            &wrong_subject_ledger.descriptor.zone_id,
            REGISTER_CONSENSUS_VALIDATOR_ACTION_V2,
            wrong_subject.payload_hash(),
            9_200,
        );
        let before = serde_json::to_vec(&wrong_subject_ledger).unwrap();
        assert!(matches!(
            wrong_subject_ledger.register_consensus_validator_v2(wrong_subject),
            Err(LedgerError::StakeResource(message)) if message.contains("subject hash")
        ));
        assert_eq!(serde_json::to_vec(&wrong_subject_ledger).unwrap(), before);

        let mut reused_ledger = ledger.clone();
        reused_ledger.authorization_nullifiers.insert(
            request
                .resource_envelope
                .authorization
                .authorization_id
                .clone(),
        );
        let before = serde_json::to_vec(&reused_ledger).unwrap();
        assert!(matches!(
            reused_ledger.register_consensus_validator_v2(request.clone()),
            Err(LedgerError::Duplicate(_))
        ));
        assert_eq!(serde_json::to_vec(&reused_ledger).unwrap(), before);

        let mut capped_ledger = ledger.clone();
        let mut capped = request.clone();
        capped.resource_envelope.max_resource_fee = Amount::ZERO;
        resign_resource_bound_registration(
            &capped_ledger,
            &owner,
            &sponsor,
            &mut capped,
            9_300,
            9_301,
        );
        let before = serde_json::to_vec(&capped_ledger).unwrap();
        assert!(matches!(
            capped_ledger.register_consensus_validator_v2(capped),
            Err(LedgerError::StakeResource(message)) if message.contains("exceeds sponsor maximum")
        ));
        assert_eq!(serde_json::to_vec(&capped_ledger).unwrap(), before);

        let mut no_policy = ledger;
        no_policy.stake_resource_accounting = None;
        let before = serde_json::to_vec(&no_policy).unwrap();
        assert!(matches!(
            no_policy.register_consensus_validator_v2(request),
            Err(LedgerError::StakeResource(message)) if message.contains("no active")
        ));
        assert_eq!(serde_json::to_vec(&no_policy).unwrap(), before);
    }

    #[test]
    fn active_resource_policy_blocks_new_legacy_registration_but_replays_old_commit() {
        let (mut ledger, validators, _owner, _candidate, request) =
            consensus_validator_registration_fixture();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        ledger.descriptor.notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::RegisterConsensusValidator(Box::new(request.clone())),
        );
        let historical = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "legacy-gate-resource-proposal",
            policy,
            ledger.height + 1,
            ledger.height + 20,
        );
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "legacy-gate-resource-activation",
        );
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();
        let root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.register_consensus_validator(request),
            Err(LedgerError::StakeResource(message)) if message.contains("use V2")
        ));
        assert_eq!(ledger.state_root().unwrap(), root);
        assert_eq!(ledger.apply_consensus_commit(commit).unwrap(), historical);
        assert_eq!(ledger.state_root().unwrap(), root);
    }

    #[test]
    fn resource_bound_stake_v3_is_atomic_metered_and_replayable() {
        let (mut ledger, validators, _owner, _sponsor, request) = resource_bound_stake_fixture();
        let runtime_keys = ledger.descriptor.validator_keys.clone();
        let authority_before = ledger.consensus_stake_authority.clone().unwrap();
        let source = ledger.coins[&request.source_coin_id].clone();
        let funding = ledger.coins[&request.resource_envelope.funding_coin_id].clone();
        let wire_bytes = ConsensusCommand::LockConsensusStakeV3(Box::new(request.clone()))
            .wire_v1_command_bytes(&ledger.descriptor.network_domain)
            .unwrap()
            .len();
        let persistent_bytes = lock_consensus_stake_persistent_bytes_v3(&request).unwrap();
        let usage = StakeStateResourceUsageV1 {
            wire_bytes: wire_bytes.try_into().unwrap(),
            persistent_bytes,
            signature_checks: LOCK_CONSENSUS_STAKE_SIGNATURE_CHECKS_V3,
            state_reads: LOCK_CONSENSUS_STAKE_STATE_READS_V3,
            state_writes: LOCK_CONSENSUS_STAKE_STATE_WRITES_V3,
        };
        let quote = ledger
            .stake_resource_accounting
            .as_ref()
            .unwrap()
            .quote(StakeStateResourceKindV1::Position, usage)
            .unwrap();
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::LockConsensusStakeV3(Box::new(request.clone())),
        );
        let expected_height = commit.proposal.expected_height;
        let consensus_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::ConsensusStakeResourceLock(outcome) = &consensus_outcome else {
            panic!("resource-bound stake returned the wrong outcome");
        };
        assert_eq!(outcome.position.position_id, request.position_id);
        assert_eq!(outcome.position.locked_height, u128::from(expected_height));
        assert_eq!((outcome.charged_fee, outcome.locked_bond), quote);
        assert_eq!(
            outcome.resource_key,
            format!("POSITION/{}", request.position_id)
        );
        assert_eq!(ledger.descriptor.validator_keys, runtime_keys);
        assert_eq!(ledger.coins[&source.object_id].state, CoinState::Consumed);
        assert_eq!(ledger.coins[&funding.object_id].state, CoinState::Consumed);
        let escrow = &ledger.coins[&outcome.position.escrow_coin_id];
        assert_eq!(escrow.state, CoinState::Reserved);
        assert_eq!(escrow.amount, request.amount);
        assert_eq!(escrow.parent_ids, std::slice::from_ref(&source.object_id));
        let record =
            &ledger.stake_resource_accounting.as_ref().unwrap().bonds()[&outcome.resource_key];
        assert_eq!(record.charged_persistent_bytes, persistent_bytes);
        assert_eq!(record.charged_signature_checks, 3);
        assert_eq!(record.charged_state_reads, 12);
        assert_eq!(record.charged_state_writes, 14);
        assert_eq!(
            record.initial_record_hash(),
            outcome.initial_bond_record_hash
        );
        assert_eq!(
            ledger
                .consensus_stake_authority
                .as_ref()
                .unwrap()
                .positions
                .len(),
            authority_before.positions.len() + 1
        );
        for authorization_id in [
            &request.authorization.authorization_id,
            &request.slash_terms_authorization.authorization_id,
            &request.resource_envelope.authorization.authorization_id,
        ] {
            assert!(ledger.authorization_nullifiers.contains(authorization_id));
        }
        ledger.assert_conservation().unwrap();
        ledger
            .audit_proof_bundle()
            .unwrap()
            .verify_structure()
            .unwrap();
        let encoded = serde_json::to_vec(&ledger).unwrap();
        let mut restored: Ledger = serde_json::from_slice(&encoded).unwrap();
        let replay_root = restored.state_root().unwrap();
        assert_eq!(
            restored.apply_consensus_commit(commit).unwrap(),
            consensus_outcome
        );
        assert_eq!(restored.state_root().unwrap(), replay_root);
    }

    #[test]
    fn resource_bound_stake_v3_rejects_alias_forgery_and_sponsor_cap_atomically() {
        let (ledger, _validators, owner, sponsor, request) = resource_bound_stake_fixture();

        let mut aliased_ledger = ledger.clone();
        let mut aliased = request.clone();
        aliased.resource_envelope.funding_coin_id = aliased.source_coin_id.clone();
        let before = serde_json::to_vec(&aliased_ledger).unwrap();
        assert!(matches!(
            aliased_ledger.lock_consensus_stake_v3(aliased),
            Err(LedgerError::StakeResource(message)) if message.contains("distinct Coins")
        ));
        assert_eq!(serde_json::to_vec(&aliased_ledger).unwrap(), before);

        let mut forged_ledger = ledger.clone();
        let mut forged = request.clone();
        forged.resource_envelope.resource_subject_hash = "55".repeat(32);
        let before = serde_json::to_vec(&forged_ledger).unwrap();
        assert!(matches!(
            forged_ledger.lock_consensus_stake_v3(forged),
            Err(LedgerError::StakeResource(message)) if message.contains("subject hash")
        ));
        assert_eq!(serde_json::to_vec(&forged_ledger).unwrap(), before);

        let mut capped_ledger = ledger.clone();
        let mut capped = request.clone();
        capped.resource_envelope.max_state_bond = Amount::ZERO;
        resign_resource_bound_stake(&capped_ledger, &owner, &sponsor, &mut capped, 9_600, 9_601);
        let before = serde_json::to_vec(&capped_ledger).unwrap();
        assert!(matches!(
            capped_ledger.lock_consensus_stake_v3(capped),
            Err(LedgerError::StakeResource(message)) if message.contains("exceeds sponsor maximum")
        ));
        assert_eq!(serde_json::to_vec(&capped_ledger).unwrap(), before);

        let mut unmetered_ledger = ledger;
        let unmetered = LockConsensusStakeRequestV2 {
            position_id: request.position_id,
            zone_id: request.zone_id,
            currency_genesis_root: request.currency_genesis_root,
            protocol_era: request.protocol_era,
            crypto_era: request.crypto_era,
            proposed_height: request.proposed_height,
            expires_at_height: request.expires_at_height,
            expected_authority_sequence: request.expected_authority_sequence,
            expected_authority_commitment: request.expected_authority_commitment,
            position_type: request.position_type,
            validator_id: request.validator_id,
            owner: request.owner,
            source_coin_id: request.source_coin_id,
            amount: request.amount,
            committed_through_height: request.committed_through_height,
            slash_terms_authorization: request.slash_terms_authorization,
            authorization: request.authorization,
        };
        let before = serde_json::to_vec(&unmetered_ledger).unwrap();
        assert!(matches!(
            unmetered_ledger.lock_consensus_stake_v2(unmetered),
            Err(LedgerError::StakeResource(message)) if message.contains("use V3")
        ));
        assert_eq!(serde_json::to_vec(&unmetered_ledger).unwrap(), before);
    }

    #[test]
    fn bounded_legacy_position_resource_migration_is_exact_and_replayable() {
        let (mut ledger, validators, _owner, _sponsor, request) =
            resource_position_migration_fixture();
        let authority_before = ledger.consensus_stake_authority.clone().unwrap();
        let escrows_before = ledger.consensus_stake_escrows.clone();
        let funding = ledger.coins[&request.resource_envelope.funding_coin_id].clone();
        let position = escrows_before[&request.escrow_coin_id].clone();
        let persistent_bytes =
            migrate_consensus_stake_resource_persistent_bytes_v1(&request, &position).unwrap();
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::MigrateConsensusStakeResource(Box::new(request.clone())),
        );
        let consensus_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::ConsensusStakeResourceMigration(outcome) = &consensus_outcome else {
            panic!("resource migration returned the wrong outcome");
        };
        assert_eq!(outcome.position, position);
        assert_eq!(ledger.consensus_stake_authority, Some(authority_before));
        assert_eq!(ledger.consensus_stake_escrows, escrows_before);
        assert_eq!(ledger.coins[&funding.object_id].state, CoinState::Consumed);
        let record =
            &ledger.stake_resource_accounting.as_ref().unwrap().bonds()[&outcome.resource_key];
        assert_eq!(record.charged_persistent_bytes, persistent_bytes);
        assert_eq!(record.charged_signature_checks, 2);
        assert_eq!(record.charged_state_reads, 10);
        assert_eq!(record.charged_state_writes, 9);
        assert_eq!(
            record.initial_record_hash(),
            outcome.initial_bond_record_hash
        );
        ledger.assert_conservation().unwrap();
        let mut restored: Ledger =
            serde_json::from_slice(&serde_json::to_vec(&ledger).unwrap()).unwrap();
        let replay_root = restored.state_root().unwrap();
        assert_eq!(
            restored.apply_consensus_commit(commit).unwrap(),
            consensus_outcome
        );
        assert_eq!(restored.state_root().unwrap(), replay_root);

        let (base, _validators, owner, sponsor, mut forged) = resource_position_migration_fixture();
        forged.expected_position_commitment = "77".repeat(32);
        let exact_position = base.consensus_stake_escrows[&forged.escrow_coin_id].clone();
        resign_resource_migration(
            &base,
            &owner,
            &sponsor,
            &exact_position,
            &mut forged,
            9_700,
            9_701,
        );
        let mut forged_ledger = base;
        let before = serde_json::to_vec(&forged_ledger).unwrap();
        assert!(matches!(
            forged_ledger.migrate_consensus_stake_resource(forged),
            Err(LedgerError::Invalid(message)) if message.contains("exact slashable position")
        ));
        assert_eq!(serde_json::to_vec(&forged_ledger).unwrap(), before);
    }

    #[test]
    fn bounded_legacy_candidate_resource_migration_is_exact_and_replayable() {
        let (mut ledger, validators, _owner, _sponsor, request) =
            resource_candidate_migration_fixture();
        let authority_before = ledger.consensus_stake_authority.clone().unwrap();
        let runtime_before = ledger.descriptor.validator_keys.clone();
        let candidate = authority_before.candidates[0].clone();
        let persistent_bytes =
            migrate_consensus_candidate_resource_persistent_bytes_v1(&request, &candidate).unwrap();
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::MigrateConsensusCandidateResource(Box::new(request.clone())),
        );
        let consensus_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::ConsensusCandidateResourceMigration(outcome) = &consensus_outcome
        else {
            panic!("candidate migration returned the wrong outcome");
        };
        assert_eq!(outcome.candidate, candidate);
        assert_eq!(ledger.consensus_stake_authority, Some(authority_before));
        assert_eq!(ledger.descriptor.validator_keys, runtime_before);
        let record =
            &ledger.stake_resource_accounting.as_ref().unwrap().bonds()[&outcome.resource_key];
        assert_eq!(record.charged_persistent_bytes, persistent_bytes);
        assert_eq!(record.charged_signature_checks, 2);
        assert_eq!(record.charged_state_reads, 8);
        assert_eq!(record.charged_state_writes, 9);
        assert_eq!(
            record.initial_record_hash(),
            outcome.initial_bond_record_hash
        );
        ledger.assert_conservation().unwrap();
        ledger
            .audit_proof_bundle()
            .unwrap()
            .verify_structure()
            .unwrap();
        let mut restored: Ledger =
            serde_json::from_slice(&serde_json::to_vec(&ledger).unwrap()).unwrap();
        let replay_root = restored.state_root().unwrap();
        assert_eq!(
            restored.apply_consensus_commit(commit).unwrap(),
            consensus_outcome
        );
        assert_eq!(restored.state_root().unwrap(), replay_root);

        let (base, _validators, owner, sponsor, mut forged) =
            resource_candidate_migration_fixture();
        let exact = base.consensus_stake_authority.as_ref().unwrap().candidates[0].clone();
        forged.expected_candidate_commitment = "77".repeat(32);
        resign_candidate_resource_migration(
            &base,
            &owner,
            &sponsor,
            &exact,
            &mut forged,
            9_810,
            9_811,
        );
        let mut forged_ledger = base;
        let before = serde_json::to_vec(&forged_ledger).unwrap();
        assert!(matches!(
            forged_ledger.migrate_consensus_candidate_resource(forged),
            Err(LedgerError::Invalid(message)) if message.contains("exact retained candidate")
        ));
        assert_eq!(serde_json::to_vec(&forged_ledger).unwrap(), before);
    }

    #[test]
    fn resource_bond_renewal_is_narrow_atomic_metered_and_replayable() {
        let (mut ledger, validators, _sponsor, request) = resource_bond_renewal_fixture();
        let original = ledger.stake_resource_accounting.as_ref().unwrap().bonds()
            [&request.resource_key]
            .clone();
        let candidate_before = ledger.consensus_stake_authority.clone();
        let pool_before = ledger
            .stake_resource_accounting
            .as_ref()
            .unwrap()
            .maintenance_pool()
            .clone();
        let height_before = ledger.height;
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::RenewStakeStateResourceBond(Box::new(request.clone())),
        );
        let consensus_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::StakeStateResourceBondRenewal(outcome) = &consensus_outcome else {
            panic!("renewal returned the wrong outcome");
        };
        assert_eq!(ledger.height, height_before + 1);
        assert_eq!(ledger.consensus_stake_authority, candidate_before);
        let accounting = ledger.stake_resource_accounting.as_ref().unwrap();
        assert_eq!(accounting.bonds()[&request.resource_key], original);
        assert_eq!(accounting.renewals().len(), 1);
        let record = &accounting.renewals()[&request.renewal_id];
        assert_eq!(
            record.previous_renewal_hash,
            crate::stake_resource_accounting::ZERO_SHA256
        );
        assert_eq!(record.previous_lease_end_height, original.lease_end_height);
        assert_eq!(record.new_lease_end_height, request.new_lease_end_height);
        assert_eq!(record.renewed_height, height_before + 1);
        assert_eq!(record.charged_signature_checks, 1);
        assert_eq!(record.charged_state_reads, 7);
        assert_eq!(record.charged_state_writes, 9);
        assert_eq!(
            record.charged_persistent_bytes,
            renew_stake_state_resource_bond_persistent_bytes_v1(&request).unwrap()
        );
        assert_eq!(
            accounting.effective_lease_end_height(&request.resource_key),
            Some(request.new_lease_end_height)
        );
        assert_eq!(
            ledger.coins[&request.funding_coin_id].state,
            CoinState::Consumed
        );
        assert_eq!(
            ledger.coins[&outcome.bond_coin_id].state,
            CoinState::Reserved
        );
        assert_eq!(
            ledger.coins[&outcome.bond_coin_id].amount,
            outcome.additional_bond
        );
        assert_eq!(
            accounting.maintenance_pool().total_charged_fees,
            pool_before
                .total_charged_fees
                .checked_add(outcome.charged_fee)
                .unwrap()
        );
        assert_eq!(
            accounting.maintenance_pool().total_live_bonds,
            pool_before
                .total_live_bonds
                .checked_add(outcome.additional_bond)
                .unwrap()
        );
        assert_eq!(
            accounting.maintenance_pool().active_bond_records,
            pool_before.active_bond_records
        );
        assert!(ledger
            .authorization_nullifiers
            .contains(&request.authorization.authorization_id));
        let first_hash = record.record_hash.clone();
        let first_lease = record.new_lease_end_height;
        let funded = Amount(1_000_000);
        ledger.reserve = ledger.reserve.checked_sub(funded).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(funded)
            .unwrap();
        let second_funding = CoinObject {
            object_id: "stake-resource-renewal-funding-0002".into(),
            lineage_root: hash_parts(&[b"RLD-TEST-STAKE-RESOURCE-RENEWAL-LINEAGE-2"]),
            parent_ids: Vec::new(),
            owner: request.sponsor.clone(),
            zone_id: ledger.descriptor.zone_id.clone(),
            amount: funded,
            state: CoinState::Spendable,
            version: 1,
            created_height: ledger.height,
            transit_id: None,
            imported_from: None,
            origin_zone: ledger.descriptor.zone_id.clone(),
            origin_genesis_root: ledger.descriptor.currency_genesis_root.clone(),
        };
        ledger
            .coins
            .insert(second_funding.object_id.clone(), second_funding.clone());
        let mut second = request.clone();
        second.renewal_id = "stake-resource-renewal-0002".into();
        second.proposed_height = ledger.height;
        second.expires_at_height = ledger.height + 20;
        second.expected_previous_renewal_hash = first_hash.clone();
        second.expected_current_lease_end_height = first_lease;
        second.new_lease_end_height = first_lease + 100;
        second.funding_coin_id = second_funding.object_id.clone();
        resign_resource_bond_renewal(&ledger, &_sponsor, &mut second, 10_110);
        let second_outcome = ledger
            .renew_stake_state_resource_bond(second.clone())
            .unwrap();
        assert_eq!(second_outcome.previous_renewal_hash, first_hash);
        assert_eq!(
            ledger
                .stake_resource_accounting
                .as_ref()
                .unwrap()
                .effective_lease_end_height(&request.resource_key),
            Some(second.new_lease_end_height)
        );

        let fork_funded = Amount(1_000_000);
        ledger.reserve = ledger.reserve.checked_sub(fork_funded).unwrap();
        ledger.reserve_pools.demand_matching = ledger
            .reserve_pools
            .demand_matching
            .checked_sub(fork_funded)
            .unwrap();
        let mut fork_coin = second_funding;
        fork_coin.object_id = "stake-resource-renewal-funding-fork".into();
        fork_coin.lineage_root = hash_parts(&[b"RLD-TEST-STAKE-RESOURCE-RENEWAL-FORK"]);
        fork_coin.created_height = ledger.height;
        ledger
            .coins
            .insert(fork_coin.object_id.clone(), fork_coin.clone());
        let mut fork = second;
        fork.renewal_id = "stake-resource-renewal-fork".into();
        fork.proposed_height = ledger.height;
        fork.expires_at_height = ledger.height + 20;
        fork.funding_coin_id = fork_coin.object_id;
        resign_resource_bond_renewal(&ledger, &_sponsor, &mut fork, 10_111);
        let before_fork = serde_json::to_vec(&ledger).unwrap();
        assert!(matches!(
            ledger.renew_stake_state_resource_bond(fork),
            Err(LedgerError::StakeResource(message)) if message.contains("predecessor")
        ));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), before_fork);
        ledger.assert_conservation().unwrap();
        ledger
            .audit_proof_bundle()
            .unwrap()
            .verify_structure()
            .unwrap();
        let replay_root = ledger.state_root().unwrap();
        assert_eq!(
            ledger.apply_consensus_commit(commit).unwrap(),
            consensus_outcome
        );
        assert_eq!(ledger.state_root().unwrap(), replay_root);
    }

    #[test]
    fn resource_bond_renewal_rejects_rewrite_stale_chain_alias_and_caps_atomically() {
        let (ledger, _validators, sponsor, request) = resource_bond_renewal_fixture();
        let cases: Vec<(&str, RenewStakeStateResourceBondRequestV1)> = {
            let mut same_lease = request.clone();
            same_lease.new_lease_end_height = same_lease.expected_current_lease_end_height;
            resign_resource_bond_renewal(&ledger, &sponsor, &mut same_lease, 10_101);

            let mut owner_rewrite = request.clone();
            owner_rewrite.resource_owner = "rld:forged-owner".into();
            resign_resource_bond_renewal(&ledger, &sponsor, &mut owner_rewrite, 10_102);

            let mut stale = request.clone();
            stale.expected_previous_renewal_hash = "77".repeat(32);
            resign_resource_bond_renewal(&ledger, &sponsor, &mut stale, 10_103);

            let mut wrong_kind = request.clone();
            wrong_kind.resource_kind = StakeStateResourceKindV1::Position;
            resign_resource_bond_renewal(&ledger, &sponsor, &mut wrong_kind, 10_106);

            let mut signer_mismatch = request.clone();
            signer_mismatch.sponsor = "rld:forged-sponsor".into();
            resign_resource_bond_renewal(&ledger, &sponsor, &mut signer_mismatch, 10_107);

            let mut capped = request.clone();
            capped.max_additional_bond = Amount::ZERO;
            resign_resource_bond_renewal(&ledger, &sponsor, &mut capped, 10_104);

            let mut alias = request.clone();
            alias.funding_coin_id = ledger.stake_resource_accounting.as_ref().unwrap().bonds()
                [&request.resource_key]
                .bond_coin_id
                .clone();
            resign_resource_bond_renewal(&ledger, &sponsor, &mut alias, 10_105);
            vec![
                ("same lease", same_lease),
                ("owner rewrite", owner_rewrite),
                ("stale chain", stale),
                ("wrong kind", wrong_kind),
                ("sponsor signer mismatch", signer_mismatch),
                ("bond cap", capped),
                ("bond Coin alias", alias),
            ]
        };
        for (label, forged) in cases {
            let mut attempt = ledger.clone();
            let before = serde_json::to_vec(&attempt).unwrap();
            assert!(
                attempt.renew_stake_state_resource_bond(forged).is_err(),
                "{label}"
            );
            assert_eq!(serde_json::to_vec(&attempt).unwrap(), before, "{label}");
        }

        let mut underfunded_ledger = ledger.clone();
        underfunded_ledger
            .coins
            .get_mut(&request.funding_coin_id)
            .unwrap()
            .amount = Amount(1);
        let before = serde_json::to_vec(&underfunded_ledger).unwrap();
        assert!(matches!(
            underfunded_ledger.renew_stake_state_resource_bond(request.clone()),
            Err(LedgerError::StakeResource(message)) if message.contains("below fee")
        ));
        assert_eq!(serde_json::to_vec(&underfunded_ledger).unwrap(), before);

        let mut unknown_usage = serde_json::to_value(&request).unwrap();
        unknown_usage
            .as_object_mut()
            .unwrap()
            .insert("usage".into(), serde_json::json!({"persistent_bytes": 1}));
        assert!(
            serde_json::from_value::<RenewStakeStateResourceBondRequestV1>(unknown_usage).is_err()
        );

        let mut capped_ledger = ledger;
        capped_ledger.value_risk_policy.current_cap = ValueCap::ValueCap1;
        let before = serde_json::to_vec(&capped_ledger).unwrap();
        assert!(matches!(
            capped_ledger.renew_stake_state_resource_bond(request),
            Err(LedgerError::ValueRisk(message)) if message.contains("VALUE_CAP_0")
        ));
        assert_eq!(serde_json::to_vec(&capped_ledger).unwrap(), before);
    }

    #[test]
    fn resource_bound_epoch_is_dependency_funded_atomic_and_replayable() {
        let (mut ledger, validators, _payer, _sponsor, request, preview) =
            resource_bound_epoch_fixture();
        let runtime_before = ledger.descriptor.validator_keys.clone();
        let (next_horizons, next_horizon_history) = ledger
            .preview_stake_liability_horizon_update(&preview)
            .unwrap();
        let horizon_usage = stake_liability_horizon_usage_delta_v1(
            &ledger.stake_position_liability_horizons,
            &ledger.stake_position_liability_horizon_history,
            &next_horizons,
            &next_horizon_history,
        )
        .unwrap();
        let persistent_bytes =
            derive_next_stake_epoch_persistent_bytes_v2(&request, &preview, horizon_usage).unwrap();
        let state_reads = derive_next_stake_epoch_state_reads_v2(&preview, horizon_usage).unwrap();
        let state_writes = derive_next_stake_epoch_state_writes_v2(horizon_usage).unwrap();
        let funding = ledger.coins[&request.resource_envelope.funding_coin_id].clone();
        let legacy = DeriveNextStakeEpochRequestV1 {
            request_id: "legacy-epoch-after-resource-policy".into(),
            zone_id: request.zone_id.clone(),
            currency_genesis_root: request.currency_genesis_root.clone(),
            protocol_era: request.protocol_era,
            crypto_era: request.crypto_era,
            proposed_height: request.proposed_height,
            expires_at_height: request.expires_at_height,
            expected_authority_sequence: request.expected_authority_sequence,
            expected_authority_commitment: request.expected_authority_commitment.clone(),
            expected_consensus_epoch: request.expected_consensus_epoch,
            expected_snapshot_height: request.expected_snapshot_height,
            expected_snapshot_state_root: request.expected_snapshot_state_root.clone(),
        };
        let legacy_before = serde_json::to_vec(&ledger).unwrap();
        assert!(matches!(
            ledger.derive_next_stake_epoch(legacy),
            Err(LedgerError::StakeResource(message)) if message.contains("use V2")
        ));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), legacy_before);
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::DeriveNextStakeEpochV2(Box::new(request.clone())),
        );
        let consensus_outcome = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let ConsensusOutcome::DerivedStakeEpochResource(outcome) = &consensus_outcome else {
            panic!("resource-bound Epoch returned the wrong outcome");
        };
        assert_eq!(outcome.epoch, preview);
        assert_eq!(ledger.descriptor.validator_keys, runtime_before);
        assert_eq!(ledger.coins[&funding.object_id].state, CoinState::Consumed);
        let record =
            &ledger.stake_resource_accounting.as_ref().unwrap().bonds()[&outcome.resource_key];
        assert_eq!(record.resource_kind, StakeStateResourceKindV1::Epoch);
        assert_eq!(record.charged_persistent_bytes, persistent_bytes);
        assert_eq!(record.charged_signature_checks, 2);
        assert_eq!(record.charged_state_reads, state_reads);
        assert_eq!(record.charged_state_writes, state_writes);
        assert_eq!(
            ledger.stake_liability_horizon_activation_epoch,
            Some(preview.descriptor.consensus_epoch)
        );
        assert_eq!(
            horizon_usage.appended_records as usize,
            preview.stake_liabilities.len()
        );
        assert_eq!(
            ledger.stake_position_liability_horizons.len(),
            preview.stake_liabilities.len()
        );
        assert_eq!(
            record.initial_record_hash(),
            outcome.initial_bond_record_hash
        );
        for validator in &preview.descriptor.validators {
            assert!(ledger
                .stake_resource_accounting
                .as_ref()
                .unwrap()
                .bonds()
                .contains_key(&format!("CANDIDATE/{}", validator.validator_id)));
        }
        for liability in &preview.stake_liabilities {
            assert!(ledger
                .stake_resource_accounting
                .as_ref()
                .unwrap()
                .bonds()
                .contains_key(&format!("POSITION/{}", liability.position.position_id)));
        }
        ledger.assert_conservation().unwrap();
        let audit = ledger.audit_proof_bundle().unwrap();
        assert_eq!(
            audit.stake_position_liability_horizons,
            ledger.stake_position_liability_horizons
        );
        assert_eq!(
            audit.stake_liability_horizon_activation_epoch,
            ledger.stake_liability_horizon_activation_epoch
        );
        audit.verify_structure().unwrap();
        let mut tampered = ledger.clone();
        tampered
            .stake_position_liability_horizons
            .values_mut()
            .next()
            .unwrap()
            .retained_liability_count += 1;
        assert!(matches!(
            tampered.assert_conservation(),
            Err(LedgerError::Invalid(message)) if message.contains("liability horizons")
        ));
        let mut restored: Ledger =
            serde_json::from_slice(&serde_json::to_vec(&ledger).unwrap()).unwrap();
        let replay_root = restored.state_root().unwrap();
        assert_eq!(
            restored.apply_consensus_commit(commit).unwrap(),
            consensus_outcome
        );
        assert_eq!(restored.state_root().unwrap(), replay_root);
    }

    #[test]
    fn resource_bound_epoch_rejects_short_lease_forged_output_and_sponsor_cap_atomically() {
        let (ledger, _validators, payer, sponsor, request, preview) =
            resource_bound_epoch_fixture();

        let mut short_ledger = ledger.clone();
        let mut short = request.clone();
        let required_end = u64::try_from(
            preview.descriptor.exit_height
                + short_ledger
                    .consensus_stake_authority
                    .as_ref()
                    .unwrap()
                    .policy
                    .evidence_window_blocks,
        )
        .unwrap()
            + short_ledger
                .stake_resource_accounting
                .as_ref()
                .unwrap()
                .active_policy()
                .terminal_retention_blocks;
        short.resource_envelope.lease_end_height = required_end - 1;
        resign_epoch_resource_derivation(
            &short_ledger,
            &payer,
            &sponsor,
            &preview,
            &mut short,
            12_100,
            12_101,
        );
        let before = serde_json::to_vec(&short_ledger).unwrap();
        assert!(matches!(
            short_ledger.derive_next_stake_epoch_v2(short),
            Err(LedgerError::StakeResource(message)) if message.contains("does not cover")
        ));
        assert_eq!(serde_json::to_vec(&short_ledger).unwrap(), before);

        let mut dependency_ledger = ledger.clone();
        let dependency_key = format!(
            "CANDIDATE/{}",
            preview.descriptor.validators[0].validator_id
        );
        dependency_ledger
            .stake_resource_accounting
            .as_mut()
            .unwrap()
            .mark_releaseable(
                &dependency_key,
                &hash_parts(&[b"RLD-TEST-TERMINAL-CANDIDATE-RESOURCE"]),
                0,
                0,
                100,
            )
            .unwrap();
        let mut dependency_preview_ledger = dependency_ledger.clone();
        let dependency_preview = dependency_preview_ledger
            .derive_and_store_next_stake_epoch()
            .unwrap();
        let mut dependency_request = request.clone();
        dependency_request.expected_snapshot_state_root = dependency_ledger.state_root().unwrap();
        dependency_request.expected_derived_record_hash = dependency_preview.record_hash.clone();
        resign_epoch_resource_derivation(
            &dependency_ledger,
            &payer,
            &sponsor,
            &dependency_preview,
            &mut dependency_request,
            12_150,
            12_151,
        );
        let before = serde_json::to_vec(&dependency_ledger).unwrap();
        assert!(matches!(
            dependency_ledger.derive_next_stake_epoch_v2(dependency_request),
            Err(LedgerError::StakeResource(message)) if message.contains("candidate resource bond is ineligible")
        ));
        assert_eq!(serde_json::to_vec(&dependency_ledger).unwrap(), before);

        let mut forged_ledger = ledger.clone();
        let mut forged = request.clone();
        forged.expected_derived_record_hash = "77".repeat(32);
        resign_epoch_resource_derivation(
            &forged_ledger,
            &payer,
            &sponsor,
            &preview,
            &mut forged,
            12_200,
            12_201,
        );
        let before = serde_json::to_vec(&forged_ledger).unwrap();
        assert!(matches!(
            forged_ledger.derive_next_stake_epoch_v2(forged),
            Err(LedgerError::Invalid(message)) if message.contains("exact output commitment")
        ));
        assert_eq!(serde_json::to_vec(&forged_ledger).unwrap(), before);

        let mut capped_ledger = ledger;
        let mut capped = request;
        capped.resource_envelope.max_resource_fee = Amount::ZERO;
        resign_epoch_resource_derivation(
            &capped_ledger,
            &payer,
            &sponsor,
            &preview,
            &mut capped,
            12_300,
            12_301,
        );
        let before = serde_json::to_vec(&capped_ledger).unwrap();
        assert!(matches!(
            capped_ledger.derive_next_stake_epoch_v2(capped),
            Err(LedgerError::StakeResource(message)) if message.contains("exceeds sponsor maximum")
        ));
        assert_eq!(serde_json::to_vec(&capped_ledger).unwrap(), before);
    }

    #[test]
    fn active_resource_policy_blocks_unmetered_stake_but_replays_old_v2_commit() {
        let (mut ledger, validators, owner, v1) = consensus_stake_lock_fixture();
        let request = v2_lock_request_from_v1(&ledger, &owner, v1, 9_800);
        let commit = certified_command(
            &ledger,
            &validators,
            ConsensusCommand::LockConsensusStakeV2(Box::new(request.clone())),
        );
        let historical = ledger.apply_consensus_commit(commit.clone()).unwrap();
        let notaries = (0..4).map(|_| generate_identity()).collect::<Vec<_>>();
        ledger.descriptor.notary_keys = notaries
            .iter()
            .map(|identity| identity.public_key.clone())
            .collect();
        let mut policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        policy.maximum_total_stake_state_bytes = 1_000_000;
        policy.maximum_stake_state_bytes_per_block = 100_000;
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "legacy-position-freeze-proposal",
            policy,
            ledger.height + 1,
            ledger.height + 20,
        );
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(
            &ledger,
            &validators,
            &notaries,
            "legacy-position-freeze-activation",
        );
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();
        let root = ledger.state_root().unwrap();
        assert!(matches!(
            ledger.lock_consensus_stake_v2(request),
            Err(LedgerError::StakeResource(message)) if message.contains("use V3")
        ));
        assert_eq!(ledger.state_root().unwrap(), root);
        assert_eq!(ledger.apply_consensus_commit(commit).unwrap(), historical);
        assert_eq!(ledger.state_root().unwrap(), root);
    }

    #[test]
    fn resource_policy_cannot_undercut_retained_stake_inventory() {
        let (mut ledger, validators, notaries, _candidates, authority_update) =
            stake_authority_governance_fixture();
        ledger
            .submit_stake_authority_update(authority_update)
            .unwrap();
        let policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        assert!(
            ledger
                .consensus_stake_authority
                .as_ref()
                .unwrap()
                .candidates
                .len()
                > policy.maximum_active_candidates as usize
        );
        let proposal = resource_policy_proposal(
            &ledger,
            &validators,
            &notaries,
            "undercut-retained-stake",
            policy,
            ledger.height + 1,
            ledger.height + 20,
        );
        let before = serde_json::to_vec(&ledger).unwrap();
        assert!(matches!(
            ledger.propose_stake_state_resource_policy(proposal),
            Err(LedgerError::StakeResource(message)) if message.contains("below retained state")
        ));
        assert_eq!(serde_json::to_vec(&ledger).unwrap(), before);
    }

    #[test]
    fn era_transition_retires_only_value_empty_resource_policy_state() {
        let mut ledger =
            Ledger::genesis_zone("Resource era boundary", vec![], vec![], true).unwrap();
        let policy =
            stake_resource_policy(1, crate::stake_resource_accounting::ZERO_SHA256.into(), 1);
        let proposal =
            resource_policy_proposal(&ledger, &[], &[], "resource-era-proposal", policy, 1, 10);
        ledger
            .propose_stake_state_resource_policy(proposal)
            .unwrap();
        let activation = resource_policy_activation(&ledger, &[], &[], "resource-era-activation");
        ledger
            .activate_stake_state_resource_policy(activation)
            .unwrap();
        assert!(!ledger
            .stake_resource_accounting
            .as_ref()
            .unwrap()
            .has_accounted_value());
        let suite = CryptoSuiteDescriptor {
            suite_id: "resource-era-suite-2".into(),
            signature_algorithm: "Ed25519".into(),
            hash_algorithm: "SHA-256".into(),
            encoding: "RLD-WIRE-V1".into(),
        };
        let mut injected_value = serde_json::to_value(&ledger).unwrap();
        injected_value["stake_resource_accounting"]["maintenance_pool"]["total_charged_fees"] =
            serde_json::json!("1");
        let mut value_bearing: Ledger = serde_json::from_value(injected_value).unwrap();
        let before = serde_json::to_vec(&value_bearing).unwrap();
        assert!(matches!(
            value_bearing.activate_testnet_era(suite.clone()),
            Err(LedgerError::EraTransition(message)) if message.contains("carries value")
        ));
        assert_eq!(serde_json::to_vec(&value_bearing).unwrap(), before);
        ledger.activate_testnet_era(suite).unwrap();
        assert!(ledger.pending_stake_resource_policy.is_none());
        assert!(ledger.stake_resource_accounting.is_none());
        assert_eq!(ledger.stake_resource_policy_proposals.len(), 1);
        assert_eq!(ledger.stake_resource_policy_activations.len(), 1);
        ledger.assert_conservation().unwrap();
        ledger
            .audit_proof_bundle()
            .unwrap()
            .verify_structure()
            .unwrap();
    }
}
