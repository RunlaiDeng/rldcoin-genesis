//! Typed public consensus carriage. The mesh never supplies validator rights.
//! Standalone proof verification precedes catch-up or any new local signature.
use super::*;
use crate::{bft, storage::Store};

pub const FORMAT: &str = "RLD-REGIONAL-BFT-NETWORK-V2";
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub enum Body {
    Signed(Box<bft::Message>),
    Finalized(Box<Snapshot>),
    Submission(Vec<Command>),
    EpochApproval(Box<crate::joint_epoch::CarriedApproval>),
    EpochActivation(Box<epoch::Transition>),
    EpochSigned {
        message: Box<bft::Message>,
        epochs: Vec<epoch::Transition>,
    },
    EpochSubmission {
        commands: Vec<Command>,
        epochs: Vec<epoch::Transition>,
    },
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Envelope {
    pub format: String,
    pub currency: Hash,
    pub region: Hash,
    pub evidence: Evidence,
    pub body: Body,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WireEnvelope {
    pub format: String,
    pub currency: Hash,
    pub region: Hash,
    pub evidence: crate::carriage::CarriedEvidence,
    pub body: Body,
}
impl WireEnvelope {
    pub fn expand(self) -> Result<Envelope> {
        require(self.format == FORMAT, "consensus wire format mismatch")?;
        Ok(Envelope {
            format: self.format,
            currency: self.currency,
            region: self.region,
            evidence: self.evidence.expand()?,
            body: self.body,
        })
    }
}
impl Envelope {
    pub fn pack(&self) -> Result<WireEnvelope> {
        require(self.format == FORMAT, "consensus wire format mismatch")?;
        Ok(WireEnvelope {
            format: self.format.clone(),
            currency: self.currency,
            region: self.region,
            evidence: crate::carriage::CarriedEvidence::pack(&self.evidence)?,
            body: self.body.clone(),
        })
    }
    pub fn carried_epochs(&self) -> &[epoch::Transition] {
        match &self.body {
            Body::EpochSigned { epochs, .. } | Body::EpochSubmission { epochs, .. } => epochs,
            _ => &[],
        }
    }
    pub fn value(&self) -> Result<Option<Hash>> {
        match &self.body {
            Body::Signed(message) | Body::EpochSigned { message, .. } => match message.as_ref() {
                bft::Message::Proposal(p) => Ok(Some(p.snapshot.statement.id()?)),
                bft::Message::Vote(v) => Ok(Some(v.value)),
                bft::Message::Timeout(_) => Ok(None),
                bft::Message::EpochApproval { .. } => Ok(None),
            },
            Body::Finalized(s) => Ok(Some(s.statement.id()?)),
            Body::Submission(_) | Body::EpochSubmission { .. } | Body::EpochApproval(_) => Ok(None),
            Body::EpochActivation(proof) => Ok(Some(proof.statement.id()?)),
        }
    }
    pub fn verify(&self, node: &Store) -> Result<Hash> {
        require(
            self.format == FORMAT
                && self.currency == node.trust.currency()?
                && self.region == node.chain.region
                && bft::is_profile(&node.trust.region(self.region)?.rules),
            "consensus envelope domain/profile mismatch",
        )?;
        let mut evidence = VerifiedEvidence::verify(&self.evidence, &node.trust)?;
        if matches!(
            self.body,
            Body::EpochSigned { .. } | Body::EpochSubmission { .. }
        ) {
            require(
                node.trust.region(self.region)?.rules == bft::JOINT_RULES,
                "scoped epoch body requires joint profile",
            )?;
        }
        require(
            self.carried_epochs().len() <= epoch::MAX_EPOCHS,
            "consensus carried epoch bound",
        )?;
        for proof in self.carried_epochs() {
            require(
                proof.statement.region == self.region,
                "carried epoch foreign region",
            )?;
            evidence.install_epoch(proof.clone(), &node.trust)?;
        }
        match &self.body {
            Body::EpochApproval(vote) => {
                require(
                    vote.proposal.statement.region == self.region
                        && vote.proposal.statement.currency == self.currency,
                    "joint approval envelope domain",
                )?;
                vote.verify(&node.trust, &evidence)?;
            }
            Body::EpochActivation(proof) => {
                require(
                    node.trust.region(self.region)?.rules == bft::JOINT_RULES
                        && proof.statement.region == self.region
                        && proof.statement.currency == self.currency,
                    "joint activation envelope profile/domain",
                )?;
                let mut verified = evidence.clone();
                verified.install_epoch((**proof).clone(), &node.trust)?;
            }
            Body::Signed(message) | Body::EpochSigned { message, .. } => {
                let c = match message.as_ref() {
                    bft::Message::Proposal(p) => {
                        p.verify(&node.trust, &evidence)?;
                        p.context()?
                    }
                    bft::Message::Vote(v) => {
                        v.verify(&v.context.keys(&node.trust, &evidence)?)?;
                        v.context.clone()
                    }
                    bft::Message::Timeout(t) => {
                        t.verify(&t.context.keys(&node.trust, &evidence)?)?;
                        t.context.clone()
                    }
                    bft::Message::EpochApproval { .. } => {
                        return Err("epoch approvals require an explicit complete activation certificate, not ordinary consensus carriage".into());
                    }
                };
                require(
                    c.currency == self.currency && c.region == self.region,
                    "consensus message differs from envelope domain",
                )?;
                // Even votes bind an independently certified native parent.
                if let Some(previous) = c.previous {
                    let parent = evidence.snapshot(previous)?;
                    require(
                        parent.statement.region == c.region
                            && parent.statement.height == c.parent_height
                            && parent.statement.block == c.parent_block
                            && parent.statement.state == c.parent_state,
                        "consensus message omits or changes certified parent",
                    )?;
                } else {
                    require(
                        c.parent_height == 0
                            && c.parent_block == c.region
                            && c.parent_state == Ledger::default().root()?,
                        "consensus message changes native genesis parent",
                    )?;
                }
            }
            Body::Finalized(snapshot) => {
                require(
                    snapshot.statement.region == self.region,
                    "foreign finality message",
                )?;
                let mut verified = evidence.clone();
                verified.add((**snapshot).clone(), &node.trust)?;
            }
            Body::Submission(commands) | Body::EpochSubmission { commands, .. } => {
                require(
                    !commands.is_empty() && commands.len() <= 4,
                    "submission command bound",
                )?;
                let local = self
                    .evidence
                    .snapshots
                    .iter()
                    .filter(|s| s.statement.region == self.region)
                    .max_by_key(|s| s.statement.height);
                let mut chain = Chain::new(self.region, &node.trust)?;
                if let Some(s) = local {
                    chain = evidence.replay_extension(s, &node.trust)?;
                    chain.install(s.statement.id()?, &evidence)?;
                    if node.trust.region(self.region)?.rules == bft::JOINT_RULES {
                        chain.epoch =
                            crate::joint_epoch::next_epoch(&chain, &node.trust, &evidence)?;
                    }
                }
                // Validate real signed commands against the supplied certified
                // parent. Receiving a submission neither signs nor debits.
                chain.template(
                    commands.clone(),
                    node.trust.region(self.region)?.validators[0].clone(),
                    &node.trust,
                    &evidence,
                )?;
            }
        }
        id("bft-network-envelope-v2", self)
    }
}

pub fn sync(node: &mut Store, evidence: Evidence) -> Result<()> {
    bft::Context::current(node)?;
    VerifiedEvidence::verify(&evidence, &node.trust)?;
    node.add_evidence(evidence)?;
    let mut snapshots = node
        .journal
        .evidence
        .snapshots
        .iter()
        .filter(|s| s.statement.region == node.chain.region)
        .cloned()
        .collect::<Vec<_>>();
    snapshots.sort_by_key(|s| s.statement.height);
    for snapshot in snapshots {
        if snapshot.statement.height > node.chain.height() {
            // Every step remains an atomic next-block/finality native commit.
            install_carried_epochs(node, &snapshot)?;
            node.finalize(snapshot)?;
        }
    }
    Ok(())
}

fn install_carried_epochs(node: &mut Store, snapshot: &Snapshot) -> Result<()> {
    for proof in &snapshot.epochs {
        if node.chain.epoch == proof.statement.previous_epoch
            && node.chain.height() == proof.statement.closing_height
        {
            node.install_epoch(proof.clone())?;
        }
    }
    Ok(())
}

pub fn activate(node: &mut Store, proof: epoch::Transition, evidence: Evidence) -> Result<Hash> {
    require(
        node.trust.region(node.chain.region)?.rules == bft::JOINT_RULES
            && proof.statement.region == node.chain.region,
        "joint activation wrong profile/region",
    )?;
    let mut checked = VerifiedEvidence::verify(&evidence, &node.trust)?;
    let eid = checked.install_epoch(proof.clone(), &node.trust)?;
    sync(node, evidence)?;
    if !node
        .journal
        .epoch_proofs
        .iter()
        .any(|p| p.statement.id().ok() == Some(eid))
    {
        node.install_epoch(proof)?;
    }
    Ok(eid)
}
