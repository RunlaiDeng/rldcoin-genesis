#!/usr/bin/env python3
"""Contact companion launched by the native fixture node; Rust owns value checks.

Directory contacts are a bounded ground adapter. Discovered self-signed regions
are routing candidates only, never ledger, signer or monetary authority.
"""
import argparse
import base64
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time

import interstellar_mesh as mesh
import interstellar_tcp as tcp
import interstellar_transfer as wire

FORMAT = 'RLD-REGIONAL-CONTACT-NODE-V1'
MAX_PER_TICK = 4
MAX_NATIVE_OUTPUT = 8 * 1024 * 1024


class Native:
    def __init__(self, binary, ledger, authority, currency):
        self.binary = Path(binary)
        mesh.require(self.binary.is_absolute() and self.binary.is_file() and not self.binary.is_symlink(), 'native binary must be an absolute regular file')
        self.ledger = Path(ledger)
        self.authority = mesh.hex32(authority)
        self.currency = mesh.hex32(currency)
        mesh.require(self.ledger.is_absolute(), 'ledger directory must be absolute')

    def call(self, *args, private_input=None):
        mesh.require(private_input is None or isinstance(private_input,(bytes,bytearray)) and len(private_input)<=1024,
            'private native input outside bound')
        # Native outputs are bounded by the candidate's journal/frame limits.
        # File-backed capture also bounds memory if a broken executable floods.
        with tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as errors:
            result = subprocess.run([str(self.binary), '--dir', str(self.ledger),
                '--authority', self.authority, '--currency', self.currency, *map(str, args)],
                input=private_input, stdout=output, stderr=errors, timeout=30, check=False)
            mesh.require(output.tell() <= MAX_NATIVE_OUTPUT and errors.tell() <= 64 * 1024, 'native response outside bound')
            errors.seek(0)
            mesh.require(result.returncode == 0, 'native rejected: ' + errors.read(2048).decode('utf-8', errors='replace').strip())
            output.seek(0)
            return wire.decode_json(output.read(MAX_NATIVE_OUTPUT + 1))

    def apply(self, raw, miner):
        # The mesh retains the complete frame throughout. A temporary native
        # input is disposable; native proof/pending records persist separately.
        with tempfile.NamedTemporaryFile(prefix='rld-regional-contact-', suffix='.json') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
            args = ['contact-apply', '--file', handle.name]
            if miner is not None:
                args.extend(['--miner', miner])
            return self.call(*args)


def startup_config(native, path=None):
    """Restore one persistent relay identity, after native authority validation.

    An empty contact set means waiting for a real contact, never an invented
    reachable peer. Default initialization is serialized across startup races.
    """
    observation = native.call('contact-status')
    mesh.require(observation['currency'] == native.currency, 'startup currency mismatch')
    if path is not None:
        return mesh.load(path, 64 * 1024)
    root = mesh.safe_dir(native.ledger / 'transport')
    descriptor = os.open(root / '.startup.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        path = root / 'config.json'
        if path.exists() or path.is_symlink():
            return mesh.load(path, 64 * 1024)
        identity = root / 'identity.private.json'
        if not identity.exists() and not identity.is_symlink():
            mesh.initialize(root, native.currency, observation['region'], 'regional-node')
        config = {'format': mesh.VERSION, 'state': str(root),
            'network': native.currency, 'contacts': []}
        # Validate recovered identity before exposing configuration, including
        # the crash window after identity creation but before config commit.
        with mesh.Node(config) as node:
            mesh.require(node.state['adverts'][node.id]['body']['region'] == observation['region'],
                'default relay identity differs from native ledger')
        mesh.atomic(path, config)
        return config
    finally:
        os.close(descriptor)


class Service:
    def __init__(self, native, config, miner, listen=('127.0.0.1',0), insecure_tcp=False, bft_config=None):
        self.native, self.config, self.miner = native, config, miner
        self.lock = None
        self.tcp = None
        self.bft = None
        self.bft_seen = set()
        self.root = mesh.safe_dir(config['state'])
        try:
            self.lock = os.open(self.root / '.regional-contact-service.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            observation = native.call('contact-status')
            self.region = observation['region']
            mesh.require(observation['currency'] == native.currency and config['network'] == native.currency,
                'native/transport currency network binding mismatch')
            self.path = self.root / 'regional-contact-progress.json'
            if self.path.exists():
                self.progress = mesh.load(self.path, 8192)
                mesh.require(set(self.progress) == {'format', 'currency', 'region', 'cursor'}
                    and self.progress['format'] == FORMAT and self.progress['currency'] == native.currency
                    and self.progress['region'] == self.region, 'contact progress identity mismatch')
                mesh.integer(self.progress['cursor'], 0, 2**63-1)
            else:
                self.progress = {'format': FORMAT, 'currency': native.currency, 'region': self.region, 'cursor': 0}
            with mesh.Node(config) as node:
                mesh.require(node.state['adverts'][node.id]['body']['region'] == self.region,
                    'local mesh label differs from native ledger identity')
            mesh.atomic(self.path, self.progress)
            self.tcp = tcp.Server(config,listen,insecure=insecure_tcp)
            if bft_config is not None:
                mesh.require(miner is None, 'BFT validator cannot use uncertified import mining')
                from regional_bft_node import Runtime
                self.bft = Runtime(native,config,bft_config)
        except BaseException:
            self.close()
            raise

    def close(self):
        if self.bft is not None:
            self.bft.close()
            self.bft = None
        if self.tcp is not None:
            self.tcp.close()
            self.tcp = None
        if self.lock is not None:
            os.close(self.lock)
            self.lock = None

    def receive_candidates(self, summaries, receipts, destination):
        eligible = sorted(i for i, t in summaries.items()
            if t['destination'] == destination and i in receipts
            and i not in self.bft_seen)
        if not eligible:
            return []
        if self.bft is not None:
            # Cold startup authenticated the retained complete envelopes. Their
            # exact byte identities classify scheduling only: every selected
            # packet/receipt and every received envelope is still verified.
            # A changed proof on the same signed body remains a new envelope.
            retained = {self.bft.state['messages'].content(i)
                        for i in self.bft.state['messages']}
            novel = [i for i in eligible if summaries[i]['kind'] == 'regional-bft'
                     and summaries[i]['export_id'] not in retained]
            novel_set = set(novel)
            background = [i for i in eligible if i not in novel_set]
            if novel and background:
                # Reserve half the unchanged batch for each class. Neither
                # untrusted novelty nor repeated history can starve the other.
                # Advance each class by its two-item stride per complete tick.
                offset = (self.progress['cursor'] // MAX_PER_TICK) * (MAX_PER_TICK // 2)
                def rotated(items):
                    start = offset % len(items)
                    return items[start:] + items[:start]
                count = min(len(novel), max(MAX_PER_TICK // 2,
                                           MAX_PER_TICK - len(background)))
                return rotated(novel)[:count] + rotated(background)[:MAX_PER_TICK-count]
        offset = self.progress['cursor'] % len(eligible)
        return (eligible[offset:] + eligible[:offset])[:MAX_PER_TICK]

    def tick(self):
        # Release the mesh lock before native replay/mining. Enqueue and receipt
        # tools can safely operate between bounded contact iterations.
        socket_observation = self.tcp.tick()
        received, routes, adverts = [], {}, {}
        errors = list(socket_observation['errors'])
        rejected = []
        with mesh.Node(self.config) as node:
            transport = node.tick()
            transport['tcp'] = socket_observation
            errors.extend(transport['errors'])
            summaries=node.summaries();receipts=node.receipts()
            selected = self.receive_candidates(summaries, receipts, node.id)
            if selected:
                for ident in selected:
                    try:
                        transit=node.transit(ident)
                        packet, raw, _ = mesh.transit_check(transit, node.network)
                        mesh.receipt_matches(receipts[ident], transit)
                        received.append((ident, raw))
                    except (OSError, ValueError) as error:
                        errors.append(str(error))
                        rejected.append({'packet_id': ident, 'reason': str(error)})
            adverts = {i: a['body']['region'] for i, a in node.state['adverts'].items()}
            routes = {i: node.route(i) for i in adverts if i != node.id}
        native_observation = None
        applied = []
        try:
            native_observation = self.native.call('contact-status')
            mesh.require(native_observation['currency'] == self.native.currency and native_observation['region'] == self.region,
                'fresh native identity differs from startup binding')
        except (OSError, ValueError, subprocess.TimeoutExpired) as error:
            errors.append(str(error))
        if native_observation is not None:
            accepted = {c['message_id'] for c in native_observation['contacts']
                if c['import_accepted'] or (self.miner is None and c['evidence_verified'])}
            for packet_id, raw in received:
                try:
                    frame, _ = wire.inspect_frame(raw)
                    if frame['kind']=='regional-bft':
                        if self.bft is not None:
                            self.bft.receive(raw)
                            self.bft_seen.add(packet_id)
                        continue
                    if frame['message_id'] not in accepted:
                        result = self.native.apply(raw, self.miner)
                        applied.append({'packet_id': packet_id, 'native': result})
                except (OSError, ValueError, subprocess.TimeoutExpired) as error:
                    errors.append(str(error))
                    rejected.append({'packet_id': packet_id, 'reason': str(error)})
            # Export authority is obtained from the actual native ledger. A
            # region advertised by a mesh key selects only a candidate carrier.
            try:
                outgoing = self.native.call('contact-outgoing')
                offers = outgoing['offers']
                if offers:
                    offset = self.progress['cursor'] % len(offers)
                    offers = (offers[offset:] + offers[:offset])[:MAX_PER_TICK]
                for offer in offers:
                    candidates = sorted(i for i, region in adverts.items() if region == offer['destination'] and routes.get(i))
                    if not candidates:
                        continue
                    value = self.native.call('contact-export', '--export', offer['export'])
                    raw = wire.canonical(value)
                    frame, _ = wire.inspect_frame(raw)
                    mesh.require(frame['source_chain_id'] == self.region and frame['destination_chain_id'] == offer['destination'], 'outgoing native route changed')
                    with mesh.Node(self.config) as node:
                        # Inspect retained packets to reconcile enqueue-after-
                        # crash, without a fragile external "already sent" flag.
                        retained = set()
                        for summary in node.summaries().values():
                            if summary['source'] == node.id:
                                retained.add((summary['frame_id'],summary['destination']))
                        # Rotate among reachable candidates; a dishonest label
                        # can delay delivery but cannot change the ledger target.
                        # The receive/offer cursor advances by MAX_PER_TICK.
                        # Using it directly can pin a four-node destination to
                        # one candidate forever. Rotate by complete tick count.
                        destination = candidates[(self.progress['cursor'] // MAX_PER_TICK) % len(candidates)]
                        if (frame['message_id'], destination) not in retained:
                            node.enqueue(raw, destination)
            except (OSError, ValueError, subprocess.TimeoutExpired) as error:
                errors.append(str(error))
            try:
                native_observation = self.native.call('contact-status')
            except (OSError, ValueError, subprocess.TimeoutExpired) as error:
                native_observation = None
                errors.append(str(error))
        consensus = None
        if self.bft is not None:
            try:
                consensus=self.bft.tick()
            except (OSError,ValueError,subprocess.TimeoutExpired) as error:
                errors.append(str(error))
                consensus={'autonomous_signing_enabled':not self.bft.failed,'progress_observation_available':False,
                           'diagnostic':str(error)[:256],'independent_bft_qualified':False}
        self.progress['cursor'] = (self.progress['cursor'] + MAX_PER_TICK) % (2**63)
        mesh.atomic(self.path, self.progress)
        report = {'format': FORMAT, 'process_id': os.getpid(), 'currency': self.native.currency, 'region': self.region,
            'relay_enabled': True, 'local_import_mining_enabled': self.miner is not None,
            'observed_at_unix': int(time.time()), 'transport': transport,
            'native_observation': native_observation, 'native_observation_available': native_observation is not None,
            'applied': applied, 'rejected': rejected, 'errors': errors[:16], 'fixture_only': True,
            'consensus': consensus,
            'physical_route_verified': False, 'independent_operators': False,
            'transport_receipt_is_payment_authority': False, 'remote_current_state_known': False}
        mesh.atomic(self.root / 'regional-contact-status.json', report)
        return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--ledger', type=Path, required=True)
    parser.add_argument('--authority', required=True)
    parser.add_argument('--currency', required=True)
    parser.add_argument('--mesh-config', type=Path)
    parser.add_argument('--bft-config', type=Path)
    parser.add_argument('--listen',default='127.0.0.1:0')
    parser.add_argument('--insecure-tcp',action='store_true')
    parser.add_argument('--miner')
    parser.add_argument('--interval', type=float, default=1)
    args = parser.parse_args()
    mesh.require(0.1 <= args.interval <= 3600, 'contact interval outside bound')
    native = Native(args.binary, args.ledger, args.authority, args.currency)
    config = startup_config(native, args.mesh_config)
    parts=args.listen.split(':')
    mesh.require(len(parts)==2 and parts[1].isdigit(), 'TCP listener must be literal IPv4:port')
    listen=mesh.tcp_endpoint(parts[0],int(parts[1]),listening=True)
    service = Service(native, config, args.miner,listen,args.insecure_tcp,args.bft_config)
    running = True
    def stop(*_):
        nonlocal running
        running = False
        service.tcp.running = False
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    previous = None
    try:
        while running:
            result = service.tick()
            # Only material changes print; the on-disk observation is refreshed.
            comparable = {k: v for k, v in result.items() if k != 'observed_at_unix'}
            comparable['transport'] = {k: v for k, v in result['transport'].items() if k != 'observed_at_unix'}
            if comparable != previous:
                print(json.dumps(result), flush=True)
                previous = comparable
            deadline = time.monotonic() + args.interval
            while running and time.monotonic() < deadline:
                time.sleep(min(0.1, args.interval))
    finally:
        service.close()


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        raise SystemExit('regional contact node rejected: ' + str(error))
