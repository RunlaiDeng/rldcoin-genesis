//! Immutable, content-addressed native storage. A page digest is not value
//! authority: reconstruct the exact journal, then execute native replay.
//! This first storage dialect preserves the bounded logical ledger limits.
use crate::{
    storage::{read_bytes, safe_dir, Event, Journal},
    *,
};
use std::{
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::Path,
};

pub const FORMAT: &str = "RLD-NATIVE-HISTORY-MANIFEST-V1";
const OBJECT: &str = "RLD-NATIVE-HISTORY-OBJECT-V1";
pub const PAGE_EVENTS: usize = 16;
pub const MAX_FILES: usize = 4096;
pub const MAX_ARCHIVE_BYTES: u64 = 256 * 1024 * 1024;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Reference {
    pub hash: Hash,
    pub bytes: usize,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Manifest {
    pub format: String,
    pub bootstrap: Bootstrap,
    pub region: Hash,
    pub journal: Hash,
    pub journal_bytes: usize,
    pub snapshots: Vec<Reference>,
    pub pages: Vec<Reference>,
    pub incident_ids: BTreeSet<Hash>,
    pub epochs: Vec<Reference>,
    pub contacts: Vec<(Hash, Reference)>,
}
impl Manifest {
    pub fn head(&self) -> Result<Hash> {
        id("native-history-head", self)
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Page {
    first_event: usize,
    height_before: u64,
    height_after: u64,
    previous: Hash,
    events: Vec<Event>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
enum Payload {
    Snapshot(Box<Snapshot>),
    Events(Page),
    Epoch(Box<epoch::Transition>),
    Contact(Box<contact::Record>),
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Object {
    format: String,
    currency: Hash,
    region: Hash,
    payload: Payload,
}
fn err(e: std::io::Error) -> String {
    e.to_string()
}
fn canonical<T: Serialize>(value: &T) -> Result<Vec<u8>> {
    let raw = serde_json::to_vec(value).map_err(|e| e.to_string())?;
    require(raw.len() <= MAX_BYTES, "native history object byte bound")?;
    Ok(raw)
}
fn decode<T: Serialize + serde::de::DeserializeOwned>(raw: &[u8]) -> Result<T> {
    let value: T = serde_json::from_slice(raw).map_err(|e| e.to_string())?;
    require(
        canonical(&value)? == raw,
        "noncanonical native history bytes",
    )?;
    Ok(value)
}
fn validate_file(path: &Path) -> Result<()> {
    let meta = fs::symlink_metadata(path).map_err(err)?;
    require(
        meta.is_file() && !meta.file_type().is_symlink(),
        "unsafe native history file",
    )?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        require(
            meta.nlink() == 1
                && meta.uid() == unsafe { libc::geteuid() }
                && meta.mode() & 0o077 == 0,
            "native history file ownership, links or permissions",
        )?;
    }
    Ok(())
}
fn archive_usage(dir: &Path) -> Result<(usize, u64)> {
    safe_dir(dir)?;
    let mut count = 0usize;
    let mut bytes = 0u64;
    for entry in fs::read_dir(dir).map_err(err)? {
        let path = entry.map_err(err)?.path();
        let name = path
            .file_name()
            .and_then(|n| n.to_str())
            .ok_or("history filename encoding")?;
        require(
            name.len() == 69
                && name.ends_with(".json")
                && name.as_bytes()[..64]
                    .iter()
                    .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(b)),
            "unexpected native history archive entry",
        )?;
        validate_file(&path)?;
        let length = fs::symlink_metadata(&path).map_err(err)?.len();
        require(
            length <= MAX_BYTES as u64,
            "archived native history object byte bound",
        )?;
        count = count.checked_add(1).ok_or("history file count overflow")?;
        bytes = bytes
            .checked_add(length)
            .ok_or("history byte count overflow")?;
        require(
            count <= MAX_FILES && bytes <= MAX_ARCHIVE_BYTES,
            "native history archive capacity",
        )?;
    }
    Ok((count, bytes))
}
fn retained_file(path: &Path) -> Result<File> {
    validate_file(path)?;
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK);
    }
    let file = options.open(path).map_err(err)?;
    let meta = file.metadata().map_err(err)?;
    require(
        meta.is_file() && meta.len() <= MAX_BYTES as u64,
        "native history opened file type or bound",
    )?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        require(
            meta.nlink() == 1
                && meta.uid() == unsafe { libc::geteuid() }
                && meta.mode() & 0o077 == 0,
            "native history opened ownership, links or permissions",
        )?;
    }
    Ok(file)
}
fn retained_read(path: &Path) -> Result<Vec<u8>> {
    let mut bytes = Vec::new();
    retained_file(path)?
        .take(MAX_BYTES as u64 + 1)
        .read_to_end(&mut bytes)
        .map_err(err)?;
    require(
        bytes.len() <= MAX_BYTES,
        "native history file grew beyond bound",
    )?;
    Ok(bytes)
}
fn reference(object: &Object) -> Result<(Reference, Vec<u8>)> {
    let raw = canonical(object)?;
    Ok((
        Reference {
            hash: id("native-history-object", object)?,
            bytes: raw.len(),
        },
        raw,
    ))
}
/// Encode objects first. Unreferenced residue is retained, never adopted, deleted
/// or overwritten to get a passing head. An existing object must match exactly
/// and is fsynced again before any manifest acknowledgment.
pub(crate) fn prepare(dir: &Path, journal: &Journal) -> Result<Vec<u8>> {
    let logical = canonical(journal)?;
    let archive = dir.join("history");
    let (mut files, mut total) = archive_usage(&archive)?;
    let currency = journal.bootstrap.currency.id()?;
    let mut objects: BTreeMap<Hash, Vec<u8>> = BTreeMap::new();
    let mut retain = |payload| -> Result<Reference> {
        let object = Object {
            format: OBJECT.into(),
            currency,
            region: journal.region,
            payload,
        };
        let (reference, raw) = reference(&object)?;
        if let Some(old) = objects.insert(reference.hash, raw.clone()) {
            require(old == raw, "native history hash collision")?;
        }
        Ok(reference)
    };
    let mut manifest = Manifest {
        format: FORMAT.into(),
        bootstrap: journal.bootstrap.clone(),
        region: journal.region,
        journal: id("journal", journal)?,
        journal_bytes: logical.len(),
        snapshots: vec![],
        pages: vec![],
        incident_ids: journal.incident_ids.clone(),
        epochs: vec![],
        contacts: vec![],
    };
    for snapshot in &journal.evidence.snapshots {
        manifest
            .snapshots
            .push(retain(Payload::Snapshot(Box::new(snapshot.clone())))?);
    }
    let mut height = 0u64;
    let mut previous = Hash::ZERO;
    for (index, events) in journal.events.chunks(PAGE_EVENTS).enumerate() {
        let before = height;
        for event in events {
            if let Event::Block(block) = event {
                require(
                    block.header.height
                        == height.checked_add(1).ok_or("history height overflow")?,
                    "native history page height sequence",
                )?;
                height = block.header.height;
            }
        }
        let page = Page {
            first_event: index * PAGE_EVENTS,
            height_before: before,
            height_after: height,
            previous,
            events: events.to_vec(),
        };
        let reference = retain(Payload::Events(page))?;
        previous = reference.hash;
        manifest.pages.push(reference);
    }
    for proof in &journal.epoch_proofs {
        manifest
            .epochs
            .push(retain(Payload::Epoch(Box::new(proof.clone())))?);
    }
    for (key, record) in &journal.contact_records {
        manifest
            .contacts
            .push((*key, retain(Payload::Contact(Box::new(record.clone())))?));
    }
    let raw = canonical(&manifest)?;
    // Preflight all archive admission before writing any new object. Actual I/O
    // failure may still leave unaccepted residue; no manifest is published then.
    for (hash, bytes) in &objects {
        let path = archive.join(format!("{}.json", hash.to_hex()));
        if fs::symlink_metadata(&path).is_ok() {
            require(
                retained_read(&path)? == *bytes,
                "retained native history bytes differ",
            )?;
        } else {
            files = files.checked_add(1).ok_or("history count overflow")?;
            total = total
                .checked_add(bytes.len() as u64)
                .ok_or("history bytes overflow")?;
            require(
                files <= MAX_FILES && total <= MAX_ARCHIVE_BYTES,
                "native history archive capacity",
            )?;
        }
    }
    for (hash, bytes) in objects {
        let path = archive.join(format!("{}.json", hash.to_hex()));
        if fs::symlink_metadata(&path).is_ok() {
            require(
                retained_read(&path)? == bytes,
                "retained native history bytes differ",
            )?;
            retained_file(&path)?.sync_all().map_err(err)?;
        } else {
            let mut options = OpenOptions::new();
            options.write(true).create_new(true);
            #[cfg(unix)]
            {
                use std::os::unix::fs::OpenOptionsExt;
                options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
            }
            let mut file = options.open(&path).map_err(err)?;
            file.write_all(&bytes).map_err(err)?;
            file.sync_all().map_err(err)?;
        }
    }
    File::open(&archive).map_err(err)?.sync_all().map_err(err)?;
    Ok(raw)
}
fn object(dir: &Path, m: &Manifest, reference: &Reference) -> Result<Payload> {
    require(
        reference.bytes > 0 && reference.bytes <= MAX_BYTES,
        "native history reference byte bound",
    )?;
    let raw = retained_read(
        &dir.join("history")
            .join(format!("{}.json", reference.hash.to_hex())),
    )?;
    require(
        raw.len() == reference.bytes,
        "native history reference size mismatch",
    )?;
    let object: Object = decode(&raw)?;
    require(
        object.format == OBJECT
            && object.currency == m.bootstrap.currency.id()?
            && object.region == m.region
            && id("native-history-object", &object)? == reference.hash,
        "native history object scope or digest mismatch",
    )?;
    Ok(object.payload)
}
pub fn manifest(dir: &Path) -> Result<Manifest> {
    safe_dir(dir)?;
    let m: Manifest = decode(&read_bytes(&dir.join("journal.json"), MAX_BYTES)?)?;
    require(
        m.format == FORMAT && m.journal_bytes > 0 && m.journal_bytes <= MAX_BYTES,
        "native history manifest format or logical bound",
    )?;
    require(
        m.snapshots.len() <= MAX_SNAPSHOTS
            && m.epochs.len() <= epoch::MAX_EPOCHS
            && m.contacts.len() <= contact::MAX_CONTACTS
            && m.incident_ids.len() <= conflict::MAX_INCIDENTS
            && m.pages.len()
                <= (MAX_BLOCKS + MAX_SNAPSHOTS + epoch::MAX_EPOCHS).div_ceil(PAGE_EVENTS),
        "native history manifest reference bounds",
    )?;
    archive_usage(&dir.join("history"))?;
    Ok(m)
}
/// Reconstruct bytes; caller must still replay native rules. No manifest or
/// content hash replaces currency, finality, owner or permanent-import checks.
pub fn read_journal(dir: &Path) -> Result<Journal> {
    let m = manifest(dir)?;
    let mut journal = Journal {
        bootstrap: m.bootstrap.clone(),
        region: m.region,
        evidence: Evidence::default(),
        events: vec![],
        incident_ids: m.incident_ids.clone(),
        epoch_proofs: vec![],
        contact_records: BTreeMap::new(),
    };
    // Cumulative serialized payload admission bounds allocation before decoding
    // objects. The immutable archive itself may contain old and orphan objects.
    let refs = m
        .snapshots
        .iter()
        .chain(m.pages.iter())
        .chain(m.epochs.iter())
        .chain(m.contacts.iter().map(|(_, r)| r));
    let mut referenced_bytes = 0usize;
    for r in refs {
        referenced_bytes = referenced_bytes
            .checked_add(r.bytes)
            .ok_or("history reference total overflow")?;
        // Object wrappers add bounded metadata above the original logical bytes.
        require(
            referenced_bytes <= MAX_BYTES + MAX_FILES * 512,
            "native history reconstruction byte bound",
        )?;
    }
    for r in &m.snapshots {
        match object(dir, &m, r)? {
            Payload::Snapshot(s) => journal.evidence.snapshots.push(*s),
            _ => return Err("native history snapshot reference type".into()),
        }
    }
    let mut height = 0u64;
    let mut previous = Hash::ZERO;
    for (i, r) in m.pages.iter().enumerate() {
        let page = match object(dir, &m, r)? {
            Payload::Events(p) => p,
            _ => return Err("native history event reference type".into()),
        };
        require(
            page.previous == previous
                && page.first_event == journal.events.len()
                && page.height_before == height
                && !page.events.is_empty()
                && page.events.len() <= PAGE_EVENTS
                && (i + 1 == m.pages.len() || page.events.len() == PAGE_EVENTS),
            "native history page order, parent or range",
        )?;
        for event in &page.events {
            if let Event::Block(block) = event {
                require(
                    block.header.height
                        == height.checked_add(1).ok_or("history height overflow")?,
                    "native history reconstructed height sequence",
                )?;
                height = block.header.height;
            }
        }
        require(
            page.height_after == height,
            "native history page ending height",
        )?;
        journal.events.extend(page.events);
        previous = r.hash;
    }
    for r in &m.epochs {
        match object(dir, &m, r)? {
            Payload::Epoch(p) => journal.epoch_proofs.push(*p),
            _ => return Err("native history epoch reference type".into()),
        }
    }
    let mut previous_contact = None;
    for (key, r) in &m.contacts {
        require(
            previous_contact.is_none_or(|old| old < *key),
            "native history contact order",
        )?;
        match object(dir, &m, r)? {
            Payload::Contact(p) if p.message_id == *key => {
                journal.contact_records.insert(*key, *p);
            }
            _ => return Err("native history contact reference type or identity".into()),
        }
        previous_contact = Some(*key);
    }
    let raw = canonical(&journal)?;
    require(
        raw.len() == m.journal_bytes && id("journal", &journal)? == m.journal,
        "native history reconstructed journal commitment",
    )?;
    Ok(journal)
}
#[cfg(test)]
#[path = "history_tests.rs"]
mod tests;
